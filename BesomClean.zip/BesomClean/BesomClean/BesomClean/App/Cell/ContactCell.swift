import UIKit
import SnapKit
import RxSwift
import RxCocoa
import Contacts
import BEMCheckBox

enum MaskedCorners {
    case top, bottom, both
    
    var corners: CACornerMask {
        switch self {
        case .top:
            return [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        case .bottom:
            return [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        case .both:
            return [.layerMinXMinYCorner, .layerMaxXMinYCorner, .layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        }
    }
}

enum EditMode {
    case on, off
}

class ContactCell: UICollectionViewCell {
    static var identifier: String = "ContactCell"
    
    override var isSelected: Bool {
        didSet {
            if oldValue == isSelected { return }
            checkBox.setOn(isSelected, animated: true)
        }
    }
    
    private lazy var containerView: UIView! = {
        let view = UIView()
        view.backgroundColor = "232940".hexColor
        view.layer.cornerRadius = 16
        return view
    }()
    
    private lazy var checkBox: BEMCheckBox! = {
        let box = BEMCheckBox()
        box.boxType = .circle
        box.onAnimationType = .fill
        box.offAnimationType = .fill
        box.onFillColor = box.onTintColor
        box.onCheckColor = .white
        box.isUserInteractionEnabled = false
        return box
    }()
    
    private lazy var photoView: UIImageView! = {
        let imageView = UIImageView(image: UIImage(named: "ic_placeholder"))
        return imageView
    }()
    
    private lazy var nameLabel: UILabel! = {
        let label = UILabel()
        label.textColor = .black
        label.font = UIFont.systemFont(ofSize: 17, weight: .medium)
        label.textAlignment = .left
        return label
    }()
    
    var contact: CNContact! {
        didSet {
            if contact.isNil { return }
            if contact.imageDataAvailable, let imageData = contact.thumbnailImageData {
                photoView.image = UIImage(data: imageData)
            } else {
                photoView.image = UIImage(named: "ic_placeholder")
            }
            nameLabel.text = CNContactFormatter.string(from: contact, style: .fullName)
        }
    }
    
    var maskedCorners: MaskedCorners! {
        didSet {
            if maskedCorners.isNil {
                containerView.layer.maskedCorners = []
            } else {
                containerView.layer.maskedCorners = maskedCorners.corners
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }
}

extension ContactCell {
    private func commonInit() {
        addSubviews(checkBox, containerView)
        containerView.addSubviews(photoView, nameLabel)
        
        checkBox.snp.makeConstraints {
            $0.centerY.equalToSuperview()
            $0.leading.equalToSuperview().offset(-7)
            $0.size.equalTo(24)
        }
        
        containerView.snp.makeConstraints {
            $0.leading.equalToSuperview().offset(0)
            $0.top.equalToSuperview()
            $0.width.equalToSuperview()
            $0.bottom.equalToSuperview()
        }
        
        photoView.snp.makeConstraints {
            $0.centerY.equalToSuperview()
            $0.leading.equalToSuperview().offset(20)
            $0.size.equalTo(44)
            
            photoView.layer.cornerRadius = 44 / 2
            photoView.clipsToBounds = true
        }
        
        nameLabel.snp.makeConstraints {
            $0.leading.equalTo(photoView.snp.trailing).offset(10)
            $0.centerY.equalTo(photoView)
            $0.trailing.equalToSuperview().inset(20)
        }
    }
    
    func edit(_ value: Bool, animated: Bool = true) {
        UIView.animate(withDuration: animated ? 0.2 : 0.0) { [weak self] in
            self?.containerView.transform = CGAffineTransform(translationX: value ? 30 : 0, y: 0)
            self?.checkBox.alpha = value ? 1 : 0
        }
    }
}

