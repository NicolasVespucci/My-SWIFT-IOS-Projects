import UIKit

class MenuCell: UITableViewCell {
    
    var menuModel: MenuModel? {
        didSet { configureMenu() }
    }
    
    private lazy var fullView: UIView = {
        let view = UIView()
        view.backgroundColor = "84B6F3".hexColor
        view.layer.cornerRadius = 12
        return view
    }()
    
    private lazy var settingsImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    private lazy var nameLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .semibold)
        label.textColor = .white
        label.textAlignment = .left
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        backgroundColor = .clear
        setup()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setup() {
        configureLayout()
    }
    
    private func configureLayout() {
        addSubview(fullView)
        fullView.addSubviews(settingsImageView, nameLabel)
        
        fullView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(56)
        }
        
        settingsImageView.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(16)
            make.centerY.equalToSuperview()
            make.size.equalTo(24)
        }
        
        nameLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalTo(settingsImageView.snp.trailing).offset(12)
            make.height.equalTo(24)
        }
    }
    
    private func configureMenu() {
        guard let menu = menuModel else { return }
        nameLabel.text = menu.title
        settingsImageView.image = menu.image?.image
    }
}
