import UIKit
import SwiftyAttributes
import RxSwift

class OptionsCell: UITableViewCell {
    
    var optionsCellModel: OptionsModel? {
        didSet { configureOptionsModel() }
    }
    
    var completion2: (()->())? = nil
    
    private lazy var cellView: UIView = {
        let view = UIView()
        view.layer.masksToBounds = true
        view.backgroundColor = "2E8DFF".hexColor.withAlphaComponent(0.7)
        view.layer.cornerRadius = 12
        let blurEffect = UIBlurEffect(style: UIBlurEffect.Style.systemUltraThinMaterialLight)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = view.bounds
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        blurEffectView.layer.cornerRadius = 12
        view.layer.cornerRadius = 12
        view.addSubview(blurEffectView)
        return view
    }()
    
    private lazy var optionsImageView: UIImageView = {
        let imageView = UIImageView(image: "".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private lazy var optionsNameLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.adjustsFontSizeToFitWidth = true
        label.textColor = .white
        label.textAlignment = .left
        label.numberOfLines = 2
        return label
    }()
    
    private lazy var descriptionNameLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 12, weight: .regular)
        label.adjustsFontSizeToFitWidth = true
        label.textColor = .white.withAlphaComponent(0.65)
        label.textAlignment = .left
        label.numberOfLines = 2
        return label
    }()
    
    public var optionsButton: UIButton = {
        let button = UIButton()
        button.setTitle("", for: .normal)
        button.layer.cornerRadius = 16
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 12, weight: .medium)
        return button
    }()
    
    let disposeBag = DisposeBag()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        selectionStyle = .none
//        configureLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureLayout() {
        addSubview(cellView)
        cellView.addSubviews(optionsImageView, optionsNameLabel, descriptionNameLabel, optionsButton)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(136)
        }
        
        optionsImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(16)
            make.leading.equalToSuperview().offset(16)
            make.size.equalTo(40.resized())
        }
        
        optionsNameLabel.snp.makeConstraints { make in
            make.top.equalTo(optionsImageView.snp.top)
            make.leading.equalTo(optionsImageView.snp.trailing).offset(16)
            make.height.equalTo(48)
        }
        
        descriptionNameLabel.snp.makeConstraints { make in
            make.top.equalTo(optionsNameLabel.snp.bottom).offset(16)
            make.leading.equalToSuperview().offset(16)
            make.trailing.equalToSuperview().offset(-16)
            make.height.equalTo(40)
        }
        
        optionsButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-16)
            make.height.equalTo(32)
            make.width.equalTo(optionsButton.currentTitle!.width(constrainedBy: 100, with: .systemFont(ofSize: 12, weight: .medium)) + 16)
        }
        
        layoutIfNeeded()
        optionsButton.addGradient(.leftRight,["1C83FC".hexColor, "445BBB".hexColor], 16)
    }
    
    private func configureOptionsModel() {
        guard let optionsCellModel = optionsCellModel else { return }
        optionsImageView.image = optionsCellModel.image?.image
        optionsNameLabel.text = optionsCellModel.nameOptions
        descriptionNameLabel.text = optionsCellModel.descriptionOptions
        optionsButton.setTitle(optionsCellModel.nameButton, for: .normal)
        configureLayout()
    }
}

