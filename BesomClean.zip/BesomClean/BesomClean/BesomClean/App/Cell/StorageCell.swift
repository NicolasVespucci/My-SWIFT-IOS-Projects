import UIKit

class StorageCell: UICollectionViewCell {
    
    enum CellStyle2{
        case asset(UIImage?)
        case contact(Contact)
    }
    
    var StorageModel: Storage? {
        didSet { configureStorage() }
    }
    
    private var fullImageView: UIImageView = {
        let imageView = UIImageView(image: "".image)
        imageView.layer.cornerRadius = 10
        imageView.clipsToBounds = true
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    public var cellStyle2: CellStyle2! {
        didSet {
            switch cellStyle2 {
            case .asset(let image)?:
                addSubview(fullImageView)
                
                fullImageView.snp.makeConstraints { make in
                    make.center.equalToSuperview()
                    make.size.equalTo(100)
                }
                fullImageView.image = image
            case .contact(_), .none:
                break
            }
        }
    }
    
    public var setSelected2: Bool! = false {
        didSet{
            print("CHeckBox")
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        configureLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureLayout() {
        addSubview(fullImageView)
        
        fullImageView.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.size.equalTo(100)
        }
    }
    
    private func configureStorage() {
        guard let storage = StorageModel else { return }
        fullImageView.image = storage.image?.image
    }
    
    weak var parent: StorageViewController?
}
