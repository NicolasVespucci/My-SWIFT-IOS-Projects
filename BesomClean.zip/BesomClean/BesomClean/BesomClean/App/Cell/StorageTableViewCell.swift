import RxSwift
import RxCocoa
import Photos
import UIKit
import SnapKit
import IHProgressHUD

class StorageTableViewCell: UITableViewCell {
    
    // MARK: - Duplicates Photo Section
    
    var storageTableViewModel: StorageTableViewModel? {
        didSet { configureOptionsModel() }
    }
    
    private var duplicatesLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .bold)
        label.textColor = "454D6A".hexColor
        label.text = ""
        label.textAlignment = .left
        return label
    }()
    
    private var volumeLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 18, weight: .regular)
        label.textColor = "#707070".hexColor.withAlphaComponent(0.4)
        label.text = ""
        label.textAlignment = .left
        return label
    }()
    
    private lazy var duplicatesPhotoCollectionView: UICollectionView = {
        let collection = UICollectionView(frame: .zero, collectionViewLayout: .init())
        collection.backgroundColor = .clear
        collection.showsHorizontalScrollIndicator = false
        collection.showsVerticalScrollIndicator = false
        collection.clipsToBounds = false
        return collection
    }()
    
    private lazy var duplicatesPhotoLayout: UICollectionViewLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = .init(width: 100, height: 100)
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 8
        layout.scrollDirection = .horizontal
        layout.sectionInset = .init(top: 0, left: 8, bottom: 0, right: 0)
        return layout
    }()
    
    private var libraryManager: LibraryMediaManager! {
        return LibraryMediaManager.shared
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        selectionStyle = .none
        configureLayout()
        duplicateCollection()
    }
        
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureLayout() {
        contentView.addSubviews(duplicatesLabel, volumeLabel, duplicatesPhotoCollectionView)
        
        duplicatesLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(32)
            make.leading.equalToSuperview().offset(24)
            make.height.equalTo(24)
        }
        
        volumeLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(38)
            make.leading.equalTo(duplicatesLabel.snp.trailing).offset(8)
            make.height.equalTo(18)
        }
        
        duplicatesPhotoCollectionView.snp.makeConstraints { make in
            make.top.equalTo(duplicatesLabel.snp.bottom).offset(16)
            make.trailing.equalToSuperview()
            make.leading.equalToSuperview()
            make.height.equalTo(100)
        }
    }
    
    private func duplicateCollection() {
        duplicatesPhotoCollectionView.setCollectionViewLayout(duplicatesPhotoLayout, animated: true)
        duplicatesPhotoCollectionView.dataSource = self
        duplicatesPhotoCollectionView.delegate = self
        duplicatesPhotoCollectionView.register(StorageCell.self, forCellWithReuseIdentifier: StorageCell.nibIdentifier)
    }
    
    convenience init(_ photoDetail: PhotoOptions?) {
        self.init()
    }
    
    //MARK: - setup Photo and Video
    
    deinit {
        print(self, #function)
    }
    
    var currentAccets = [PHAsset]()
    
    private func configureOptionsModel() {
        guard let storageTableViewModel = storageTableViewModel else { return }
        duplicatesLabel.text = storageTableViewModel.nameSections
        currentAccets = storageTableViewModel.sectionsImageArray!
        volumeLabel.text = storageTableViewModel.volumeStorage
        duplicatesPhotoCollectionView.reloadData()
    }
    
    weak var parent: StorageViewController?
}

extension StorageTableViewCell: UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return currentAccets.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "StorageCell", for: indexPath) as? StorageCell else { return UICollectionViewCell() }
        
        let image = currentAccets[indexPath.item].thumbnailSync
        cell.cellStyle2 = .asset(image)
        cell.parent = parent
        return cell
    }
}

extension StorageTableViewCell: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        switch  duplicatesLabel.text {
        case NSLocalizedString("Duplicates", comment: ""):
            IHProgressHUD.show()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                let selectedOption = PhotoOptions.similar
                let vc = AssetsScreen(selectedOption)
                self.parent?.navigationController?.pushViewController(vc, animated: false)
            }
        case NSLocalizedString("Screenshots", comment: ""):
            if IAPManager.shared().isPurchased {
                IHProgressHUD.show()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    let selectedOption = PhotoOptions.screens
                    let vc = AssetsScreen(selectedOption)
                    self.parent?.navigationController?.pushViewController(vc, animated: false)
                }
            } else {
                Constants.ud.currentDismissing = 2
                Constants.ud.currentRestoreDismissing = 2
                IAPManager.shared().presentSingleSubscriptionVC(animated: true)
               
                IAPManager.shared().purchaseCompletion = { _ in
                    IAPManager.shared().dismissSubscriptionVC()
                }
                IAPManager.shared().restoreCompletion = { subscription in
                    IAPManager.shared().dismissSubscriptionVC()
                    if Constants.ud.isPurchased {
                        AlertManager.shared().showPurchasesWereRestored()
                    }
                }
            }
        case NSLocalizedString("Live Photo", comment: ""):
            if IAPManager.shared().isPurchased {
                IHProgressHUD.show()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    let selectedOption = PhotoOptions.live
                    let vc = AssetsScreen(selectedOption)
                    self.parent?.navigationController?.pushViewController(vc, animated: true)
                }
              
            } else {
                Constants.ud.currentDismissing = 2
                Constants.ud.currentRestoreDismissing = 2
                IAPManager.shared().presentSingleSubscriptionVC(animated: true)
               
                IAPManager.shared().purchaseCompletion = { _ in
                    IAPManager.shared().dismissSubscriptionVC()
                }
                IAPManager.shared().restoreCompletion = { subscription in
                    IAPManager.shared().dismissSubscriptionVC()
                    if Constants.ud.isPurchased {
                        AlertManager.shared().showPurchasesWereRestored()
                    }
                }
            }
        case NSLocalizedString("Burst Photo", comment: ""):
            if IAPManager.shared().isPurchased {
                IHProgressHUD.show()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    let selectedOption = PhotoOptions.burst
                    let vc = AssetsScreen(selectedOption)
                    self.parent?.navigationController?.pushViewController(vc, animated: true)
                }
            } else {
                Constants.ud.currentDismissing = 2
                Constants.ud.currentRestoreDismissing = 2
                IAPManager.shared().presentSingleSubscriptionVC(animated: true)
               
                IAPManager.shared().purchaseCompletion = { _ in
                    IAPManager.shared().dismissSubscriptionVC()
                }
                IAPManager.shared().restoreCompletion = { subscription in
                    IAPManager.shared().dismissSubscriptionVC()
                    if Constants.ud.isPurchased {
                        AlertManager.shared().showPurchasesWereRestored()
                    }
                }
            }
        case NSLocalizedString("Video", comment: ""):
            if IAPManager.shared().isPurchased {
                IHProgressHUD.show()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    let vc = AssetsScreen(nil)
                    self.parent?.navigationController?.pushViewController(vc, animated: true)
                }
             
            } else {
                Constants.ud.currentDismissing = 2
                Constants.ud.currentRestoreDismissing = 2
                IAPManager.shared().presentSingleSubscriptionVC(animated: true)
               
                IAPManager.shared().purchaseCompletion = { _ in
                    IAPManager.shared().dismissSubscriptionVC()
                }
                IAPManager.shared().restoreCompletion = { subscription in
                    IAPManager.shared().dismissSubscriptionVC()
                    if Constants.ud.isPurchased {
                        AlertManager.shared().showPurchasesWereRestored()
                    }
                }
            }
        default:
            break
        }
    }
}
