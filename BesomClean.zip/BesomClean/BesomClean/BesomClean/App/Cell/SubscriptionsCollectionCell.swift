import UIKit
import StoreKit

class SubscriptionsCollectionCell: UICollectionViewCell {
    
    private lazy var cellView: UIView = {
        let cell = UIView()
        cell.layer.cornerRadius = 8
        cell.backgroundColor = .clear
        cell.clipsToBounds = false
        return cell
    }()
    
    private lazy var periodLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .semibold)
        label.textColor = "02008C".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .center
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private lazy var priceLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .bold)
        label.textColor = "8B68DF".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .center
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private lazy var freeTrialLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 8, weight: .bold)
        label.textColor = .black
        label.text = NSLocalizedString("FREE TRIAL", comment: "").uppercased()
        label.backgroundColor = "00FFA3".hexColor
        label.layer.cornerRadius = 4
        label.textAlignment = .center
        label.numberOfLines = 0
        label.layer.masksToBounds = true
        return label
    }()
    
    var product: Product?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func configureTrialLayout() {
        
        cellView.subviews.forEach({ make in
            make.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            make.removeBorders()
            make.removeFromSuperview()
        })
        
        subviews.forEach({ make in
            make.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            make.removeBorders()
            make.removeFromSuperview()
        })
        
        clipsToBounds = false
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubviews(freeTrialLabel, periodLabel, priceLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        freeTrialLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(8)
            make.leading.equalToSuperview().offset(8)
            make.trailing.equalToSuperview().offset(-8)
            make.height.equalTo(20)
        }
        
        periodLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(38.resized())
            make.height.equalTo(16)
        }
        
        priceLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview().offset(-38.resized())
            make.height.equalTo(16)
        }
        
        cellView.addBorder(width: 1, color: "#454D6A")
        freeTrialLabel.layer.cornerRadius = 4
        freeTrialLabel.backgroundColor = .black.withAlphaComponent(0.04)
        freeTrialLabel.textColor = .black
        priceLabel.textColor = "454D6A".hexColor
        periodLabel.textColor = "2579EC".hexColor
        priceLabel.text = price
        periodLabel.text = perPeriodString
        cellView.backgroundColor = .clear
        layoutIfNeeded()
        layoutSubviews()
    }
    
    public func configureCommonLayout() {
        cellView.subviews.forEach({ make in
            make.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            make.removeBorders()
            make.removeFromSuperview()
        })
        
        subviews.forEach({ make in
            make.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            make.removeBorders()
            make.removeFromSuperview()
        })
        
        clipsToBounds = false
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubviews(periodLabel, priceLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        periodLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(38.resized())
            make.height.equalTo(16)
        }
        
        priceLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview().offset(-38.resized())
            make.height.equalTo(16)
        }
        
        cellView.layer.masksToBounds = true
        cellView.addBorder(width: 1, color: "454D6A")
        priceLabel.textColor = "454D6A".hexColor
        periodLabel.textColor = "2579EC".hexColor
        priceLabel.text = price
        periodLabel.text = perPeriodString
        cellView.backgroundColor = .clear
        layoutIfNeeded()
        layoutSubviews()
    }
    
    public func configureTrialSelectedLayout() {
        
        cellView.subviews.forEach({ make in
            make.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            make.removeBorders()
            make.removeFromSuperview()
        })
        
        subviews.forEach({ make in
            make.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            make.removeBorders()
            make.removeFromSuperview()
        })
        
        clipsToBounds = false
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString.capitalized // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubviews(freeTrialLabel, periodLabel, priceLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        freeTrialLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(8)
            make.leading.equalToSuperview().offset(8)
            make.trailing.equalToSuperview().offset(-8)
            make.height.equalTo(20)
        }
        
        periodLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(38.resized())
            make.height.equalTo(16)
        }
        
        priceLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview().offset(-38.resized())
            make.height.equalTo(16)
        }
        
        priceLabel.tintColor = "FE02A8".hexColor
        freeTrialLabel.layer.cornerRadius = 4
        freeTrialLabel.backgroundColor = .black.withAlphaComponent(0.14)
        freeTrialLabel.textColor = .white
        priceLabel.text = price
        periodLabel.text = perPeriodString
        priceLabel.textColor = .white
        periodLabel.textColor = .white
        layoutIfNeeded()
        cellView.addGradient(.topLeftBottomRight,["90C2FF".hexColor, "86BDFF".hexColor], 8)
        layoutSubviews()
    }
    
    public func configureCommonSelectedLayout() {
        
        cellView.subviews.forEach({ make in
            make.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            make.removeBorders()
            make.removeFromSuperview()
        })
        
        subviews.forEach({ make in
            make.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            make.removeBorders()
            make.removeFromSuperview()
        })
        
        clipsToBounds = false
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubviews(periodLabel, priceLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        periodLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(38.resized())
            make.height.equalTo(16)
        }
        
        priceLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview().offset(-38.resized())
            make.height.equalTo(16)
        }
        
        priceLabel.textColor = .white
        periodLabel.textColor = .white
        priceLabel.text = price
        periodLabel.text = perPeriodString
        layoutIfNeeded()
        cellView.addGradient(.topLeftBottomRight,["90C2FF".hexColor, "86BDFF".hexColor], 8)
        layoutSubviews()
    }
}
