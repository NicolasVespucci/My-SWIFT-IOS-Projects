import Foundation

struct AdvantagesModel {
    var title: String?
}
