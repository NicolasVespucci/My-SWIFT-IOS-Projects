import Foundation
import UIKit

struct OptionsModel {
    var image: String?
    var nameOptions: String?
    var descriptionOptions: String?
    var nameButton: String?
}
