import Foundation

struct Storage {
    var image: String?
}
