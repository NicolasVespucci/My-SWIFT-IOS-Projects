import Foundation
import UIKit
import Photos
struct StorageTableViewModel {
    var nameSections: String?
    var sectionsImageArray: [PHAsset]?
    var volumeStorage: String?
}
