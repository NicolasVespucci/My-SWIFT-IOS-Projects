import UIKit

class PresentScrollView: UIView {

    var image: UIImage?
    var topText: String?
    var bottomText: String?
    
    private lazy var centerImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    private lazy var firstLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 32, weight: .heavy)
        label.textColor = "1C83FC".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .center
        return label
    }()
    
    private lazy var secondLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15, weight: .medium)
        label.textColor = "464D6A".hexColor.withAlphaComponent(0.7)
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    
    init(image: UIImage, topText: String, bottomText: String) {
        super.init(frame: .zero)
        self.image = image
        self.topText = topText
        self.bottomText = bottomText
        isUserInteractionEnabled = true
        launch()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func launch() {
        configureLayout()
        configureViewContent()
    }
    
    private func configureLayout() {
        addSubviews(centerImageView, firstLabel, secondLabel)
        
        centerImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.centerX.equalToSuperview()
            make.width.equalTo(299)
            make.height.equalTo(164)
        }
    
        firstLabel.snp.makeConstraints { make in
            make.top.equalTo(centerImageView.snp.bottom).offset(32.resized())
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(40)
        }
        
        secondLabel.snp.makeConstraints { make in
            make.top.equalTo(firstLabel.snp.bottom).offset(16.resized())
            make.leading.equalToSuperview().offset(38)
            make.trailing.equalToSuperview().offset(-38)
            make.height.equalTo(65)
        }
    }
    
    private func configureViewContent() {
        centerImageView.image = image
        firstLabel.text = topText
        secondLabel.text = bottomText
    }
}
