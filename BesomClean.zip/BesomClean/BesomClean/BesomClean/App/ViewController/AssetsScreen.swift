import UIKit
import BEMCheckBox

//MARK: - CELL

final class AssetCell: UICollectionViewCell {
    
    enum CellStyle{
        case asset(UIImage?)
        case contact(Contact)
    }
    
    private lazy var checkBox: UIImageView! = {
        let box = UIImageView()
        box.contentMode = .scaleAspectFit
        return box
    }()
    
    private lazy var assetThumbImage: UIImageView! = {
        let iv = UIImageView(frame: .zero)
        iv.layer.cornerRadius = 10
        iv.clipsToBounds = true
        return iv
    }()
    
    private lazy var contactName: UILabel! = {
        let label = UILabel()
        label.textColor = .black
        label.font = .systemFont(ofSize: 17, weight: .medium)
        return label
    }()
    
    public var cellStyle: CellStyle! {
        didSet {
            switch cellStyle {
            case .asset(let image)?:
                assetThumbImage.image = image
                assetThumbImage.contentMode = .scaleAspectFill
            case .contact(_), .none:
                break
            }
        }
    }
    
    public func configureDefaultLayout() {
        backgroundColor = .clear
        subviews.forEach({ $0.removeFromSuperview() })
        addSubviews(assetThumbImage, checkBox)
        
        assetThumbImage.snp.makeConstraints { make in
            make.size.equalToSuperview()
            make.center.equalToSuperview()
        }
        checkBox.snp.makeConstraints { make in
            make.size.equalTo(20)
            make.bottom.equalToSuperview().offset(-5)
            make.trailing.equalToSuperview().offset(-5)
        }
        checkBox.image = "ic_default_checkmark".image
    }
    
    public func configureSelectedLayout() {
        backgroundColor = .clear
        subviews.forEach({ $0.removeFromSuperview() })
        addSubviews(assetThumbImage, checkBox)
        
        assetThumbImage.snp.makeConstraints { make in
            make.size.equalToSuperview()
            make.center.equalToSuperview()
        }
        checkBox.snp.makeConstraints { make in
            make.size.equalTo(20)
            make.bottom.equalToSuperview().offset(-5)
            make.trailing.equalToSuperview().offset(-5)
        }
        checkBox.image = "ic_active_checkmark".image
    }
}

public protocol DeselectDelegate {
    func deselectAction(section: Int?)
}

//MARK: - HEADER

final class AssetSectionHeader: UICollectionReusableView {
    
    var deselectDelegate: DeselectDelegate?
    
    public lazy var countLabel: UILabel! = {
        let label = UILabel(frame: .zero)
        label.textColor = "454D6A".hexColor
        label.textAlignment = .left
        label.font = .systemFont(ofSize: 24, weight: .bold)
        return label
    }()
    
    public lazy var deselectButton: UIButton! = {
        let b = UIButton(frame: .zero)
        b.setTitleColor("1C83FC".hexColor, for: .normal)
        b.setTitle(NSLocalizedString("Deselect", comment: ""), for: .normal)
        return b
    }()
    
    public var action: PublishRelay<Void> = .init()
    public var section: Int?
    
    private let bag = DisposeBag()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubviews(countLabel, deselectButton)
        countLabel.snp.makeConstraints { make in
            make.leading.equalToSuperview()
            make.bottom.equalToSuperview().offset(-5)
            make.width.greaterThanOrEqualTo(10)
        }
        
        deselectButton.snp.makeConstraints { make in
            make.trailing.equalToSuperview().inset(20)
            make.centerY.equalTo(countLabel.snp.centerY)
            make.width.greaterThanOrEqualTo(10)
            make.height.equalTo(30)
        }
        
        deselectButton.rx.tap.bind { [weak self] _ in
            self?.deselectDelegate?.deselectAction(section: self?.section)
        }.disposed(by: bag)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


import RxSwift
import RxCocoa
import Photos
import IHProgressHUD

//MARK: - CONTROLLER

final class AssetsScreen: UIViewController {
    
    let disposeBag = DisposeBag()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("UpLeftPage".image, for: .normal)
        return button
    }()
    
    private var topDuplicatesLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .heavy)
        label.text = NSLocalizedString("Duplicates", comment: "")
        label.textColor = "454D6A".hexColor
        label.textAlignment = .center
        return label
    }()
    
    private var scanningLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .heavy)
        label.text = NSLocalizedString("Scanning...", comment: "")
        label.textColor = "1C83FC".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var noDublicateLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 30, weight: .heavy)
        label.text = NSLocalizedString("Everything is clean, \n no duplicates found on your phone", comment: "")
        label.textColor = "1C83FC".hexColor
        label.textAlignment = .center
        label.numberOfLines = 0
        label.isHidden = true
        return label
    }()
    
    private lazy var assetsCollection: UICollectionView! = {
        let layout = SNCollectionViewLayout()
        layout.fixedDivisionCount = 4
        layout.delegate = self
        layout.scrollDirection = .vertical
        layout.itemSpacing = 10
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.allowsMultipleSelection = true
        cv.backgroundColor = .clear
        cv.contentInset.bottom = 50
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.delegate = self
        cv.dataSource = self
        cv.register(AssetCell.self, forCellWithReuseIdentifier: "AssetCell")
        cv.register(AssetSectionHeader.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "AssetSectionHeader")
        return cv
    }()
    
    private lazy var deleteButton: UIButton! = {
        let b = UIButton()
        b.backgroundColor = .clear
        
        b.setTitleColor(.red, for: .normal)
        
        libraryManager
            .toDeleteCounter
            .debug()
            .compactMap { [weak self] in
                return $0
                //+ " \(self?.selectedOption?.title ?? "")"
            }
            .bind(to: b.rx.title())
            .disposed(by: bag)
        return b
    }()
    
    private var selectedOption: PhotoOptions? = nil
    
    private var cleanerOption: CleanerCategories? = nil {
        didSet {
            assetsCollection.reloadData()
        }
    }
    
    public var cleanerOptionAssets: [[LibraryMediaManager.SimilarObject]] = [[]]
    var isCleaner = false
    
    private let bag = DisposeBag()
    
    private var libraryManager: LibraryMediaManager! {
        return LibraryMediaManager.shared
    }
    
    var selectedIndexes = [IndexPath]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
        view.backgroundColor = .white
        view.addSubviews(backButton, topDuplicatesLabel, assetsCollection, deleteButton, scanningLabel, noDublicateLabel)
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(44)
            make.leading.equalToSuperview().offset(24)
            make.size.equalTo(48)
        }
        
        topDuplicatesLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.leading.equalToSuperview().offset(30)
            make.trailing.equalToSuperview().offset(-30)
            make.height.equalTo(24)
        }
        
        assetsCollection.snp.makeConstraints { make in
            make.top.equalTo(topDuplicatesLabel.snp.bottom).offset(50)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.bottom.equalToSuperview()
        }
        
        deleteButton.snp.makeConstraints { make in
            make.height.equalTo(24)
            make.top.equalToSuperview().offset(56)
            make.trailing.equalToSuperview().offset(-24)
        }
        
        scanningLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview().offset(25)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(50)
        }
        
        noDublicateLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(200)
        }
        
        deleteButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            let assets = self.libraryManager.itemsToDelete.value.compactMap {
                asset, _ in
                return asset
            }
            self.removeSelectedItems(assets)
        }.disposed(by: bag)
        
        libraryManager
            .itemsToDelete
            .compactMap {
                return $0.count <= 0
            }
            .bind(to: deleteButton.rx.isHidden)
            .disposed(by: bag)
        
        if isCleaner == false {
            backButton.rx.tap.bind { [weak self] in
                self?.navigationController?.popViewController(animated: true)
                self?.libraryManager.itemsToDelete.accept([])
            }.disposed(by: disposeBag)
            topDuplicatesLabel.text = NSLocalizedString("Duplicates", comment: "")
        } else {
            backButton.rx.tap.bind { [weak self] in
                self?.navigationController?.popToRootViewController(animated: true)
                self? .libraryManager.itemsToDelete.accept([])
            }.disposed(by: disposeBag)
            topDuplicatesLabel.text = NSLocalizedString("Cleaner", comment: "")
        }
    }
    
    convenience init(rootOption option: CleanerCategories) {
        self.init()
        title = option.title.replacingOccurrences(of: "\n", with: " ")
        print(libraryManager.fetchByOption(option).count)
        cleanerOption = option
        cleanerOptionAssets = libraryManager.fetchByOption(option)
        self.scanningLabel.isHidden = true
    }
    
    convenience init(_ photoDetail: PhotoOptions?) {
        self.init()
        IHProgressHUD.show()
        selectedOption = photoDetail
        title = photoDetail?.title
        if let o = photoDetail{
            DispatchQueue.main.async { [weak self] in
                guard let self = self else { return }
                self.libraryManager.askPermission(o.fetchPredicate) { [weak self] in
                    DispatchQueue.main.async {
                        self?.assetsCollection.reloadData()
                            self?.scanningLabel.isHidden = true
                        IHProgressHUD.dismiss()
                    }
                }
            }
        } else {
            self.title = NSLocalizedString("Videos", comment: "")
            selectedOption = .screens
            DispatchQueue.main.async { [weak self] in
                guard let self = self else { return }
                self.libraryManager.fetchVideos { [weak self] in
                    DispatchQueue.main.async {
                        self?.assetsCollection.reloadData()
                        self?.scanningLabel.isHidden = true
                        IHProgressHUD.dismiss()
                    }
                }
            }
        }
    }
    
   
    
    private func removeSelectedItems(_ itms: [PHAsset]) {
        self.libraryManager.removeAssets(selectedOption: selectedOption == nil, cleanerAssets: cleanerOptionAssets, itms) { [weak self] result in
            switch result {
            case .error(_):
                DispatchQueue.main.async { [weak self] in
                    guard let self = self else { return }
                    self.assetsCollection.reloadData()
                }
                break
            case .success(_, let newCleanerAssets):
                DispatchQueue.main.async { [weak self] in
                    if newCleanerAssets != nil { self?.cleanerOptionAssets = newCleanerAssets!
                        if self?.cleanerOptionAssets[0].count == 0 {
                        self?.noDublicateLabel.isHidden = false
                    }}
                    guard let self = self else { return }
                    self.libraryManager.itemsToDelete.accept([])
                    self.selectedIndexes = [IndexPath]()
                    self.assetsCollection.reloadData()
                    if  self.libraryManager.similars[0].count == 0 {
                        self.noDublicateLabel.isHidden = false
                    }
                }
            }
        }
    }
    
    deinit {
        print(self, #function)
        IHProgressHUD.dismiss()
        if cleanerOption == nil {
            libraryManager.itemsToDelete.accept([])
            libraryManager.fetchResult = nil
            libraryManager.similars.removeAll()
            libraryManager.allSimilarAssets.removeAll()
            libraryManager.allScreenshotAssets.removeAll()
            libraryManager.allPhotoLiveAssets.removeAll()
            libraryManager.allBurstPhotoAssets.removeAll()
        } else {
            cleanerOptionAssets.removeAll()
            libraryManager.itemsToDelete.accept([])
        }
    }
}

//MARK: cellForItemAt
extension AssetsScreen: UICollectionViewDataSource, DeselectDelegate {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return selectedOption != nil ? libraryManager.similars.count : cleanerOptionAssets.count
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if  libraryManager.similars.count == 0 {
            noDublicateLabel.isHidden = false
        } else if cleanerOptionAssets.count == 0 {
            noDublicateLabel.isHidden = false
        }
        return selectedOption != nil ? libraryManager.similars[section].count : cleanerOptionAssets[section].count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AssetCell", for: indexPath) as? AssetCell else { return UICollectionViewCell() }
        if selectedOption == nil {
            
            let s = cleanerOptionAssets[indexPath.section]
            let i = s[indexPath.item].asset?.thumbnailSync
            cell.cellStyle = .asset(i)
            (selectedIndexes.contains(indexPath)) ? cell.configureSelectedLayout() : cell.configureDefaultLayout()
            return cell
        }
        switch selectedOption {
        case .burst, .live, .similar, .screens:
            let s = libraryManager.similars[indexPath.section]
            let i = s[indexPath.item].asset?.thumbnailSync
            cell.cellStyle = .asset(i)
            (selectedIndexes.contains(indexPath)) ? cell.configureSelectedLayout() : cell.configureDefaultLayout()
        default: break
        }
        return cell
    }
    
    func deselectAction(section: Int?) {
        let paths = self.libraryManager.itemsToDelete.value.filter { ass, ind in
            return ind.section == section
        }
        paths.forEach { assets, index in
            self.selectedIndexes.removeAll(where: { $0 == index })
            var newItems = self.libraryManager.itemsToDelete.value
            let itemToDelete = ItemToDelete(assets, index)
            newItems.removeAll { $0 == itemToDelete }
            self.libraryManager.itemsToDelete.accept([])
            self.libraryManager.itemsToDelete.accept(newItems)
        }
        self.assetsCollection.reloadData()
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let v = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "AssetSectionHeader", for: indexPath) as! AssetSectionHeader
        let count = self.cleanerOption == nil ? libraryManager.similars[indexPath.section].count : cleanerOptionAssets[indexPath.section].count
        v.deselectDelegate = self
        v.countLabel.text = "\(count) \(NSLocalizedString("Photos", comment: ""))"
        v.section = indexPath.section
        libraryManager
            .itemsToDelete
            .compactMap {
                return $0.count == 0
            }
            .bind(to: v.deselectButton.rx.isHidden)
            .disposed(by: bag)
        return v
    }
}

//MARK: Did Select Item At
extension AssetsScreen: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        didSelectDeselectAction(collectionView: collectionView, indexPath: indexPath)
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        didSelectDeselectAction(collectionView: collectionView, indexPath: indexPath)
    }
    
    func didSelectDeselectAction(collectionView: UICollectionView, indexPath: IndexPath) {
        switch  selectedOption {
        case .burst, .live, .similar, .screens:
            let fetchedSimilar = self.libraryManager.similars[indexPath.section]
            guard let asset = fetchedSimilar[indexPath.item].asset else { return }
            if let cell = collectionView.cellForItem(at: indexPath) as? AssetCell {
                if selectedIndexes.contains(indexPath) {
                    selectedIndexes.removeAll(where: { $0 == indexPath })
                } else {
                    selectedIndexes.append(indexPath)
                }
                if selectedIndexes.contains(indexPath) {
                    let itemToDelete = ItemToDelete(asset, indexPath)
                    libraryManager.itemsToDelete.accept(libraryManager.itemsToDelete.value + [itemToDelete])
                }else {
                    let itemToDelete = ItemToDelete(asset, indexPath)
                    var lib2 = libraryManager.itemsToDelete.value
                    lib2.removeAll { $0 == itemToDelete }
                    libraryManager.itemsToDelete.accept(lib2)
                }
            }
        default:
            let fetchedSimilar = cleanerOptionAssets[indexPath.section]
            guard let asset = fetchedSimilar[indexPath.item].asset else { return }
            if let cell = collectionView.cellForItem(at: indexPath) as? AssetCell {
                if selectedIndexes.contains(indexPath) {
                    selectedIndexes.removeAll(where: { $0 == indexPath })
                } else {
                    selectedIndexes.append(indexPath)
                }
                if selectedIndexes.contains(indexPath) {
                    let itemToDelete = ItemToDelete(asset, indexPath)
                    libraryManager.itemsToDelete.accept(libraryManager.itemsToDelete.value + [itemToDelete])
                }else {
                    let itemToDelete = ItemToDelete(asset, indexPath)
                    var lib2 = libraryManager.itemsToDelete.value
                    lib2.removeAll { $0 == itemToDelete }
                    libraryManager.itemsToDelete.accept(lib2)
                }
            }
        }
        self.assetsCollection.reloadData()
    }
}

extension AssetsScreen: SNCollectionViewLayoutDelegate {
    func headerFlexibleDimension(inCollectionView collectionView: UICollectionView, withLayout layout: UICollectionViewLayout, fixedDimension: CGFloat) -> CGFloat {
        return 40
    }
    
    func scaleForItem(inCollectionView collectionView: UICollectionView, withLayout layout: UICollectionViewLayout, atIndexPath indexPath: IndexPath) -> UInt {
        if indexPath.item == 0 {
            return 2
        }
        return 1
    }
}
