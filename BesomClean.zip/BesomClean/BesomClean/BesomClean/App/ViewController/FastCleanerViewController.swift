import UIKit
import SnapKit
import RxSwift
import SwiftyAttributes
import IHProgressHUD

class FastCleanerViewController: UIViewController {
    
    private var fullScreenImageView: UIImageView = {
        let imageView = UIImageView(image: "FullScreenImageView".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("UpLeftPage".image, for: .normal)
        return button
    }()
    
    private var topImageView: UIImageView = {
        let imageView = UIImageView(image: "fastVc".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private var lookingLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 13, weight: .semibold)
        label.text = NSLocalizedString("Looking for similar photos...", comment: "")
        label.textAlignment = .center
        label.textColor = "545F71".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var procentLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 72, weight: .heavy)
        label.text = ""
        label.textAlignment = .center
        label.textColor = "1C83FC".hexColor
        return label
    }()
    
    public var cleaningCategories = CleanerCategories.similar
    private var currentSize = 0.0
    
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        IHProgressHUD.dismiss()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    private func setup(){
        configureLayout()
        setupButtons()
        setupAllDuplicateSimilarsPhoto()
    }
    
    private func configureLayout() {
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
        view.addSubviews(fullScreenImageView, backButton, topImageView, lookingLabel, procentLabel)
        
        fullScreenImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(44)
            make.leading.equalToSuperview().offset(24)
            make.size.equalTo(48)
        }
        
        topImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(135)
            make.centerX.equalToSuperview()
            make.size.equalTo(141)
        }
        
        lookingLabel.snp.makeConstraints { make in
            make.top.equalTo(topImageView.snp.bottom).offset(32)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(20)
        }
        
        procentLabel.snp.makeConstraints { make in
            make.top.equalTo(lookingLabel.snp.bottom).offset(8)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(72)
        }
    }
    
    private func setupButtons() {
        backButton.rx.tap.bind { [weak self] in
            self?.navigationController?.popViewController(animated: true)
        }.disposed(by: disposeBag)
    }
    
    func setupAllDuplicateSimilarsPhoto(){
        fetchByOption()
        
        LibraryMediaManager.shared
            .countedSize
            .do(onNext: { [weak self] _, _ in
            })
                .compactMap { size, s in
                    return (("\(String(format: "%.2f", size)) GB"), size, s)
                }
                .subscribe(onNext: { [weak self] stringSize , size, stop in
                    guard let self = self else { return }
                    self.animateProgress()
                    if size == -1.0 {
                        IHProgressHUD.dismiss()
                        self.procentLabel.isHidden = true
                        self.lookingLabel.text = NSLocalizedString("No duplicates have been found", comment: "")
                        return
                    } else {
                       
                    }
                    if stop {
                        
                    }
                })
                .disposed(by: disposeBag)
    }
    
    private func fetchByOption() {
        LibraryMediaManager.shared.fetchPhotos(with: PhotoOptions.similar.fetchPredicate) {
            LibraryMediaManager.shared.appendToExistingAssets()
            LibraryMediaManager.shared.mapAssets(predicate: NSPredicate(format: "burstIdentifier == nil")) { _ in
                LibraryMediaManager.shared.requestForSize()
                LibraryMediaManager.shared.getSize(assets: LibraryMediaManager.shared.allSimilarAssets)
            }
        }
    }
    
    func animateProgress() {
        
        DispatchQueue.main.async {
            
        
        UIView.animate(withDuration: 2, animations: { [weak self] in
            guard let self = self else { return }
            self.currentSize += 0.04
            self.procentLabel.text = "\(Int(self.currentSize))%"
            
        }) { [weak self] _ in
            guard let self = self else { return }
            if self.currentSize <= 100 {
               
                self.animateProgress()
            } else {
                if self.lookingLabel.text == NSLocalizedString("No duplicates have been found", comment: "") {
                } else {
                    
                    if IAPManager.shared().isPurchased {
                        let assetsVC = AssetsScreen(rootOption: self.cleaningCategories)
                        assetsVC.isCleaner = true
                        LibraryMediaManager.shared.itemsToDelete.value.forEach { element in
                            assetsVC.selectedIndexes.append(element.indexPath)
                        }
                        self.navigationController?.pushViewController(assetsVC, animated: true)
                    } else {
                        Constants.ud.currentDismissing = 3
                        let vc = FirstSubscriptionsViewController()
                        self.navigationController?.pushViewController(vc, animated: true)
                        IAPManager.shared().purchaseCompletion = { _ in
                            let assetsVC = AssetsScreen(rootOption: self.cleaningCategories)
                            assetsVC.isCleaner = true
                            LibraryMediaManager.shared.itemsToDelete.value.forEach { element in
                                assetsVC.selectedIndexes.append(element.indexPath)
                            }
                            self.navigationController?.pushViewController(assetsVC, animated: true)
                            
                        }
                        IAPManager.shared().restoreCompletion = { subscription in
                            let assetsVC = AssetsScreen(rootOption: self.cleaningCategories)
                            assetsVC.isCleaner = true
                            LibraryMediaManager.shared.itemsToDelete.value.forEach { element in
                                assetsVC.selectedIndexes.append(element.indexPath)
                            }
                            self.navigationController?.pushViewController(assetsVC, animated: true)
                            
                            if Constants.ud.isPurchased {
                                AlertManager.shared().showPurchasesWereRestored()
                            }
                        }
                    }
                }
            }
        }
        
        }
    }
    
    deinit {
        print(self, #function)
        LibraryMediaManager.shared.allSimilarAssets.removeAll()
        LibraryMediaManager.shared.fetchedAssets.removeAll()
        LibraryMediaManager.shared.itemsToDelete.accept([])
    }
}
