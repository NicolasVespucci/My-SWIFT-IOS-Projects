import UIKit
import SnapKit
import RxSwift
import SwiftyAttributes
import MBCircularProgressBar
import Photos
import RxCocoa
import IHProgressHUD
import Contacts

class HomeViewController: UIViewController {
    
    public var options = [OptionsModel(image: "Photo", nameOptions: NSLocalizedString("Photo \nand Video", comment: ""), descriptionOptions: NSLocalizedString("We will find you duplicated and similar photos which \nmight help clean up some space", comment: ""), nameButton: NSLocalizedString("Clean", comment: "")),
                          OptionsModel(image: "Contacts", nameOptions:NSLocalizedString("Duplicated \nContacts", comment: ""), descriptionOptions:NSLocalizedString("We will find you duplicated contacts which you can \nmerge or delete", comment: ""), nameButton: NSLocalizedString("Merge", comment: ""))]
    
    private var fullScreenImageView: UIImageView = {
        let imageView = UIImageView(image: "FullScreenImageView".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private var menuButton: UIButton = {
        let button = UIButton()
        button.setImage("menuButton".image, for: .normal)
        button.isUserInteractionEnabled = true
        return button
    }()
    
    private var memoryImageView: UIImageView = {
        let imageView = UIImageView(image: "memoryStore".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    //  MARK: - Percentage Of Memory Already Filled And Amount Of Memory
    
    typealias Capacity = (used: String, total: String)
    
    private var deviceCapacity: Capacity {
        return ("\(UIDevice.current.usedDiskSpaceInt)",
                "\(UIDevice.current.totalDiskSpaceInt)")
    }
    //- memory as a percentage
    private var capacityPercent: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 64, weight: .bold)
        label.textAlignment = .center
        label.attributedText = UIDevice.current.usedPercent.withAttribute(.font(.systemFont(ofSize: 72, weight: .heavy))) + "%".withAttribute(.font(.systemFont(ofSize: 72, weight: .heavy)))
        label.textColor = "207FF5".hexColor
        return label
    }()
    
    //- filled places out of everything
    private lazy var spaceLabel: UILabel = {
        let label = UILabel()
        label.textColor = "9A999D".hexColor
        label.textAlignment = .center
        let total = deviceCapacity.total
        let used = deviceCapacity.used
        label.text = "\(used) GB of \(total) GB"
        label.font = .systemFont(ofSize: 12, weight: .semibold)
        return label
    }()
    
    // FAST CLEANER Button
    private var fastCleanerButton: UIButton = {
        let button = UIButton()
        button.titleLabel?.font = .systemFont(ofSize: 14, weight: .bold)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = 12
        button.setTitle(NSLocalizedString("FAST CLEANER", comment: ""), for: .normal)
        button.titleLabel?.adjustsFontSizeToFitWidth = true
        button.titleLabel?.minimumScaleFactor = 0.5
        button.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.34).cgColor
        button.layer.shadowOffset = CGSize(width: 0.0, height: 6.0)
        button.layer.shadowOpacity = 1
        button.layer.shadowRadius = 30
        button.layer.masksToBounds = false
        return button
    }()
    
    // Options TableView
    private lazy var optionsTableView: UITableView = {
        let table = UITableView()
        table.backgroundColor = .clear
        table.rowHeight = 152
        table.showsVerticalScrollIndicator = false
        table.separatorStyle = .none
        table.isScrollEnabled = false
        return table
    }()
    
    // Pause Button
    private lazy var fullView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.isHidden = true
        return view
    }()
    
    private var getFullAccessButton: UIButton = {
        let button = UIButton()
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 14, weight: .bold)
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = 12
        button.setTitle(NSLocalizedString("GET FULL ACCESS", comment: ""), for: .normal)
        button.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.34).cgColor
        button.layer.shadowOffset = CGSize(width: 0.0, height: 6.0)
        button.layer.shadowOpacity = 1
        button.layer.shadowRadius = 30
        button.layer.masksToBounds = false
        return button
    }()
    
    private var currentOption: CleaningOptions?
    public var allOptions = [CleaningOptions]()
    
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()

        if !IAPManager.shared().isPurchased {
            Constants.ud.currentDismissing = 2
            Constants.ud.currentRestoreDismissing = 2
            
            IAPManager.shared().presentSingleSubscriptionVC(animated: true)
            IAPManager.shared().purchaseCompletion = { _ in
                IAPManager.shared().dismissSubscriptionVC()
                self.getFullAccessButton.isHidden = true
            }
            IAPManager.shared().restoreCompletion = { subscription in
                IAPManager.shared().dismissSubscriptionVC()
                if Constants.ud.isPurchased {
                    AlertManager.shared().showPurchasesWereRestored()
                    self.getFullAccessButton.isHidden = true
                }
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        fullView.isHidden = true
        if IAPManager.shared().isPurchased {
            getFullAccessButton.isHidden = true
        }
    }
    
    private func setup() {
        configureLayout()
        configureButtons()
        configureTableView()
    }
    
    convenience init(_ options: [CleaningOptions]) {
        self.init()
        allOptions = options
    }
    
    deinit {
        print(self, #function)
    }
    
    private func configureLayout() {
        navigationController?.isNavigationBarHidden = true
        view.addSubviews(fullScreenImageView, menuButton, memoryImageView, capacityPercent, spaceLabel, fastCleanerButton, optionsTableView, fullView, getFullAccessButton )
        
        fullScreenImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        menuButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.leading.equalToSuperview().offset(24)
            make.size.equalTo(24)
        }
        
        memoryImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(94.resized())
            make.centerX.equalToSuperview()
            make.size.equalTo(24)
        }
        
        capacityPercent.snp.makeConstraints { make in
            make.top.equalTo(memoryImageView.snp.bottom).offset(8.resized())
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(72)
        }
        
        spaceLabel.snp.makeConstraints { make in
            make.top.equalTo(capacityPercent.snp.bottom).offset(8.resized())
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(16)
        }
        
        fastCleanerButton.snp.makeConstraints { make in
            make.top.equalTo(spaceLabel.snp.bottom).offset(24.resized())
            make.leading.equalToSuperview().offset(85)
            make.trailing.equalToSuperview().offset(-85)
            make.height.equalTo(48)
        }
        
        optionsTableView.snp.makeConstraints { make in
            make.top.equalTo(fastCleanerButton.snp.bottom).offset(38.resized())
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(304)
        }
        
        fullView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        getFullAccessButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-20.resized())
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(48)
        }
        
        view.layoutIfNeeded()
        fastCleanerButton.addGradient(.leftRight,["1C83FC".hexColor, "445BBB".hexColor], 12)
        getFullAccessButton.addGradient(.leftRight,["1C83FC".hexColor, "445BBB".hexColor], 12)
    }
    
    private func configureButtons() {
        DispatchQueue.main.async {
            self.menuButton.rx.tap.bind { [weak self] in
                guard let self = self else { return }
                self.menuViewControllerActions()
            }.disposed(by: self.disposeBag)
            
            self.fastCleanerButton.rx.tap.bind { [weak self] in
                IHProgressHUD.show()
                guard let self = self else { return }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    self.fastCleanerButtonActions()
                }
            
            }.disposed(by: self.disposeBag)
            
            self.getFullAccessButton.rx.tap.bind { [weak self] in
                guard let self = self else { return }
                self.premiunButtonAction()
            }.disposed(by: self.disposeBag)

        }
    }
    
    private func menuViewControllerActions() {
        var termsVC = MenuViewController()
        navigationController?.pushViewController(termsVC, animated: true)
    }
    
    private func configureTableView() {
        optionsTableView.delegate = self
        optionsTableView.dataSource = self
        optionsTableView.register(OptionsCell.self, forCellReuseIdentifier: OptionsCell.nibIdentifier)
    }
    
    private func premiunButtonAction() {
        Constants.ud.currentDismissing = 2
        Constants.ud.currentRestoreDismissing = 2
        IAPManager.shared().presentSingleSubscriptionVC(animated: true)
       
        IAPManager.shared().purchaseCompletion = { _ in
            IAPManager.shared().dismissSubscriptionVC()
        }
        IAPManager.shared().restoreCompletion = { subscription in
            IAPManager.shared().dismissSubscriptionVC()
            if Constants.ud.isPurchased {
                AlertManager.shared().showPurchasesWereRestored()
            }
        }
    }
    
    // FAST CLEANER action
    private func fastCleanerButtonActions(){
        DispatchQueue.main.async {
            LibraryMediaManager.shared.askPermission(PhotoOptions.similar.fetchPredicate) { [weak self] in
                Constants.ud.currentDismissing = 3
                Constants.ud.currentRestoreDismissing = 2
                    let vc = FastCleanerViewController()
                self?.navigationController?.pushViewController(vc, animated: false)
            }
        }
    }
}

//MARK: - Table View 

extension HomeViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let option = CleaningOptions.contacts
        switch self.options[indexPath.row].nameButton {
        case NSLocalizedString("Clean", comment: ""):
            IHProgressHUD.show()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                LibraryMediaManager.shared.askPermission(PhotoOptions.similar.fetchPredicate) { [weak self] in
                    DispatchQueue.main.async {
                        guard let self = self else { return }
                        let vc = StorageViewController()
                        self.navigationController?.pushViewController(vc, animated: true)
                        self.fullView.isHidden = false
                        LibraryMediaManager.shared.allSimilarAssets.removeAll()
                        
                    }
                }
            }
            
        case NSLocalizedString("Merge", comment: ""):
            IHProgressHUD.show()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                let vc = ContactScreen()
                self.navigationController?.pushViewController(vc, animated: true)
                self.fullView.isHidden = false
            }
         
        default: print("Unknown")
        }
    }
}

extension HomeViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return options.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = optionsTableView.dequeueReusableCell(withIdentifier: OptionsCell.nibIdentifier, for: indexPath) as! OptionsCell
        let option = options[indexPath.row]
        cell.optionsCellModel = option
        
        return cell
    }
}

