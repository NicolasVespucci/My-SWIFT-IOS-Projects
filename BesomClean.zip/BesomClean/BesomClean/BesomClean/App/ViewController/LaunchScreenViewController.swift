import UIKit
import SnapKit

class LaunchScreenViewController: UIViewController {
    
    private var fullScreenImageView: UIImageView = {
        let imageView = UIImageView(image: "FullScreenImageView".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private var nameAppLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 29, weight: .heavy)
        label.textColor = "454D6A".hexColor
        label.text = "Besom Clean"
        label.textAlignment = .center
        return label
    }()
    
    private var centerFastCleanerImageView: UIImageView = {
        let imageView = UIImageView(image: "BesomCleaner".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup() {
        configureLayout()
        setHomeViewController()
    }
    
    private func configureLayout() {
        view.addSubviews(fullScreenImageView, nameAppLabel, centerFastCleanerImageView)
        
        fullScreenImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
//        nameAppLabel.snp.makeConstraints { make in
//            make.top.equalTo(centerFastCleanerImageView.snp.top)
//            make.height.equalTo(30)
//            make.leading.equalToSuperview()
//            make.trailing.equalToSuperview()
//
//        }
        
        centerFastCleanerImageView.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.size.equalTo(173)
        }
    }
    private func homeViewControllerAction(){
        let options = CleaningOptions.allCases
        let vc = HomeViewController(options)
        let nc = UINavigationController(rootViewController: vc)
        guard let window = UIApplication.shared.windows.first else { return }
        window.rootViewController = nc
    }
    
    private func setHomeViewController() {
        
        if UserDefaults.standard.value(forKey: "isShownBefore") != nil {
            isShownBefore = UserDefaults.standard.value(forKey: "isShownBefore") as! Bool
        }
        if isShownBefore {
            homeViewControllerAction()
        } else {
            let controller = PresentViewController()
            let navigationController = UINavigationController(rootViewController: controller)
            UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.rootViewController = navigationController
            UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.makeKeyAndVisible()
        }
    }
}
