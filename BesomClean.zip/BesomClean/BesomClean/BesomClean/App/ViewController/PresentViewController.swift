import UIKit
import SnapKit
import RxSwift
import Photos
import AppTrackingTransparency

class PresentViewController: UIViewController, UIScrollViewDelegate {
    
    private let firstView = PresentScrollView(image: "first2".image ?? UIImage(), topText: NSLocalizedString("Clean up contacts.", comment: ""), bottomText: NSLocalizedString("Stop having multiple phone number \nof one person, clean your phonebook", comment: ""))
    private let secondView = PresentScrollView(image: "second2".image ?? UIImage(), topText: NSLocalizedString("Keep the best only.", comment: ""), bottomText: NSLocalizedString("We will find duplicates and similar \nphotos and let you keep the best only", comment: ""))
    
    private var fullScreenImageView: UIImageView = {
        let imageView = UIImageView(image: "FullScreenImageView".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private var scrollView: UIScrollView = {
        let view = UIScrollView()
        view.isPagingEnabled = true
        view.isScrollEnabled = false
        view.showsHorizontalScrollIndicator = false
        return view
    }()
    
    private var continueStartButton: UIButton = {
        let button = UIButton()
        button.titleLabel?.font = .systemFont(ofSize: 14, weight: .bold)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.textAlignment = .center
        button.backgroundColor = "02008C".hexColor
        button.layer.cornerRadius = 12
        button.setTitle(NSLocalizedString("CONTINUE", comment: ""), for: .normal)
        button.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.34).cgColor
        button.layer.shadowOffset = CGSize(width: 0.0, height: 6.0)
        button.layer.shadowOpacity = 1
        button.layer.shadowRadius = 30
        button.layer.masksToBounds = false
        return button
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("UpLeftPage".image, for: .normal)
        button.isUserInteractionEnabled = true
        button.isHidden = true
        return button
    }()
    
    var xOffSet: CGFloat = 0
    var contentWidth: CGFloat = 0.0
    let disposeBag = DisposeBag()
    
    typealias CleaningOption = (image: UIImage?, title: String, option: CleaningOptions)
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup() {
        configureLayout()
        configureButtons()
        configureScrollView()
    }
    
    private func configureLayout() {
        navigationController?.isNavigationBarHidden = true
        view.addSubviews(fullScreenImageView, backButton, scrollView, continueStartButton)
        
        fullScreenImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(44)
            make.leading.equalToSuperview().offset(24)
            make.height.equalTo(48)
        }
        
        scrollView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(194.resized())
            make.leading.equalToSuperview()
            make.height.equalTo(330)
            make.width.equalTo(375.resized(.width))
        }
        
        continueStartButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-64.resized())
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(48)
        }
        
        view.layoutIfNeeded()
        continueStartButton.addGradient(.leftRight,["308DFB".hexColor, "445BBB".hexColor], 12)
        Constants.ud.currentDismis = false
    }
    
    private func configureButtons() {
        continueStartButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.continueStartButtonAction()
        }.disposed(by: disposeBag)
        
        backButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.backBattonsActions()
        }.disposed(by: disposeBag)
    }
    
    private func homeViewControllerAction(){
        let options = CleaningOptions.allCases
        let vc = HomeViewController(options)
        let nc = UINavigationController(rootViewController: vc)
        guard let window = UIApplication.shared.windows.first else { return }
        window.rootViewController = nc
    }
    
    private func backBattonsActions() {
        self.xOffSet = 0
        self.scrollView.contentOffset.x = self.xOffSet
        backButton.isHidden = true
        self.continueStartButton.setTitle(NSLocalizedString("CONTINUE", comment: ""), for: .normal)
    }
    
    private func continueStartButtonAction(){
        if self.xOffSet < UIScreen.main.bounds.width {
            DispatchQueue.main.async {
                self.xOffSet += UIScreen.main.bounds.width
                self.scrollView.contentOffset.x = self.xOffSet
                self.continueStartButton.setTitle(NSLocalizedString("START", comment: ""), for: .normal)
                self.backButton.isHidden = false
            }
            
        } else {
            isShownBefore = true
            UserDefaults.standard.set(isShownBefore, forKey: "isShownBefore")
            
//            requestPermission()
            if IAPManager.shared().isPurchased {
                homeViewControllerAction()
            } else {
                homeViewControllerAction()
//                Constants.ud.currentDismissing = 1
//                    Constants.ud.currentRestoreDismissing = 1
//                    IAPManager.shared().presentSingleSubscriptionVC(animated: true)
//                    IAPManager.shared().purchaseCompletion = { _ in
//                        IAPManager.shared().dismissSubscriptionVC()
//                    }
//                    IAPManager.shared().restoreCompletion = { subscription in
//                        IAPManager.shared().dismissSubscriptionVC()
//                        if Constants.ud.isPurchased {
//                            AlertManager.shared().showPurchasesWereRestored()
//                        }
//                    }
            }
            self.xOffSet = UIScreen.main.bounds.width
        }
    }
    
    private func configureScrollView() {
        scrollView.delegate = self
        let viewsForScroll = [firstView, secondView]
        for (index, view) in viewsForScroll.enumerated() {
            scrollView.addSubview(view)
            view.snp.makeConstraints { make in
                make.top.equalToSuperview()
                make.bottom.equalToSuperview()
                make.leading.equalToSuperview().offset(CGFloat(index) * UIScreen.main.bounds.width)
                make.width.equalToSuperview()
            }
            self.view.layoutIfNeeded()
            self.scrollView.layoutIfNeeded()
            contentWidth += self.view.frame.width
        }
        scrollView.contentSize = CGSize(width: contentWidth, height: scrollView.frame.height)
    }
    
   
}
