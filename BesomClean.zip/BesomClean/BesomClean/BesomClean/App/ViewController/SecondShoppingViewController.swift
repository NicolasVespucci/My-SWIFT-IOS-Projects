import UIKit
import RxSwift
import SwiftyStoreKit
import SnapKit
import NetworkExtension
import Network
import SwiftyAttributes
import Reachability
import StoreKit
import IHProgressHUD

class SecondShoppingViewController: UIViewController {
    
    var identifiers = [Constants.analytics.week, Constants.analytics.threeMonth, Constants.analytics.year]
    
    public var advantagesModel = [AdvantagesModel(title: NSLocalizedString("Clean up and boost your iphone", comment: "")),
                                  AdvantagesModel(title: NSLocalizedString("Find all unnecessary files", comment: "")),
                                  AdvantagesModel(title: NSLocalizedString("Delete all duplicates", comment: "")),
                                  AdvantagesModel(title: NSLocalizedString("Unlimited smart cleaner", comment: ""))
    ]
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("topBack".image, for: .normal)
        button.isUserInteractionEnabled = true
        return button
    }()
    
    private var restoreButton: UIButton = {
        let button = UIButton()
        button.setTitle(NSLocalizedString("Restore", comment: ""), for: .normal)
        button.setTitleColor("404865".hexColor, for: .normal)
        button.titleLabel?.textAlignment = .left
        button.isUserInteractionEnabled = true
        return button
    }()
    
    private var topExampeImageView: UIImageView = {
        let imageView = UIImageView(image: "payTopImage".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private lazy var AdvantagesShoppingTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 40
        table.backgroundColor = .clear
        table.isScrollEnabled = false
        table.separatorStyle = .none
        return table
    }()
    
    private lazy var payCollectionView: UICollectionView = {
        let collection = UICollectionView(frame: .zero, collectionViewLayout: .init())
        collection.backgroundColor = .clear
        collection.showsHorizontalScrollIndicator = false
        collection.showsVerticalScrollIndicator = false
        collection.isScrollEnabled = true
        collection.clipsToBounds = false
        return collection
    }()
    
    private lazy var payLayout: UICollectionViewLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 0
        layout.itemSize = .init(width: 98.resized(.width), height: 120.resized())
        layout.sectionInset = .init(top: 0, left: 0, bottom: 0, right: 0)
        return layout
    }()
    
    public var pricePeriodLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15, weight: .medium)
        label.textColor = "414860".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private lazy var subscribeButton: UIButton = {
        let button = UIButton()
        button.layer.cornerRadius = 12
        button.setTitle(NSLocalizedString("SUBSCRIBE", comment: ""), for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 14, weight: .bold)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = "#02008C".hexColor
        button.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.34).cgColor
        button.layer.shadowOffset = CGSize(width: 0.0, height: 6.0)
        button.layer.shadowOpacity = 1
        button.layer.shadowRadius = 30
        button.layer.masksToBounds = false
        return button
    }()
    
    var productsDescription: NSAttributedString {
        let terms = NSLocalizedString("Terms", comment: "") + " " + NSLocalizedString("of", comment: "") + " " + NSLocalizedString("Use", comment: "")
        let privacy = NSLocalizedString("Privacy", comment: "") + " " + NSLocalizedString("and", comment: "")
        + " " + NSLocalizedString("Policy", comment: "")
        let and = " & "
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        
        let textAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12, weight: .medium)),
            .textColor("414860".hexColor),
            .paragraphStyle(paragraphStyle)
        ]
        
        let andAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12, weight: .medium)),
            .textColor("414860".hexColor.withAlphaComponent(0.4)),
            .paragraphStyle(paragraphStyle)
        ]
        
        let attributedDescription =
        terms.withAttributes(textAttributes)
        + and.withAttributes(andAttributes)
        + privacy.withAttributes(textAttributes)
        return attributedDescription
    }
    
    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.layoutIfNeeded()
        textView.isEditable = false
        textView.isSelectable = false
        textView.isScrollEnabled = true
        textView.backgroundColor = .clear
        textView.showsVerticalScrollIndicator = true
        textView.attributedText = productsDescription
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapResponse(recognizer:)))
        textView.addGestureRecognizer(tap)
        return textView
    }()
    
    var products = [SKProduct]()
    var selectedIndex = 0
    
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        configureUpdateProducts()
    }
    
    private func setup() {
        configureUpdateProducts()
        configureLayout()
        setupTableView()
        configureCollection()
        configureButtons()
    }
    
    private func configureLayout() {
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = .white
        view.addSubviews(backButton, restoreButton, topExampeImageView, AdvantagesShoppingTableView, payCollectionView, pricePeriodLabel, textView, subscribeButton)
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(44)
            make.leading.equalToSuperview().offset(24)
            make.size.equalTo(48)
        }
        
        restoreButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(56)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(24)
        }
        
        topExampeImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(112.resized())
            make.centerX.equalToSuperview()
            make.width.equalTo(236)
            make.height.equalTo(116)
        }
        
        AdvantagesShoppingTableView.snp.makeConstraints { make in
            make.top.equalTo(topExampeImageView.snp.bottom).offset(32.resized())
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(160)
        }
        
        payCollectionView.snp.makeConstraints { make in
            make.top.equalTo(AdvantagesShoppingTableView.snp.bottom).offset(16.resized())
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(120)
        }
        
        pricePeriodLabel.snp.makeConstraints { make in
            make.top.equalTo(payCollectionView.snp.bottom).offset(15.resized())
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(24)
        }
        
        textView.snp.makeConstraints { make in
            make.bottom.equalTo(subscribeButton.snp.top).offset(-32.resized())
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(25)
        }
        
        subscribeButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-20.resized())
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(48)
        }
        
        view.layoutIfNeeded()
        subscribeButton.addGradient(.leftRight,["1C83FC".hexColor, "445BBB".hexColor], 12)
    }
    
    private func setupTableView() {
        AdvantagesShoppingTableView.delegate = self
        AdvantagesShoppingTableView.dataSource = self
        AdvantagesShoppingTableView.register(AdvantagesShoppingCell.self, forCellReuseIdentifier: AdvantagesShoppingCell.nibIdentifier)
    }
    
    private func configureCollection() {
        payCollectionView.setCollectionViewLayout(payLayout, animated: true)
        payCollectionView.dataSource = self
        payCollectionView.delegate = self
        payCollectionView.register(SubscriptionsCollectionCell.self, forCellWithReuseIdentifier: SubscriptionsCollectionCell.nibIdentifier)
    }
    
    private func configureButtons() {
        backButton.rx.tap.bind { [weak self] in
            self?.dismiss(animated: true)
        }.disposed(by: disposeBag)
        
        subscribeButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            let product = self.identifiers[self.selectedIndex]
            IAPManager.shared().purchase(rcPackage: product, quantity: 1, atomically: true)
        }.disposed(by: disposeBag)
        
        restoreButton.rx.tap.bind {
            IAPManager.shared().restore()
            IAPManager.shared().restoreCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                    AlertManager.shared().showPurchasesWereRestored()
                }
            }
        }.disposed(by: disposeBag)
    }
    
    private func configurePriceLabel(product: SKProduct?) {
        guard let appHudproduct = product else { return }
        let product = Product(product: appHudproduct)
        guard let period = product.period else { return }
        let price = product.localizedPrice
        let perPeriodString = period.perFormattedString.capitalized
        
        if product.introductory?.period != nil {
            pricePeriodLabel.text = (product.introductory?.period?.formattedString ?? "asda") + NSLocalizedString(" free trial then ", comment: "") + price + NSLocalizedString(" per ", comment: "") + perPeriodString
        } else {
            pricePeriodLabel.text = price + NSLocalizedString(" per ", comment: "") + perPeriodString
        }
    }
    
    private func configureUpdateProducts() {
        IHProgressHUD.show()
        SwiftyStoreKit.retrieveProductsInfo([Constants.analytics.week, Constants.analytics.threeMonth, Constants.analytics.year]) { result in
            if(!result.retrievedProducts.isEmpty) {
                self.products = Array(result.retrievedProducts).sorted(by: { Product(product: $0).price < Product(product: $1).price })
                self.payCollectionView.reloadData()
                self.configurePriceLabel(product: self.products[0])
                IHProgressHUD.dismiss()
            } else {
                IHProgressHUD.dismiss()
                self.configureUpdateProducts()
            }
        }
    }
}
//MARK: - Top TableView
extension SecondShoppingViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
}
extension SecondShoppingViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return advantagesModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = AdvantagesShoppingTableView.dequeueReusableCell(withIdentifier: AdvantagesShoppingCell.nibIdentifier, for:  indexPath) as! AdvantagesShoppingCell
        let settingModelTwo = advantagesModel[indexPath.row]
        cell.AdvantagesShoppingCellModel = settingModelTwo
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
}

//MARK: - CollectionView
extension SecondShoppingViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedIndex = indexPath.item
        let apphudProduct = self.products[selectedIndex]
        configurePriceLabel(product: apphudProduct)
        payCollectionView.reloadData()
        if IAPManager.shared().isPurchased {
            IAPManager.shared().dismissSubscriptionVC()
        }
    }
}

extension SecondShoppingViewController: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return products.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SubscriptionsCollectionCell.nibIdentifier, for: indexPath) as! SubscriptionsCollectionCell
        let apphudProduct = products[indexPath.item]
        let product = Product(product: apphudProduct)
        cell.product = product
        if indexPath.item == self.selectedIndex {
            product.type == .renewable(.trial) ? cell.configureTrialSelectedLayout() : cell.configureCommonSelectedLayout()
        } else {
            product.type == .renewable(.trial) ? cell.configureTrialLayout() : cell.configureCommonLayout()
        }
        return cell
    }
}

//MARK: - Text View
extension SecondShoppingViewController {
    @objc func tapResponse(recognizer: UITapGestureRecognizer) {
        let location: CGPoint = recognizer.location(in: textView)
        let position: CGPoint = CGPoint(x: location.x, y: location.y)
        let tapPosition: UITextPosition? = textView.closestPosition(to: position)
        if tapPosition != nil {
            let textRange: UITextRange? = textView.tokenizer.rangeEnclosingPosition(tapPosition!, with: UITextGranularity.word, inDirection: UITextDirection(rawValue: 1))
            if textRange != nil
            {
                let tappedWord: String? = textView.text(in: textRange!)
                guard let word = tappedWord else { return }
                wordAction(word)
            }
        }
    }
    
    private func wordAction(_ word: String) {
        switch word {
        case NSLocalizedString("Terms", comment: ""), NSLocalizedString("of", comment: ""), NSLocalizedString("Use", comment: ""): pushPoliciesVC(.terms)
        case NSLocalizedString("Privacy", comment: ""),NSLocalizedString("and", comment: ""), NSLocalizedString("Policy", comment: ""): pushPoliciesVC(.privacy)
            
        default: break
        }
    }
    
    func pushPoliciesVC(_ policiesType: Policies) {
        let termsVC = TermsAndPrivacy()
        termsVC.policiesType = policiesType
        navigationController?.pushViewController(termsVC, animated: true)
    }
}

