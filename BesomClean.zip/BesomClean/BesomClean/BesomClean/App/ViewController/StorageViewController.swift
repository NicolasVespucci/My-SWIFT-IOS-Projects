import RxSwift
import RxCocoa
import Photos
import UIKit
import SnapKit
import IHProgressHUD

//MARK: - CONTROLLER

class StorageViewController: UIViewController {
    
    private var libraryManager: LibraryMediaManager! {
        return LibraryMediaManager.shared
    }
    
    //MARK: - Volume Sections Photo in Storage View Controller
    //Similar Photo
    var memoryDuplicatesVolume = 0.0
    var memoryDuplicatesVolumeString = ""
    //Screenshot
    public var memoryScreenshotVolume = 0.0
    public var memoryScreenshotVolumeString = ""
    //Live Photo
    public var memoryLivePhotoVolume = 0.0
    public var memoryLivePhotoVolumeString = ""
    //Burst Phoro
    public var memoryBurstPhoroVolume = 0.0
    public var memoryBurstPhoroVolumeString = ""
    
    public var sectionsName = [StorageTableViewModel(nameSections: NSLocalizedString("Duplicates", comment: ""), sectionsImageArray: LibraryMediaManager.shared.allSimilarAssets, volumeStorage: ""),
                               StorageTableViewModel(nameSections:NSLocalizedString("Screenshots", comment: ""), sectionsImageArray: LibraryMediaManager.shared.allScreenshotAssets, volumeStorage: ""),
                               StorageTableViewModel(nameSections: NSLocalizedString("Live Photo", comment: ""), sectionsImageArray:
                                                        LibraryMediaManager.shared.allPhotoLiveAssets, volumeStorage: ""),
                               StorageTableViewModel(nameSections: NSLocalizedString("Burst Photo", comment: ""), sectionsImageArray:
                                                        LibraryMediaManager.shared.allBurstPhotoAssets, volumeStorage: ""),
                               StorageTableViewModel(nameSections: NSLocalizedString("Video", comment: ""), sectionsImageArray:
                                                        LibraryMediaManager.shared.allVideoAssets, volumeStorage: "")]
    
    
    let disposeBag = DisposeBag()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("UpLeftPage".image, for: .normal)
        return button
    }()
    
    private var topStorageLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .heavy)
        label.text = NSLocalizedString("Storage", comment: "")
        label.textColor = "454D6A".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var scanningLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .heavy)
        label.text = NSLocalizedString("Scanning...", comment: "")
        label.textColor = "1C83FC".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var noDublicateLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 30, weight: .heavy)
        label.text = NSLocalizedString("Everything is clean, \n no duplicates found on your phone", comment: "")
        label.textColor = "1C83FC".hexColor
        label.textAlignment = .center
        label.numberOfLines = 0
        label.isHidden = true
        return label
    }()
//    
    //MARK: - Table View
    
    private lazy var storageTableView: UITableView = {
        let table = UITableView()
        table.backgroundColor = .clear
        table.rowHeight = 172
        table.showsVerticalScrollIndicator = false
        table.separatorStyle = .none
        table.isScrollEnabled = true
        return table
    }()
    
    private var cleanerOptionAssetsOne: [[LibraryMediaManager.SimilarObject]] = [[]]
    //MARK: - LibraryMediaManager
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureLayout()
        //setupSimilarPhoto()
    }
    
    private func configureLayout() {
        view.backgroundColor = .white
        view.addSubviews(backButton, topStorageLabel, storageTableView, scanningLabel, noDublicateLabel)
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(44.resized())
            make.leading.equalToSuperview().offset(24)
            make.size.equalTo(48)
        }
        
        topStorageLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54.resized())
            make.leading.equalToSuperview().offset(75)
            make.trailing.equalToSuperview().offset(-75)
            make.height.equalTo(24)
        }
        
        storageTableView.snp.makeConstraints { make in
            make.top.equalTo(topStorageLabel.snp.bottom).offset(14)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        scanningLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview().offset(25)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(50)
        }
        
        noDublicateLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(200)
        }
        
        backButton.rx.tap.bind { [weak self] in
            self?.navigationController?.popViewController(animated: true)
        }.disposed(by: disposeBag)
    }
    
    //MARK: - Setup Table View
    private func configureTableView() {
        storageTableView.delegate = self
        storageTableView.dataSource = self
        storageTableView.register(StorageTableViewCell.self, forCellReuseIdentifier: StorageTableViewCell.nibIdentifier)
    }
    
    func setupSimilarPhoto() {
        IHProgressHUD.show()
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            // Duplicates Photo
            self.libraryManager.askPermission(PhotoOptions.similar.fetchPredicate) { [weak self] in
                DispatchQueue.main.async { [weak self] in
                    guard let self = self else { return }
                    self.sectionsName[0].sectionsImageArray = self.libraryManager.allSimilarAssets
                    IHProgressHUD.dismiss()
                    self.sectionsName[0].volumeStorage = self.libraryManager.getSize(assets: self.libraryManager.allSimilarAssets)
                }
            }
            //2  Screenshots Photo
            self.libraryManager.askPermission(PhotoOptions.screens.fetchPredicate) { [weak self] in
                DispatchQueue.main.async { [weak self] in
                    guard let self = self else { return }
                    self.sectionsName[1].sectionsImageArray = self.libraryManager.allScreenshotAssets
                    IHProgressHUD.dismiss()
                    self.sectionsName[1].volumeStorage = self.libraryManager.getSize(assets: self.libraryManager.allScreenshotAssets)
                }
            }
            //3 Live Photo
            self.libraryManager.askPermission(PhotoOptions.live.fetchPredicate) { [weak self] in
                DispatchQueue.main.async { [weak self] in
                    guard let self = self else { return }
                    self.sectionsName[2].sectionsImageArray = self.libraryManager.allPhotoLiveAssets
                    IHProgressHUD.dismiss()
                    self.sectionsName[2].volumeStorage = self.libraryManager.getSize(assets: self.libraryManager.allPhotoLiveAssets)
                }
            }
            //4 Burst photo
            self.libraryManager.askPermission(PhotoOptions.burst.fetchPredicate) { [weak self] in
                DispatchQueue.main.async { [weak self] in
                    guard let self = self else { return }
                    self.sectionsName[3].sectionsImageArray = self.libraryManager.allBurstPhotoAssets
                    IHProgressHUD.dismiss()
                    self.sectionsName[3].volumeStorage = self.libraryManager.getSize(assets: self.libraryManager.allBurstPhotoAssets)
                }
            }
            self.libraryManager.fetchVideos { [weak self] in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    self.sectionsName[4].sectionsImageArray = self.libraryManager.allVideoAssets
                    IHProgressHUD.dismiss()
                    self.sectionsName[4].volumeStorage = self.libraryManager.getSize(assets: self.libraryManager.allVideoAssets)
                    //self.configureTableView()
                    self.scanningLabel.isHidden = true
                    
            
                    IHProgressHUD.dismiss()
                    
                    var currentCountInLibraryPhotoVideo = [self.libraryManager.allSimilarAssets.count, self.libraryManager.allScreenshotAssets.count, self.libraryManager.allPhotoLiveAssets.count, self.libraryManager.allBurstPhotoAssets.count, self.libraryManager.allVideoAssets.count]
                    
                   if currentCountInLibraryPhotoVideo.filter({$0 == 0}).count == 5 {
                       self.noDublicateLabel.isHidden = false
                       self.storageTableView.isHidden = true
                   } else {
                       self.noDublicateLabel.isHidden = true
                        self.configureTableView()
                       self.storageTableView.reloadData()
                    }
                }
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.scanningLabel.isHidden = false
        setupSimilarPhoto()
    }
    
    func getMemoryString(volume: Double) -> String {
        if volume / 1024.0 < 1.0 {
            return String(format: "%.2f Mb", volume)
        } else {
            return String(format: "%.2f Gb", volume/1024.0)
        }
    }
    
    deinit {
        print(self, #function)
        libraryManager.itemsToDelete.accept([])
        libraryManager.fetchResult = nil
        libraryManager.allSimilarAssets.removeAll()
        libraryManager.allScreenshotAssets.removeAll()
        libraryManager.allPhotoLiveAssets.removeAll()
        libraryManager.allBurstPhotoAssets.removeAll()
        libraryManager.allVideoAssets.removeAll()
        libraryManager.similars.removeAll()
    }
}

extension StorageViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
}

extension StorageViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 5
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = storageTableView.dequeueReusableCell(withIdentifier: StorageTableViewCell.nibIdentifier, for: indexPath) as! StorageTableViewCell
        let sectionsName = sectionsName[indexPath.row]
        cell.storageTableViewModel = sectionsName
        cell.parent = self
        
        return cell
    }
}



