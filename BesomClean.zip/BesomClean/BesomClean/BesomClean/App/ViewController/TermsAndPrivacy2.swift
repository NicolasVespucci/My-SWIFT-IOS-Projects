
import UIKit
import WebKit
import SnapKit
import IHProgressHUD

enum Policies {
    case terms, privacy
}

class TermsAndPrivacy: UIViewController {
    
    private lazy var webView: WKWebView = {
        let view = WKWebView()
        return view
    }()
    
    var policiesType: Policies = .terms

    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.makeClearBar(color: .white)
        view.backgroundColor = .white
        view.addSubview(webView)
        
        webView.snp.makeConstraints {
            $0.top.equalTo(view.snp.topMargin)
            $0.leading.trailing.bottom.equalToSuperview()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        navigationController?.isNavigationBarHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.isNavigationBarHidden = false
        navigationItem.largeTitleDisplayMode = .never
        let url: String
        
        switch policiesType {
        case .terms:
            navigationItem.title = NSLocalizedString("Terms of Use", comment: "")
            url = "http://besomclean.com/terms.html"
        case .privacy:
            navigationItem.title = NSLocalizedString("Privacy Policy", comment: "")
            url = "http://besomclean.com/policy.html"
        }
        
        loadRequest(urlString: url)
        navigationController?.isNavigationBarHidden = false
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        IHProgressHUD.dismiss()
        navigationController?.isNavigationBarHidden = true
    }
    
    private func loadRequest(urlString: String) {
        IHProgressHUD.show()
        let url = URL(string: urlString)
        let urlRequest = URLRequest(url: url!)
        webView.navigationDelegate = self
        webView.load(urlRequest)
    }
}

// MARK: UIWebViewDelegate
extension TermsAndPrivacy: WKNavigationDelegate {
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        IHProgressHUD.dismiss()
    }
    
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        IHProgressHUD.dismiss()
    }
    
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        IHProgressHUD.dismiss()
    }
}


