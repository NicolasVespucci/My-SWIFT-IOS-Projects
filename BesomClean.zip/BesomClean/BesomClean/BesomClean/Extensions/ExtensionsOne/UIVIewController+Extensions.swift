

import Foundation
import UIKit
import MessageUI
import SwiftMessages
import Reachability

extension UIViewController {
    
    var className: String {
                NSStringFromClass(self.classForCoder).components(separatedBy: ".").last!
            }
  
  func alert(message: String, title: String = "") {
    let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
    let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
    alertController.addAction(OKAction)
    self.present(alertController, animated: true, completion: nil)
  }
  
  func showInputDialog(title:String? = nil,
                       subtitle:String? = nil,
                       actionTitle:String? = NSLocalizedString("Add", comment: ""),
                       cancelTitle:String? = NSLocalizedString("Cancel", comment: ""),
                       inputPlaceholder:String? = nil,
                       inputKeyboardType:UIKeyboardType = UIKeyboardType.default,
                       cancelHandler: ((UIAlertAction) -> Swift.Void)? = nil,
                       actionHandler: ((_ text: String?) -> Void)? = nil) {

      let alert = UIAlertController(title: title, message: subtitle, preferredStyle: .alert)
      alert.addTextField { (textField:UITextField) in
          textField.placeholder = inputPlaceholder
          textField.keyboardType = inputKeyboardType
      }
      alert.addAction(UIAlertAction(title: actionTitle, style: .default, handler: { (action:UIAlertAction) in
          guard let textField =  alert.textFields?.first else {
              actionHandler?(nil)
              return
          }
          actionHandler?(textField.text)
      }))
      alert.addAction(UIAlertAction(title: cancelTitle, style: .cancel, handler: cancelHandler))

      self.present(alert, animated: true, completion: nil)
  }
  
  public func setupReachability(reachability: Reachability, _ reachableComp: @escaping(() -> (Void)), unreachableComp: (() -> (Void))? = nil) {
    reachability.whenReachable = { _ in
      reachableComp()
    }
    reachability.whenUnreachable = { _ in
      AlertManager.shared().showNoInternetConnection()
      unreachableComp?()
    }
    do {
        try reachability.startNotifier()
    } catch {
        print("Unable to start notifier")
    }
  }
}

 //MARK: MAILCOMPOSER
extension UIViewController: MFMailComposeViewControllerDelegate {
  // MARK: MAIL COMPOSER
  func configuredMailComposeViewController(recipients : [String]?, subject :
    String, body : String, isHtml : Bool = false,
            images : [UIImage]?) -> MFMailComposeViewController {
    let customBody = "<br><br><br><p>Version - \(UIApplication.applicationVersion)<br> Build - \(UIApplication.applicationBuild)<br> Device - \(UIDevice.modelName)<br> iOS version - \(UIDevice.current.systemVersion)</p>"
    let mailComposerVC = MFMailComposeViewController()
    mailComposerVC.mailComposeDelegate = self

    mailComposerVC.setToRecipients(recipients)
    mailComposerVC.setSubject(subject)
    mailComposerVC.setMessageBody(customBody, isHTML: isHtml)

    for image in images ?? [] {
      if let imageData = image.jpegData(compressionQuality: 1.0) {
        mailComposerVC.addAttachmentData(imageData,
                                         mimeType: "image/jpg",
                                         fileName: "Image")
      }
    }
    return mailComposerVC
  }
  
  func presentMailComposeViewController(mailComposeViewController :
    MFMailComposeViewController) {
    if MFMailComposeViewController.canSendMail() {
      self.present(mailComposeViewController, animated: true, completion:{ () in

      })
    }
  }
  
  public func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
    switch (result) {
    case .cancelled:
      self.dismiss(animated: true, completion: nil)
    case .sent:
      self.dismiss(animated: true, completion: nil)
    case .failed:
      self.dismiss(animated: true, completion: nil)
    case .saved:
      self.dismiss(animated: true, completion: nil)
    default:
      self.dismiss(animated: true, completion: nil)
    }
  }
  
  var version: String {
    let bundleVersionKey = "CFBundleShortVersionString"
    guard let version = Bundle.main.object(forInfoDictionaryKey: bundleVersionKey) else { return "" }
    return "Version \(version)"
  }
  
  var buildVersion: String {
    let buildVersionKey = "CFBundleVersion"
    guard let build = Bundle.main.object(forInfoDictionaryKey: buildVersionKey) else { return "" }
    return "Build \(build)"
  }
}

