//
//  AppIconManager.h
//  DocScan
//
//  Created by Mister Grizzly on 9/6/20.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AppIconManager : NSObject
- (void)lc_setAlternateIconName:(NSString*)iconName;
@end

NS_ASSUME_NONNULL_END
