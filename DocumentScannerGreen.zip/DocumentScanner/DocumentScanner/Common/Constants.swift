
import Foundation
import UIKit



var UD = UserDefaults.standard

public struct Constants {
  
  static var app = AppConstants()
  static var analytics = AnalyticsConstants()
  static var ud = UDConstants()
  
  struct AnalyticsConstants {
     
//
//      let week = "com.verst.weekly"
//      let threeMonth = "com.verst.3month"
//      let year = "com.verst.yearly"
      
      let week = "doc.week.plan"
      let threeMonth = "doc.month.plan"
      let year = "doc.annual.plan"
      
       //com.verst.test
   //com.docscan.os

  }
  
  struct AppConstants {
    let appid = "1631744459"
  }
  
  struct UDConstants {
    
    
    var didAcceptPrivacy: Bool {
      get { return UD.bool(forKey: UserDefaults.Keys.didAcceptPrivacy) }
      set { UD.set(newValue, forKey: UserDefaults.Keys.didAcceptPrivacy) }
    }
    
      var isPurchased : Bool {
          get { return UD.bool(forKey: UserDefaults.Keys.isPurchased) }
          set { UD.set(newValue, forKey: UserDefaults.Keys.isPurchased) }
      }
    

//      var batchScanValue: Bool {
//          get { return UD.bool(forKey: "blockAdsSwitchValue") }
//          set { UD.set(newValue, forKey: "blockAdsSwitchValue") }
//      }
//
//      var vibrateValue: Bool {
//          get { return UD.bool(forKey: "blockSocialSwitchValue") }
//          set { UD.set(newValue, forKey: "blockSocialSwitchValue") }
//      }
//
//      var historyValue: Bool {
//          get { return UD.bool(forKey: "blockScriptsSwitchValue") }
//          set { UD.set(newValue, forKey: "blockScriptsSwitchValue") }
//      }
//
//      var dublicateScansValue: Bool {
//          get { return UD.bool(forKey: "blockTrackingSwitchValue") }
//          set { UD.set(newValue, forKey: "blockTrackingSwitchValue") }
//      }
//
      var currentDismis: Int? {
          set { UD.set(newValue, forKey: "currentDismis") }
          get { return UD.integer(forKey: "currentDismis") }
      }
            
      var guideCompleted: Bool {
                get { return UD.bool(forKey: "guideCompleted") }
                set { UD.set(newValue, forKey: "guideCompleted") }
            }
      
      var onboardingShow: Bool {
                get { return UD.bool(forKey: "onboardingShow") }
                set { UD.set(newValue, forKey: "onboardingShow") }
            }
      
      var firstFlag: Bool {
                get { return UD.bool(forKey: "firstFlag") }
                set { UD.set(newValue, forKey: "firstFlag") }
            }
      
      var totalScans: Int? {
          set { UD.set(newValue, forKey: "totalScans") }
          get { return UD.integer(forKey: "totalScans") }
      }
      
      var startCameraAtStartUp: Bool {
          get { return UD.bool(forKey: "startCameraAtStartUp") }
          set { UD.set(newValue, forKey: "startCameraAtStartUp") }
      }
      
      var allowGalleryPhotoEditing: Bool {
          get { return UD.bool(forKey: "allowGalleryPhotoEditing") }
          set { UD.set(newValue, forKey: "allowGalleryPhotoEditing") }
      }
      
  }
  
  static var country: String = {
    let locale: NSLocale = NSLocale(localeIdentifier: "en_US")
    if let countryCode = locale.object(forKey: NSLocale.Key.countryCode) as? String,
      let country = locale.displayName(forKey: NSLocale.Key.countryCode, value: countryCode) {
      print(country)
      return country
    }
    return "unsigned"
  }()
}


extension UserDefaults {
  enum Keys {
    static let isPurchased = "isPurchased"
    static let didLaunchingApp = "didLaunchingApp"
    static let trackingId = "trackingId"
    static let fbCampagneId = "fbCampagneId"
    static let campagneId = "campagneId"
    static let purchasePath = "purchasePath"
    static let purchasePathNotification = "purchasePathNotification"
    static let sessionFromTime = "sessionFromTime"
    static let dynamicProductsKey = "dynamicProductsKey"
    static let paramPref = "paramPref"
    static let sourceApp = "sourceApp"
    static let wasAF_SUB1 = "wasAF_SUB1"
    static let wasLaunchedBefore = "wasLaunchedBefore"
    static let wasFBDeeplink = "wasFBDeeplink"
    static let didAcceptPrivacy = "didAcceptPrivacy"
  }
  
  enum TestsKeys {
    static let notes_data = "notes_data"
    static let passwords_data = "passwords_data"
    static let albums_data = "albums_data"
    static let contacts_data = "contacts_data"
  }
  
}
