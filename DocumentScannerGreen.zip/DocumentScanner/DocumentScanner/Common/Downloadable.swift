import Foundation
import Alamofire

protocol Downloadable {
  func downloadLanguage(_ ocrTessDataURL: URL, languageName: String,
                        progressCompletion: @escaping (_ fractionCompleted: Float) -> (),
                        downloadCompletion: @escaping (_ succes: Bool, _ error: Error?) -> ())
}

extension Downloadable {
  
  func downloadLanguage(_ ocrTessDataURL: URL, languageName: String,
                        progressCompletion: @escaping (_ fractionCompleted: Float) -> (),
                        downloadCompletion: @escaping (_ succes: Bool, _ error: Error?) -> ()) {
    
    let tesseractURL = Config.DownloadLanguagesURL(languageName)
    let destination = DownloadRequest.suggestedDownloadDestination(for: .documentDirectory)
      

    
      Alamofire.download(tesseractURL, method: .get, parameters: nil,
                       encoding: JSONEncoding.default, headers: nil, to: destination).downloadProgress(closure: { (progress) in
                        let pr = progress.fractionCompleted
                        debugPrint(pr)
                        progressCompletion(Float(pr))
                       }).response(completionHandler: { (DefaultDownloadResponse) in
                        if let destinationURL = DefaultDownloadResponse.destinationURL {
                          if FileManager.default.fileExists(atPath: destinationURL.path) {
                            debugPrint(destinationURL)
                            do {
                              try FileManager.default.moveItem(at: destinationURL,
                                                               to: ocrTessDataURL.appendingPathComponent(destinationURL.lastPathComponent))
                              debugPrint(ocrTessDataURL)
                              downloadCompletion(true, nil)
                            } catch {
                              debugPrint("error = \(error.localizedDescription)")
                              downloadCompletion(false, error)
                            }
                          } else {
                            debugPrint("error to download")
                          }
                        }
                       })
  }
}

