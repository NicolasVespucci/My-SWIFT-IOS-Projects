//
//  DrawerCollectionViewCell.swift
//  DocScan
//
//  Created by Mister Grizzly on 8/30/20.
//

import UIKit

final class DrawerCollectionViewCell: UICollectionViewCell {
    
    static let ReuseIdentifier = String(describing: DrawerCollectionViewCell.self)
    
    @IBOutlet private var documentImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()        
        documentImageView.layer.cornerRadius = 7.0
        documentImageView.layer.borderWidth = 3.0
        documentImageView.layer.borderColor = "#118DFF".hexColor.cgColor
        documentImageView.backgroundColor = UIColor.init(white: 1.0, alpha: 0.1)
        documentImageView.clipsToBounds = true
    }
    
    func configure(with image: UIImage) {
        documentImageView.image = image
    }
}
