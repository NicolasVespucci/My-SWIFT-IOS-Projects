//
//  DrawerPresentationControllerDelegate.swift
//  DocScan
//
//  Created by Mister Grizzly on 8/30/20.
//

import Foundation

protocol DrawerPresentationControllerDelegate: class {
    func drawerMovedTo(position: DraweSnapPoint)
}

enum DraweSnapPoint {
    case top
    case middle
    case close
}
