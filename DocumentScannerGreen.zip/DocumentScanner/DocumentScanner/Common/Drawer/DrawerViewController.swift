//
//  DrawerViewController.swift
//  DocScan
//
//  Created by Mister Grizzly on 8/30/20.
//

import UIKit

/// DrawerViewControllerDelegate allows to pick an UIImage.
protocol DrawerViewControllerDelegate: AnyObject {
    /// Allows to pick an UIImage.
    func drawerController(controller: DrawerViewController, didSelect image: UIImage)
}

/// DrawerViewController is a DrawerPresentationController that allows
/// modals to be presented like a bottom sheet. The kind of presentation style
/// you can see on the Maps app on iOS.
/// A view controller that specializes in managing a collection view.
///
/// Return a DrawerViewControllerDelegate.
///
/// If you assign a new collection view object to this property and that view’s data source or
/// delegate are not yet set, the collection view controller makes itself the delegate or data source or both.
/// Xib setup.
final class DrawerViewController: UICollectionViewController {
    
    /// DrawerViewControllerDelegate
    weak var delegate: DrawerViewControllerDelegate?
    
    @IBOutlet private weak var gridLayout: GridLayout!
    
    private var images: [UIImage]
    
    /// Takes an array of UIImages
    convenience init(with images: [UIImage]) {
        self.init(nibName: String(describing: DrawerViewController.self), bundle: Bundle(for: DrawerViewController.self))
        self.images = images
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        self.images = []
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        self.images = []
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = false
        title = "Imported images"
        navigationItem.setRightBarButton(UIBarButtonItem(image: UIImage(named: "close"),
                                                         style: .plain, target: self,
                                                         action: #selector(buttonAction)), animated: true)
        navigationController?.navigationBar.isTranslucent = true
        
        setupColletionView()
    }
    
    @objc private func buttonAction() {
        self.dismiss(animated: true)
    }
    
    private func setupColletionView() {
        collectionView.contentInset.top = 20
        collectionView.verticalScrollIndicatorInsets.top = 20
        
        collectionView.register(UINib(nibName: DrawerCollectionViewCell.ReuseIdentifier,
                                      bundle: Bundle(for: DrawerViewController.self)),
                                forCellWithReuseIdentifier: DrawerCollectionViewCell.ReuseIdentifier)
        
        collectionView.delegate = self
        collectionView.dataSource = self
        
        gridLayout.delegate = self
        gridLayout.itemSpacing = 3
        gridLayout.fixedDivisionCount = 3
    }
}

/// The UICollectionViewDelegateFlowLayout protocol defines methods that let you coordinate with a UICollectionViewFlowLayout object to implement a grid-based layout.
/// The methods of this protocol define the size of items and the spacing between items in the grid.
extension DrawerViewController: UICollectionViewDelegateFlowLayout {
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return images.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: DrawerCollectionViewCell.ReuseIdentifier,
                                                            for: indexPath) as? DrawerCollectionViewCell, !images.isEmpty else { return UICollectionViewCell() }
        let image = images[indexPath.row]
        cell.configure(with: image)
        
        return cell
    }

    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard !images.isEmpty else { return }
        delegate?.drawerController(controller: self, didSelect: images[indexPath.row])
    }
}

extension DrawerViewController: GridLayoutDelegate {
    
    func scaleForItem(inCollectionView collectionView: UICollectionView, withLayout layout: UICollectionViewLayout, atIndexPath indexPath: IndexPath) -> UInt {
        if indexPath.row == 1 {
            return 2
        } else {
            return 1
        }
    }
    
    func itemFlexibleDimension(inCollectionView collectionView: UICollectionView, withLayout layout: UICollectionViewLayout, fixedDimension: CGFloat) -> CGFloat {
        return fixedDimension
    }
}
