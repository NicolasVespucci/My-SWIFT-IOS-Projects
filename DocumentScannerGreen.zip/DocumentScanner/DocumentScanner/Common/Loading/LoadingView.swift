/*
 Created by Mister Grizzly on 2019.
 Copyright © 2018 Mister Grizzly. All rights reserved.
 
 Permission is hereby granted, only to person who PURCHASED a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 1. The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 2. IF WILL BE DETECTED A PROJECT USED THIS SOURCE CODE WITHOUT COPYRIGHT OF BARCLOUDAPP.COM, YOU'LL LOST ALL YOUR RIGHT TO THIS SOURCE CODE.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 */

import UIKit

protocol LoadingViewDelegate: class {
  func didCalcelButtonTapped()
}

class LoadingView: UIView {
  
  private static let reuseIdentifier = String(describing: LoadingView.self)
  
  @IBOutlet private weak var containerView: UIView!
  @IBOutlet private weak var progressView: UIProgressView!
  
  @IBOutlet private weak var nameLabel: UILabel!
  @IBOutlet private weak var spinner: UIActivityIndicatorView!
  
  fileprivate var animationTimer: Timer!
  
  var bgColor: UIColor? {
    didSet {
      containerView.backgroundColor = bgColor
    }
  }
  
  func setTitle(_ title: String) {
    nameLabel.text = title
  }
  
  func setProgress(progress: Float) {
    progressView.isHidden = false
    progressView.setProgress(progress, animated: true)
    progressView.isHidden = progress == 100
  }
  
  weak var delegate: LoadingViewDelegate?
  
  // MARK: - Initializers
  
  override init(frame: CGRect) {
    super.init(frame: frame)
    setupViews()
  }
  
  required init?(coder aDecoder: NSCoder) {
    super.init(coder: aDecoder)
    setupViews()
  }
  
  override func layoutSubviews() {
    super.layoutSubviews()
    if let window = UIApplication.shared.windows.first {
      containerView.frame = window.bounds
    }
  }
  
  private func setupViews() {
    let bundle = Bundle(for: type(of: self))
    let nib = UINib(nibName: LoadingView.reuseIdentifier, bundle: bundle)
    containerView = nib.instantiate(withOwner: self, options: nil).first as? UIView
    addSubview(containerView)
    
    containerView.frame = self.bounds
    containerView.autoresizingMask = [.flexibleHeight, .flexibleWidth]
    
    nameLabel.textColor = UIColor(red: 0.00, green: 0.48, blue: 1.00, alpha: 1.00)
    nameLabel.font = UIFont.systemFont(ofSize: 17)
    containerView.backgroundColor = .clear
    
    spinner.sizeToFit()
    spinner.color = UIColor(red: 0.00, green: 0.48, blue: 1.00, alpha: 1.00)
    spinner.transform = CGAffineTransform(scaleX: 1.5, y: 1.5)
    
    progressView.tintColor = UIColor(red: 0.00, green: 0.48, blue: 1.00, alpha: 1.00)
  }
  
  @IBAction private func cancelTapped() {
    delegate?.didCalcelButtonTapped()
  }
}
