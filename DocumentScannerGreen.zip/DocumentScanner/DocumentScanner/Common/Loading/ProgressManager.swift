//
//  ProgressManager.swift
//  Project
//
//  Created by Mister Grizzly on 5/28/20.
//  Copyright © 2020 Mister Grizzly LLC. All rights reserved.
//

import UIKit

/**
 This is a class to mime a progress.
 */
class ProgressManager {
  
  /**
   An object that implements some complex visual effects.
   */
  private var visualEffectView = UIVisualEffectView()
  
  /**
   This is a method to start loading the spinner and add the blur view.
   */
  func startLoading(with title: String) {
    if let window = UIApplication.shared.windows.first {
      if !visualEffectView.isDescendant(of: window) {
        
        let blurEffect = UIBlurEffect(style: .light)
        visualEffectView = UIVisualEffectView(effect: blurEffect)
        visualEffectView.alpha = 0.0
        visualEffectView.frame = window.bounds
        
        visualEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        
        window.addSubview(visualEffectView)
        
        let loadingView = LoadingView(frame: window.bounds)
        loadingView.setTitle(title)
        loadingView.bgColor = .clear
        loadingView.accessibilityIdentifier = "loadingView"
        
        visualEffectView.contentView.addSubview(loadingView)
      }
    }
    
    UIView.animate(withDuration: 0.2, delay: 0,
                   options: [.curveEaseIn],
                   animations: { [unowned self] in
                    self.visualEffectView.alpha = 0.99
                   }, completion: nil)
  }
  
  /**
   This is a method to start loading the progress
   */
  func set(progress: Float) {
    if let loadingView = getLoadingView() {
      loadingView.setProgress(progress: progress)
    }
  }
  
  /**
   This is a method to stop loading the spinner and remove the blur view.
   */
  func stopLoading() {
    UIView.animate(withDuration: 0.2, delay: 0,
                   options: [.curveEaseIn],
                   animations: { [unowned self] in
                    self.visualEffectView.removeFromSuperview()
                   }, completion: nil)
  }
  
  private func getLoadingView() -> LoadingView? {
    return visualEffectView.contentView.subviews.first(where: { $0.accessibilityIdentifier == "loadingView" }) as? LoadingView
  }
}
