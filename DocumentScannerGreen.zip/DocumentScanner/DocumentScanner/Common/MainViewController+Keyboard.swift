//
//  MainViewController+Keyboard.swift
//  DocScan
//
//  Created by Mister Grizzly on 9/6/20.
//

import UIKit

extension ViewController {
  /// The key for an NSValue object containing a CGRect that identifies the ending frame rectangle of the keyboard in screen coordinates.
  /// The frame rectangle reflects the current orientation of the device.
//  @objc func keyboardWillShow(notification: NSNotification) {
//    if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
//      if self.view.frame.origin.y == 0 {
//        self.view.frame.origin.y -= keyboardSize.height
//      }
//    }
//  }
//  
//  /// Hide keyboard by setting the view frame origin to 0.
//  @objc func keyboardWillHide(notification: NSNotification) {
//    if self.view.frame.origin.y != 0 {
//      self.view.frame.origin.y = 0
//    }
//  }
}
