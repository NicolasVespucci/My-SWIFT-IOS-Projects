//
//  MainViewController+Transitioning.swift
//  DocScan
//
//  Created by Mister Grizzly on 9/6/20.
//

import UIKit

/// A set of methods that vend objects used to manage a fixed-length or interactive transition between view controllers.
extension ViewController: UIViewControllerTransitioningDelegate {
  /// Asks your delegate for the custom presentation controller to use for managing the view hierarchy when presenting a view controller.
  internal func presentationController(forPresented presented: UIViewController, presenting: UIViewController?,
                                       source: UIViewController) -> UIPresentationController? {
    return DrawerPresentationController(presentedViewController: presented, presenting: presenting,
                                        blurEffectStyle: .dark)
  }
}
