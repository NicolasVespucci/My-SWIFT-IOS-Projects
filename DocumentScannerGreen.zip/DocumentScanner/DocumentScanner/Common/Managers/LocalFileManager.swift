//
//  LocalFileManager.swift
//  iOCR
//
//  Created by Mister Grizzly on 9/18/20.
//  Copyright © 2020 Mister Grizzly LLC. All rights reserved.
//

import UIKit

final class LocalFileManager: UserDefaultable {
  
  private let fileManager = FileManager.default
  
  private var documentsDirectoryURL: URL {
    guard let documentsPathURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
      return URL(fileURLWithPath: NSTemporaryDirectory())
    }
    
    return documentsPathURL
  }
  
  var ocrTessDataURL: URL {
    return documentsDirectoryURL.appendingPathComponent(".ocrLanguages").appendingPathComponent("tessdata")
  }
  
  func fileExist(at url: URL) -> Bool {
    return fileManager.fileExists(atPath: url.path)
  }
  
  /// By default, we uploaded into tessdata folder the english language only, setupTessData method will create a hidded folder and move everything to it. And the final URL will be used for ocrTessDataURL's value.
  func setupTessData() {
    let url = Bundle.main.bundleURL.appendingPathComponent("tessdata")
    moveTessDataFolder(from: url) { success in
      print(success, #function)
    }
  }
  
  private func moveTessDataFolder(from bundleURL: URL, _ completion: (Bool) -> Void) {
    let tessDataFolderName = "tessdata"
    let tessDataBundleURL = bundleURL
    
    let documentsOCRLanguagesURL = documentsDirectoryURL.appendingPathComponent(".ocrLanguages")
    let documentsTessdataURL = documentsOCRLanguagesURL.appendingPathComponent(tessDataFolderName)
    
    if fileManager.fileExists(atPath: documentsTessdataURL.path) {
      completion(true)
      return
    }
    
    if !fileManager.fileExists(atPath: documentsOCRLanguagesURL.path) {
      do {
        try self.fileManager.createDirectory(atPath: documentsOCRLanguagesURL.path, withIntermediateDirectories: true, attributes: nil)
      } catch {
        print("error creation folder \(error.localizedDescription)")
        completion(false)
      }
    }
    
    if !fileManager.fileExists(atPath: documentsTessdataURL.path) {
      do {
        try self.fileManager.copyItem(at: tessDataBundleURL, to: documentsTessdataURL)
      } catch {
        print("error move folder \(error.localizedDescription)")
        completion(false)
      }
    }
    
    if userDefaultsGetValue(userDefaultsOCRIndexPath) == nil {
      self.userDefaultsSaveValue(Config.DefaultLanguageNumberAtFirstLaunch, key: userDefaultsOCRIndexPath)
    }
    
    completion(true)
  }
}
