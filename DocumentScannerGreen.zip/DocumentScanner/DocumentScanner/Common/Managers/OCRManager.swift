//
//  OCRManager.swift
//  DocScan
//
//  Created by Mister Grizzly on 12/14/20.
//
// https://www.raywenderlich.com/2010498-tesseract-ocr-tutorial-for-ios

import Foundation
import SwiftyTesseract
import UIKit

class LanguageBundle: LanguageModelDataSource {
  var pathToTrainedData: String
  
  init(pathToTrainedData: String) {
    self.pathToTrainedData = pathToTrainedData
  }
}

final class OCRManager: NSObject, Downloadable {
  
  let ocrTessDataURL: URL
  
  func fileExist(at url: URL) -> Bool {
    return fileManager.fileExist(at: url)
  }
  
  private let fileManager: LocalFileManager
  
  override init() {
    fileManager = LocalFileManager()
    ocrTessDataURL = fileManager.ocrTessDataURL
    super.init()
  }
  
  // Use this method - recognizes image, giving an array of languages(up to 3 maximum) and return an error and the text result.
  func recognize(image: UIImage, languages: [RecognitionLanguage],
                 completion: @escaping (Error?, String?) -> Void) {
    let tesseract = Tesseract(languages: languages,
                                    dataSource: LanguageBundle(pathToTrainedData: ocrTessDataURL.path),
                                    engineMode: .tesseractLstmCombined)
    

      
    let result = tesseract.performOCRPublisher(on: image).sink { result in
      switch result {
      case .failure(let error):
        completion(error, nil)
      case .finished:
        debugPrint("finished", result)
      }
    } receiveValue: { text in
      completion(nil, text)
    }
    
    result.cancel()
  }
  
  /// downloadFileSync uses alamofire to download the language from github or your own hosting by using a lanuage name only. Under the hood, the ocrTessDataURL will be Called
  /// which is an url where all the OCR languages are saved and downloaded.
  func downloadFileSync(_ fileName: String,
                        progressCompletion: @escaping (_ fractionCompleted: Float) -> (),
                        downloadCompletion: @escaping (_ succes: Bool, _ error: Error?) -> ()) {
    downloadLanguage(ocrTessDataURL, languageName: fileName, progressCompletion: progressCompletion,
                     downloadCompletion: downloadCompletion)
  }
}
