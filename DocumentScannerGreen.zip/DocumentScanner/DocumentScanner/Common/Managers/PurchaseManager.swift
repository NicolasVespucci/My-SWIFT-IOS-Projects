////
////  IAPManager.swift
////  DocScan
////
////  Created by Mister Grizzly on 9/6/20.
////
//
//import Foundation
//import StoreKit
//
//final class Persistance {
//  
//  static let shared = Persistance()
//  
//  private let keyTransaction = "DocScanFullVersion"
//  private let rewardVideoNumberKey = "rewardVideoNumberKey"
//  
//  var isProVersion: Bool {
//    set {
//      UserDefaults.standard.set(newValue, forKey: keyTransaction)
//      UserDefaults.standard.synchronize()
//    } get {
//      return UserDefaults.standard.bool(forKey: keyTransaction)
//    }
//  }
//  
//  var rewardVideoNumber: Int {
//    set {
//      UserDefaults.standard.set(newValue, forKey: rewardVideoNumberKey)
//      UserDefaults.standard.synchronize()
//    } get {
//      return (UserDefaults.standard.value(forKey: rewardVideoNumberKey) as? Int) ?? 0
//    }
//  }
//}
//
//final class PurchaseManager: NSObject {
//  
//  static let shared = PurchaseManager()
//  
//  private override init() { }
//  
//  var products: [SKProduct] = []
//  let paymentQueue = SKPaymentQueue.default()
//  
//  func setupPurchases(callback: @escaping(Bool) -> ()) {
//    if SKPaymentQueue.canMakePayments() {
//      paymentQueue.add(self)
//      callback(true)
//      return
//    }
//    callback(false)
//  }
//  
//  func getProducts() {
//    let identifiersProduct: Set = [
//      Config.IAP.premiumUnlimitedSubscription.rawValue
//    ]
//    
//    let request = SKProductsRequest(productIdentifiers: identifiersProduct)
//    request.delegate = self
//    request.start()
//  }
//  
//  func purchase(productWith identifier: String) {
//    guard let product = products.filter({ $0.productIdentifier == identifier }).first else { return }
//    let payment = SKPayment(product: product)
//    paymentQueue.add(payment)
//  }
//  
//  func restoreCompletedTransactions() {
//    paymentQueue.restoreCompletedTransactions()
//  }
//  
//  func isProVersionActive() -> Bool {
//    return Persistance.shared.isProVersion
//  }
//}
//
//extension PurchaseManager:SKPaymentTransactionObserver {
//  func paymentQueue(_ queue: SKPaymentQueue, updatedTransactions transactions: [SKPaymentTransaction]) {
//    for transaction in transactions {
//      switch transaction.transactionState {
//      case .deferred: break
//      case .purchasing: break
//      case .failed: failed(transaction: transaction)
//      case .purchased: completed(transaction: transaction)
//      case .restored: restored(transaction: transaction)
//      @unknown default:
//        print("error")
//      }
//    }
//  }
//  
//  private  func failed(transaction: SKPaymentTransaction) {
//    if let transactionError = transaction.error as NSError? {
//      if transactionError.code != SKError.paymentCancelled.rawValue {
//        print("Transaction failed: \(transaction.error!.localizedDescription)")
//      }
//    }
//    Persistance.shared.isProVersion = false
//    NotificationCenter.default.post(name: NSNotification.Name.IAPReloadUI, object: nil)
//    paymentQueue.finishTransaction(transaction)
//  }
//  
//  private func completed(transaction: SKPaymentTransaction) {
//    paymentQueue.finishTransaction(transaction)
//    Persistance.shared.isProVersion = true
//    NotificationCenter.default.post(name: .IAPReloadUI, object: nil)
//    
////    if Config.ShowConfettiAfterPurchase {
////      NotificationCenter.default.post(name: .ShowConfettiOnPremiumPurchase, object: nil)
////    }
//  }
//  
//  private func restored(transaction: SKPaymentTransaction) {
//    
//    guard (transaction.original?.payment.productIdentifier) != nil else { return }
//    
//    Persistance.shared.isProVersion = true
//    NotificationCenter.default.post(name: NSNotification.Name.IAPReloadUI, object: nil)
//    paymentQueue.finishTransaction(transaction)
//  }
//  
//  func showRateController() {
//    let maximNumberOfScans = Persistance.shared.rewardVideoNumber
//    
//    #if targetEnvironment(simulator)
//    #else
//    if maximNumberOfScans == 2 {
//      SKStoreReviewController.requestReview()
//    }
//    #endif
//  }
//}
//
//extension PurchaseManager: SKProductsRequestDelegate {
//  func productsRequest(_ request: SKProductsRequest, didReceive response: SKProductsResponse) {
//    self.products = response.products
//    products.forEach { print($0.localizedTitle) }
//    
//    if products.count > 0 {
//      NotificationCenter.default.post(name: NSNotification.Name.IAPProductNotificationIdentifier, object: nil)
//    }
//  }
//}
//
//extension NSNotification.Name {
//  static let IAPProductNotificationIdentifier = NSNotification.Name("IAPManagerProductIdentifier")
//  static let IAPReloadUI = NSNotification.Name("IAPManagerReloadUI")
//  static let ReloadLanguage = NSNotification.Name("ReloadLanguage")
//}
