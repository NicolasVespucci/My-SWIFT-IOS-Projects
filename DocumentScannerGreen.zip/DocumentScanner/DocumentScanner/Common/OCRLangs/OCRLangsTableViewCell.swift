import UIKit

final class OCRLangsTableViewCell: UITableViewCell {
  
  // MARK: - Properties
    var nameLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15, weight: .semibold)
        label.textAlignment = .left
        label.textColor = .black
        label.text = "GGGGGGGG"
        return label
    }()
    
    var downloadButton: UIButton = {
        let button = UIButton()
        return button
    }()
    
    var spinner: UIActivityIndicatorView = {
        let spinner = UIActivityIndicatorView()
        return spinner
    }()
    
    override func layoutSubviews() {
      super.layoutSubviews()
        selectionStyle = .none
      configure()
    }
    
    private func configure() {
        addSubviews(nameLabel, downloadButton, spinner)
        
        nameLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.height.equalTo(25)
            make.leading.equalToSuperview().offset(15)
            make.trailing.equalToSuperview()
        }
        
        downloadButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-39)
            make.size.equalTo(20)
        }
        
        spinner.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-39)
            make.size.equalTo(20)
        }
    }
    
  static let reuseIdentifier = "OCRLangsTableViewCell"
    static var identifier: String { return String(describing: self) }
  
  static let downloadImageDone = UIImage(systemName: "circle")?.tint(with: UIColor(red: 0.00, green: 0.48, blue: 1.00, alpha: 0.50))
  static let downloadImageNew = UIImage(named: "downIcon")
  
  var isDownloaded: Bool = false {
    didSet {
      if isDownloaded {
        downloadButton.setImage(OCRLangsTableViewCell.downloadImageDone, for: .normal)
        downloadButton.imageView?.image = downloadButton.imageView?.image?.tint(with: .gray)
          nameLabel.textColor = UIColor.gray
          nameLabel.font = UIFont.boldSystemFont(ofSize: 18)
          spinner.stopAnimating()
      } else {
        downloadButton.setImage(OCRLangsTableViewCell.downloadImageNew, for: .normal)
          nameLabel.textColor = "#404147".hexColor
      }
    }
  }
}
