import UIKit
import SwiftyTesseract
import RxSwift

class OCRLangsViewController: UIViewController, UserDefaultable {
    
  let disposeBag = DisposeBag()
    
  struct ConstantsLocal {
    static let reuseIdentifier = String(describing: OCRLangsViewController.self)
    static let storyboardName = "OCRLanguages"
    static let title = "Select language"
    static let languageExtension = ".traineddata"
  }
    
   var ocrManager: OCRManager?
  
    private var backButton: UIButton = {
        let button = UIButton()
        button.setTitle("Back", for: .normal)
        button.setTitleColor("827C7C".hexColor, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 18, weight: .regular)
        button.layer.cornerRadius = 13
        button.backgroundColor = "FAFAFB".hexColor
        button.addTarget(self, action: #selector(doneTapped), for: .touchUpInside)
        return button
    }()
    
    
    private var topLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 20, weight: .regular)
        label.textAlignment = .center
    
        label.text = "Select language"
        label.textColor = "2E2E2E".hexColor
        return label
    }()
    
    private var tableView: UITableView = {
        let table = UITableView()
        table.separatorStyle = .singleLine
        table.separatorColor = "D7D8DB".hexColor
        table.rowHeight = 48
        table.isScrollEnabled = true
        table.backgroundColor = .clear
        return table
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupLayout()
        setupTable()
        
        debugPrint("languages = \(RecognitionLanguage.allLanguages().count)")
        ocrManager = OCRManager()
        
        /// Set english by default
        if userDefaultsGetValue(userDefaultsOCRIndexPath) == nil {
            userDefaultsSaveValue(Config.DefaultLanguageNumberAtFirstLaunch, key: userDefaultsOCRIndexPath)
        }
    }
  
  deinit {
    ocrManager = nil
  }

    private func setupTable(){
            tableView.register(OCRLangsTableViewCell.self, forCellReuseIdentifier: OCRLangsTableViewCell.identifier)
            tableView.delegate = self
            tableView.dataSource = self
    }
    
    private func setupLayout() {
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = .white
        view.addSubviews(backButton,topLabel, tableView)
        
        backButton.snp.makeConstraints { make in
            make.width.equalTo(76)
            make.height.equalTo(48)
            make.top.equalToSuperview().offset(40)
            make.leading.equalToSuperview().offset(16)
        }
        
        topLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(53)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(23)
        }
        
        tableView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(106)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        backButton.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.1).cgColor
        backButton.layer.shadowOffset = CGSize(width: 0.0, height: 4.0)
        backButton.layer.shadowOpacity = 1
        backButton.layer.shadowRadius = 4
        backButton.layer.masksToBounds = false
    }

  

  
  @objc func downloadLanguageButtonTapped(_ sender: UIButton) {
    let indexPath = IndexPath(row: sender.tag, section: 0)
    let language = RecognitionLanguage.allLanguages()[indexPath.row]
    let paramForDownload = language.description
    
    if let cell = self.tableView.cellForRow(at: indexPath) as? OCRLangsTableViewCell {
      if let ocrManager = ocrManager {
        let filePath = ocrManager.ocrTessDataURL.appendingPathComponent(paramForDownload + ConstantsLocal.languageExtension)
          if(Constants.ud.isPurchased){
              if ocrManager.fileExist(at: filePath) {
                cell.downloadButton.addTarget(self, action: #selector(selectLanguageTapped(_:)), for: .touchUpInside)
              } else {
                  cell.spinner.startAnimating()
                self.showHud(with: "Downloading" + " \(language.name) " + "language")
                  cell.downloadButton.isHidden = true
                
                let tesseractLanguage = paramForDownload
                debugPrint(tesseractLanguage)
                ocrManager.downloadFileSync(paramForDownload, progressCompletion: { fractionCompleted in
                  self.set(progress: fractionCompleted)
                }, downloadCompletion: { [weak self] (success, error) in
                  if success {
                    self?.hideHud()
                    cell.isDownloaded = true
                    cell.spinner.stopAnimating()
                    cell.downloadButton.isHidden = false
                    self?.tableView.reloadData()
                    self?.showAlert(message: "Downloaded" + " \(language.name) " + "language")
                    
                    UIView.animate(withDuration: 0.33) {
                      cell.backgroundColor = UIColor.darkGray.withAlphaComponent(0.2)
                    } completion: { success in
                      if success {
                        cell.backgroundColor = .black
                      }
                    }
                  }
                })
              }
          } else {
              IAPManager.shared().presentSingleSubscriptionVC()
              IAPManager.shared().purchaseCompletion = { subscription in
                  if Constants.ud.isPurchased {
                      IAPManager.shared().dismissSubscriptionVC()
                  }
              }
              IAPManager.shared().restoreCompletion = { subscription in
                  if Constants.ud.isPurchased {
                      IAPManager.shared().dismissSubscriptionVC()
                  }
              }
          }
      }
    }
  }
  
  @objc func selectLanguageTapped(_ sender: UIButton) {
    let indexPath = IndexPath(row: sender.tag, section: 0)
    debugPrint(indexPath.row)
    userDefaultsSaveValue(indexPath.row, key: userDefaultsOCRIndexPath)
    tableView.reloadData()
    let language = RecognitionLanguage.allLanguages()[indexPath.row]
    let languageName = language.name    
    showAlert(message: "\(languageName) " + "language was successfully set to default.")
  }
  
  @objc func doneTapped() {
    dismiss(animated: true)
  }
}


extension OCRLangsViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      return RecognitionLanguage.allLanguages().count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: OCRLangsTableViewCell.identifier, for: indexPath) as? OCRLangsTableViewCell else { return UITableViewCell() }
        
      let language = RecognitionLanguage.allLanguages()[indexPath.row]
      
      cell.nameLabel.text = language.name
      cell.downloadButton.tag = indexPath.row
      cell.nameLabel.font = UIFont.systemFont(ofSize: 17)
      
      let paramForDownload = language.description
      
      if let ocrManager = ocrManager {
        let filePath = ocrManager.ocrTessDataURL.appendingPathComponent(paramForDownload + ".traineddata")
        if ocrManager.fileExist(at: filePath) {
          cell.isDownloaded = true
          cell.downloadButton.addTarget(self, action: #selector(selectLanguageTapped(_:)), for: .touchUpInside)
        } else {
          cell.isDownloaded = false
            cell.downloadButton.addTarget(self, action: #selector(downloadLanguageButtonTapped(_:)), for: .touchUpInside)
        }
      }
      
      if let index = self.userDefaultsGetValue(userDefaultsOCRIndexPath) as? Int {
        if indexPath.row == index && cell.isDownloaded {
          cell.downloadButton.setTitle("", for: .normal)
          cell.downloadButton.setImage(UIImage(systemName: "checkmark.circle.fill")?.tint(with: UIColor(red: 0.00, green: 0.48, blue: 1.00, alpha: 1.00)), for: .normal)
            cell.nameLabel.textColor = UIColor(red: 0.00, green: 0.48, blue: 1.00, alpha: 1.00)
            cell.nameLabel.font = UIFont.boldSystemFont(ofSize: 21)
        } else if cell.isDownloaded {
          cell.downloadButton.setImage(OCRLangsTableViewCell.downloadImageDone, for: .normal)
          cell.downloadButton.imageView?.tintColor = UIColor(red: 0.00, green: 0.48, blue: 1.00, alpha: 1.00)
        } else {
          cell.downloadButton.setTitleColor(UIColor.darkGray.withAlphaComponent(0.5), for: .normal)
          cell.downloadButton.setImage(OCRLangsTableViewCell.downloadImageNew, for: .normal)
          cell.downloadButton.imageView?.tintColor = UIColor(red: 0.00, green: 0.48, blue: 1.00, alpha: 1.00)
        }
      }
      
      return cell
    }
    
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
      return "\(RecognitionLanguage.allLanguages().count) languages"
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
      return 30
    }
    
}

extension OCRLangsViewController: UITableViewDelegate {
    
}

