//
//  SettingsTableViewCell.swift
//  DocScan
//
//  Created by Mister Grizzly on 9/22/20.
//

import UIKit
import SnapKit

enum SettingsType: String {
  case url, none, contact, share, restore
}

struct SettingsViewModel {
  let imageName: String
  let title: String
  
  var isSwitchOn = false
  var isSwitcherOn: ((Bool) -> Void)? = nil
  
  var isSwitchHidden = true
  var urlString: String? = nil
  var type = SettingsType.none
}

final class SettingsTableViewCell: UITableViewCell {
  
  static let ReuseIdentifier = String(describing: SettingsTableViewCell.self)

//  @IBOutlet private weak var imgView: UIImageView!
//  @IBOutlet private weak var nameLabel: UILabel!
//  @IBOutlet private weak var settingsSwitch: UISwitch!
    
    var imgView : UIImageView = {
       var img = UIImageView()
        
        return img
    }()
    
    var nameLabel : UILabel = {
       var label = UILabel()
        label.textAlignment = .left
        label.textColor = "#404147".hexColor
        label.font = .systemFont(ofSize: 16, weight: .regular)
        return label
    }()
    
    var settingsSwitch : UISwitch = {
       var switchh = UISwitch()
        switchh.onTintColor = "#118DFF".hexColor
        switchh.addTarget(self, action:#selector(didTapSwitching(_:)), for: .valueChanged)
        return switchh
    }()
    
  private var isSwitcherOn: ((Bool) -> Void)?
  
  override func awakeFromNib() {
    super.awakeFromNib()
    // Initialization code
    imgView.tintColor = UIColor(red: 0.00, green: 0.48, blue: 1.00, alpha: 1.00)
      
    
      
  }
  
  func configure(with viewModel: SettingsViewModel) {
      
      addSubview(imgView)
      
    imgView.snp.makeConstraints { make in
            make.size.equalTo(24)
            make.leading.equalToSuperview().offset(16)
            make.centerY.equalToSuperview()
        }
      
      addSubview(nameLabel)
      
      nameLabel.snp.makeConstraints { make in
          make.centerY.equalToSuperview()
          make.leading.equalTo(imgView.snp.trailing).offset(8)
          make.height.equalTo(24)
      }
      
      addSubview(settingsSwitch)
      
      settingsSwitch.snp.makeConstraints { make in
          make.centerY.equalToSuperview()
          make.trailing.equalToSuperview().offset(-17)
          make.width.equalTo(51)
          make.height.equalTo(31)
      }
      
    imgView.image = UIImage(named: viewModel.imageName)
    nameLabel.text = viewModel.title
    settingsSwitch.isOn = viewModel.isSwitchOn
    settingsSwitch.isHidden = viewModel.isSwitchHidden
    isSwitcherOn = viewModel.isSwitcherOn
  }
  
  @objc private func didTapSwitching(_ sender: UISwitch) {
    isSwitcherOn?(sender.isOn)
  }
}
