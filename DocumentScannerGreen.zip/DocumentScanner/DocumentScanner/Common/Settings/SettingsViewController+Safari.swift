//
//  SettingsViewController+Safari.swift
//  DocScan
//
//  Created by Mister Grizzly on 9/6/20.
//

import UIKit
import SafariServices

//extension SettingsViewController {
//  /// Shows SFSafariViewController
//  /// entersReaderIfAvailable - A value that specifies whether Safari should enter Reader mode, if it is available.
//  func presentSafariController(with urlString: String) {
//    guard let url = URL(string: urlString) else { return }
//    let config = SFSafariViewController.Configuration()
//    config.entersReaderIfAvailable = true
//    
//    let vc = SFSafariViewController(url: url, configuration: config)
//    present(vc, animated: true)
//  }
//}


extension UIViewController {
  /// Shows SFSafariViewController
  /// entersReaderIfAvailable - A value that specifies whether Safari should enter Reader mode, if it is available.
  func presentSafariController(with urlString: String) {
    guard let url = URL(string: urlString) else { return }
    let config = SFSafariViewController.Configuration()
    config.entersReaderIfAvailable = true
    
    let vc = SFSafariViewController(url: url, configuration: config)
    present(vc, animated: true)
  }
}
