import UIKit
import SnapKit
import RxSwift
import RxCocoa
import MessageUI

final class SettingsViewController: UIViewController, MFMailComposeViewControllerDelegate {
  
  private var viewModels: [SettingsViewModel] = []
  
    let disposeBag = DisposeBag()
    
    private var topSettingsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 20, weight: .regular)
        label.text = "Settings"
        label.textAlignment = .center
        label.textColor = "2E2E2E".hexColor
        return label
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setTitle("Back", for: .normal)
        button.setTitleColor("827C7C".hexColor, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 18, weight: .regular)
        button.layer.cornerRadius = 13
        button.backgroundColor = "FAFAFB".hexColor
        button.addTarget(self, action: #selector(doneTapped), for: .touchUpInside)
        return button
    }()
    
    var emptyTopSettingsView: UIView = {
        let view = UIView()
        view.addBorder(width: 1, color: "D7D8DB")
        view.layer.cornerRadius = 15
        return view
    }()
    
    private var allowGalleryPhotoEditingLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.text = "Allow gallery photo editing"
        label.textAlignment = .center
        label.textColor = "404147".hexColor
        return label
    }()
    
    private var startCameraAtStartUpLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.text = "Start camera at start up"
        label.textAlignment = .center
        label.textColor = "404147".hexColor
        return label
    }()
    
    private var AllowGalleryPhotoEditingSwitch: UISwitch = {
        let slender = UISwitch()
        slender.onTintColor = "1EB780".hexColor
        slender.isOn = Constants.ud.allowGalleryPhotoEditing
        slender.addTarget(self, action:#selector(TapSwitching(_:)), for: .touchUpInside)
        return slender
    }()
    
    private var StartCameraAtStartUpSwitch: UISwitch = {
        let slender = UISwitch()
        slender.onTintColor = "1EB780".hexColor
        slender.isOn = Constants.ud.startCameraAtStartUp
        slender.addTarget(self, action:#selector(Tap2Switching(_:)), for: .touchUpInside)
        return slender
    }()
    
    var emptyTableSettingsView: UIView = {
        let view = UIView()
        view.addBorder(width: 1, color: "D7D8DB")
        view.layer.cornerRadius = 15
        return view
    }()
    
    var tableView: UITableView = {
        let table = UITableView()
        table.backgroundColor = .white
        table.rowHeight = 48
        table.separatorInset.left = 48
        table.separatorColor = "D7D8DB".hexColor
        table.showsVerticalScrollIndicator = false
        table.isScrollEnabled = false
//        table.tableFooterView = UIView(frame: CGRect(x: 0, y: 0, width: table.frame.size.width, height: 1))
        return table
    }()
    
    var emptyBlueView: UIView = {
        let view = UIView()
        view.backgroundColor = "0066FF".hexColor
        view.layer.cornerRadius = 12
        return view
    }()
    
    var premimImageView: UIImageView = {
        let imageView = UIImageView(image: "getPremium".image)
        imageView.contentMode = .scaleAspectFill
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    var premiumLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .bold)
        label.textAlignment = .left
        label.textColor = .white
        label.text = "Upgrade \nto premium"
        label.numberOfLines = 2
        return label
    }()

    var purchaseButton : UIButton = {
       var button = UIButton()
        return button
    }()
    
    @objc private func TapSwitching(_ sender: UISwitch) {
        Constants.ud.allowGalleryPhotoEditing = !Constants.ud.allowGalleryPhotoEditing
        AllowGalleryPhotoEditingSwitch.isOn = Constants.ud.allowGalleryPhotoEditing
        if !IAPManager.shared().isPurchased {
            AllowGalleryPhotoEditingSwitch.isOn = false
            Constants.ud.allowGalleryPhotoEditing = false
            IAPManager.shared().presentSingleSubscriptionVC()
            IAPManager.shared().purchaseCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                    Constants.ud.allowGalleryPhotoEditing = true
                    self.emptyBlueView.isHidden = true
                }
            }
            IAPManager.shared().restoreCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                    Constants.ud.allowGalleryPhotoEditing = true
                    self.emptyBlueView.isHidden = true
                }
            }
         
        }
    }
    
    @objc private func Tap2Switching(_ sender: UISwitch) {
        Constants.ud.startCameraAtStartUp = !Constants.ud.startCameraAtStartUp
        StartCameraAtStartUpSwitch.isOn = Constants.ud.startCameraAtStartUp
    }
    
    override func viewDidLoad() {
    super.viewDidLoad()
        view.backgroundColor = .white
        view.addSubviews(backButton, topSettingsLabel, emptyTopSettingsView, emptyTableSettingsView, emptyBlueView)
        emptyBlueView.addSubviews(premimImageView, premiumLabel)
        premimImageView.addSubview(purchaseButton)
        emptyTableSettingsView.addSubviews(tableView)
        
        emptyTopSettingsView.addSubviews(allowGalleryPhotoEditingLabel, AllowGalleryPhotoEditingSwitch, startCameraAtStartUpLabel, StartCameraAtStartUpSwitch)
        
        backButton.snp.makeConstraints { make in
            make.width.equalTo(76)
            make.height.equalTo(48)
            make.top.equalToSuperview().offset(40)
            make.leading.equalToSuperview().offset(16)
        }
        
        topSettingsLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(53.resized())
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(23)
        }
        
        emptyTopSettingsView.snp.makeConstraints { make in
            make.top.equalTo(topSettingsLabel.snp.bottom).offset(33.resized())
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(127)
        }
        
        allowGalleryPhotoEditingLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(26)
            make.leading.equalToSuperview().offset(17)
            make.height.equalTo(24)
        }
        
        AllowGalleryPhotoEditingSwitch.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(22)
            make.trailing.equalToSuperview().offset(-16)
            make.width.equalTo(51)
            make.height.equalTo(31)
        }
        
        startCameraAtStartUpLabel.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-25)
            make.leading.equalToSuperview().offset(17)
            make.height.equalTo(24)
        }
        
        StartCameraAtStartUpSwitch.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-22)
            make.trailing.equalToSuperview().offset(-16)
            make.width.equalTo(51)
            make.height.equalTo(31)
        }
        
        emptyTableSettingsView.snp.makeConstraints { make in
            make.top.equalTo(emptyTopSettingsView.snp.bottom).offset(13.resized())
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(272)
        }
        
        tableView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(16)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview().offset(-16)
        }
        
        emptyBlueView.snp.makeConstraints { make in
            make.top.equalTo(emptyTableSettingsView.snp.bottom).offset(14.resized())
            make.height.equalTo(120)
            make.width.equalTo(311)
            make.centerX.equalToSuperview()
        }
        
        premiumLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.height.equalTo(64)
            make.width.equalTo(130)
            make.trailing.equalToSuperview().offset(-27)
        }
        
        premimImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        purchaseButton.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        purchaseButton.rx.tap.bind { [weak self] in
            IAPManager.shared().presentSubscriptionVC()
            IAPManager.shared().purchaseCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                    self?.emptyBlueView.isHidden = true
                }
            }
            IAPManager.shared().restoreCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                    self?.emptyBlueView.isHidden = true
                }
            }
        }.disposed(by: disposeBag)
    // Do any additional setup after loading the view.
    setupViewModels()
  }
    
    override func viewWillAppear(_ animated: Bool) {
        if(Constants.ud.isPurchased){
            emptyBlueView.isHidden = true
        }
    }
    
    @objc func doneTapped() {
      dismiss(animated: true)
    }
    
  private func setupViewModels() {
      navigationController?.isNavigationBarHidden = true

    let privacy = SettingsViewModel(imageName: "privacy", title: "Privacy Policy", urlString: Config.Settings.privacy.rawValue, type: .url)
    let terms = SettingsViewModel(imageName: "terms", title: "Terms & Conditions", urlString: Config.Settings.terms.rawValue, type: .url)
    
      let contact = SettingsViewModel(imageName: "contact", title: "Contact support", urlString: Config.Settings.privacy.rawValue, type: .contact)
      let share = SettingsViewModel(imageName: "share", title: "Share app", urlString: Config.Settings.terms.rawValue, type: .share)
      
      let restore = SettingsViewModel(imageName: "restore", title: "Restore purchases", urlString: Config.Settings.terms.rawValue, type: .restore)
      
    viewModels = [privacy, terms, contact, restore, share]
    tableView.delegate = self
    tableView.dataSource = self
    tableView.register(SettingsTableViewCell.self, forCellReuseIdentifier: SettingsTableViewCell.nibIdentifier)
  }
    
    func shareButtonAction(message: String, link: String) {
        if let link = NSURL(string: link) {
            let objectsToShare = [message,link] as [Any]
            let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            self.present(activityVC, animated: true, completion: nil)
        }
    }
  
     func contact() {
        print("contact pressed")
        if MFMailComposeViewController.canSendMail() {
            let mail = MFMailComposeViewController()
            mail.mailComposeDelegate = self
            mail.setToRecipients(["support@docuscreen-app.com"])
            present(mail, animated: true)
        } else {
            AlertManager.shared().showCustom(message: "Configure your email in Mail application")
        }
    }
    
    private func restore() {
        if Constants.ud.isPurchased {
            AlertManager.shared().showNoPurchasesToRestore()
        } else {
            IAPManager.shared().restore()
            IAPManager.shared().restoreCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                    AlertManager.shared().showPurchasesWereRestored()
                    self.tableView.reloadData()
                }
            }
        }
    }
}

extension SettingsViewController : UITableViewDataSource {
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      return viewModels.count
    }
    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      guard let cell = tableView.dequeueReusableCell(withIdentifier: SettingsTableViewCell.nibIdentifier,
                                                     for: indexPath) as? SettingsTableViewCell else {
        return UITableViewCell()
      }
         
         if indexPath.row == (viewModels.count - 1) {
             cell.separatorInset.left = UIScreen.main.bounds.width
         }
         
        cell.configure(with: viewModels[indexPath.row])
        cell.selectionStyle = .none
      return cell
    }
}

extension SettingsViewController : UITableViewDelegate {

     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      let viewModel = viewModels[indexPath.row]
      switch viewModel.type {
      case .url:
        guard let urlString = viewModel.urlString else { return }
        presentSafariController(with: urlString)
      case .contact:
          self.contact()
      case .share:
          self.shareButtonAction(message: "Pro PDF-scanner", link: "https://apps.apple.com/us/app/pro-pdf-scanner/id1620159926")
      case .restore:
          self.restore()
      default:
        break
      }
    }
}

extension UIView {
    func addBorder(width: CGFloat, color: String, withAlphaComponent: CGFloat? = nil) {
        layer.borderWidth = width
        layer.borderColor = color.hexColor.withAlphaComponent(withAlphaComponent ?? 1.0).cgColor
    }
}
