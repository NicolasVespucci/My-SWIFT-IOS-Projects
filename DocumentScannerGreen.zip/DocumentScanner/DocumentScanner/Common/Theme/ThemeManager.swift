//
//  ThemeManager.swift
//  DocScan
//
//  Created by Mister Grizzly on 8/30/20.
//

import UIKit

final class ThemeManager {
  
  static let shared = ThemeManager()
  
  /// Setups the appearance proxy for the UINavigationBar, UIToolbar and UIButton.
  func setupTheme() {
    let navigationBarAppearace = UINavigationBar.appearance()
    
    navigationBarAppearace.tintColor = .tintColor
    navigationBarAppearace.barTintColor = .barTintColor
    
    let toolBarAppearace = UIToolbar.appearance()
    
    toolBarAppearace.tintColor = .tintColor
    toolBarAppearace.barTintColor = .barTintColor
    
    let buttonAppearance = UIButton.appearance()
    buttonAppearance.tintColor = .tintColor
  }
  
  func setAppIcon() {
    _ = Timer.scheduledTimer(timeInterval: 0.33, target: self,
                             selector: #selector(setIcon), userInfo: nil,
                             repeats: false)
  }
  
  @objc private func setIcon() {
    if UIApplication.shared.supportsAlternateIcons {
      let appIconManager = AppIconManager()
      
      if PurchaseManager.shared.isProVersionActive() {
        if UIApplication.shared.alternateIconName != "glyph" {
          appIconManager.lc_setAlternateIconName("glyph")
        }
      } else {
        if UIApplication.shared.alternateIconName != "fade" {
          appIconManager.lc_setAlternateIconName("fade")
        }
      }
    }
  }
}

extension UIColor {
  class var tintColor: UIColor {
    if UIScreen.isDarkMode {
      return .white
    } else {
      return .darkText
    }
  }
  
  class var barTintColor: UIColor {
    if UIScreen.isDarkMode {
      return .darkText
    } else {
      return .white
    }
  }
}

extension UIScreen {
  static var isDarkMode: Bool {
    return main.traitCollection.userInterfaceStyle == .dark
  }
}

extension UIDevice {
  static var isSimulator: Bool {
    #if targetEnvironment(simulator)
    return true
    #else
    return false
    #endif
  }
}
