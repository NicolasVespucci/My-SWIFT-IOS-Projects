//
//  Config.swift
//  DocScan
//
//  Created by Mister Grizzly on 9/5/20.
//

import Foundation

struct Config {
  
  // Privacy policies and term links
  enum Settings: String {
    case terms = "https://docuscreen-app.com/terms.html"
    case privacy = "https://docuscreen-app.com/policy.html"
  }

//  // In app purchases
//  enum IAP: String {
//    // Change this value to your own, just create a Non-Consumable App Store subscription.
//    case premiumUnlimitedSubscription = "com.verst.weekly"
//  }
//
//  /// Replace all values to yours.
//  enum ADMob: String {
//    case bannerID = "ca-app-pub-3940256099942544/2934735716"
//    case rewardVideoAD2 = "ca-app-pub-3940256099942544/1712485313"
//  }
//
  struct LiteVersionChecks {
    // Maximum number of free scans - set your own value
    static let MaximumNumberOfFreeScans = 12
  }
  
//  enum PushNotificationsOneSignal: String {
//    // Replace 'YOUR_ONESIGNAL_APP_ID' with your OneSignal App ID.
//    case appID = "YOUR_ONESIGNAL_APP_ID"
//  }
  
  /// Set to false if you don't want to show confetti after purchase.
//  static let ShowConfettiAfterPurchase = false
//
//  /// Show tooltips at start
//  static let ShowTooltipsAtStart = true
  
  // OCR language
  /// Upload ocr languges to your own server and change the url in the same format to specify the languageName parameter inside,
  static func DownloadLanguagesURL(_ languageName: String) -> URL {
    return URL(string: "https://raw.githubusercontent.com/tesseract-ocr/tessdata/master/\(languageName).traineddata")!
  }
  
  /// By default we have uploaded eglish and arabic language, the english is 24 in languages list, you can upload your own language, just don't forget to calculate the language number here. from OCRLanguages.allLanguages()
  static let DefaultLanguageNumberAtFirstLaunch = 24
}


enum Policies {
    case terms, privacy
}
