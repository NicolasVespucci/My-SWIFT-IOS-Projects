//
//  Bundle+Extensions.swift
//  DocScan
//
//  Created by Mister Grizzly on 9/21/20.
//

import UIKit

extension Bundle {
  class var appName: String {
    let bundleDisplayname = Bundle.main.infoDictionary?["CFBundleDisplayName"] as? String
    let bundleName = Bundle.main.infoDictionary![kCFBundleNameKey as String] as! String
    
    return bundleDisplayname ?? bundleName
  }
}
