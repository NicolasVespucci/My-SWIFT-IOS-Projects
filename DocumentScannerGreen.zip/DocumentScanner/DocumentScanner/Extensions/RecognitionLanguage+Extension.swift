//
//  RecognitionLanguage+Extension.swift
//  DocScan
//
//  Created by Mister Grizzly on 12/15/20.
//

import Foundation
import SwiftyTesseract


protocol OCRLanguageStringConverter {
  associatedtype LanguageType

  static func createLanguageString(from languages: [LanguageType]) -> String
}

extension RecognitionLanguage: OCRLanguageStringConverter {
  static func createLanguageString(from languages: [RecognitionLanguage]) -> String {
    let stringLanguages = languages.reduce("") { $0.appending("\($1.description)+") }
    return stringLanguages.droppingLast()
  }
}

extension RecognitionLanguage {
  static func allLanguages() -> [RecognitionLanguage] {
    return [.afrikaans,
            .albanian,
            .amharic,
            .arabic,
            .assamese,
            .azerbaijani,
            .azerbaijaniCyrillic,
            .basque,
            .belarusian,
            .bengali,
            .bosnian,
            .bulgarian,
            .burmese,
            .catalanAndValencian,
            .cebuano,
            .centralKhmer,
            .chineseSimplified,
            .chineseTraditional,
            .croatian,
            .czech,
            .cherokee,
            .danish,
            .dutchFlemish,
            .dzongkha,
            .english,
            .englishMiddle,
            .esperanto,
            .estonian,
            .finnish,
            .frankish,
            .french,
            .frenchMiddle,
            .galician,
            .georgian,
            .georgianOld,
            .german,
            .greekAncient,
            .greekModern,
            .guajarati,
            .haitian,
            .hebrew,
            .hindi,
            .hungarian,
            .icelandic,
            .inuktitut,
            .indonesian,
            .italian,
            .italianOld,
            .irish,
            .javanese,
            .japanese,
            .kannada,
            .kazakh,
            .korean,
            .kurdish,
            .kyrgyz,
            .lao,
            .latin,
            .lithuanian,
            .malayalam,
            .macedonian,
            .malay,
            .maltese,
            .marathi,
            .nepali,
            .norwegian,
            .oriya,
            .pashto,
            .persian,
            .polish,
            .portugese,
            .punjabi,
            .romanian,
            .russian,
            .sanskrit,
            .serbian,
            .serbianLatin,
            .sinhala,
            .slovak,
            .slovenian,
            .spanish,
            .spanishOld,
            .swahili,
            .swedish,
            .syriac,
            .tamil,
            .tagalog,
            .tajik,
            .telugu,
            .thai,
            .tibetan,
            .tigrinya,
            .turkish,
            .uighur,
            .ukrainian,
            .urdu,
            .uzbek,
            .uzbekCyrillic,
            .vietnamese,
            .welsh,
            .yiddish]
  }
}

extension RecognitionLanguage {
  var name: String {
    switch self {
    case .afrikaans: return "Afrikaans"
    case .albanian:  return "Albanian"
    case .amharic: return "Amharic"
    case .arabic: return "Arabic"
    case .assamese: return "Assamese"
    case .azerbaijani: return "Azerbaijani"
    case .azerbaijaniCyrillic: return "Azerbaijani Cyrillic"
    case .basque: return "Basque"
    case .belarusian: return "Belarusian"
    case .bengali: return "Bengali"
    case .bosnian: return "Bosnian"
    case .bulgarian: return "Bulgarian"
    case .burmese: return "Burmese"
    case .catalanAndValencian: return "Catalan and Valencian"
    case .cebuano: return "Cebuano"
    case .centralKhmer: return "Central Khmer"
    case .chineseSimplified: return "Chinese Simplified"
    case .chineseTraditional: return "Chinese Traditional"
    case .croatian: return "Croatian"
    case .czech: return "Czech"
    case .cherokee: return "Cherokee"
    case .danish: return "Danish"
    case .dutchFlemish: return "Dutch Flemish"
    case .dzongkha: return "Dzongkha"
    case .english: return "English"
    case .englishMiddle: return "English Middle"
    case .esperanto: return "Esperanto"
    case .estonian: return "Estonian"
    case .finnish: return "Finnish"
    case .frankish: return "Frankish"
    case .french: return "French"
    case .frenchMiddle: return "French Middle"
    case .galician: return "Galician"
    case .georgian: return "Georgian"
    case .georgianOld: return "Georgian Old"
    case .german: return "German"
    case .greekAncient: return "Greek Ancient"
    case .greekModern: return "Greek Modern"
    case .guajarati: return "Guajarati"
    case .haitian: return "Haitian"
    case .hebrew: return "Hebrew"
    case .hindi: return "Hindi"
    case .hungarian: return "Hungarian"
    case .icelandic: return "Icelandic"
    case .inuktitut: return "Inuktitut"
    case .indonesian: return "Indonesian"
    case .italian: return "Italian"
    case .italianOld: return "Italian Old"
    case .irish: return "Irish"
    case .javanese: return "Javanese"
    case .japanese: return "Japanese"
    case .kannada: return "Kannada"
    case .kazakh: return "Kazakh"
    case .korean: return "Korean"
    case .kurdish: return "Kurdish"
    case .kyrgyz: return "Kyrgyz"
    case .lao: return "Lao"
    case .latin: return "Latin"
    case .lithuanian: return "Lithuanian"
    case .malayalam: return "Malayalam"
    case .macedonian: return "Macedonian"
    case .malay: return "Malay"
    case .maltese: return "Maltese"
    case .marathi: return "Marathi"
    case .nepali: return "Nepali"
    case .norwegian: return "Norwegian"
    case .oriya: return "Oriya"
    case .pashto: return "Pashto"
    case .persian: return "Persian"
    case .polish: return "Polish"
    case .portugese: return "Portugese"
    case .punjabi: return "Punjabi"
    case .romanian: return "Romanian"
    case .russian: return "Russian"
    case .sanskrit: return "Sanskrit"
    case .serbian: return "Serbian"
    case .serbianLatin: return "Serbian Latin"
    case .sinhala: return "Sinhala"
    case .slovak: return "Slovak"
    case .slovenian: return "Slovenian"
    case .spanish: return "Spanish"
    case .spanishOld: return "Spanish Old"
    case .swahili: return "Swahili"
    case .swedish: return "Swedish"
    case .syriac: return "Syriac"
    case .tamil: return "Tamil"
    case .tagalog: return "Tagalog"
    case .tajik: return "Tajik"
    case .telugu: return "Telugu"
    case .thai: return "Thai"
    case .tibetan: return "Tibetan"
    case .tigrinya: return "Tigrinya"
    case .turkish: return "Turkish"
    case .uighur: return "Uighur"
    case .ukrainian: return "Ukrainian"
    case .urdu: return "Urdu"
    case .uzbek: return "Uzbek"
    case .uzbekCyrillic: return "Uzbek Cyrillic"
    case .vietnamese: return "Vietnamese"
    case .welsh: return "Welsh"
    case .yiddish: return "Yiddish"
    case .custom(let customLanguage): return customLanguage
    }
  }
}

