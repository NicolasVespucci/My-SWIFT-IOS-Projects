//
//  String+Extensions.swift
//  DocScan
//
//  Created by Mister Grizzly on 9/6/20.
//

import Foundation

extension String {
  var localized: String {
    return NSLocalizedString(self, comment: "")
  }
  
  var toError: NSError {
    return NSError(domain: "",
                   code: 10099,
                   userInfo: [NSLocalizedDescriptionKey: self])
  }
}

extension String {
  func droppingLast() -> String {
    return String(self.dropLast())
  }
}
