//
//  UIBarButtonItems+Extensions.swift
//  DocScan
//
//  Created by Mister Grizzly on 9/5/20.
//

import UIKit

extension UIBarButtonItem {
  func setBadge(with value: Int) {
    guard let badgeLabel = customView?.viewWithTag(100) as? UILabel else { return }
    if value > 0 {
      badgeLabel.isHidden = false
      badgeLabel.text = "\(value)"
    } else {
      badgeLabel.isHidden = true
    }
  }
  
  func setup(image: UIImage? = nil) {
    customView?.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
    let badgeLabel = UILabel()
    badgeLabel.frame = CGRect(x: 20, y: 0, width: 15, height: 15)
    badgeLabel.backgroundColor = .red
    badgeLabel.tag = 100
    badgeLabel.clipsToBounds = true
    badgeLabel.layer.cornerRadius = 7
    badgeLabel.textColor = UIColor.white
    badgeLabel.font = UIFont.systemFont(ofSize: 10)
    badgeLabel.textAlignment = .center
    badgeLabel.isHidden = true
    badgeLabel.minimumScaleFactor = 0.1
    badgeLabel.adjustsFontSizeToFitWidth = true
    customView?.addSubview(badgeLabel)
  }
}

extension UIBarButtonItem {
  var frame: CGRect? {
    guard let view = self.value(forKey: "view") as? UIView else {
      return nil
    }
    return view.frame
  }
}

extension UIBarButtonItem {
    var view: UIView? {
        return perform(#selector(getter: UIViewController.view)).takeRetainedValue() as? UIView
    }
}
