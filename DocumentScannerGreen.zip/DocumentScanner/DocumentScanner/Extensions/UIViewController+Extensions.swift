//
//  UIViewController+Extensions.swift
//  DocScan
//
//  Created by Mister Grizzly on 9/6/20.
//

import UIKit

private let ProgressManagerInstance = ProgressManager()

extension UIViewController {
  
  func showHud(with text: String? = nil) {
    let text = text ?? "Loading".localized
    ProgressManagerInstance.startLoading(with: text)
  }
  
  func hideHud() {
    ProgressManagerInstance.stopLoading()
  }
  
  func set(progress: Float) {
    ProgressManagerInstance.set(progress: progress)
  }
}


extension UIViewController {
  func showAlert(title: String? = nil, message: String) {    
    DispatchQueue.main.async {
      let alert = UIAlertController(title: title ?? Bundle.appName,
                                    message: message,
                                    preferredStyle: .alert)
      
      alert.addAction(UIAlertAction(title: "Ok".localized, style: .default))
      self.present(alert, animated: true)
    }
  }
}


//extension UIButton {
//    func setBadge(with value: Int) {
//      guard let badgeLabel = customView?.viewWithTag(100) as? UILabel else { return }
//      if value > 0 {
//        badgeLabel.isHidden = false
//        badgeLabel.text = "\(value)"
//      } else {
//        badgeLabel.isHidden = true
//      }
//    }
//}
