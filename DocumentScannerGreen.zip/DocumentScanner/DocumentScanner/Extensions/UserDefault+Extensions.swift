//
//  UserDefault+Extensions.swift
//  DocScan
//
//  Created by Mister Grizzly on 9/22/20.
//

import UIKit

extension UserDefaults {
  
  var isPhotoEditigOn: Bool {
    get {
      return bool(forKey: "isPhotoEditigOn")
    } set {
      set(newValue, forKey: "isPhotoEditigOn")
      synchronize()
    }
  }
  
  var startsAppWithCamera: Bool {
    get {
      return bool(forKey: "startsAppWithCamera")
    } set {
      set(newValue, forKey: "startsAppWithCamera")
      synchronize()
    }
  }
  
  var hideTooltips: Bool {
    get {
      return bool(forKey: "hideTooltips")
    } set {
      set(newValue, forKey: "hideTooltips")
      synchronize()
    }
  }
}
