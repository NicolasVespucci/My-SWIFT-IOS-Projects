//
//  GuideViewController.swift
//  DocumentScanner
//
//  Created by iMac 21 on 18/04/2022.
//

import Foundation
import UIKit
import SnapKit
import RxSwift
import RxCocoa


 class GuideViewController: UIViewController {
  
     var currentGuide = 1;
     var canChange = false
     let disposeBag = DisposeBag()
     
     var viewOne: UIImageView = {
        let imageView = UIImageView()
         imageView.image = "one".image
         imageView.contentMode = .scaleAspectFill
         imageView.alpha = 0
         return imageView
     }()
     
     var labelOne : UILabel = {
        let label = UILabel()
         label.textColor = "#404147".hexColor
         label.font = .systemFont(ofSize: 15, weight: .regular)
         label.text = "Open camera to scan any document !"
         return label
     }()
     
     var viewTwo: UIImageView = {
        let imageView = UIImageView()
         imageView.image = "two".image
         imageView.contentMode = .scaleAspectFill
         imageView.alpha = 0
         return imageView
     }()
     
     var labelTwo : UILabel = {
        let label = UILabel()
         label.textColor = "#404147".hexColor
         label.font = .systemFont(ofSize: 15, weight: .regular)
         label.text = "Or you can import any image from gallery"
         label.minimumScaleFactor = 0.5
         label.adjustsFontSizeToFitWidth = true
         return label
     }()
     
     var viewThree: UIImageView = {
        let imageView = UIImageView()
         imageView.image = "three".image
         imageView.contentMode = .scaleAspectFill
         imageView.alpha = 0
         return imageView
     }()
     
     var labelThree : UILabel = {
        let label = UILabel()
         label.textColor = "#404147".hexColor
         label.font = .systemFont(ofSize: 15, weight: .regular)
         label.text = """
         All imported images will be visible here.
         You can scroll trough them, select one
         and recognize it.
        """
         label.numberOfLines = 3
         return label
     }()
     
     var viewFour: UIImageView = {
        let imageView = UIImageView()
         imageView.image = "four".image
         imageView.contentMode = .scaleAspectFill
         imageView.alpha = 0
         return imageView
     }()
     
     var labelFour : UILabel = {
        let label = UILabel()
         label.textColor = "#404147".hexColor
         label.font = .systemFont(ofSize: 15, weight: .regular)
         label.text = """
         Share recognized text or PDF file via
         email or text it!
         """
         label.numberOfLines = 2
         return label
     }()
     
     var viewFive: UIImageView = {
        let imageView = UIImageView()
         imageView.image = "five".image
         imageView.contentMode = .scaleAspectFill
         imageView.alpha = 0
         return imageView
     }()
     
     var labelFive : UILabel = {
        let label = UILabel()
         label.textColor = "#404147".hexColor
         let str = """
         Get premium - scan unlimited!
         Also you can find here the app’s settings
         """
         label.font = .systemFont(ofSize: 15, weight: .regular)
         var myMutableString = NSMutableAttributedString(string: str, attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 15)])
         myMutableString.addAttribute(NSAttributedString.Key.foregroundColor, value: "#118DFF".hexColor, range: NSRange(location:0,length:12))
         label.numberOfLines = 2
         label.attributedText = myMutableString
         return label
     }()
     
     var viewSix: UIImageView = {
        let imageView = UIImageView()
         imageView.alpha = 0
         imageView.contentMode = .scaleAspectFill
         return imageView
     }()
     
     var labelSix : UILabel = {
        let label = UILabel()
         label.textColor = "#404147".hexColor
         let str = "Start using doc scan !"
         label.font = .systemFont(ofSize: 15, weight: .regular)
         var myMutableString = NSMutableAttributedString(string: str, attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 15)])
         myMutableString.addAttribute(NSAttributedString.Key.foregroundColor, value: "#118DFF".hexColor, range: NSRange(location:0,length:5))
         label.attributedText = myMutableString
         return label
     }()
     
     var startNow : UIButton = {
        let button = UIButton()
         button.setImage("startNow".image, for: .normal)
         button.contentMode = .scaleAspectFit
         button.alpha = 0
         return button
     }()
     
     lazy var gestRect:
         UITapGestureRecognizer = {
             let gestureRecognizer = UITapGestureRecognizer()
             gestureRecognizer
                 .addTarget(self, action: #selector(handleOneTap))

             return gestureRecognizer
     }()
     
  override func viewDidLoad() {
    super.viewDidLoad()
      view.backgroundColor = .clear
      view.addGestureRecognizer(gestRect)
      view.addSubview(viewOne)
      
      viewOne.snp.makeConstraints { make in
          make.leading.equalToSuperview().offset(20)
          make.trailing.equalToSuperview().offset(-20)
          make.height.equalTo(51.resized())
          make.bottom.equalToSuperview().offset(-105.resized())
      }
      
      viewOne.addSubview(labelOne)
      
      labelOne.snp.makeConstraints { make in
          make.leading.equalToSuperview().offset(30.resized(.width))
          make.top.equalToSuperview().offset(5.resized())
          make.height.equalTo(24)
      }
      
      view.addSubview(viewTwo)
      
      viewTwo.snp.makeConstraints { make in
          make.leading.equalToSuperview().offset(10.resized(.width))
          make.width.equalTo(333.resized(.width))
          make.height.equalTo(51.resized())
          make.bottom.equalToSuperview().offset(-105.resized())
      }
      
      viewTwo.addSubview(labelTwo)
      
      labelTwo.snp.makeConstraints { make in
          make.leading.equalToSuperview().offset(25.resized(.width))
          make.top.equalToSuperview().offset(5.resized())
          make.height.equalTo(24)
      }
      
      view.addSubview(viewThree)
      
      viewThree.snp.makeConstraints { make in
          make.width.equalTo(333.resized(.width))
          make.trailing.equalToSuperview().offset(-15.resized(.width))
          make.height.equalTo(97.resized())
          make.bottom.equalToSuperview().offset(-105.resized())
      }
      
      viewThree.addSubview(labelThree)
      
      labelThree.snp.makeConstraints { make in
          make.trailing.equalToSuperview().offset(-20)
          make.leading.equalToSuperview().offset(20)
          make.top.equalToSuperview().offset(5.resized())
          make.height.equalTo(72.resized())
      }
      
      view.addSubview(viewFour)
      
      viewFour.snp.makeConstraints { make in
          make.trailing.equalToSuperview().offset(-15.resized(.width))
          make.width.equalTo(333.resized(.width))
          make.height.equalTo(75.resized())
          make.top.equalToSuperview().offset(110.resized())
      }
      
      viewFour.addSubview(labelFour)
      
      labelFour.snp.makeConstraints { make in
          make.leading.equalToSuperview().offset(25.resized(.width))
          make.bottom.equalToSuperview().offset(-7.resized())
          make.height.equalTo(50.resized())
      }
      
      view.addSubview(viewFive)
      
      viewFive.snp.makeConstraints { make in
          make.leading.equalToSuperview().offset(15.resized(.width))
          make.width.equalTo(333.resized(.width))
          make.height.equalTo(75.resized())
          make.top.equalToSuperview().offset(110.resized())
      }
      
      viewFive.addSubview(labelFive)
      
      labelFive.snp.makeConstraints { make in
          make.leading.equalToSuperview().offset(25.resized(.width))
          make.bottom.equalToSuperview().offset(-7.resized())
          make.height.equalTo(50.resized())
      }
      view.addSubview(viewSix)
      
      viewSix.snp.makeConstraints { make in
          make.centerX.equalToSuperview()
          make.width.equalTo(200)
          make.height.equalTo(52)
          make.centerY.equalToSuperview()
      }
      
      viewSix.addSubview(labelSix)
      
      labelSix.snp.makeConstraints { make in
          make.leading.equalToSuperview().offset(20.resized(.width))
          make.trailing.equalToSuperview().offset(-20.resized(.width))
          make.centerY.equalToSuperview()
          make.height.equalTo(24.resized())
      }
      
      view.addSubview(startNow)
      
      startNow.snp.makeConstraints { make in
          make.top.equalTo(viewSix.snp.bottom).offset(12)
          make.width.equalTo(200)
          make.height.equalTo(50)
          make.centerX.equalToSuperview()
      }
      
      startNow.rx.tap.bind { [weak self] in
          self?.closeController()
      }.disposed(by: disposeBag)
      
      changeUI(value : currentGuide)
    }
     
     @objc func handleOneTap(sender: UITapGestureRecognizer) {
         if(canChange){
             changeUI(value: currentGuide)
         }
       
     }
     
     func closeController(){
         Constants.ud.guideCompleted = true
         self.dismiss(animated: false, completion: nil)
     }
     
     func changeUI(value : Int){
         
         switch value {
         case 1:
             canChange = false
             UIView.animate(withDuration: 0.3, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
                 self.viewOne.alpha = 1
                    },completion: {_ in
                        self.currentGuide += 1
                        self.canChange = true
                    })
         case 2:
             canChange = false
             UIView.animate(withDuration: 0.3, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
                 self.viewOne.alpha = 0
                    },completion: {_ in
                        UIView.animate(withDuration: 0.3, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
                            self.viewTwo.alpha = 1
                               },completion: {_ in
                                   self.currentGuide += 1
                                   self.canChange = true
                               })
                        
                    })
         case 3:
             canChange = false
             UIView.animate(withDuration: 0.3, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
                 self.viewTwo.alpha = 0
                    },completion: {_ in
                        UIView.animate(withDuration: 0.3, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
                            self.viewThree.alpha = 1
                               },completion: {_ in
                                   self.currentGuide += 1
                                   self.canChange = true
                               })
                        
                    })
         case 4:
             canChange = false
             UIView.animate(withDuration: 0.3, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
                 self.viewThree.alpha = 0
                    },completion: {_ in
                        UIView.animate(withDuration: 0.3, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
                            self.viewFour.alpha = 1
                               },completion: {_ in
                                   self.currentGuide += 1
                                   self.canChange = true
                               })
                        
                    })
         case 5:
             canChange = false
             UIView.animate(withDuration: 0.3, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
                 self.viewFour.alpha = 0
                    },completion: {_ in
                        UIView.animate(withDuration: 0.3, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
                            self.viewFive.alpha = 1
                               },completion: {_ in
                                   self.currentGuide += 1
                                   self.canChange = true
                               })
                        
                    })
         case 6:
             canChange = false
             UIView.animate(withDuration: 0.3, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
                 self.viewFive.alpha = 0
                    },completion: {_ in
                        UIView.animate(withDuration: 0.3, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
                            self.viewSix.alpha = 1
                            self.startNow.alpha = 1
                               },completion: {_ in
                                   self.currentGuide += 1
                                   self.canChange = true
                               })
                        
                    })
         default:
             print("test")
         }
     }
     
}
