
import UIKit
import SnapKit

class InformationAboutBenefits: UIView {

    private var paidLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.textColor = "FFFFFF".hexColor
        label.text = "Paid subscription benefits:"
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.font = .systemFont(ofSize: 16, weight: .bold)
        return label
    }()

    private var allowsLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .left
        label.textColor = "FFFFFF".hexColor
        label.text = "• Allows editing photos in the gallery"
//        label.adjustsFontSizeToFitWidth = true
//        label.minimumScaleFactor = 0.5
        label.font = .systemFont(ofSize: 14, weight: .regular)
        return label
    }()

    private var unlocklabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .left
        label.textColor = "FFFFFF".hexColor
        label.text = "• Unlock access to 100 other languages \n   to read from documents"
//        label.adjustsFontSizeToFitWidth = true
//        label.minimumScaleFactor = 0.5
        label.numberOfLines = 0
        label.font = .systemFont(ofSize: 14, weight: .regular)
        return label
    }()
    
    
    override init(frame: CGRect) {
      super.init(frame: frame)
        setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
      super.init(coder: aDecoder)
      
    }
    
    
    private func setupView(){
        addSubviews(paidLabel, allowsLabel, unlocklabel)
        
        paidLabel.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(24)
        }
        
        allowsLabel.snp.makeConstraints { make in
            make.top.equalTo(paidLabel.snp.bottom).offset(5)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(24)
        }
        
        unlocklabel.snp.makeConstraints { make in
            make.top.equalTo(allowsLabel.snp.bottom).offset(5)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(34)
        }
    }
    
}
