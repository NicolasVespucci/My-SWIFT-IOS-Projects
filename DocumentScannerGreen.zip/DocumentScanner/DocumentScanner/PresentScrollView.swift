import UIKit
import SnapKit


class PresentScrollView: UIView {

    var topText: String?
    var bottomText: String?

    private lazy var firstLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 28, weight: .semibold)
        label.textColor = "E5E5E5".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .left
        return label
    }()
    
    private lazy var secondLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.textColor = "E5E5E5".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .left
        label.numberOfLines = 3
        return label
    }()

    init(topText: String, bottomText: String) {
        super.init(frame: .zero)
        self.topText = topText
        self.bottomText = bottomText
        isUserInteractionEnabled = true
        launch()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func launch() {
        configureLayout()
        configureViewContent()
    }
    
    private func configureLayout() {
        addSubviews(firstLabel, secondLabel)

        firstLabel.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.height.equalTo(32)
            make.leading.equalToSuperview().offset(35)
            make.trailing.equalToSuperview().offset(-35)
        }

        secondLabel.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(35)
            make.trailing.equalToSuperview().offset(-35)
            make.height.equalTo(72)
            make.top.equalTo(firstLabel.snp.bottom)
        }
    }
    
    private func configureViewContent() {
        firstLabel.text = topText
        secondLabel.text = bottomText
    }

}

