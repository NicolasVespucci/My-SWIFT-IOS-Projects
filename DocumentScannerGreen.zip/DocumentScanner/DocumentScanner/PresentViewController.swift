import UIKit
import RxSwift
import SnapKit
import AppTrackingTransparency

class PresentViewController: UIViewController, UIScrollViewDelegate {
    
    private let firstView = PresentScrollView(topText: "DocuScreen", bottomText: "Use the latest OCR technology on the market")
    private let secondView = PresentScrollView(topText: "Try it now", bottomText: "Extract the text from every printed file.\nCopy, edit and modify it as You want")
    
    private var fullImageView: UIImageView = {
        let imageView = UIImageView(image: "fullPresent".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    
    private var scrollView: UIScrollView = {
        let view = UIScrollView()
        view.isPagingEnabled = true
        view.isScrollEnabled = false
        view.showsHorizontalScrollIndicator = false
        return view
    }()

    private var continueButton: UIButton = {
        let button = UIButton()
        button.setTitle("Continue", for: .normal)
        button.setTitleColor("0D7751".hexColor, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .medium)
        button.backgroundColor = "E5E5E5".hexColor
        button.clipsToBounds = true
        button.layer.cornerRadius = 12
        return button
    }()
    
    private var pageControllImageView: UIImageView = {
        let imageview = UIImageView(image: "firstPage".image)
        return imageview
    }()

    var window: UIWindow?
    
    var xOffSet: CGFloat = 0
    var contentWidth: CGFloat = 0.0
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup (){
        configureLayout()
        setupButtons()
        configureScrollView()
    }
    
    private func configureLayout() {
        navigationController?.isNavigationBarHidden = true
        view.addSubviews(fullImageView, pageControllImageView, continueButton, scrollView)
        
        fullImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }

        pageControllImageView.snp.makeConstraints { make in
            make.bottom.equalTo(continueButton.snp.top).offset(-29.resized())
            make.width.equalTo(51)
            make.height.equalTo(8)
            make.centerX.equalToSuperview()
        }
        
        continueButton.snp.makeConstraints { make in
            make.bottom.equalTo(scrollView.snp.top).offset(-29.resized())
            make.height.equalTo(56)
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
        }
        
        scrollView.snp.makeConstraints { make in
            make.height.equalTo(104)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview().offset(-51.resized())
        }
    
        view.layoutIfNeeded()
    }
    
    private func setupButtons() {
        continueButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.continueStartButtonAction()
        }.disposed(by: disposeBag)
    }
    
    private func continueStartButtonAction(){
        if self.xOffSet < UIScreen.main.bounds.width {
            DispatchQueue.main.async {
                self.xOffSet += UIScreen.main.bounds.width
                self.scrollView.setContentOffset(CGPoint(x: self.xOffSet, y: 0), animated: true)
                self.continueButton.setTitle("Start", for: .normal)
            }
            
            if #available(iOS 14, *) {
              ATTrackingManager.requestTrackingAuthorization { (status) in
                switch status {
                case .denied:
                        print("denied")
                case .notDetermined:
                    print("notDetermined")
                case .restricted:
                    print("restricted")
                case .authorized:
                    print("authorized")
                @unknown default:
                    fatalError("Invalid authorization status")
                }
              }
            }
            pageControllImageView.image = "secondPage".image
        } else {
            Constants.ud.onboardingShow = true
          
            if IAPManager.shared().isPurchased {
                nextButtonActions()
            } else {
                if(!Constants.ud.firstFlag){
                    IAPManager.shared().presentSingleSubscriptionVC()
                    IAPManager.shared().purchaseCompletion = { _ in
                        IAPManager.shared().dismissSubscriptionVC()
                        AlertManager.shared().showPurchaseComplite()
                        self.nextButtonActions()
                    }
                    IAPManager.shared().restoreCompletion = { subscription in
                        IAPManager.shared().dismissSubscriptionVC()
                        if Constants.ud.isPurchased {
                            AlertManager.shared().showPurchasesWereRestored()
                            self.nextButtonActions()
                        }
                    }
                    Constants.ud.firstFlag = true
                } else {
                    nextButtonActions()
                }
                
            }
    
        }
    }
    
    private func configureScrollView() {
        scrollView.delegate = self
        let viewsForScroll = [firstView, secondView]
        for (index, view) in viewsForScroll.enumerated() {
            scrollView.addSubview(view)
            view.snp.makeConstraints { make in
                make.top.equalToSuperview()
                make.bottom.equalToSuperview()
                make.leading.equalToSuperview().offset(CGFloat(index) * UIScreen.main.bounds.width)
                make.width.equalToSuperview()
            }
            self.view.layoutIfNeeded()
            self.scrollView.layoutIfNeeded()
            contentWidth += self.view.frame.width
        }
        scrollView.contentSize = CGSize(width: contentWidth, height: scrollView.frame.height)
    }
    
    private func nextButtonActions(){
        window = UIWindow(frame: UIScreen.main.bounds)
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let navigationViewController = storyboard.instantiateViewController(withIdentifier: "NavigationController") as! UINavigationController
        let vc : ViewController = storyboard.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        navigationViewController.pushViewController(vc, animated: true)
        window?.rootViewController = navigationViewController
        window?.makeKeyAndVisible()
        window?.overrideUserInterfaceStyle = .light
    }
}
