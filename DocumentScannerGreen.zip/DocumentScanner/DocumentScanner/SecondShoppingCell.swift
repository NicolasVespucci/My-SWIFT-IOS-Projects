import UIKit
import StoreKit
import SnapKit

class SecondShoppingCell: UICollectionViewCell {
    
    private lazy var cellView: UIView = {
        let cell = UIView()
        cell.layoutIfNeeded()
        cell.backgroundColor = "208E92".hexColor.withAlphaComponent(0.03)
        cell.layer.cornerRadius = 16
        return cell
    }()
    
    private lazy var periodPeriodLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.textColor = "0F4345".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .center
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private lazy var priceLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.textColor = "0F4345".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .left
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private lazy var trialLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 12, weight: .medium)
        label.textColor = .white
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .center
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var currentCellImageView: UIImageView = {
        let imageView = UIImageView(image: "CurrentCell".image)
        return imageView
    }()
    
    var product: Product?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func configureTrialLayout() {
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubview(periodPeriodLabel)
        

        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(68)
        }
        
        periodPeriodLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
            make.height.equalTo(24)
        }
        
        cellView.addBorder(width: 1, color: "FFFFFF", withAlphaComponent: 0.2)
        cellView.backgroundColor = "FFFFFF".hexColor.withAlphaComponent(0.22)
        periodPeriodLabel.text = perPeriodString + " • " + price
        periodPeriodLabel.textColor = .white
        layoutSubviews()
    }
    
    public func configureCommonLayout() {
        
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubviews(periodPeriodLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(68)
        }
        
        periodPeriodLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
            make.height.equalTo(24)
        }
       
        
        cellView.addBorder(width: 1, color: "FFFFFF", withAlphaComponent: 0.2)
        cellView.backgroundColor = "FFFFFF".hexColor.withAlphaComponent(0.22)
        periodPeriodLabel.text = perPeriodString + " • " + price
        periodPeriodLabel.textColor = .white
        layoutSubviews()
    }
    
    public func configureTrialSelectedLayout() {
        
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let perPeriodString2 = period.perFormattedString

        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubviews(cellView, trialLabel)
        cellView.addSubviews(periodPeriodLabel, currentCellImageView)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(68)
        }
    
        periodPeriodLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
            make.height.equalTo(24)
        }
        
        currentCellImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.size.equalTo(18)
            make.trailing.equalToSuperview().offset(-22)
        }
        
        trialLabel.snp.makeConstraints { make in
            make.top.equalTo(cellView.snp.bottom).offset(5)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(16)
        }

        layoutIfNeeded()
        
        cellView.addBorder(width: 1, color: "FFFFFF", withAlphaComponent: 0.2)
        cellView.backgroundColor = "FFFFFF".hexColor.withAlphaComponent(0.22)
        trialLabel.text = NSLocalizedString("(free trial ", comment: "") + (product.introductory?.period?.formattedString ?? "asda") + NSLocalizedString(" at ", comment: "") + price + "/" + perPeriodString2 + ")"
        periodPeriodLabel.text = perPeriodString + " • " + price
        periodPeriodLabel.textColor = .white
        
        layoutSubviews()
    }
    
    public func configureCommonSelectedLayout() {
        
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubviews(periodPeriodLabel, currentCellImageView)

        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(68)
        }
        
        periodPeriodLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
            make.height.equalTo(24)
        }
        currentCellImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.size.equalTo(18)
            make.trailing.equalToSuperview().offset(-22)
        }

        cellView.addBorder(width: 1, color: "FFFFFF", withAlphaComponent: 0.2)
        cellView.backgroundColor = "FFFFFF".hexColor.withAlphaComponent(0.22)
        periodPeriodLabel.text = perPeriodString + " • " + price
        periodPeriodLabel.textColor = .white
        layoutSubviews()
    }
}

extension UIView {
    func addDashBorder() {
        let color = "#42A4FF".hexColor.cgColor

        let shapeLayer:CAShapeLayer = CAShapeLayer()

        let frameSize = self.frame.size
        let shapeRect = CGRect(x: 0, y: 0, width: frameSize.width, height: frameSize.height)

        shapeLayer.bounds = shapeRect
        shapeLayer.name = "DashBorder"
        shapeLayer.position = CGPoint(x: frameSize.width/2, y: frameSize.height/2)
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.strokeColor = color
        shapeLayer.lineWidth = 4
        shapeLayer.lineJoin = .round
        shapeLayer.lineDashPattern = [2,4]
        shapeLayer.path = UIBezierPath(roundedRect: shapeRect, cornerRadius: 12).cgPath

        self.layer.masksToBounds = false

        self.layer.addSublayer(shapeLayer)
    }
}
