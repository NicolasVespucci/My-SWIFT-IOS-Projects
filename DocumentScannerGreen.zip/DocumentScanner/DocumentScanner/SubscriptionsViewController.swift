import UIKit
import RxSwift
import SwiftyStoreKit
import StoreKit
import SwiftyAttributes
import IHProgressHUD
import SnapKit

class SubscriptionsViewController: UIViewController {
    
    var identifiers = [Constants.analytics.week, Constants.analytics.threeMonth, Constants.analytics.year]

    private var topImageView: UIImageView = {
        let imageView = UIImageView(image: "fullPay".image)
        imageView.contentMode = .scaleAspectFill
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    private var topBackButton: UIButton = {
        let button = UIButton()
        button.setImage("topBack".image, for: .normal)
        return button
    }()
    
    private var restoreButton: UIButton = {
        let button = UIButton()
        button.setTitle("Restore", for: .normal)
        button.setTitleColor("FFFFFF".hexColor, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .regular)
        return button
    }()
    
    private lazy var payCollectionView: UICollectionView = {
        let collection = UICollectionView(frame: .zero, collectionViewLayout: .init())
        collection.backgroundColor = .clear
        collection.showsHorizontalScrollIndicator = false
        collection.showsVerticalScrollIndicator = false
        collection.isScrollEnabled = true
        collection.clipsToBounds = false
        collection.isScrollEnabled = false
        return collection
    }()
    
    private lazy var payLayout: UICollectionViewLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 0
        layout.itemSize = .init(width: (UIScreen.main.bounds.width - 64), height: 95)
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
        layout.sectionInset = .init(top: 0, left: 0, bottom: 0, right: 0)
        return layout
    }()
    
    
    var informationAboutBenefits = InformationAboutBenefits()
    
    private var enjoyLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.textColor = "74757A".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.text = "Enjoy full version \n app without ads"
        label.numberOfLines = 2
        return label
    }()
    
    private var subscribeButton: UIButton = {
        let button = UIButton()
        button.setTitle("Subscribe", for: .normal)
        button.setTitleColor("0B3628".hexColor, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .semibold)
        button.backgroundColor = .white
        button.clipsToBounds = true
        button.layer.cornerRadius = 12
        return button
    }()
    
    var productsDescription: NSAttributedString {
        let terms = NSLocalizedString("Terms", comment: "") + " " + NSLocalizedString("of", comment: "") + " " + NSLocalizedString("Use", comment: "")
        let privacy = NSLocalizedString("Privacy", comment: "") + NSLocalizedString(" ", comment: "") + NSLocalizedString("Policy", comment: "")
        let and = " & "
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        
        let textAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12, weight: .medium)),
            .textColor("FFFFFF".hexColor.withAlphaComponent(0.77)),
            .paragraphStyle(paragraphStyle)
        ]

        let andAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12, weight: .medium)),
            .textColor("FFFFFF".hexColor.withAlphaComponent(0.44)),
            .paragraphStyle(paragraphStyle)
        ]
        
        let attributedDescription =
        terms.withAttributes(textAttributes)
        + and.withAttributes(andAttributes)
        + privacy.withAttributes(textAttributes)
        return attributedDescription
    }
    
    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.layoutIfNeeded()
        textView.isEditable = false
        textView.isSelectable = false
        textView.isScrollEnabled = false
        textView.backgroundColor = .clear
        textView.showsVerticalScrollIndicator = true
        textView.attributedText = productsDescription
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapResponse(recognizer:)))
        textView.addGestureRecognizer(tap)
        return textView
    }()
    
    private var decorativeBottom: UIImageView = {
        let imageview = UIImageView()
        imageview.image = "bottomDecoration".image
        imageview.contentMode = .scaleAspectFill
        return imageview
    }()
    
    let disposeBag = DisposeBag()
    var products = [SKProduct]()
        
    var selectedIndex = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }

    private func setup() {
        configureUpdateProducts()
        configureLayout()
        setupShoppingCollection()
        setupButtons()
    }
    
    private func configureLayout() {
        navigationController?.isNavigationBarHidden = true
        view.addSubviews(topImageView, topBackButton, restoreButton, payCollectionView, informationAboutBenefits, subscribeButton, textView)
    
        topImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        topBackButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(64.resized())
            make.leading.equalToSuperview().offset(25)
            make.width.equalTo(31)
            make.height.equalTo(18)
        }
        
        restoreButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(59.resized())
            make.trailing.equalToSuperview().offset(-24)
            make.width.equalTo(70)
            make.height.equalTo(22)
        }
        
        payCollectionView.snp.makeConstraints { make in
            make.height.equalTo(285)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.top.equalToSuperview().offset(128.resized())
        }
        
        informationAboutBenefits.snp.makeConstraints { make in
            make.bottom.equalTo(subscribeButton.snp.top).offset(-32.resized())
            make.height.equalTo(92)
            make.leading.equalToSuperview().offset(50)
            make.trailing.equalToSuperview().offset(-50)
        }
        
        subscribeButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-146.resized())
            make.height.equalTo(56)
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
        }

        textView.snp.makeConstraints { make in
            make.top.equalTo(subscribeButton.snp.bottom).offset(53.resized())
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(30)
        }
       
        view.layoutIfNeeded()

        view.layoutSubviews()
        
        IAPManager.shared().productsReceived.bind { [weak self] received in
            if received {
                self?.payCollectionView.reloadData()
            } else {
                self?.configureUpdateProducts()
            }
        }.disposed(by: disposeBag)
        
        IAPManager.shared().productsReceived.bind { [weak self] received in
            if received {
                self?.payCollectionView.reloadData()
            } else {
                self?.configureUpdateProducts()
                self?.payCollectionView.reloadData()
            }
        }.disposed(by: disposeBag)
    }
    
    private func setupShoppingCollection() {
        payCollectionView.setCollectionViewLayout(payLayout, animated: true)
        payCollectionView.dataSource = self
        payCollectionView.delegate = self
        payCollectionView.register(SecondShoppingCell.self, forCellWithReuseIdentifier: SecondShoppingCell.nibIdentifier)
    }
    
    private func setupButtons() {
        topBackButton.rx.tap.bind { [weak self] in
            self?.dismiss(animated: true)
        }.disposed(by: disposeBag)
    
        restoreButton.rx.tap.bind {
            IAPManager.shared().restore()
            IAPManager.shared().restoreCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                    AlertManager.shared().showPurchasesWereRestored()
                }
            }
        }.disposed(by: disposeBag)
        
        subscribeButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            let product = self.identifiers[self.selectedIndex]
            IAPManager.shared().purchase(rcPackage: product, quantity: 1, atomically: true)
            IAPManager.shared().purchaseCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                }
            }
        }.disposed(by: disposeBag)
    }

    private func configureUpdateProducts() {
        IHProgressHUD.show()
        SwiftyStoreKit.retrieveProductsInfo([Constants.analytics.week, Constants.analytics.threeMonth, Constants.analytics.year]) { result in
            if(!result.retrievedProducts.isEmpty) {
                self.products = Array(result.retrievedProducts).sorted(by: { Product(product: $0).price < Product(product: $1).price })
                self.payCollectionView.reloadData()
                IHProgressHUD.dismiss()
            } else {
                IHProgressHUD.dismiss()
                self.configureUpdateProducts()
            }
        }
    }
    
    deinit {
        IHProgressHUD.dismiss()
    }
}

//MARK: - CollectionView
extension SubscriptionsViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedIndex = indexPath.item
        let apphudProduct = self.products[selectedIndex]
        //configurePriceLabel(product: apphudProduct)
        payCollectionView.reloadData()
        if IAPManager.shared().isPurchased {
            IAPManager.shared().dismissSubscriptionVC()
        }
    }
}

extension SubscriptionsViewController: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return products.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SecondShoppingCell.nibIdentifier, for: indexPath) as! SecondShoppingCell
        let apphudProduct = products[indexPath.item]
        let product = Product(product: apphudProduct)
        print(product)
        cell.product = product
        if indexPath.item == self.selectedIndex {
            product.type == .renewable(.trial) ? cell.configureTrialSelectedLayout() : cell.configureCommonSelectedLayout()
        } else {
            product.type == .renewable(.trial) ? cell.configureTrialLayout() : cell.configureCommonLayout()
        }
        return cell
    }
}

//MARK: - Text View
extension SubscriptionsViewController {
    @objc func tapResponse(recognizer: UITapGestureRecognizer) {
        let location: CGPoint = recognizer.location(in: textView)
        let position: CGPoint = CGPoint(x: location.x, y: location.y)
        let tapPosition: UITextPosition? = textView.closestPosition(to: position)
        if tapPosition != nil {
            let textRange: UITextRange? = textView.tokenizer.rangeEnclosingPosition(tapPosition!, with: UITextGranularity.word, inDirection: UITextDirection(rawValue: 1))
            if textRange != nil
            {
                let tappedWord: String? = textView.text(in: textRange!)
                guard let word = tappedWord else { return }
                wordAction(word)
            }
        }
    }
    
    private func wordAction(_ word: String) {
        switch word {
        case NSLocalizedString("Terms", comment: ""), NSLocalizedString("of", comment: ""), NSLocalizedString("Use", comment: ""): pushPoliciesVC(.terms)
            
        case NSLocalizedString("Privacy", comment: ""),NSLocalizedString("and", comment: ""), NSLocalizedString("Policy", comment: ""): pushPoliciesVC(.privacy)
        default: break
        }
    }
    
    func pushPoliciesVC(_ policiesType: Policies) {
        if(policiesType == Policies.terms){
            presentSafariController(with:  Config.Settings.terms.rawValue)
        } else {
            presentSafariController(with:  Config.Settings.privacy.rawValue)
        }
       
    }
}
