//
//  ViewController.swift
//  DocumentScanner
//
//  Created by iMac 21 on 18/04/2022.
//

import UIKit
import Foundation
import SnapKit
import RxCocoa
import RxSwift
import Vision
import VisionKit
import SwiftyTesseract
import PDFKit
import AVFoundation
import Photos

class ViewController: UIViewController, UserDefaultable, UITextViewDelegate {
    
    let disposeBag = DisposeBag()
    
    private var progressManager: ProgressManager?
    
    private var ocrManager: OCRManager?
    
    private var images: [UIImage] = [] {
      didSet {
      //  monitorButton.setBadge(with: images.count)
          print("set")
      }
    }
    
    lazy var premiumButton : UIButton = {
        var button = UIButton()
        button.setImage("premium".image, for: .normal)
        button.contentMode = .scaleAspectFit
        return button
    }()
    
    lazy var downloadButton : UIButton = {
        var button = UIButton()
        button.setImage("download".image, for: .normal)
        button.contentMode = .scaleAspectFit
        return button
    }()
    
    lazy var reportButton : UIButton = {
        var button = UIButton()
        button.setImage("report".image, for: .normal)
        button.contentMode = .scaleAspectFit
        return button
    }()
    
    lazy var bottomLineImageView: UIImageView = {
        let imageView = UIImageView(image: "bottomLine".image)
        
        return imageView
    }()
    
    lazy var galleryButton : UIButton = {
        var button = UIButton()
        button.setImage("gallery".image, for: .normal)
        button.contentMode = .scaleAspectFit
        return button
    }()
    
    lazy var scanButton : UIButton = {
        var button = UIButton()
        button.setImage("scan".image, for: .normal)
        button.contentMode = .scaleAspectFit
        return button
    }()
    
    lazy var monitorButton : UIButton = {
        var button = UIButton()
        button.setImage("monitor".image, for: .normal)
        button.contentMode = .scaleAspectFit
        return button
    }()
    
    lazy var bottomView : UIView = {
        var view = UIView()
        view.backgroundColor = "F2F2F2".hexColor
        view.clipsToBounds = true
        view.layer.cornerRadius = 13
        return view
    }()

    lazy var mainImageView : UIImageView = {
        var imageView = UIImageView()
        imageView.image = "mainFrame".image
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var imageView : UIImageView = {
        var imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var parentImageView : UIImageView = {
        var imageView = UIImageView()
        imageView.image = "imageBorder".image
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var textParent : UIImageView = {
        var imageView = UIImageView()
        imageView.image = "textBorder".image
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    lazy var textView : UITextView = {
       var textView = UITextView()
        textView.isEditable = true
        textView.isSelectable = true
        textView.font = .systemFont(ofSize: 16, weight: .regular)
        textView.isScrollEnabled = true
        textView.showsVerticalScrollIndicator = true
        textView.alwaysBounceVertical = true
        textView.textColor = "#404147".hexColor
        return textView
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        view.backgroundColor = "#FFFFFF".hexColor
        
        progressManager = ProgressManager()
        ocrManager = OCRManager()
        
        view.addGestureRecognizer(gestRect)
        view.addSubview(bottomView)
        view.addSubview(mainImageView)
        
        bottomView.snp.makeConstraints { make in
            make.height.equalTo(112)
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
        }
        
        mainImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(34.resized(.width))
            make.trailing.equalToSuperview().offset(-34.resized(.width))
            make.height.equalTo(490.resized())
        }
        
        view.addSubview(premiumButton)
        premiumButton.snp.makeConstraints { make in
            make.size.equalTo(34)
            make.top.equalToSuperview().offset(54.resized())
            make.trailing.equalToSuperview().offset(-34)
        }
        
        view.addSubview(reportButton)
        reportButton.snp.makeConstraints { make in
            make.size.equalTo(34)
            make.top.equalToSuperview().offset(54.resized())
            make.leading.equalToSuperview().offset(34.resized(.width))
        }
        
        view.addSubview(downloadButton)
        downloadButton.snp.makeConstraints { make in
            make.size.equalTo(34)
            make.top.equalToSuperview().offset(54.resized())
            make.centerX.equalToSuperview()
        }
        
        view.addSubview(bottomLineImageView)
        
        bottomLineImageView.snp.makeConstraints { make in
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(1)
            make.bottom.equalToSuperview().offset(-79)
        }
        
        view.addSubview(galleryButton)
        galleryButton.snp.makeConstraints { make in
            make.height.equalTo(56)
            make.width.equalTo(57)
            make.bottom.equalToSuperview().offset(-34)
            make.leading.equalToSuperview().offset(34)
        }
        view.addSubview(scanButton)
        scanButton.snp.makeConstraints { make in
            make.size.equalTo(88)
            make.bottom.equalToSuperview().offset(-37)
            make.centerX.equalToSuperview()
        }
        view.addSubview(monitorButton)
        monitorButton.snp.makeConstraints { make in
            make.height.equalTo(56)
            make.width.equalTo(57)
            make.bottom.equalToSuperview().offset(-34)
            make.trailing.equalToSuperview().offset(-34)
        }
        setupButtons()
        
        view.addSubview(parentImageView)
        
        parentImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(150.resized())
            make.leading.equalToSuperview().offset(34)
            make.trailing.equalToSuperview().offset(-34)
            make.height.equalTo(280.resized())
        }
        
        parentImageView.addSubview(imageView)
        
        imageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(40.resized())
            make.trailing.equalToSuperview().offset(-16)
            make.leading.equalToSuperview().offset(16)
            make.bottom.equalToSuperview().offset(-40.resized())
        }
        parentImageView.isHidden = true
        view.addSubview(textParent)
        
        textParent.snp.makeConstraints { make in
            make.top.equalTo(parentImageView.snp.bottom).offset(15)
            make.height.equalTo(201.resized())
            make.trailing.equalToSuperview().offset(-34)
            make.leading.equalToSuperview().offset(34)
        }
        textParent.isHidden = true
        textView.isHidden = true
        view.addSubview(textView)
        
        textView.snp.makeConstraints { make in
            make.top.equalTo(textParent.snp.top).offset(15)
            make.height.equalTo(168.resized())
            make.leading.equalTo(textParent.snp.leading).offset(15.resized())
            make.trailing.equalTo(textParent.snp.trailing).offset(-5.resized())
        }
        
        if(!Constants.ud.guideCompleted){
            let guide = GuideViewController()
            guide.modalPresentationStyle = .overCurrentContext
            present(guide, animated: true, completion: nil)
        } else {
            if(Constants.ud.startCameraAtStartUp){
                openCamera()
            }
            if(!Constants.ud.isPurchased){
                IAPManager.shared().presentSingleSubscriptionVC()
                IAPManager.shared().purchaseCompletion = { subscription in
                    if Constants.ud.isPurchased {
                        IAPManager.shared().dismissSubscriptionVC()
                       
                    }
                }
                IAPManager.shared().restoreCompletion = { subscription in
                    if Constants.ud.isPurchased {
                        IAPManager.shared().dismissSubscriptionVC()
                       
                    }
                }
            }
        }
        
        

        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        textView.delegate = self
    }
    
    lazy var gestRect:
        UITapGestureRecognizer = {
            let gestureRecognizer = UITapGestureRecognizer()
            gestureRecognizer
                .addTarget(self, action: #selector(handleOneTap))

            return gestureRecognizer
    }()

    @objc func handleOneTap(sender: UITapGestureRecognizer) {
        textView.resignFirstResponder()
    }
    
    
    private func process(image: UIImage) {
   //   self.textView.isHidden = false
   //   self.textView.text = ""

        self.progressManager?.startLoading(with: "Recognizing text from image")
        if let index = userDefaultsGetValue(userDefaultsOCRIndexPath) as? Int {
          let language = RecognitionLanguage.allLanguages()[index]
          
        ocrManager?.recognize(image: image, languages: [language], completion: { (error, ocrText) in
            self.progressManager?.stopLoading()
              self.parentImageView.isHidden = false
              self.textParent.isHidden = false
              self.textView.isHidden = false
              self.mainImageView.isHidden = true
              self.textView.text = ocrText
              Constants.ud.totalScans = Constants.ud.totalScans! + 1
        })
        }
        
//      ocrManager?.recognize(image: image, languages: [language], completion: { (error, ocrText) in
//        self.progressManager?.stopLoading()
//          self.parentImageView.isHidden = false
//          self.textParent.isHidden = false
//          self.mainImageView.isHidden = true
//          self.textView.text = ocrText
//
//      })
      
    }
    
    
    @objc func keyboardWillShow(notification: NSNotification) {
      if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
          UIView.animate(withDuration: 0.5, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
              self.parentImageView.alpha = 0
              self.parentImageView.snp.updateConstraints { make in
                  make.top.equalToSuperview().offset(-150.resized())
              }
              self.view.layoutIfNeeded()
          }, completion: nil)
         
      }
    }
    
    
  
    @objc func keyboardWillHide(notification: NSNotification) {
        UIView.animate(withDuration: 0.5, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
            self.parentImageView.alpha = 1
            self.parentImageView.snp.updateConstraints { make in
                make.top.equalToSuperview().offset(150.resized())
            }
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
    
    private func share(items: [Any]) {
      let activityViewController = UIActivityViewController(activityItems: items, applicationActivities: nil)
      activityViewController.popoverPresentationController?.sourceView = self.view
      present(activityViewController, animated: true, completion: nil)
    }
    
    func shareAction() {
      guard let image = imageView.image else { return }
      
      let alert = UIAlertController(title: "Share", message: "Choose an option to share:", preferredStyle: .actionSheet)
      
      alert.addAction(UIAlertAction(title: "Plain Text", style: .default) { [weak self] _ in
        guard let self = self else { return }
        guard let textToShare = self.textView.text, !textToShare.isEmpty else { return }
        self.share(items: [textToShare])
      })
      
      alert.addAction(UIAlertAction(title: "PDF Document", style: .default) { [weak self] _ in
        guard let self = self else { return }
        
        guard let page = PDFPage(image: image),
              let data = page.dataRepresentation,
              let document = PDFDocument(data: data), let pdfData = document.dataRepresentation() else { return }
        
        let temporaryPDFDocumentURL = URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true).appendingPathComponent("Recognized-PDF.pdf")
        
        try? pdfData.write(to: temporaryPDFDocumentURL)
        
        self.share(items: [temporaryPDFDocumentURL])
      })
      
      alert.addAction(UIAlertAction(title: "Image (JPEG)", style: .default) { [weak self] _ in
        guard let self = self else { return }
        
        guard let imageData = image.jpegData(compressionQuality: 1.0) else { return }
        
        let temporaryJPEGURL = URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true).appendingPathComponent("Document-Image.jpeg")
        
        try? imageData.write(to: temporaryJPEGURL)
        
        self.share(items: [temporaryJPEGURL])
      })
      
      alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
      
      alert.popoverPresentationController?.sourceView = self.view
      present(alert, animated: true)
    }
    
    
    
    func setupButtons(){
        galleryButton.rx.tap.bind { [weak self] in
            self?.openGallery()
        }.disposed(by: disposeBag)
        
        scanButton.rx.tap.bind { [weak self] in
            self?.openCamera()
        }.disposed(by: disposeBag)
        
        downloadButton.rx.tap.bind { [weak self] in
            self?.openDownloads()
        }.disposed(by: disposeBag)
        
        reportButton.rx.tap.bind { [weak self] in
            self?.shareAction()
        }.disposed(by: disposeBag)
        
        monitorButton.rx.tap.bind { [weak self] in
            self?.openBottomDrawer()
        }.disposed(by: disposeBag)
        
        premiumButton.rx.tap.bind { [weak self] in
            self?.upgradeTapped()
        }.disposed(by: disposeBag)
        
    }
    
    func openGallery() {
        
        if(Constants.ud.totalScans! > 20 && !Constants.ud.isPurchased){
            IAPManager.shared().presentSingleSubscriptionVC()
            IAPManager.shared().purchaseCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                }
            }
            IAPManager.shared().restoreCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                }
            }
        } else {
            let photos = PHPhotoLibrary.authorizationStatus()
                if photos == .authorized {
                    guard UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.savedPhotosAlbum) else { return }
                    let imagePickerController = UIImagePickerController()
                    imagePickerController.delegate = self
                    imagePickerController.sourceType = UIImagePickerController.SourceType.savedPhotosAlbum
                    imagePickerController.allowsEditing = Constants.ud.startCameraAtStartUp
                    
                    present(imagePickerController, animated: true, completion: nil)
                } else {
                    var flag = 0
                    PHPhotoLibrary.requestAuthorization({status in
                        if status == .authorized{
                           flag = 1
                        } else {
                            
                        }
                    })
                    if(flag == 1){
                        guard UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.savedPhotosAlbum) else { return }
                        let imagePickerController = UIImagePickerController()
                        imagePickerController.delegate = self
                        imagePickerController.sourceType = UIImagePickerController.SourceType.savedPhotosAlbum
                        imagePickerController.allowsEditing = Constants.ud.startCameraAtStartUp
                        self.present(imagePickerController, animated: true, completion: nil)
                    }
                }
           
        }

      }
    
    func openCamera(){
      
        if(Constants.ud.totalScans! > 20 && !Constants.ud.isPurchased){
            IAPManager.shared().presentSingleSubscriptionVC()
            IAPManager.shared().purchaseCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                }
            }
            IAPManager.shared().restoreCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                }
            }
        } else {
            guard UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera) else { return }
            let controller = VNDocumentCameraViewController()
            controller.delegate = self
            present(controller, animated: true)
        }
    }
    
    func openDownloads(){
        let controller = OCRLangsViewController()
        let navigation = UINavigationController(rootViewController: controller)
        navigation.modalPresentationStyle = .fullScreen
        present(navigation, animated: true)
    }
    
    private func openBottomDrawer() {
      guard !images.isEmpty else { return }
      
        let viewController = DrawerViewController(with: images)
        let navigation = UINavigationController(rootViewController: viewController)
        navigation.modalPresentationStyle = .custom
        navigation.transitioningDelegate = self
        viewController.delegate = self
        present(navigation, animated: true)
      
    }
    
    private func upgradeTapped() {
        let vc = SettingsViewController()
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: true)
    }
    
    
}


extension ViewController: VNDocumentCameraViewControllerDelegate {
  /// Tells the delegate that the user successfully saved a scanned document from the document camera.
  func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFinishWith scan: VNDocumentCameraScan) {
    if scan.pageCount == 1 {
      progressManager?.startLoading(with: "Recognizing text from image...".localized)
    }
    
    controller.dismiss(animated: true) { [weak self] in
      guard let self = self else { return }
      if scan.pageCount == 1 {
        self.imageView.image = scan.imageOfPage(at: 0)
        self.images.append(scan.imageOfPage(at: 0))
        self.process(image: scan.imageOfPage(at: 0))
      } else {
        self.images.removeAll()
        
        for index in 0..<scan.pageCount {
          self.images.append(scan.imageOfPage(at: index))
        }
        
          let viewController = DrawerViewController(with: self.images)
          let navigation = UINavigationController(rootViewController: viewController)
          navigation.modalPresentationStyle = .custom
          navigation.transitioningDelegate = self
          viewController.delegate = self
          self.present(navigation, animated: true)
      }
    }
  }
  
  /// Tells the delegate that document scanning failed while the camera view controller was active.
  func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFailWithError error: Error) {
    controller.dismiss(animated: true)
  }
  
  /// Tells the delegate that the user canceled out of the document scanner camera.
  func documentCameraViewControllerDidCancel(_ controller: VNDocumentCameraViewController) {
    controller.dismiss(animated: true)
  }
}

extension ViewController: DrawerViewControllerDelegate {
  func drawerController(controller: DrawerViewController, didSelect image: UIImage) {
    progressManager?.startLoading(with: "Recognizing text from image...")
    
    controller.dismiss(animated: true) { [weak self] in
      guard let self = self else { return }
      self.imageView.image = image
      self.process(image: image)
    }
  }
}

extension ViewController: UINavigationControllerDelegate, UIImagePickerControllerDelegate {
  /// Your delegate object’s implementation of this method should pass the specified media on to any custom code that needs it, and should then dismiss the picker view.
  /// When editing is enabled, the image picker view presents the user with a preview of the currently selected image or movie along with controls for modifying it.
  /// (This behavior is managed by the picker view prior to calling this method.) If the user modifies the image or movie, the editing information is available in the info parameter.
  /// The original image is also returned in the info parameter.
  func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
    
    progressManager?.startLoading(with: "Recognizing text from image...")
    
    picker.dismiss(animated: true) { [weak self] in
      guard let self = self else { return }
      guard let image = info[UserDefaults.standard.isPhotoEditigOn ? UIImagePickerController.InfoKey.editedImage : UIImagePickerController.InfoKey.originalImage] as? UIImage else { return }
      self.imageView.image = image
  //    self.images.insert(image, at: 0)
      self.process(image: image)
    }
  }
}


