import UIKit
import Contacts
import IHProgressHUD

 @main
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        ContactManager.shared().requestAccess { accessGranted in

        }
        setMain()
        return true
    }
}

extension AppDelegate {
    private func setMain(){
        window = UIWindow()
        let vc = LaunchScreenViewController()
        let nc = UINavigationController(rootViewController: vc)
        window?.rootViewController = nc
        self.window?.makeKeyAndVisible()
    }
}
