import UIKit
import CallKit
import PushKit
import SnapKit
import SwiftyContacts
import Contacts
import MessageUI
import RxSwift
import ContactsUI

class ContactsViewController: UIViewController, MFMessageComposeViewControllerDelegate, CNContactViewControllerDelegate {
    
    private lazy var searchBar: UISearchBar = {
        let bar = UISearchBar()
        bar.searchBarStyle = UISearchBar.Style.default
        bar.placeholder = "Search..."
        bar.setShowsCancelButton(false, animated: false)
        bar.isSearchResultsButtonSelected = true
        bar.delegate = self
        bar.searchBarStyle = .minimal
        return bar
    }()
    
    private var groupsTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 64
        table.backgroundColor = .clear
        table.isScrollEnabled = true
        table.separatorStyle = .none
        table.sectionIndexColor = .black
        return table
    }()
    
    private var searchTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 61
        table.backgroundColor = .clear
        table.isScrollEnabled = true
        table.separatorStyle = .none
        table.sectionIndexColor = .black
        return table
    }()
    
    private var emptyView: UIView = {
        let view = UIView()
        view.backgroundColor = .gray
        view.isHidden = true
        return view
    }()
    
    private var groupsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .semibold)
        label.textAlignment = .left
        label.textColor = "404147".hexColor
        label.text = "Groups"
        return label
    }()
    
    private var contactsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .semibold)
        label.textAlignment = .left
        label.textColor = "404147".hexColor
        label.text = "Contacts"
        return label
    }()
    
    private var addGroupeButton: UIButton = {
        let button = UIButton()
        button.setImage("AddNew".image, for: .normal)
        return button
    }()
    
    private var addContactsButton: UIButton = {
        let button = UIButton()
        button.setImage("AddNew".image, for: .normal)
        return button
    }()
    
    private var groupsView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()
    
    private var openFullGroupsButton: UIButton = {
        let button = UIButton()
        button.setImage("down".image, for: .normal)
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setupGroups()
        self.fullContactsCN = ContactManager.shared().allContactsCN
        self.sortedContacts = ContactManager.shared().sortedContacts
        self.searchContact = ContactManager.shared().sortedContacts
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.searchTableView.reloadData()
        }
    }
    
    var fullContacts = [ContactsModel]()
    var fullContactsCN = ContactManager.shared().allContactsCN
    
    var sortedContacts = ContactManager.shared().sortedContacts
    var searchContact = ContactManager.shared().sortedContacts
    
    var selectedIndex = 0
    var deselected = -1
    
    var UpOrDown = false
    
    var currentData: [Data]?
    
    var myGroup = [GroupModel]()
    
    let disposeBag = DisposeBag()
    
    private func setup(){
        setupLayout()
        
        configureTableView2()
        configureGroupsTableView()
        setupHideKeyboardOnTap()
        setupButton()
    }
    
    private func setupLayout(){
        navigationController?.isNavigationBarHidden = true
        view.addSubviews(searchBar, groupsLabel, addGroupeButton, groupsView, openFullGroupsButton, contactsLabel, addContactsButton, searchTableView, emptyView)
        
        groupsView.addSubviews(groupsTableView)
        
        searchBar.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(50)
            make.height.equalTo(50)
            make.leading.equalToSuperview().offset(10)
            make.trailing.equalToSuperview().offset(-10)
        }
        
        groupsLabel.snp.makeConstraints { make in
            make.top.equalTo(searchBar.snp.bottom).offset(23)
            make.leading.equalToSuperview().offset(16)
            make.height.equalTo(32)
        }
        
        addGroupeButton.snp.makeConstraints { make in
            make.top.equalTo(searchBar.snp.bottom).offset(26)
            make.leading.equalTo(groupsLabel.snp.trailing).offset(8)
            make.size.equalTo(26)
        }
        
        groupsView.snp.makeConstraints { make in
            make.top.equalTo(groupsLabel.snp.bottom).offset(24)
            make.leading.equalToSuperview().offset(19)
            make.trailing.equalToSuperview().offset(-19)
            make.height.equalTo(108)
        }
        
        groupsTableView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        openFullGroupsButton.snp.makeConstraints { make in
            make.top.equalTo(groupsView.snp.bottom).offset(11)
            make.width.equalTo(34)
            make.height.equalTo(23)
            make.centerX.equalToSuperview()
        }
        
        contactsLabel.snp.makeConstraints { make in
            make.top.equalTo(groupsView.snp.bottom).offset(42)
            make.leading.equalToSuperview().offset(16)
            make.height.equalTo(32)
        }
        
        addContactsButton.snp.makeConstraints { make in
            make.top.equalTo(groupsView.snp.bottom).offset(42)
            make.leading.equalTo(contactsLabel.snp.trailing).offset(8)
            make.size.equalTo(26)
        }
        
        searchTableView.snp.makeConstraints { make in
            make.top.equalTo(contactsLabel.snp.bottom).offset(27)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-10)
        }
        
        UpOrDown = false
    }
    
    //MARK: Configure TableView
    
    private func configureTableView2() {
        searchTableView.delegate = self
        searchTableView.dataSource = self
        searchTableView.register(SearchCell.self, forCellReuseIdentifier: SearchCell.nibIdentifier)
    }
    
    private func configureGroupsTableView() {
        groupsTableView.delegate = self
        groupsTableView.dataSource = self
        groupsTableView.register(GroupsCell.self, forCellReuseIdentifier: GroupsCell.nibIdentifier)
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        switch result {
        case .cancelled:
            print("cancelled")
            self.dismiss(animated: true)
        case .sent:
            self.dismiss(animated: true)
            print("sent")
        case .failed:
            self.dismiss(animated: true)
            print("failed")
        default:
            self.dismiss(animated: true)
            print("UNKOWN")
        }
    }
    
    private func setupButton(){
        addContactsButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.addNewContactAction()
        }.disposed(by: disposeBag)
        
        addGroupeButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.addGroupOfContactsAction()
        }.disposed(by: disposeBag)
        
        openFullGroupsButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            if self.UpOrDown == false {
                self.reveal()
            } else {
                self.close()
            }
        }.disposed(by: disposeBag)
    }
    
    private func reveal(){
        
        UIView.animate(withDuration: 1) {
            self.groupsView.snp.remakeConstraints { make in
                make.top.equalTo(self.groupsLabel.snp.bottom).offset(24)
                make.leading.equalToSuperview().offset(19)
                make.trailing.equalToSuperview().offset(-19)
                make.bottom.equalTo(self.view.safeAreaLayoutGuide.snp.bottom).offset(-100)
            }
            
            self.groupsTableView.snp.remakeConstraints { make in
                make.top.equalToSuperview()
                make.leading.equalToSuperview()
                make.trailing.equalToSuperview()
                make.bottom.equalToSuperview()
            }
            
            self.openFullGroupsButton.snp.remakeConstraints { make in
                make.top.equalTo(self.groupsView.snp.bottom).offset(11)
                make.width.equalTo(34)
                make.height.equalTo(23)
                make.centerX.equalToSuperview()
            }
            
            self.contactsLabel.snp.remakeConstraints { make in
                make.top.equalTo(self.groupsView.snp.bottom).offset(42)
                make.leading.equalToSuperview().offset(16)
                make.height.equalTo(32)
            }
            
            self.addContactsButton.snp.remakeConstraints { make in
                make.top.equalTo(self.groupsView.snp.bottom).offset(42)
                make.leading.equalTo(self.contactsLabel.snp.trailing).offset(8)
                make.size.equalTo(26)
            }
            
            self.searchTableView.snp.remakeConstraints { make in
                make.top.equalTo(self.contactsLabel.snp.bottom).offset(107)
                make.leading.equalToSuperview().offset(20)
                make.trailing.equalToSuperview().offset(-20)
                
            }
            
            self.searchTableView.reloadData()
            self.openFullGroupsButton.setImage("up".image, for: .normal)
            self.UpOrDown = true
            self.view.layoutIfNeeded()
        }
    }
    
    private func close(){
        UIView.animate(withDuration: 1) {
            self.groupsView.snp.remakeConstraints { make in
                make.top.equalTo(self.groupsLabel.snp.bottom).offset(24)
                make.leading.equalToSuperview().offset(19)
                make.trailing.equalToSuperview().offset(-19)
                make.height.equalTo(108)
            }
            
            self.groupsTableView.snp.remakeConstraints { make in
                make.top.equalToSuperview()
                make.leading.equalToSuperview()
                make.trailing.equalToSuperview()
                make.bottom.equalToSuperview()
            }
            
            self.openFullGroupsButton.snp.remakeConstraints { make in
                make.top.equalTo(self.groupsView.snp.bottom).offset(11)
                make.width.equalTo(34)
                make.height.equalTo(23)
                make.centerX.equalToSuperview()
            }
            
            self.contactsLabel.snp.remakeConstraints { make in
                make.top.equalTo(self.groupsView.snp.bottom).offset(42)
                make.leading.equalToSuperview().offset(16)
                make.height.equalTo(32)
            }
            
            self.addContactsButton.snp.remakeConstraints { make in
                make.top.equalTo(self.groupsView.snp.bottom).offset(42)
                make.leading.equalTo(self.contactsLabel.snp.trailing).offset(8)
                make.size.equalTo(26)
            }
            
            self.searchTableView.snp.remakeConstraints { make in
                make.top.equalTo(self.contactsLabel.snp.bottom).offset(27)
                make.leading.equalToSuperview().offset(20)
                make.trailing.equalToSuperview().offset(-20)
                make.bottom.equalTo(self.view.safeAreaLayoutGuide.snp.bottom).offset(-10)
            }
            self.searchTableView.reloadData()
            self.openFullGroupsButton.setImage("down".image, for: .normal)
            self.UpOrDown = false
            self.view.layoutIfNeeded()
        }
    }
    
    private func addNewContactAction(){
        navigationController?.isNavigationBarHidden = false
        let con = CNMutableContact()
        con.phoneNumbers.append(CNLabeledValue(
            label: "New Contact", value: CNPhoneNumber(stringValue: "\("")")))
        
        let unkvc = CNContactViewController(forNewContact: con)
        unkvc.contactStore = CNContactStore()
        unkvc.delegate = self
        DispatchQueue.main.async {
            self.present(UINavigationController(rootViewController: unkvc), animated: true)
        }
    }
    
    private func addGroupOfContactsAction() {
        let vc = GroupViewController()
        vc.modalPresentationStyle = .pageSheet
        self.present(vc, animated: true)
    }
    
    func setupGroups(){
        myGroup = []
        for name in (Constants.ud.contactGroupNames) {
            myGroup.append(GroupModel(nameGroup: name))
        }
        groupsTableView.reloadData()
    }
}

//MARK: SearhBar
extension ContactsViewController: UISearchBarDelegate {
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        emptyView.isHidden = false
        searchTableView.reloadData()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchContact = []
        
        let number = searchText
        let numberWithoutSpaces = number.filter {!$0.isWhitespace}
        
        if numberWithoutSpaces == "" {
            searchContact = sortedContacts
        } else {
            for contact in sortedContacts {
                let name = contact.name!
                let phoneNumberWithoutSpaces = contact.phoneNumber!.filter {!$0.isWhitespace}
                let phoneNumber = phoneNumberWithoutSpaces.digitString
                
                if searchText.contains("+373") {
                    let filteredText = searchText.dropFirst(4)
                    if (name.lowercased().contains(filteredText.lowercased())) {
                        searchContact.append(contact)
                    } else if (phoneNumber.lowercased().contains(filteredText.lowercased())) {
                        searchContact.append(contact)
                    }
                } else {
                    if (name.lowercased().contains(searchText.lowercased())) {
                        searchContact.append(contact)
                    } else if (phoneNumber.lowercased().contains(searchText.lowercased())) {
                        searchContact.append(contact)
                    }
                }
            }
        }
        self.searchTableView.reloadData()
        
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
}

//MARK: UITableViewDelegate, UITableViewDataSource

extension ContactsViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == groupsTableView {
            let vc = CurrentGroupViewController()
            let data = Constants.ud.dataContactsGroup[indexPath.item]
            vc.dataCurrentContacts = data as! Data
            vc.nameGroup = myGroup[indexPath.row].nameGroup
            vc.currentIndexData = indexPath.row
            vc.modalPresentationStyle = .pageSheet
            self.present(vc, animated: true)
        }
    }
}

extension ContactsViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if tableView == groupsTableView {
            return 1
        } else {
            return 1
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == groupsTableView {
            return myGroup.count
        } else {
            return searchContact.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == groupsTableView {
            let cell = groupsTableView.dequeueReusableCell(withIdentifier: GroupsCell.nibIdentifier, for: indexPath) as! GroupsCell
            cell.groupModel = myGroup[indexPath.row]
            return cell
            
        } else {
            let cell = searchTableView.dequeueReusableCell(withIdentifier: SearchCell.nibIdentifier, for: indexPath) as! SearchCell
            let contact = searchContact[indexPath.row]
            
            cell.contactModel = contact
            
            cell.openInformationOfContacts = { [weak self] in
                guard let self = self else { return }
                
                let store = CNContactStore()
            
                let currentContacts = self.searchContact[indexPath.row].identifier
                
                do {
                    let descriptor = CNContactViewController.descriptorForRequiredKeys()
                    let editContact = try store.unifiedContact(withIdentifier: currentContacts ?? "-1", keysToFetch: [descriptor])
                    let vc = CNContactViewController(for: editContact)
                    vc.allowsEditing = true
                    vc.delegate = self
                    DispatchQueue.main.async {
                        self.navigationController?.isNavigationBarHidden = false
                        self.navigationController?.makeClearBar(color: .clear)
                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                } catch {
                    print(error)
                }
            }
            
            cell.completionInfoContacts = { [weak self] in
                guard let self = self else { return }
                
                if self.selectedIndex != indexPath.row {
                    self.searchContact[self.selectedIndex].checkSelected = false
                }
                
                if self.searchContact[indexPath.row].checkSelected == true {
                    self.searchContact[indexPath.row].checkSelected = false
                } else {
                    self.searchContact[indexPath.row].checkSelected = true
                    self.selectedIndex = indexPath.row
                }
                
                self.searchTableView.reloadData()
            }
            
            if self.searchContact[indexPath.row].checkSelected == true {
                cell.setupLayoutSelected()
            } else {
                cell.setupLayoutNotSelected()
            }
            
            cell.completion = { [weak self] in
                guard let self = self else { return }
                let number = (self.searchContact[indexPath.row].phoneNumber)!
                let composer = MFMessageComposeViewController()
                composer.messageComposeDelegate = self
                composer.recipients = ["\(number)"]
                composer.subject = "Hello Agent"
                self.present(composer, animated: true)
            }
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == searchTableView {
            if self.searchContact[indexPath.row].checkSelected == true {
                return 110
            } else {
                return 61
            }
        } else {
            return 64
        }
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        if tableView == groupsTableView {
            return true
        } else {
            return false
        }
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if tableView == groupsTableView {
            if editingStyle == .delete {
                self.myGroup.remove(at: indexPath.row)
                Constants.ud.dataContactsGroup.remove(at: indexPath.row)
                Constants.ud.contactGroupNames.remove(at: indexPath.row)
                self.groupsTableView.reloadData()
            }
        }
    }
}

extension UIImage {
    func toPngString() -> String? {
        let data = self.pngData()
        return data?.base64EncodedString(options: .endLineWithLineFeed)
    }
    
    func toJpegString(compressionQuality cq: CGFloat) -> String? {
        let data = self.jpegData(compressionQuality: cq)
        return data?.base64EncodedString(options: .endLineWithLineFeed)
    }
}
