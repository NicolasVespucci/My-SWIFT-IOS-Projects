import UIKit
import SnapKit
import SwiftyContacts
import Contacts
import MessageUI
import RxSwift
import ContactsUI
import SwiftyAttributes

class AddMoreContactsViewController: UIViewController, MFMessageComposeViewControllerDelegate, CNContactViewControllerDelegate {
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("dismiss".image, for: .normal)
        return button
    }()
    
    private var compliteButton: UIButton = {
        let button = UIButton()
        button.setImage("complite".image, for: .normal)
        return button
    }()
    
    private var chooseLabel: UILabel = {
        let label = UILabel()
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        let attributedTitle = ("Chosen - "
            .withAttributes([.textColor("323232".hexColor),
                             .font(.systemFont(ofSize: 14, weight: .medium))])
                               + "0"
            .withAttributes([.textColor("007AFF".hexColor),
                             .font(.systemFont(ofSize: 14, weight: .regular))])
                               + " contacts"
            .withAttributes([.textColor("323232".hexColor),
                             .font(.systemFont(ofSize: 14, weight: .semibold))])).withAttribute(.paragraphStyle(paragraphStyle))
        label.attributedText = attributedTitle
        return label
    }()
    
    private var groupNameTextField: UITextField = {
        let tf = UITextField()
        tf.placeholder = "  Group Name"
        tf.backgroundColor = "F2F2F2".hexColor
        tf.layer.cornerRadius = 8
        return tf
    }()
    
    private var groupTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 61
        table.backgroundColor = .clear
        table.isScrollEnabled = true
        table.separatorStyle = .none
        table.sectionIndexColor = .black
        return table
    }()
    
    private var addMoreContactsButton: UIButton = {
        let button = UIButton()
        button.setImage("AddNew".image, for: .normal)
        return button
    }()
    
    let disposeBag = DisposeBag()
    
    var fullContacts = [ContactsModel]()
    var searchContact = [ContactsModel]()
    var contactsForCurrentGroup = [ContactsModel]()
    
    var selectedIndex = 0
    var deselected = -1
    var currentIndexData: Int?
    
    var selectedCellValue = [String]()
    var countSelectedCell = [String]()
    
    var fullContactsCN = [CNContact]()
    var selectedContactsCN = [CNContact]()
    
    var currentGroupContacts = [ContactsModel]()
    
    var newSelectedContactsCN = [CNContact]()
    var newContactsForCurrentGroup = [ContactsModel]()
    var countNotAddedContacts = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if let groupContacts = (presentingViewController as? CurrentGroupViewController) {
            print("Added New Contacts in current group")
            groupContacts.newlyAddedContacts = newContactsForCurrentGroup
            groupContacts.addedNewContactsInCurrentGroupAction()
        } else {
            print("error")
        }
    }
    
    private func setup(){
        setupLayout()
        fetchContact()
        setupButton()
        configureGroupsTableView()
        setupHideKeyboardOnTap()
    }
    
    private func setupLayout(){
        view.backgroundColor = .white
        view.addSubviews(backButton, compliteButton, chooseLabel, groupNameTextField, addMoreContactsButton, groupTableView)
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(75)
            make.leading.equalToSuperview().offset(16)
            make.size.equalTo(35)
        }
        
        compliteButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(71)
            make.trailing.equalToSuperview().offset(-16)
            make.size.equalTo(35)
        }
        
        chooseLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(69)
            make.leading.equalToSuperview().offset(70)
            make.trailing.equalToSuperview().offset(-70)
            make.height.equalTo(26)
        }
        
        groupTableView.snp.makeConstraints { make in
            make.top.equalTo(chooseLabel.snp.bottom).offset(45)
            make.leading.equalToSuperview().offset(16)
            make.trailing.equalToSuperview().offset(-16)
            make.bottom.equalToSuperview()
        }
    }
    
    private func setupButton(){
        backButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.dismiss(animated: true)
            self.searchContact.removeAll()
            self.fullContactsCN.removeAll()
            self.selectedContactsCN.removeAll()
            self.fullContacts.removeAll()
            self.contactsForCurrentGroup.removeAll()
        }.disposed(by: disposeBag)
        
        compliteButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.compliteButtonAction()
        }.disposed(by: disposeBag)
    }
    
    private func compliteButtonAction() {
        contactsForCurrentGroup.forEach { one in
            let count = currentGroupContacts.filter ({ $0.identifier == one.identifier}).count
            let name = currentGroupContacts.filter ({ $0.name == one.name}).count
            let number = currentGroupContacts.filter ({ $0.phoneNumber == one.phoneNumber}).count
            
            if count == 0 {
                newContactsForCurrentGroup.append(one)
            } else if name == 0 {
                newContactsForCurrentGroup.append(one)
            } else if number == 0 {
                newContactsForCurrentGroup.append(one)
            } else {
                countNotAddedContacts += 1
                print("This Contact there in current group")
            }
        }
        
        if countNotAddedContacts != 0 {
            AlertManager.shared().contactsHaveAlreadyBeenAdded(count: countNotAddedContacts)
        }
        
        self.dismiss(animated: true)
    }
    
    private func configureGroupsTableView() {
        groupTableView.delegate = self
        groupTableView.dataSource = self
        groupTableView.register(GroupCell.self, forCellReuseIdentifier: GroupCell.nibIdentifier)
    }
    
    private func fetchContact() {
        searchContact = ContactManager.shared().sortedContacts
        fullContactsCN = ContactManager.shared().allContactsCN
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        switch result {
        case .cancelled:
            print("cancelled")
            self.dismiss(animated: true)
        case .sent:
            self.dismiss(animated: true)
            print("sent")
        case .failed:
            self.dismiss(animated: true)
            print("failed")
        default:
            self.dismiss(animated: true)
            print("UNKOWN")
        }
    }
    
    private func configureSelectedCell() {
        selectedCellValue = []
        countSelectedCell = []
        contactsForCurrentGroup = []
        for contact in searchContact {
            selectedCellValue.append(contact.selectedNonSelectedImage ?? "nonSelectedCell")
            if contact.selectedNonSelectedImage == "SelectedCell" {
                countSelectedCell.append(contact.selectedNonSelectedImage ?? "nonSelectedCell")
                contactsForCurrentGroup.append(contact)
            }
            
        }
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        let attributedTitle = ("Chosen - "
            .withAttributes([.textColor("323232".hexColor),
                             .font(.systemFont(ofSize: 14, weight: .medium))])
                               + "\(countSelectedCell.count)"
            .withAttributes([.textColor("007AFF".hexColor),
                             .font(.systemFont(ofSize: 14, weight: .regular))])
                               + " contacts"
            .withAttributes([.textColor("323232".hexColor),
                             .font(.systemFont(ofSize: 14, weight: .semibold))])).withAttribute(.paragraphStyle(paragraphStyle))
        chooseLabel.attributedText = attributedTitle
    }
    
    //MARK: Deinit
    deinit {
        print("deinit Complite-----.....")
    }
    
}

extension AddMoreContactsViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
}

extension AddMoreContactsViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchContact.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = groupTableView.dequeueReusableCell(withIdentifier: GroupCell.nibIdentifier, for: indexPath) as! GroupCell
        let contact = searchContact[indexPath.row]
        cell.contactModel = contact
        
        cell.completionSelectedCell = { [weak self] in
            guard let self = self else { return }
            if self.searchContact[indexPath.row].selectedNonSelectedImage == "SelectedCell" {
                self.searchContact[indexPath.row].selectedNonSelectedImage = "nonSelectedCell"
                self.configureSelectedCell()
                self.groupTableView.reloadData()
            } else {
                self.searchContact[indexPath.row].selectedNonSelectedImage = "SelectedCell"
                self.configureSelectedCell()
                self.groupTableView.reloadData()
            }
        }
        
        cell.openInformationOfContacts = { [weak self] in
            guard let self = self else { return }
            
            let store = CNContactStore()
            
            let currentContacts = self.searchContact[indexPath.row].identifier
            
            do {
                let descriptor = CNContactViewController.descriptorForRequiredKeys()
                let editContact = try store.unifiedContact(withIdentifier: currentContacts ?? "-1", keysToFetch: [descriptor])
                let vc = CNContactViewController(for: editContact)
                vc.allowsEditing = true
                vc.delegate = self
                DispatchQueue.main.async {
                    self.navigationController?.isNavigationBarHidden = false
                    self.navigationController?.makeClearBar(color: .clear)
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            } catch {
                print(error)
            }
        }
        
        cell.completionInfoContacts = { [weak self] in
            guard let self = self else { return }
            
            if self.selectedIndex != indexPath.row {
                self.searchContact[self.selectedIndex].checkSelected = false
            }
            
            if self.searchContact[indexPath.row].checkSelected == true {
                self.searchContact[indexPath.row].checkSelected = false
            } else {
                self.searchContact[indexPath.row].checkSelected = true
                self.selectedIndex = indexPath.row
            }
            
            self.groupTableView.reloadData()
        }
        
        if self.searchContact[indexPath.row].checkSelected == true {
            cell.setupLayoutSelected()
        } else {
            cell.setupLayoutNotSelected()
        }
        
        cell.completion = { [weak self] in
            guard let self = self else { return }
            let number = (self.searchContact[indexPath.row].phoneNumber)!
            let composer = MFMessageComposeViewController()
            composer.messageComposeDelegate = self
            composer.recipients = ["\(number)"]
            composer.subject = "Hello Agent"
            self.present(composer, animated: true)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if self.searchContact[indexPath.row].checkSelected == true {
            return 110
        } else {
            return 61
        }
    }
}
