
import UIKit
import SnapKit
import SwiftyContacts
import Contacts
import MessageUI
import RxSwift
import ContactsUI
import SwiftyAttributes

class CurrentGroupViewController: UIViewController, MFMessageComposeViewControllerDelegate, CNContactViewControllerDelegate {
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("dismiss".image, for: .normal)
        return button
    }()
    
    private var compliteButton: UIButton = {
        let button = UIButton()
        button.setImage("complite".image, for: .normal)
        return button
    }()
    
    private var chooseLabel: UILabel = {
        let label = UILabel()
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        let attributedTitle = ("0"
            .withAttributes([.textColor("007AFF".hexColor),
                             .font(.systemFont(ofSize: 14, weight: .regular))])
                               + " contacts in your group"
            .withAttributes([.textColor("323232".hexColor),
                             .font(.systemFont(ofSize: 14, weight: .semibold))])).withAttribute(.paragraphStyle(paragraphStyle))
        label.attributedText = attributedTitle
        return label
    }()
    
    private var groupNameTextField: UITextField = {
        let tf = UITextField()
        tf.placeholder = "  Group Name"
        tf.backgroundColor = "F2F2F2".hexColor
        tf.layer.cornerRadius = 8
        return tf
    }()
    
    private var groupTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 61
        table.backgroundColor = .clear
        table.isScrollEnabled = true
        table.separatorStyle = .none
        table.sectionIndexColor = .black
        return table
    }()
    
    private var addMoreContactsButton: UIButton = {
        let button = UIButton()
        button.setImage("AddNew".image, for: .normal)
        return button
    }()
    
    let disposeBag = DisposeBag()
    
    var fullContacts = [ContactsModel]()
    var searchContact = [ContactsModel]()
    var contactsForCurrentGroup = [ContactsModel]()
    var newlyAddedContacts = [ContactsModel]()
    
    var selectedIndex = 0
    var deselected = -1
    var currentIndexData: Int?
    
    var selectedCellValue = [String]()
    var countSelectedCell = [String]()
    
    var fullContactsCN = [CNContact]()
    var selectedContactsCN = [CNContact]()
    var newlyAddedContactsCN = [CNContact]()
    
    var dataCurrentContacts: Data?
    
    var nameGroup: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("")
        if let contactVC = (((presentingViewController as? UINavigationController)?.viewControllers.first as? MainTabBarViewController)?.viewControllers?[1] as? UINavigationController)?.viewControllers.first as? ContactsViewController {
            contactVC.setupGroups()
        } else {
            print("error")
        }
    }
    
    private func setup(){
        setupLayout()
        configurateCurrentGroup()
        setupButton()
        configureGroupsTableView()
        setupHideKeyboardOnTap()
    }
    
    private func setupLayout(){
        view.backgroundColor = .white
        view.addSubviews(backButton, compliteButton, chooseLabel, groupNameTextField, addMoreContactsButton, groupTableView)
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(75)
            make.leading.equalToSuperview().offset(16)
            make.size.equalTo(35)
        }
        
        compliteButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(71)
            make.trailing.equalToSuperview().offset(-16)
            make.size.equalTo(35)
        }
        
        chooseLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(69)
            make.leading.equalToSuperview().offset(70)
            make.trailing.equalToSuperview().offset(-70)
            make.height.equalTo(26)
        }
        
        groupNameTextField.snp.makeConstraints { make in
            make.top.equalTo(compliteButton.snp.bottom).offset(59)
            make.leading.equalToSuperview().offset(16)
            make.trailing.equalToSuperview().offset(-50)
            make.height.equalTo(50)
        }
        
        addMoreContactsButton.snp.makeConstraints { make in
            make.top.equalTo(compliteButton.snp.bottom).offset(67)
            make.trailing.equalToSuperview().offset(-10)
            make.size.equalTo(35)
        }
        
        groupTableView.snp.makeConstraints { make in
            make.top.equalTo(groupNameTextField.snp.bottom).offset(45)
            make.leading.equalToSuperview().offset(16)
            make.trailing.equalToSuperview().offset(-16)
            make.bottom.equalToSuperview()
        }
    }
    
    private func setupButton(){
        backButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.dismiss(animated: true)
            self.searchContact.removeAll()
            self.fullContactsCN.removeAll()
            self.selectedContactsCN.removeAll()
            self.fullContacts.removeAll()
            self.contactsForCurrentGroup.removeAll()
            self.dataCurrentContacts = nil
        }.disposed(by: disposeBag)
        
        compliteButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.addContactsInNewGroup()
        }.disposed(by: disposeBag)
        
        addMoreContactsButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.addMoreContactsButtonAction()
        }.disposed(by: disposeBag)
    }
    
    private func configureGroupsTableView() {
        groupTableView.delegate = self
        groupTableView.dataSource = self
        groupTableView.register(GroupWithoutCheckMarkCell.self, forCellReuseIdentifier: GroupWithoutCheckMarkCell.nibIdentifier)
    }
    
    private func addMoreContactsButtonAction(){
        let vc = AddMoreContactsViewController()
        vc.currentIndexData = currentIndexData
        vc.currentGroupContacts = searchContact
        vc.modalPresentationStyle = .pageSheet
        self.present(vc, animated: true)
    }
    
    func addedNewContactsInCurrentGroupAction() {
        if newlyAddedContacts.count != 0 {
            for contacts in newlyAddedContacts {
                searchContact.append(contacts)
            }
            
            let currentData = Constants.ud.dataContactsGroup[currentIndexData ?? -1]
            
            let transformationIntoContacts = NSKeyedUnarchiver.unarchiveObject(with: currentData as! Data) as? [CNContact]
            
            fullContactsCN = transformationIntoContacts ?? [CNContact]()
            
            for contact in newlyAddedContactsCN {
                fullContactsCN.append(contact)
            }
            
            let updatingContactsCurrentGroupData = NSKeyedArchiver.archivedData(withRootObject: fullContactsCN)
            let fullData = Constants.ud.dataContactsGroup
            var newFullData = [Any]()
            
            fullData.enumerated().forEach { indexData, data in
                if indexData == currentIndexData {
                    newFullData.append(updatingContactsCurrentGroupData)
                } else {
                    newFullData.append(data)
                }
            }
            
            Constants.ud.dataContactsGroup = newFullData
            
            groupTableView.reloadData()
            
            updateCountContactsInGroupLabel()
        }
    }
    
    private func addContactsInNewGroup(){
        //Rename Group
        let currentNameGroup = Constants.ud.contactGroupNames[currentIndexData ?? -1]
        var updatingNamesArray = [String]()
        
        for name in (Constants.ud.contactGroupNames) {
            var newName = "-1"
            if name == currentNameGroup {
                newName = groupNameTextField.text!
                updatingNamesArray.append(newName)
                //return
                //MARK: Если одинакое имя шо делать?
            } else {
                updatingNamesArray.append(name)
            }
        }
        
        Constants.ud.contactGroupNames = updatingNamesArray
        
        //Resave Contacts
        
        var dataOld = Constants.ud.savedAndCheckContacts
        
        let transformationIntoContacts = NSKeyedUnarchiver.unarchiveObject(with: dataOld!) as? [CNContact]
        
        fullContactsCN = transformationIntoContacts ?? [CNContact]()
        
        var newAddedContacts = [ContactsModel]()
        
        searchContact.forEach({ one in
            fullContactsCN.forEach { two in
                
                //ONE
                let id1 = one.identifier
                let name1 = one.name
                let number1 = one.phoneNumber
                
                //TWO
                let id2 = two.identifier
                let name2 = two.givenName + " " + two.familyName
                let number2 = two.phoneNumbers.first?.value.stringValue ?? ""
                
                if id1 == id2 {
                    if name1 != name2 {
                        if number1 == number2 {
                            selectedContactsCN.append(two)
                        }
                    } else {
                        if number1 == number2 {
                            selectedContactsCN.append(two)
                        }
                    }
                }
            }
        })
        
        let dataUpdateContacts = NSKeyedArchiver.archivedData(withRootObject: selectedContactsCN)
        
        var currentData = Constants.ud.dataContactsGroup[currentIndexData ?? -1]
        let data = Constants.ud.dataContactsGroup
        
        var newDataGroup = [Any]()
        
        data.enumerated().forEach { indexData, data in
            if indexData == currentIndexData {
                newDataGroup.append(dataUpdateContacts)
            } else {
                newDataGroup.append(data)
            }
        }
        
        Constants.ud.dataContactsGroup = newDataGroup
        self.dismiss(animated: true)
    }
    
    private func configurateCurrentGroup(){
        
        groupNameTextField.text = (nameGroup ?? "")
        let transformationIntoContacts = NSKeyedUnarchiver.unarchiveObject(with: dataCurrentContacts!) as? [CNContact]
        
        var contacts = [CNContact]()
        
        contacts = transformationIntoContacts ?? [CNContact]()
        
        for contact in contacts {
            
            let fullName = contact.givenName + " " + contact.familyName
            let number = contact.phoneNumbers.first?.value.stringValue ?? ""
            let identy = contact.identifier
            
            
            if let imageData = contact.thumbnailImageData {
                let imageString = String(describing: UIImage(data: imageData))
                let stringImage = String(decoding: imageData, as: UTF8.self)
                
                self.fullContacts.append(ContactsModel(name: fullName, phoneNumber: number, dataImage: imageData, selectedNonSelectedImage: "nonSelectedCell", identifier: identy))
                self.fullContactsCN.append(contact)
                
            } else {
                var notImage = "contactImage"
                self.fullContacts.append(ContactsModel(name: fullName, phoneNumber: number, image: notImage, selectedNonSelectedImage: "nonSelectedCell", identifier: identy))
                self.fullContactsCN.append(contact)
            }
        }
        
        searchContact = fullContacts.sorted { (($0.name) ?? "√").compare(($1.name) ?? "√", options: .numeric) == .orderedAscending }
        
        updateCountContactsInGroupLabel()
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        switch result {
        case .cancelled:
            print("cancelled")
            self.dismiss(animated: true)
        case .sent:
            self.dismiss(animated: true)
            print("sent")
        case .failed:
            self.dismiss(animated: true)
            print("failed")
        default:
            self.dismiss(animated: true)
            print("UNKOWN")
        }
    }
    
    private func updateCountContactsInGroupLabel(){
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        let attributedTitle = ("\(searchContact.count)"
            .withAttributes([.textColor("007AFF".hexColor),
                             .font(.systemFont(ofSize: 14, weight: .regular))])
                               + " contacts in your group"
            .withAttributes([.textColor("323232".hexColor),
                             .font(.systemFont(ofSize: 14, weight: .semibold))])).withAttribute(.paragraphStyle(paragraphStyle))
        chooseLabel.attributedText = attributedTitle
    }
    
    //MARK: Deinit
    deinit {
        print("deinit Complite-----.....")
    }
    
}

extension CurrentGroupViewController: UITableViewDelegate {
}

extension CurrentGroupViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchContact.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = groupTableView.dequeueReusableCell(withIdentifier: GroupWithoutCheckMarkCell.nibIdentifier, for: indexPath) as! GroupWithoutCheckMarkCell
        let contact = searchContact[indexPath.row]
        cell.contactModel = contact
        
        cell.openInformationOfContacts = { [weak self] in
            guard let self = self else { return }
            let store = CNContactStore()
            let currentContacts = self.searchContact[indexPath.row].identifier
            
            do {
                let descriptor = CNContactViewController.descriptorForRequiredKeys()
                let editContact = try store.unifiedContact(withIdentifier: currentContacts ?? "-1", keysToFetch: [descriptor])
                let vc = CNContactViewController(for: editContact)
                vc.allowsEditing = true
                vc.delegate = self
                DispatchQueue.main.async {
                    
                    self.present(UINavigationController(rootViewController: vc), animated: true)
                }
            } catch {
                print(error)
            }
        }
        
        cell.completionInfoContacts = { [weak self] in
            guard let self = self else { return }
            
            if self.selectedIndex != indexPath.row {
                self.searchContact[self.selectedIndex].checkSelected = false
            }
            
            if self.searchContact[indexPath.row].checkSelected == true {
                self.searchContact[indexPath.row].checkSelected = false
            } else {
                self.searchContact[indexPath.row].checkSelected = true
                self.selectedIndex = indexPath.row
            }
            
            self.groupTableView.reloadData()
        }
        
        if self.searchContact[indexPath.row].checkSelected == true {
            cell.setupLayoutSelected()
        } else {
            cell.setupLayoutNotSelected()
        }
        
        cell.completion = { [weak self] in
            guard let self = self else { return }
            let number = (self.searchContact[indexPath.row].phoneNumber)!
            let composer = MFMessageComposeViewController()
            composer.messageComposeDelegate = self
            composer.recipients = ["\(number)"]
            composer.subject = "Hello Agent"
            self.present(composer, animated: true)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if self.searchContact[indexPath.row].checkSelected == true {
            return 110
        } else {
            return 61
        }
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            self.searchContact.remove(at: indexPath.row)
            self.updateCountContactsInGroupLabel()
            self.groupTableView.reloadData()
        }
    }
}
