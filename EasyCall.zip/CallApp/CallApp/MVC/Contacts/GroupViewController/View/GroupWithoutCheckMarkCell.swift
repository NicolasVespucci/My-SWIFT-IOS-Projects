import UIKit
import RxSwift
import MessageUI
import PhoneNumberKit

class GroupWithoutCheckMarkCell: UITableViewCell, MFMessageComposeViewControllerDelegate  {
    
    var completion: (()->())?
    
    var completionInfoContacts: (()->())?
    
    var openInformationOfContacts: (()->())?
    
    var contactModel: ContactsModel? {
        didSet { configureBackUpModel() }
    }
    
    let phoneNumberKit = PhoneNumberKit()
    
    private var cellView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 16
        return view
    }()
    
    private var nameLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.text = ""
        label.textColor = "3D485B".hexColor
        label.textAlignment = .left
        return label
    }()
    
    private var phoneNumberLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.text = ""
        label.textColor = "969696".hexColor
        label.textAlignment = .right
        return label
    }()
    
    private var messageButton: UIButton = {
        let button = UIButton()
        button.setImage("message".image, for: .normal)
        return button
    }()
    
    private var callButton: UIButton = {
        let button = UIButton()
        button.setImage("phone".image, for: .normal)
        return button
    }()
    
    private var informationOfContactButton: UIButton = {
        let button = UIButton()
        button.setImage("info".image, for: .normal)
        return button
    }()
    
    private var infoButton: UIButton = {
        let button = UIButton()
        return button
    }()
    
    private var detailsButton: UIButton = {
        let button = UIButton()
        button.setImage("details".image, for: .normal)
        return button
    }()
    
    private var viberButton: UIButton = {
        let button = UIButton()
        button.setImage("Viber".image, for: .normal)
        return button
    }()
    
    private var whatsAppButton: UIButton = {
        let button = UIButton()
        button.setImage("WhatsApp".image, for: .normal)
        return button
    }()
    
    private var telegramButton: UIButton = {
        let button = UIButton()
        button.setImage("Telegram".image, for: .normal)
        return button
    }()
    
    private var emptyView: UIView = {
        let view = UIView()
        view.backgroundColor = "F2F2F2".hexColor
        view.layer.cornerRadius = 7
        return view
    }()
    
    private var centerEmptyLineView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()
    
    let disposeBag = DisposeBag()
    var phoneNumber = ""
    var messageNumbe = ""
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        selectionStyle = .none
        setupButton()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupLayoutNotSelected(){
        emptyView.isHidden = true
        telegramButton.isHidden = true
        viberButton.isHidden = true
        telegramButton.isHidden = true
        detailsButton.setImage("openDown".image, for: .normal)
        
        cellView.subviews.forEach({
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.removeFromSuperview()
        })
        
        addSubview(cellView)
        cellView.addSubviews(nameLabel, centerEmptyLineView, phoneNumberLabel, infoButton)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        nameLabel.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.height.equalTo(27)
            make.leading.equalToSuperview()
            make.trailing.equalTo(centerEmptyLineView.snp.leading).offset(-5)
        }
        
        centerEmptyLineView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.centerX.equalToSuperview()
            make.width.equalTo(1)
            make.height.equalTo(27)
        }
        
        phoneNumberLabel.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.height.equalTo(27)
            make.trailing.equalToSuperview()
            make.leading.equalTo(centerEmptyLineView.snp.trailing).offset(5)
        }
        
        infoButton.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(27)
        }
    }
    
    func setupLayoutSelected(){
        
        emptyView.isHidden = false
        telegramButton.isHidden = false
        viberButton.isHidden = false
        telegramButton.isHidden = false
        detailsButton.setImage("closeUp".image, for: .normal)
        
        emptyView.subviews.forEach({
            $0.removeFromSuperview()
        })
        
        cellView.subviews.forEach({
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.removeFromSuperview()
        })
        
        addSubview(cellView)
        cellView.addSubviews(nameLabel, phoneNumberLabel, infoButton, emptyView)
        
        emptyView.addSubviews(callButton, messageButton, informationOfContactButton, telegramButton, viberButton,  whatsAppButton)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        nameLabel.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.height.equalTo(27)
            make.leading.equalToSuperview()
        }
        
        phoneNumberLabel.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.height.equalTo(27)
            make.trailing.equalToSuperview()
            make.leading.equalTo(nameLabel.snp.trailing).offset(10)
        }
        
        infoButton.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(27)
        }
        
        emptyView.snp.makeConstraints { make in
            make.top.equalTo(phoneNumberLabel.snp.bottom).offset(10)
            make.height.equalTo(48)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
        }
        
        callButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.size.equalTo(25)
            make.leading.equalToSuperview().offset(35.resized(.width))
        }
        
        messageButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.size.equalTo(25)
            make.leading.equalTo(callButton.snp.trailing).offset(16)
        }
        
        informationOfContactButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalTo(messageButton.snp.trailing).offset(16)
            make.size.equalTo(25)
        }
        
        telegramButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.size.equalTo(25)
            make.leading.equalTo(informationOfContactButton.snp.trailing).offset(16)
        }
        
        viberButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.size.equalTo(25)
            make.leading.equalTo(telegramButton.snp.trailing).offset(16)
        }
        
        whatsAppButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.size.equalTo(25)
            make.leading.equalTo(viberButton.snp.trailing).offset(16)
        }
    }
    
    private func setupButton() {
        
        callButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.phoneCalled()
        }.disposed(by: disposeBag)
        
        messageButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.sendMessage()
        }.disposed(by: disposeBag)
        
        infoButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.completionInfoContacts!()
        }.disposed(by: disposeBag)
        
        informationOfContactButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.openInformationOfContacts!()
        }.disposed(by: disposeBag)
        
        viberButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.viber()
        }.disposed(by: disposeBag)
        
        telegramButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.telegram()
        }.disposed(by: disposeBag)
        
        whatsAppButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.whatsapp()
        }.disposed(by: disposeBag)
    }
    
    private func configureBackUpModel() {
        guard let contactModel = contactModel else { return }
        phoneNumberLabel.text = contactModel.phoneNumber
        nameLabel.text = contactModel.name
        
        if nameLabel.text == " " {
            nameLabel.text = "No Name"
        } else if nameLabel.text == "" {
            nameLabel.text = "No Name"
        }
    }
    
    //  MARK: Whatsapp
    private func whatsapp() {
        let screenName = (phoneNumberLabel.text)!
        let numberWithoutSpaces = screenName.filter {!$0.isWhitespace}
        var changingNumber = ""
        do {
            var phoneNumber = try self.phoneNumberKit.parse(numberWithoutSpaces)
            changingNumber = self.phoneNumberKit.format(phoneNumber, toType: .international)
        }
        catch {
            print("Generic parser error")
        }
        let numberWithoutSpaces2 = changingNumber.filter {!$0.isWhitespace}
        let url  = NSURL(string: "whatsapp://send?phone=" + "\(numberWithoutSpaces2)")
        
        guard let url = url else { return }
        
        if UIApplication.shared.canOpenURL(url as URL) {
            // Open Whatsapp
            UIApplication.shared.open(url as URL, options: [:]){ (success) in
                if success {
                    print("WhatsApp accessed successfully")
                } else {
                    print("Error accessing WhatsApp")
                    let urlAppStore = NSURL(string: "https://apps.apple.com/ru/app/whatsapp-messenger/id310633997")!
                    UIApplication.shared.openURL(urlAppStore as URL)
                }
            }
        }
        
        UIApplication.shared.open(url as URL, options: [:]){ (success) in
            if success {
                print("WhatsApp accessed successfully")
            } else {
                print("Error accessing WhatsApp")
                let urlAppStore = NSURL(string: "https://apps.apple.com/ru/app/whatsapp-messenger/id310633997")!
                UIApplication.shared.openURL(urlAppStore as URL)
            }
        }
    }
    
    private func viber(){
        let screenName = (phoneNumberLabel.text)!
        let numberWithoutSpaces = screenName.filter {!$0.isWhitespace}
        var changingNumber = ""
        do {
            var phoneNumber = try self.phoneNumberKit.parse(numberWithoutSpaces)
            changingNumber = self.phoneNumberKit.format(phoneNumber, toType: .international)
        }
        catch {
            print("Generic parser error")
        }
        let numberWithoutSpaces2 = changingNumber.filter {!$0.isWhitespace}
        let url  = NSURL(string: "viber://contact?number=" + "\(numberWithoutSpaces2)")
        
        guard let url = url else { return }
        
        if UIApplication.shared.canOpenURL(url as URL) {
            UIApplication.shared.open(url as URL, options: [:]){ (success) in
                if success {
                    print("Viber accessed successfully")
                } else {
                    print("Error accessing Viber")
                    let urlAppStore = NSURL(string: "https://apps.apple.com/ru/app/viber-%D0%BC%D0%B5%D1%81%D1%81%D0%B5%D0%BD%D0%B4%D0%B6%D0%B5%D1%80-%D0%B8-%D0%B2%D0%B8%D0%B4%D0%B5%D0%BE-%D1%87%D0%B0%D1%82/id382617920")!
                    UIApplication.shared.openURL(urlAppStore as URL)
                }
            }
        }
        
        UIApplication.shared.open(url as URL, options: [:]){ (success) in
            if success {
                print("Viber accessed successfully")
            } else {
                print("Error accessing Viber")
                let urlAppStore = NSURL(string: "https://apps.apple.com/ru/app/viber-%D0%BC%D0%B5%D1%81%D1%81%D0%B5%D0%BD%D0%B4%D0%B6%D0%B5%D1%80-%D0%B8-%D0%B2%D0%B8%D0%B4%D0%B5%D0%BE-%D1%87%D0%B0%D1%82/id382617920")!
                UIApplication.shared.openURL(urlAppStore as URL)
            }
        }
    }
    
    //MARK: Telegram
    private func telegram() {
        let screenName = (phoneNumberLabel.text)!
        let numberWithoutSpaces = screenName.filter {!$0.isWhitespace}
        var changingNumber = ""
        do {
            var phoneNumber = try self.phoneNumberKit.parse(numberWithoutSpaces)
            changingNumber = self.phoneNumberKit.format(phoneNumber, toType: .international)
        }
        catch {
            print("Generic parser error")
        }
        let numberWithoutSpaces2 = changingNumber.filter {!$0.isWhitespace}
        
        let url = NSURL(string: "https://t.me/\(numberWithoutSpaces2)")
        
        guard let url = url else { return }
        
        if UIApplication.shared.canOpenURL(url as URL) {
            UIApplication.shared.open(url as URL, options: [:]){ (success) in
                if success {
                    print("Telegram accessed successfully")
                } else {
                    print("Error accessing Telegram")
                    let urlAppStore = NSURL(string: "https://apps.apple.com/ru/app/telegram/id686449807")!
                    UIApplication.shared.openURL(urlAppStore as URL)
                }
            }
        }
        
        UIApplication.shared.open(url as URL, options: [:]){ (success) in
            if success {
                print("Telegram accessed successfully")
            } else {
                print("Error accessing Telegram")
                let urlAppStore = NSURL(string: "https://apps.apple.com/ru/app/telegram/id686449807")!
                UIApplication.shared.openURL(urlAppStore as URL)
            }
        }
    }
    
    //MARK: Phone Called
    private func phoneCalled(){
        Constants.ud.currentCallContactOrNoName = 1
        let number = (phoneNumberLabel.text)!
        let numberWithoutSpaces = number.filter {!$0.isWhitespace}
        var changingNumber = ""
        do {
            var phoneNumber = try self.phoneNumberKit.parse(numberWithoutSpaces)
            changingNumber = self.phoneNumberKit.format(phoneNumber, toType: .international)
        }
        catch {
            print("Generic parser error")
        }
        let numberWithoutSpaces2 = changingNumber.filter {!$0.isWhitespace}
        
        Constants.ud.cellCallName = nameLabel.text!
        Constants.ud.cellCallNumber = numberWithoutSpaces2
        guard let number = URL(string: "tel://" + numberWithoutSpaces2) else { return }
        UIApplication.shared.open(number)
    }
    
    //MARK: Send Message
    
    private func sendMessage(){
        guard MFMessageComposeViewController.canSendText() else {
            print("Device is not capable to send message")
            return
        }
        completion?()
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        switch result {
        case .cancelled:
            print("cancelled")
        case .sent:
            print("sent")
        case .failed:
            print("failed")
        default:
            print("UNKOWN")
        }
    }
}
