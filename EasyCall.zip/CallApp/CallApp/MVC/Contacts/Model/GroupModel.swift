import Foundation

struct GroupModel {
    var nameGroup: String?
}
