import UIKit
import RxSwift
import MessageUI

class HistoryViewController: UIViewController, MFMessageComposeViewControllerDelegate {
    
    private var nameLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .semibold)
        label.textAlignment = .center
        label.textColor = "3D485B".hexColor
        label.text = "History"
        return label
    }()

    private var ifHistoryIsEmptyLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .semibold)
        label.textAlignment = .center
        label.textColor = "3D485B".hexColor
        label.text = "Сall history is empty"
        label.numberOfLines = 0
        return label
    }()
    
    private var historyTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 65
        table.backgroundColor = .clear
        table.isScrollEnabled = true
        table.separatorStyle = .none
        table.sectionIndexColor = .black
        return table
    }()
     
    var names = Constants.ud.historyOfContactsName
    var numbers = Constants.ud.historyOfContactsNumber
    var dates = Constants.ud.historyOfContactsDate
    var identifier = Constants.ud.identifierOfContactInContacts
    
    let disposeBag = DisposeBag()
    
    var history = [HistoryModel]()
    var selectedIndex = -1
    var deselected = -1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        reversedAndUpdateHistory()
        checkIfHistoryIsEmpty()
    }

    private func setup(){
        setupLayout()
        configureTableView2()
    }
    
    private func setupLayout() {
        view.backgroundColor = .white
        view.addSubviews(nameLabel, ifHistoryIsEmptyLabel, historyTableView)
        
        nameLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(68)
            make.leading.equalToSuperview().offset(50)
            make.trailing.equalToSuperview().offset(-50)
            make.height.equalTo(29)
        }
        
        ifHistoryIsEmptyLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
            make.height.equalTo(80)
            make.width.equalTo(150)
        }
        
        historyTableView.snp.makeConstraints { make in
            make.top.equalTo(nameLabel.snp.bottom).offset(34)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
        }
    }
    
    private func configureTableView2() {
        historyTableView.delegate = self
        historyTableView.dataSource = self
        historyTableView.register(HistoryCell.self, forCellReuseIdentifier: HistoryCell.nibIdentifier)
    }
 
    private func reversedAndUpdateHistory(){
        names = Constants.ud.historyOfContactsName
        numbers = Constants.ud.historyOfContactsNumber
        dates = Constants.ud.historyOfContactsDate
        
        var reversedNames: [String] = names.reversed()
        var reversedNumber: [String] = numbers.reversed()
        var reversedDate: [String] = dates.reversed()
        
        names = reversedNames
        numbers = reversedNumber
        dates = reversedDate
        
        historyTableView.reloadData()
    }
    
    private func checkIfHistoryIsEmpty(){
        if dates.count == 0 {
            ifHistoryIsEmptyLabel.isHidden = false
            historyTableView.isHidden = true
        } else {
            ifHistoryIsEmptyLabel.isHidden = true
            historyTableView.isHidden = false
        }
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        switch result {
        case .cancelled:
            print("cancelled")
            self.dismiss(animated: true)
        case .sent:
            self.dismiss(animated: true)
            print("sent")
        case .failed:
            self.dismiss(animated: true)
            print("failed")
        default:
            self.dismiss(animated: true)
            print("UNKOWN")
        }
    }
}

extension HistoryViewController: UITableViewDelegate {
    
}

extension HistoryViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return numbers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = historyTableView.dequeueReusableCell(withIdentifier: HistoryCell.nibIdentifier, for: indexPath) as! HistoryCell
        cell.nameLabel.text = names[indexPath.row]
        cell.numberLabel.text = numbers[indexPath.row]
        cell.dateLabel.text = dates[indexPath.row]
        
        cell.openInformationOfContacts = {
           
        }
        
        
        cell.completionInfoContacts = { [weak self] in
            guard let self = self else { return }
            if self.deselected == 1 {
                self.selectedIndex = indexPath.row - 1
                self.deselected = 0
            } else {
                self.deselected = 1
            }
            
            self.selectedIndex = indexPath.row
            self.historyTableView.reloadData()
        }
        
        if (selectedIndex == indexPath.row) {
            if deselected == 1 {
                cell.setupLayoutSelected()
            } else {
                cell.setupLayoutNotSelected()
            }
            
        } else {
            cell.setupLayoutNotSelected()
        }
        
        cell.completion = { [weak self] in
            guard let self = self else { return }
            let number = (self.numbers[indexPath.row])
            let composer = MFMessageComposeViewController()
            composer.messageComposeDelegate = self
            composer.recipients = ["\(number)"]
            composer.subject = "Hello Agent"
            self.present(composer, animated: true)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            Constants.ud.historyOfContactsName.remove(at: indexPath.row)
            Constants.ud.historyOfContactsNumber.remove(at: indexPath.row)
            Constants.ud.historyOfContactsDate.remove(at: indexPath.row)
            names.remove(at: indexPath.row)
            numbers.remove(at: indexPath.row)
            dates.remove(at: indexPath.row)
            checkIfHistoryIsEmpty()
            self.historyTableView.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            if(indexPath.row == selectedIndex){
                if deselected == 1 {
                    return 90
                } else {
                    return 44
                }
            } else {
                return 44
            }
        }
}

