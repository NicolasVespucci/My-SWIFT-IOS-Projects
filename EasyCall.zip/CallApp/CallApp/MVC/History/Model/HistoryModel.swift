import Foundation

struct HistoryModel {
    var name : String?
    var number: String?
    var date: String?
}
