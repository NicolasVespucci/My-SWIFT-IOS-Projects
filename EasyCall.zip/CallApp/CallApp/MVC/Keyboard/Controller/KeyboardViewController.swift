import UIKit
import SnapKit
import RxSwift
import SnapKit
import SwiftyContacts
import Contacts
import MessageUI
import ContactsUI
import CallKit
import AVFAudio
import AVFoundation
import AVKit
import MediaPlayer
import CoreAudio
import PhoneNumberKit

class KeyboardViewController: UIViewController, MFMessageComposeViewControllerDelegate, CNContactPickerDelegate, CXCallObserverDelegate, CNContactViewControllerDelegate {
    
    var callObserver = CXCallObserver()
    
    private var keyboard = [KeyboardModel(number: "1", letters: "", selectedNumber: false), KeyboardModel(number: "2", letters: "ABC", selectedNumber: false), KeyboardModel(number: "3", letters: "DEF", selectedNumber: false), KeyboardModel(number: "4", letters: "GHI", selectedNumber: false), KeyboardModel(number: "5", letters: "JKL", selectedNumber: false), KeyboardModel(number: "6", letters: "MNO", selectedNumber: false), KeyboardModel(number: "7", letters: "PQRS", selectedNumber: false), KeyboardModel(number: "8", letters: "TUF", selectedNumber: false), KeyboardModel(number: "9", letters: "WXYZ", selectedNumber: false), KeyboardModel(number: "*", letters: "", selectedNumber: false), KeyboardModel(number: "0", letters: "+", selectedNumber: false), KeyboardModel(number: "#", letters: "", selectedNumber: false)]
    
    private var soundName = ["bell", "bicyclebell", "cardboard", "cat", "dog", "duck", "error", "frog", "icepick", "key1", "key2", "key3", "key4", "key5", "pig", "pigeon", "smallbell", "success"]
    
    private lazy var searchBar: UISearchBar = {
        let bar = UISearchBar()
        bar.searchBarStyle = UISearchBar.Style.default
        bar.placeholder = "Search..."
        bar.setShowsCancelButton(false, animated: false)
        bar.isSearchResultsButtonSelected = true
        bar.delegate = self
        bar.searchBarStyle = .minimal
        return bar
    }()
    
    private var addNewContactButton: UIButton = {
        let button = UIButton()
        button.setImage("AddNew".image, for: .normal)
        return button
    }()
    
    private var searchTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 80
        table.backgroundColor = .clear
        table.isScrollEnabled = true
        table.separatorStyle = .none
        table.sectionIndexColor = .black
        return table
    }()
    
    private var emptyView: UIView = {
        let view = UIView()
        view.backgroundColor = "F2F2F2".hexColor
        return view
    }()
    
    private var numberEmptyView: UIView = {
        let view = UIView()
        view.backgroundColor = "F2F2F2".hexColor
        return view
    }()
    
    private var customView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()
    
    private lazy var numberTextView: UITextField = {
        let t = UITextField()
        t.font = .systemFont(ofSize: 32, weight: .regular)
        t.textAlignment = .center
        t.leftViewMode = .always
        customView = UIView(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
        customView.backgroundColor = UIColor.clear
        t.inputView = customView
        return t
    }()
    
    private var noContactsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.textAlignment = .center
        label.textColor = "BEBEBE".hexColor
        label.text = "No Contacts"
        label.isHidden = true
        return label
    }()
    
    private lazy var keyboardCollectionView: UICollectionView = {
        let collection = UICollectionView(frame: .zero, collectionViewLayout: .init())
        collection.backgroundColor = "F2F2F2".hexColor
        collection.showsHorizontalScrollIndicator = false
        collection.showsVerticalScrollIndicator = false
        collection.isScrollEnabled = true
        collection.clipsToBounds = false
        collection.isUserInteractionEnabled = true
        collection.delaysContentTouches = false
        return collection
    }()
    
    private lazy var keyboardLayout: UICollectionViewLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 0
        layout.itemSize = .init(width: 112.5.resized(.width), height: 64.resized())
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 8
        layout.sectionInset = .init(top: 10, left: 10, bottom: 0, right: 10)
        return layout
    }()
    
    private var starButton: UIButton = {
        let button = UIButton()
        button.setImage("star".image, for: .normal)
        return button
    }()
    
    private var callButton: UIButton = {
        let button = UIButton()
        button.setImage("call".image, for: .normal)
        button.backgroundColor = "007AFF".hexColor
        button.layer.cornerRadius = 10
        return button
    }()
    
    private var deleteButton: UIButton = {
        let button = UIButton()
        button.setImage("delete".image, for: .normal)
        return button
    }()
    
    let disposeBag = DisposeBag()
    
    var fullContacts = [ContactsModel]()
    var sortedContacts = ContactManager.shared().sortedContacts
    var searchContact = ContactManager.shared().sortedContacts
    var selectedIndex = 0
    var deselected = -1
    var checkingText = ""
    
    var currentDelete = false
    
    let phoneNumberKit = PhoneNumberKit()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        
        callObserver.setDelegate(self, queue: nil) //Set delegate to self to call delegate method.
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(longPress(_:)))
        deleteButton.addGestureRecognizer(longPress)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    @objc func keyboardWillHide(sender: NSNotification) {
        self.customView.frame = CGRect(x: 0, y: 0, width: 0, height: 0)
        self.numberTextView.inputView = customView
    }
    
    @objc func callObserver(_ callObserver: CXCallObserver, callChanged call: CXCall) {
        if call.hasEnded {
            print("Call hasEnded \(call.uuid)")
            //Add Call in History
            
            if Constants.ud.currentCallContactOrNoName == 0 {
                let name = "No Name"
                let number = numberTextView.text!
                let date = Date().shortDateTime
                
                Constants.ud.historyOfContactsName.append(name)
                Constants.ud.historyOfContactsNumber.append(number)
                Constants.ud.historyOfContactsDate.append(date)
            } else {
                
                let name = Constants.ud.cellCallName
                let number = Constants.ud.cellCallNumber
                let date = Date().shortDateTime
                
                Constants.ud.historyOfContactsName.append(name ?? "CCC")
                Constants.ud.historyOfContactsNumber.append(number ?? "111")
                Constants.ud.historyOfContactsDate.append(date)
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
    }
    
    private func setup() {
        configureCollectionsView()
        setupLayout()
        setupButtons()
        configureTableView()
        numberTextView.becomeFirstResponder()
        reloadController()
        requestAccess { accessGranted in
        }
        
        TestManager.shared().configureAudioSessionCategory()
        TestManager.shared().configureAudioSessionToSpeaker()
        MPVolumeView.setVolume(1)
    }
    
    func requestAccess(completionHandler: @escaping (_ accessGranted: Bool) -> Void) {
        let store = CNContactStore()
        switch CNContactStore.authorizationStatus(for: .contacts) {
        case .authorized:
            completionHandler(true)
        case .denied:
            showSettingsAlert(completionHandler)
        case .restricted, .notDetermined:
            store.requestAccess(for: .contacts) { granted, error in
                if granted {
                    completionHandler(true)
                } else {
                    DispatchQueue.main.async {
                        self.showSettingsAlert(completionHandler)
                    }
                }
            }
        }
    }
    
    private func reloadController() {
        ContactManager.shared().comlition = { [weak self] in
            guard let self = self else { return }
            self.sortedContacts = ContactManager.shared().sortedContacts
            self.searchContact = ContactManager.shared().sortedContacts
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.searchTableView.reloadData()
            }
        }
    }
    
    private func showSettingsAlert(_ completionHandler: @escaping (_ accessGranted: Bool) -> Void) {
        let alert = UIAlertController(title: nil, message: "This app requires access to Contacts to proceed. Go to Settings to grant access.", preferredStyle: .alert)
        if
            let settings = URL(string: UIApplication.openSettingsURLString),
            UIApplication.shared.canOpenURL(settings) {
            alert.addAction(UIAlertAction(title: "Open Settings", style: .default) { action in
                completionHandler(false)
                UIApplication.shared.open(settings)
            })
        }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel) { action in
            completionHandler(false)
        })
        present(alert, animated: true)
    }
    
    
    private func showPermissionAlert() {
        let alert = UIAlertController(title: "Ooops..", message: "Сontacts were not found because you did not provide access to them, you can grant access in the settings", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Settings", style: .default, handler: { _ in
            guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else { return }
            if UIApplication.shared.canOpenURL(settingsUrl) {
                UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                    print("Settings opened: \(success)")
                })
            }
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        if let vc = UIApplication.shared.keyWindow?.rootViewController {
            vc.present(alert, animated: true)
        }
    }
    
    private func setupLayout(){
        view.backgroundColor = .white
        view.addSubviews(numberTextView, noContactsLabel, searchTableView, searchBar, addNewContactButton, emptyView)
        
        emptyView.addSubviews(keyboardCollectionView, starButton, callButton, deleteButton)
        
        numberTextView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(60.resized())
            make.height.equalTo(50)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
        }
        
        noContactsLabel.snp.makeConstraints { make in
            make.top.equalTo(numberTextView.snp.bottom).offset(43)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(24)
        }
        
        searchTableView.snp.makeConstraints { make in
            make.top.equalTo(numberTextView.snp.bottom).offset(50.resized())
            make.leading.equalToSuperview().offset(16)
            make.trailing.equalToSuperview().offset(-16)
            make.bottom.equalTo(searchBar.snp.top).offset(-6.resized())
        }
        
        searchBar.snp.makeConstraints { make in
            make.bottom.equalTo(emptyView.snp.top).offset(-6.resized())
            make.leading.equalToSuperview().offset(16)
            make.trailing.equalTo(addNewContactButton.snp.leading).offset(-16)
            make.height.equalTo(47)
        }
        
        addNewContactButton.snp.makeConstraints { make in
            make.bottom.equalTo(emptyView.snp.top).offset(-16)
            make.trailing.equalToSuperview().offset(-18)
            make.size.equalTo(26)
        }
        
        emptyView.snp.makeConstraints { make in
            make.height.equalTo(374.resized())
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-10)
        }
        
        keyboardCollectionView.snp.makeConstraints { make in
            make.height.equalTo(292.resized())
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalTo(starButton.snp.top).offset(-10)
        }
        
        starButton.snp.makeConstraints { make in
            make.height.equalTo(64.resized())
            make.width.equalTo(112.5.resized(.width))
            make.leading.equalToSuperview().offset(10)
            make.bottom.equalToSuperview().offset(-9.resized())
        }
        
        callButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-9.resized())
            make.centerX.equalToSuperview()
            make.height.equalTo(64.resized())
            make.width.equalTo(112.5.resized(.width))
        }
        
        deleteButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-9.resized())
            make.height.equalTo(64.resized())
            make.leading.equalTo(callButton.snp.trailing).offset(9)
            make.trailing.equalToSuperview().offset(-10)
        }
    }
    
    private func configureCollectionsView(){
        keyboardCollectionView.setCollectionViewLayout(keyboardLayout, animated: true)
        keyboardCollectionView.dataSource = self
        keyboardCollectionView.delegate = self
        keyboardCollectionView.register(KeyboardCell.self, forCellWithReuseIdentifier: KeyboardCell.nibIdentifier)
    }
    
    private func configureTableView() {
        searchTableView.delegate = self
        searchTableView.dataSource = self
        searchTableView.register(KeyboardContactCell.self, forCellReuseIdentifier: KeyboardContactCell.nibIdentifier)
    }
    
    private func setupButtons() {
        deleteButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.deleteButtonAction()
        }.disposed(by: disposeBag)
        
        starButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            let vc = FavoritesViewController()
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: true)
        }.disposed(by: disposeBag)
        
        addNewContactButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.addNewContactAction()
        }.disposed(by: disposeBag)
        
        callButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.phoneCalled()
        }.disposed(by: disposeBag)
    }
    
    @objc func longPress(_ gesture: UILongPressGestureRecognizer) {
        if gesture.state == UILongPressGestureRecognizer.State.began {
            print("Long Press")
            numberTextView.text = ""
            self.searchContacts()
            Vibration.success.vibrate()
        }
    }
    
    private func addNewContactAction(){
        let con = CNMutableContact()
        con.phoneNumbers.append(CNLabeledValue(
            label: "New Contact", value: CNPhoneNumber(stringValue: "\(numberTextView.text!)")))
        let unkvc = CNContactViewController(forNewContact: con)
        unkvc.contactStore = CNContactStore()
        unkvc.delegate = self
        DispatchQueue.main.async {
            self.present(UINavigationController(rootViewController: unkvc), animated: true)
        }
    }
    
    private func searchContacts() {
        searchContact = []
        let number = (numberTextView.text)!
        let numberWithoutSpaces = number.filter {!$0.isWhitespace}
        let text = numberWithoutSpaces
        if text == "" {
            searchContact = sortedContacts
        } else {
            for contact in sortedContacts {
                let name = contact.name!
                let phoneNumberWithoutSpaces = contact.phoneNumber!.filter {!$0.isWhitespace}
                let phoneNumber = phoneNumberWithoutSpaces.digitString
                
                if text.contains("+373") {
                    let filteredText = text.dropFirst(4)
                    if (name.lowercased().contains(filteredText.lowercased())) {
                        searchContact.append(contact)
                    } else if (phoneNumber.lowercased().contains(filteredText.lowercased())) {
                        searchContact.append(contact)
                    }
                } else {
                    if (name.lowercased().contains(text.lowercased())) {
                        searchContact.append(contact)
                    } else if (phoneNumber.lowercased().contains(text.lowercased())) {
                        searchContact.append(contact)
                    }
                }
            }
        }
        if searchContact.count == 0 {
            noContactsLabel.isHidden = false
        } else {
            noContactsLabel.isHidden = true
        }
        self.searchTableView.reloadData()
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        switch result {
        case .cancelled:
            print("cancelled")
            self.dismiss(animated: true)
        case .sent:
            self.dismiss(animated: true)
            print("sent")
        case .failed:
            self.dismiss(animated: true)
            print("failed")
        default:
            self.dismiss(animated: true)
            print("UNKOWN")
        }
    }
    
    //MARK: Phone Called
    private func phoneCalled() {
        Constants.ud.currentCallContactOrNoName = 0
        let number = (numberTextView.text)!
        let numberWithoutSpaces = number.filter {!$0.isWhitespace}
        guard let number = URL(string: "tel://" + numberWithoutSpaces) else { return }
        UIApplication.shared.open(number)
    }
    
    private func deleteButtonAction() {
        let startPosition: UITextPosition = self.numberTextView.beginningOfDocument
        let selectedRange: UITextRange? = self.numberTextView.selectedTextRange
        let endPosition: UITextPosition = self.numberTextView.endOfDocument
        guard let select = selectedRange?.start else { return }
        let offsetStar = numberTextView.offset(from: numberTextView.beginningOfDocument, to: select)
        if startPosition == selectedRange?.start {
            if self.numberTextView.text! == "" {
            } else {
                if self.numberTextView.backSpace() == "Not Deleted" {
                } else {
                    self.numberTextView.text = self.numberTextView.backSpace()
                }
            }
        } else {
            self.numberTextView.text = self.numberTextView.backSpace()
        }
        self.searchContacts()
        Vibration.rigid.vibrate()
        if let newPosition = self.numberTextView.position(from: selectedRange!.start, offset: -1) {
            numberTextView.selectedTextRange = numberTextView.textRange(from: newPosition, to: newPosition)
        }
    }
}

extension UITextField {
    /// simulates removing a character from 1 position behind the cursor and returns the result
    func backSpace() -> String {
        guard var text = text, // local text property, matching textField's text
              let selectedRange = selectedTextRange,
              !text.isEmpty
        else { return "" }
        
        let offsetStar = offset(from: beginningOfDocument, to: selectedRange.start)
        if offsetStar == 0 {
            return "Not Deleted"
        }
        
        if let selectedRange = self.selectedTextRange {
            if let newPosition = self.position(from: selectedRange.start, offset: -1) {
                self.selectedTextRange = self.textRange(from: newPosition, to: newPosition)
            }
        }
        
        let offset = offset(from: beginningOfDocument, to: selectedRange.start)
        
        let index = text.index(text.startIndex, offsetBy: offset-1)
        // this doesn't remove text from the textField, just the local text property
        text.remove(at: index)
        return text
    }
}

extension KeyboardViewController: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: KeyboardCell.nibIdentifier, for: indexPath) as! KeyboardCell
        
        DispatchQueue.main.async {
            TestManager.shared().playSound(soundName: self.soundName[Constants.ud.currentIndexSound ?? 0] ?? "-1")
        }
        
        DispatchQueue.main.async {
            Vibration.selection.vibrate()
        }
        
        deselected = indexPath.item
        
        let startPosition: UITextPosition = self.numberTextView.beginningOfDocument
        let selectedRange: UITextRange? = self.numberTextView.selectedTextRange
        
        self.numberTextView.insertText(keyboard[indexPath.item].number ?? "")
        
        if self.deselected != indexPath.item {
            self.keyboard[deselected].selectedNumber = false
        }
        
        if self.keyboard[indexPath.item].selectedNumber == true {
            self.keyboard[indexPath.item].selectedNumber = false
        } else {
            self.keyboard[indexPath.item].selectedNumber = true
            self.deselected = indexPath.item
        }
        
        keyboardCollectionView.reloadData()
        
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            do {
                var phoneNumber = try self.phoneNumberKit.parse("\(self.numberTextView.text!)")
                self.numberTextView.text! = ""
                self.numberTextView.insertText(self.phoneNumberKit.format(phoneNumber, toType: .international))
                print("number ----->", self.numberTextView.text!)
                self.searchContacts()
            }
            catch {
                print("Generic parser error")
            }
        }
        searchContacts()
    }
}

extension KeyboardViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return keyboard.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: KeyboardCell.nibIdentifier, for: indexPath) as! KeyboardCell
        cell.optionsCellModel = keyboard[indexPath.item]
        
        cell.complitionAddPlus = { [weak self] in
            guard let self = self else { return }
            self.numberTextView.insertText("+")
        }
        return cell
    }
}

//MARK: TableView
extension KeyboardViewController: UITableViewDelegate {
    
}

extension KeyboardViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchContact.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = searchTableView.dequeueReusableCell(withIdentifier: KeyboardContactCell.nibIdentifier, for: indexPath) as! KeyboardContactCell
        let contact = searchContact[indexPath.row]
        cell.contactModel = contact
        
        cell.openInformationOfContacts = { [weak self] in
            guard let self = self else { return }
            
            let store = CNContactStore()
            let contact = CNContact()
            
            let currentContacts = self.searchContact[indexPath.row].identifier
            
            do {
                let descriptor = CNContactViewController.descriptorForRequiredKeys()
                let editContact = try store.unifiedContact(withIdentifier: currentContacts ?? "-1", keysToFetch: [descriptor])
                let vc = CNContactViewController(for: editContact)
                vc.allowsEditing = true
                vc.delegate = self
                DispatchQueue.main.async {
                    self.navigationController?.isNavigationBarHidden = false
                    self.navigationController?.makeClearBar(color: .clear)
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            } catch {
                print(error)
            }
        }
        
        cell.completionInfoContacts = { [weak self] in
            guard let self = self else { return }
            
            if self.selectedIndex != indexPath.row {
                self.searchContact[self.selectedIndex].checkSelected = false
            }
            
            if self.searchContact[indexPath.row].checkSelected == true {
                self.searchContact[indexPath.row].checkSelected = false
            } else {
                self.searchContact[indexPath.row].checkSelected = true
                self.selectedIndex = indexPath.row
            }
            
            self.searchTableView.reloadData()
        }
        
        if self.searchContact[indexPath.row].checkSelected == true {
            cell.setupLayoutSelected()
        } else {
            cell.setupLayoutNotSelected()
        }
        
        cell.completion = { [weak self] in
            guard let self = self else { return }
            let number = (self.searchContact[indexPath.row].phoneNumber)!
            let composer = MFMessageComposeViewController()
            composer.messageComposeDelegate = self
            composer.recipients = ["\(number)"]
            composer.subject = "Hello Agent"
            self.present(composer, animated: true)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if self.searchContact[indexPath.row].checkSelected == true {
            return 110
        } else {
            return 61
        }
    }
}

//MARK: SearhBar
extension KeyboardViewController: UISearchBarDelegate {
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        searchTableView.reloadData()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchContact = []
        
        let number = searchText
        let numberWithoutSpaces = number.filter {!$0.isWhitespace}
        
        if numberWithoutSpaces == "" {
            searchContact = sortedContacts
        } else {
            for contact in sortedContacts {
                let name = contact.name!
                let phoneNumberWithoutSpaces = contact.phoneNumber!.filter {!$0.isWhitespace}
                let phoneNumber = phoneNumberWithoutSpaces.digitString
                
                if searchText.contains("+373") {
                    let filteredText = searchText.dropFirst(4)
                    if (name.lowercased().contains(filteredText.lowercased())) {
                        searchContact.append(contact)
                    } else if (phoneNumber.lowercased().contains(filteredText.lowercased())) {
                        searchContact.append(contact)
                    }
                } else {
                    if (name.lowercased().contains(searchText.lowercased())) {
                        searchContact.append(contact)
                    } else if (phoneNumber.lowercased().contains(searchText.lowercased())) {
                        searchContact.append(contact)
                    }
                }
            }
        }
        self.searchTableView.reloadData()
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
    }
}

enum Vibration {
    case error
    case success
    case warning
    case light
    case medium
    case heavy
    @available(iOS 13.0, *)
    case soft
    @available(iOS 13.0, *)
    case rigid
    case selection
    case oldSchool
    
    public func vibrate() {
        switch self {
        case .error:
            UINotificationFeedbackGenerator().notificationOccurred(.error)
        case .success:
            UINotificationFeedbackGenerator().notificationOccurred(.success)
        case .warning:
            UINotificationFeedbackGenerator().notificationOccurred(.warning)
        case .light:
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
        case .medium:
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        case .heavy:
            UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
        case .soft:
            if #available(iOS 13.0, *) {
                UIImpactFeedbackGenerator(style: .soft).impactOccurred()
            }
        case .rigid:
            if #available(iOS 13.0, *) {
                UIImpactFeedbackGenerator(style: .rigid).impactOccurred()
            }
        case .selection:
            UISelectionFeedbackGenerator().selectionChanged()
        case .oldSchool:
            AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate))
        }
    }
}
