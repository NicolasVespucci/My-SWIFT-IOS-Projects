import UIKit
import CallKit
import PushKit
import SnapKit
import SwiftyContacts
import Contacts
import MessageUI
import RxSwift
import ContactsUI

class FavoritesViewController: UIViewController, MFMessageComposeViewControllerDelegate, CNContactViewControllerDelegate {
    
    private var favoritesLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .semibold)
        label.textAlignment = .center
        label.textColor = "404147".hexColor
        label.text = "Favorites"
        return label
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("back".image, for: .normal)
        return button
    }()
    
    private var addFavoriteContactButton: UIButton = {
        let button = UIButton()
        button.setImage("AddNew".image, for: .normal)
        return button
    }()
    
    private var myFavoriteContactsTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 61
        table.backgroundColor = .clear
        table.isScrollEnabled = true
        table.separatorStyle = .none
        table.sectionIndexColor = .black
        return table
    }()
    
    let disposeBag = DisposeBag()
    
    var fullContacts = [ContactsModel]()
    var searchContact = [ContactsModel]()
    var contactsForCurrentGroup = [ContactsModel]()
    var newlyAddedContacts = [ContactsModel]()
    
    var selectedIndex = 0
    var deselected = -1
    var currentIndexData: Int?
    
    var selectedCellValue = [String]()
    var countSelectedCell = [String]()
    
    var fullContactsCN = [CNContact]()
    var selectedContactsCN = [CNContact]()
    var newlyAddedContactsCN = [CNContact]()
    
    var allContacts = ContactManager.shared().allContacts
    
    var dataOfFavoriteContacts: Data?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        configureDataInContacts()
        
    }
    
    private func configureTableView() {
        myFavoriteContactsTableView.delegate = self
        myFavoriteContactsTableView.dataSource = self
        myFavoriteContactsTableView.register(FavoriteCell.self, forCellReuseIdentifier: FavoriteCell.nibIdentifier)
    }
    
    private func setup(){
        setupLayout()
        setupButton()
        configureTableView()
    }
    
    private func setupLayout() {
        view.backgroundColor = .white
        view.addSubviews(favoritesLabel, backButton, addFavoriteContactButton, myFavoriteContactsTableView)
        
        favoritesLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(68)
            make.leading.equalToSuperview().offset(50)
            make.trailing.equalToSuperview().offset(-50)
            make.height.equalTo(33)
        }
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(68)
            make.leading.equalToSuperview().offset(19)
            make.width.equalTo(35)
            make.height.equalTo(35)
        }
        
        addFavoriteContactButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(68)
            make.size.equalTo(26)
            make.trailing.equalToSuperview().offset(-20)
        }
        
        myFavoriteContactsTableView.snp.makeConstraints { make in
            make.top.equalTo(favoritesLabel.snp.bottom).offset(34)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
        }
    }
    
    private func setupButton(){
        backButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.dismiss(animated: true)
        }.disposed(by: disposeBag)
        
        addFavoriteContactButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.addFavoriteContactButtonAction()
        }.disposed(by: disposeBag)
    }
    
    private func addFavoriteContactButtonAction(){
        let vc = AddFavoriteContactViewController()
        vc.modalPresentationStyle = .pageSheet
        self.present(vc, animated: true)
    }
    
    func configureDataInContacts(){
        fullContactsCN.removeAll()
        fullContacts.removeAll()
        searchContact.removeAll()
        let oldFavoriteContacts = Constants.ud.favoriteContacts
        var contacts = [CNContact]()
        if (oldFavoriteContacts.isNil) {
        } else {
            let transformationIntoContacts = NSKeyedUnarchiver.unarchiveObject(with: oldFavoriteContacts!) as? [CNContact]
            contacts = transformationIntoContacts ?? [CNContact]()
        }
        
        for contact in contacts {
            
            let fullName = contact.givenName + " " + contact.familyName
            let number = contact.phoneNumbers.first?.value.stringValue ?? ""
            let identy = contact.identifier
            
            
            if let imageData = contact.thumbnailImageData {
                let imageString = String(describing: UIImage(data: imageData))
                let stringImage = String(decoding: imageData, as: UTF8.self)
                
                self.fullContacts.append(ContactsModel(name: fullName, phoneNumber: number, dataImage: imageData, selectedNonSelectedImage: "nonSelectedCell", identifier: identy))
                self.fullContactsCN.append(contact)
                
            } else {
                var notImage = "contactImage"
                self.fullContacts.append(ContactsModel(name: fullName, phoneNumber: number, image: notImage, selectedNonSelectedImage: "nonSelectedCell", identifier: identy))
                self.fullContactsCN.append(contact)
            }
        }
        
        searchContact = fullContacts.sorted { (($0.name) ?? "√").compare(($1.name) ?? "√", options: .numeric) == .orderedAscending }
        myFavoriteContactsTableView.reloadData()
    }
    
    private func updateFavoriteContacts(){
        var contactsCN = [CNContact]()
        
        fullContactsCN.forEach { one in
            searchContact.forEach { two in
                if one.identifier == two.identifier {
                    contactsCN.append(one)
                }
            }
        }
        
        let dataBlob = NSKeyedArchiver.archivedData(withRootObject: contactsCN)
        Constants.ud.favoriteContacts = dataBlob
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        switch result {
        case .cancelled:
            print("cancelled")
            self.dismiss(animated: true)
        case .sent:
            self.dismiss(animated: true)
            print("sent")
        case .failed:
            self.dismiss(animated: true)
            print("failed")
        default:
            self.dismiss(animated: true)
            print("UNKOWN")
        }
    }
    
    deinit {
        fullContactsCN.removeAll()
        fullContacts.removeAll()
        searchContact.removeAll()
    }
}

extension FavoritesViewController: UITableViewDelegate {
    
}

extension FavoritesViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchContact.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myFavoriteContactsTableView.dequeueReusableCell(withIdentifier: FavoriteCell.nibIdentifier, for: indexPath) as! FavoriteCell
        let contact = searchContact[indexPath.row]
        
        cell.contactModel = contact
        
        cell.openInformationOfContacts = { [weak self] in
            guard let self = self else { return }
            
            let store = CNContactStore()
            let contact = CNContact()
            
            let currentContacts = self.searchContact[indexPath.row].identifier
            
            do {
                let descriptor = CNContactViewController.descriptorForRequiredKeys()
                let editContact = try store.unifiedContact(withIdentifier: currentContacts ?? "-1", keysToFetch: [descriptor])
                let vc = CNContactViewController(for: editContact)
                vc.allowsEditing = true
                vc.delegate = self
                DispatchQueue.main.async {
                    self.present(UINavigationController(rootViewController: vc), animated: true)
                }
            } catch {
                print(error)
            }
        }
        
        cell.completionInfoContacts = { [weak self] in
            guard let self = self else { return }
            
            if self.selectedIndex != indexPath.row {
                self.searchContact[self.selectedIndex].checkSelected = false
            }
            
            if self.searchContact[indexPath.row].checkSelected == true {
                self.searchContact[indexPath.row].checkSelected = false
            } else {
                self.searchContact[indexPath.row].checkSelected = true
                self.selectedIndex = indexPath.row
            }
            
            self.myFavoriteContactsTableView.reloadData()
        }
        
        if self.searchContact[indexPath.row].checkSelected == true {
            cell.setupLayoutSelected()
        } else {
            cell.setupLayoutNotSelected()
        }
        
        cell.completion = { [weak self] in
            guard let self = self else { return }
            let number = (self.searchContact[indexPath.row].phoneNumber)!
            let composer = MFMessageComposeViewController()
            composer.messageComposeDelegate = self
            composer.recipients = ["\(number)"]
            composer.subject = "Hello Agent"
            self.present(composer, animated: true)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if self.searchContact[indexPath.row].checkSelected == true {
            return 110
        } else {
            return 61
        }
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            self.searchContact.remove(at: indexPath.row)
            updateFavoriteContacts()
            self.myFavoriteContactsTableView.reloadData()
        }
    }
}
