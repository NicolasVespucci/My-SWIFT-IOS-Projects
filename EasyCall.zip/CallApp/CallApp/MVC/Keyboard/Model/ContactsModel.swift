import Foundation

struct ContactsModel {
    var name: String?
    var phoneNumber: String?
    var image: String?
    var dataImage: Data?
    var checkSelected: Bool?
    var selectedNonSelectedImage: String?
    var identifier: String?
}
