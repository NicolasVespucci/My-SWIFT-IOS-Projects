import Foundation

struct KeyboardModel {
    var number: String?
    var letters: String?
    var selectedNumber: Bool?
}
