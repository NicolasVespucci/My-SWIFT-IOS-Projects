import UIKit
import RxSwift
import SnapKit

class KeyboardCell: UICollectionViewCell {
    
    var complitionAddPlus: (()->())?
    
    var optionsCellModel: KeyboardModel? {
        didSet { configureOptionsModel() }
    }
    
    var cellView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()
    
    var numberLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.adjustsFontSizeToFitWidth = true
        label.textColor = "323232".hexColor
        label.textAlignment = .left
        return label
    }()
    
    var lettersLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 11, weight: .regular)
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .center
        label.textColor = "969696".hexColor
        return label
    }()
    
    let disposeBag = DisposeBag()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let blueView = UIView(frame: bounds)
        blueView.backgroundColor = "007AFF".hexColor
        self.selectedBackgroundView = blueView
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override var isHighlighted: Bool {
        didSet {
            if self.isHighlighted {
                backgroundColor = "007AFF".hexColor
                self.numberLabel.textColor = "FFFFFF".hexColor
                self.lettersLabel.textColor = "CBCBCB".hexColor
            } else {
                backgroundColor = "EDEDED".hexColor
                self.numberLabel.textColor = "323232".hexColor
                self.lettersLabel.textColor = "969696".hexColor
            }
        }
    }
    
    func configureLayoutNonSelected() {
        
        layer.masksToBounds = true
        layer.cornerRadius = 13
        backgroundColor = "EDEDED".hexColor
        
        addSubview(cellView)
        cellView.addSubviews(numberLabel, lettersLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        numberLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(15.resized())
            make.centerX.equalToSuperview()
            make.width.equalTo(13)
            make.height.equalTo(24.resized())
        }
        
        lettersLabel.snp.makeConstraints { make in
            make.top.equalTo(numberLabel.snp.bottom)
            make.leading.equalToSuperview().offset(10)
            make.trailing.equalToSuperview().offset(-10)
            make.height.equalTo(13)
        }
    }
    
    func configureLayoutSelected() {
        cellView.subviews.forEach({
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.removeFromSuperview()
        })
        
        addSubview(cellView)
        cellView.addSubviews(numberLabel, lettersLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        numberLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(15.resized())
            make.centerX.equalToSuperview()
            make.width.equalTo(13)
            make.height.equalTo(24.resized())
        }
        
        lettersLabel.snp.makeConstraints { make in
            make.top.equalTo(numberLabel.snp.bottom)
            make.leading.equalToSuperview().offset(10)
            make.trailing.equalToSuperview().offset(-10)
            make.height.equalTo(13)
        }
        
        cellView.backgroundColor = "007AFF".hexColor
        numberLabel.textColor = "FFFFFF".hexColor
        lettersLabel.textColor = "CBCBCB".hexColor
    }
    
    private func configureOptionsModel() {
        guard let optionsCellModel = optionsCellModel else { return }
        numberLabel.text = optionsCellModel.number
        lettersLabel.text = optionsCellModel.letters
        configureLayoutNonSelected()
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(longPress(_:)))
        addGestureRecognizer(longPress)
    }
    
    @objc func longPress(_ gesture: UILongPressGestureRecognizer) {
        if gesture.state == UILongPressGestureRecognizer.State.began {
            if numberLabel.text! == "0" {
                print("Chenge 0 to +")
                self.complitionAddPlus!()
            }
        }
    }
}
