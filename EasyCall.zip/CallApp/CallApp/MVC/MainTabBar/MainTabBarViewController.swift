import UIKit

class MainTabBarViewController: UITabBarController, UITabBarControllerDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tabBar.clipsToBounds = true
        self.tabBarController?.delegate = self
        delegate = self
        setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.isNavigationBarHidden = true
    }
    
    private func setup(){
        tabBar.backgroundColor = .white
        let keyboard = KeyboardViewController()
        let contacts = ContactsViewController()
        let history = HistoryViewController()
        let settings = SettingsViewController()
        
        tabBarController?.tabBar.isHidden = false
        let keyboardItem = UITabBarItem(title: "Keyboard", image: "KeyboardN".image , selectedImage: "KeyboardS".image)
        let conatctsItem = UITabBarItem(title: "Contacts", image: "ContactsN".image , selectedImage: "ContactsS".image)
        let historysItem = UITabBarItem(title: "History", image: "HistoryN".image , selectedImage: "HistoryS".image)
        let settingsItem = UITabBarItem(title: "Settings", image: "SettingsN".image , selectedImage: "SettingsS".image)
        
        keyboard.tabBarItem = keyboardItem
        contacts.tabBarItem = conatctsItem
        history.tabBarItem = historysItem
        settings.tabBarItem = settingsItem
        
        
        let childOne = UINavigationController(rootViewController: keyboard)
        let childTwo = UINavigationController(rootViewController: contacts)
        let childThree = UINavigationController(rootViewController: history)
        let childFour = UINavigationController(rootViewController: settings)
        
        childOne.setNavigationBarHidden(true, animated: true)
        childTwo.setNavigationBarHidden(true, animated: true)
        childThree.setNavigationBarHidden(true, animated: true)
        childFour.setNavigationBarHidden(true, animated: true)
        
        childOne.isNavigationBarHidden = true
        childTwo.isNavigationBarHidden = true
        childThree.isNavigationBarHidden = true
        childFour.isNavigationBarHidden = true
        
        tabBar.tintColor = "007AFF".hexColor
        tabBar.unselectedItemTintColor = "323232".hexColor
        tabBar.barTintColor = "FFFFFF".hexColor
        
        addChild(childOne)
        addChild(childTwo)
        addChild(childThree)
        addChild(childFour)
    }
    
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        let tabBarIndex = tabBarController.selectedIndex
        if tabBarIndex == 0 {
        }
    }
}
