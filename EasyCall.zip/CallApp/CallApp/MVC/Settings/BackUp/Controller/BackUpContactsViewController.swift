import UIKit
import RxSwift
import Contacts
import CoreData
import SwiftyContacts

class BackUpContactsViewController: UIViewController {
    
    private var contactsBackupLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .semibold)
        label.textColor = "404147".hexColor
        label.textAlignment = .center
        label.text = "Contacts Backup"
        return label
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("back".image, for: .normal)
        return button
    }()
    
    private var checkIfBackUpThereIsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 20, weight: .regular)
        label.text = "No any backUps yet, \ncreate the first one"
        label.textColor = "007AFF".hexColor
        label.numberOfLines = 0
        label.textAlignment = .center
        return label
    }()
    
    private var backUpButton: UIButton = {
        let button = UIButton()
        button.setImage("backUpButton".image, for: .normal)
        button.layer.cornerRadius = 12
        button.backgroundColor = "007AFF".hexColor
        return button
    }()
    
    private var fullBackUpTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 66
        table.backgroundColor = .clear
        table.isScrollEnabled = true
        table.separatorStyle = .none
        table.sectionIndexColor = .black
        return table
    }()
    
    //MARK: Var and Let
    
    var backUpCountContact = [FullBackUpModel]()
    
    var fullContacts = [CNContact]()
    
    var dataCurrentContacts: Data?
    
    var currentDate: String?
    
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup() {
        fetchContact()
        setupLayout()
        checkBackUps()
        setupButton()
    }
    
    private func setupLayout() {
        view.backgroundColor = .white
        
        view.addSubviews(contactsBackupLabel, backButton, checkIfBackUpThereIsLabel, fullBackUpTableView, backUpButton)
        
        contactsBackupLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(68)
            make.leading.equalToSuperview().offset(50)
            make.trailing.equalToSuperview().offset(-50)
            make.height.equalTo(33)
        }
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(68)
            make.leading.equalToSuperview().offset(19)
            make.width.equalTo(35)
            make.height.equalTo(35)
        }
        
        checkIfBackUpThereIsLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
            make.height.equalTo(70)
            make.width.equalTo(200)
        }
        
        fullBackUpTableView.snp.makeConstraints { make in
            make.top.equalTo(contactsBackupLabel.snp.bottom).offset(72)
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
            make.bottom.equalTo(backUpButton.snp.top).offset(-10)
        }
        
        backUpButton.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(56)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-25)
        }
    }
    
    private func configureTableView() {
        fullBackUpTableView.delegate = self
        fullBackUpTableView.dataSource = self
        fullBackUpTableView.register(FullBackUpCell.self, forCellReuseIdentifier: FullBackUpCell.nibIdentifier)
    }
    
    private func setupButton(){
        backButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.navigationController?.popViewController(animated: true)
        }.disposed(by: disposeBag)
        
        backUpButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.backUpButtonAction()
        }.disposed(by: disposeBag)
    }
    
    //MARK: Button Action
    
    private func backUpButtonAction() {
        Constants.ud.dataContacts.append(dataCurrentContacts!)
        currentDate = Date().shortDate
        Constants.ud.datebackUpContacts.append(currentDate!)
        if Constants.ud.dataContacts != nil {
            let currentBackUpContacts = Constants.ud.dataContacts.last
            let transformationIntoContacts = NSKeyedUnarchiver.unarchiveObject(with: currentBackUpContacts as! Data) as? [CNContact]
            
            backUpCountContact.append(FullBackUpModel(name: "BackUp", date: currentDate, count: "\(transformationIntoContacts!.count)"))
        }
        checkBackUps()
        fullBackUpTableView.reloadData()
    }
    
    //MARK: Fetch Contacts
    
    private func fetchContact(){
        let store = CNContactStore()
        store.requestAccess(for: .contacts) { acces, error in
            if let error = error {
                print("Error------>", error)
                return
            }
            
            if acces {
                print("Acces granted")
                let key = [CNContactGivenNameKey, CNContactFamilyNameKey, CNContactPhoneNumbersKey, CNContactImageDataAvailableKey, CNContactThumbnailImageDataKey]
                let request = CNContactFetchRequest(keysToFetch: key as [CNKeyDescriptor])
                
                do {
                    try store.enumerateContacts(with: request, usingBlock: { (contact, stopEnumerating) in
                        let fullName = contact.givenName + " " +  contact.familyName
                        let number = contact.phoneNumbers.first?.value.stringValue ?? ""
                        self.fullContacts.append(contact)
                    })
                } catch let error {
                    print("Error enumerated contacts:", error)
                }
            } else {
                print("Acces denied...")
            }
        }
        
        let dataBlob = NSKeyedArchiver.archivedData(withRootObject: fullContacts)
        dataCurrentContacts = dataBlob
        
        countBackUpContact()
    }
    
    //MARK: Count In BackUp Contacts
    private func countBackUpContact() {
        if Constants.ud.dataContacts != nil {
            checkIfBackUpThereIsLabel.isHidden = true
            fullBackUpTableView.isHidden = false
            
            var dataContactsU = Constants.ud.dataContacts
            var datebackUpContactsU = Constants.ud.datebackUpContacts
            
            for (count, date) in zip(dataContactsU, datebackUpContactsU) {
                // Transformation Data Into Contacts
                let transformationIntoContacts = NSKeyedUnarchiver.unarchiveObject(with: count as! Data) as? [CNContact]
                backUpCountContact.append(FullBackUpModel(name: "BackUp", date: date, count: "\(transformationIntoContacts!.count)"))
            }
            
        } else {
            checkIfBackUpThereIsLabel.isHidden = false
            fullBackUpTableView.isHidden = true
        }
        
        fullBackUpTableView.reloadData()
    }
    
    private func checkBackUps(){
        if backUpCountContact.count == 0 {
            checkIfBackUpThereIsLabel.isHidden = false
        } else {
            checkIfBackUpThereIsLabel.isHidden = true
            configureTableView()
        }
    }
}

//MARK: UITableView

extension BackUpContactsViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = PhoneBackUpViewController()
        let data = Constants.ud.dataContacts[indexPath.item]
        vc.dataContact = data as! Data
        navigationController?.pushViewController(vc, animated: true)
    }
}

extension BackUpContactsViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return backUpCountContact.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: FullBackUpCell.nibIdentifier, for:  indexPath) as! FullBackUpCell
        let backUp = backUpCountContact[indexPath.row]
        cell.fullBackUpCellModel = backUp
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            Constants.ud.dataContacts.remove(at: indexPath.row)
            self.backUpCountContact.remove(at: indexPath.row)
            self.fullBackUpTableView.reloadData()
        }
    }
}
