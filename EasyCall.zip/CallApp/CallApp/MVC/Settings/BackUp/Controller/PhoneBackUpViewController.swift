import UIKit
import RxSwift
import Contacts
import ContactsUI
import SwiftyContacts

class PhoneBackUpViewController: UIViewController {
    
    //MARK: User Interface Elements
    
    private var backupContactsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .semibold)
        label.text = "Restore"
        label.textColor = "404147".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var selectedCountLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15, weight: .regular)
        label.text = "0 Selected"
        label.textColor = "404147".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("back".image, for: .normal)
        return button
    }()
    
    private var restoreContactsButton: UIButton = {
        let button = UIButton()
        button.setTitle("Restore", for: .normal)
        button.setTitleColor("FFFFFF".hexColor, for: .normal)
        button.layer.cornerRadius = 12
        button.backgroundColor = "007AFF".hexColor
        return button
    }()
    
    private var phoneBackUpTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 65
        table.backgroundColor = .clear
        table.isScrollEnabled = true
        table.separatorStyle = .none
        return table
    }()
    
    private var selectDeselectAllContactsButton: UIButton = {
        let button = UIButton()
        button.setTitle("Select All", for: .normal)
        button.setTitleColor("000000".hexColor, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 15, weight: .regular)
        return button
    }()
    
    //MARK: Var and Let
    
    let disposeBag = DisposeBag()
    
    public var dataContact: Data?
    
    public var currentPhoneBackUp = [PhoneBackUpModel]()
    private var selectAllContactsForBackUp = [PhoneBackUpModel]()
    private var deselectAllContactsForBackUp = [PhoneBackUpModel]()
    
    var currentContact = [CNContact]()
    
    let valueForSelectedCell = false
    var selectedCellValue = [Bool]()
    
    //MARK: viewDidLoad
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    //MARK: Setup
    
    private func setup(){
        contactSetup()
        layoutSetup()
        setupTable()
        setupButtons()
    }
    
    //MARK: Setup Layout
    
    private func layoutSetup(){
        view.backgroundColor = "FFFFFF".hexColor
        view.addSubviews(backupContactsLabel, selectedCountLabel, backButton, selectDeselectAllContactsButton, phoneBackUpTableView, restoreContactsButton)
        
        backupContactsLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(68)
            make.height.equalTo(33)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
        }
        
        selectedCountLabel.snp.makeConstraints { make in
            make.top.equalTo(backupContactsLabel.snp.bottom).offset(10)
            make.height.equalTo(33)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
        }
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(68)
            make.leading.equalToSuperview().offset(19)
            make.width.equalTo(35)
            make.height.equalTo(35)
        }
        
        selectDeselectAllContactsButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(68)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(33)
        }
        
        phoneBackUpTableView.snp.makeConstraints { make in
            make.top.equalTo(backupContactsLabel.snp.bottom).offset(60)
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.bottom.equalTo(restoreContactsButton.snp.top).offset(15)
        }
        
        restoreContactsButton.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(56)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-5)
        }
    }
    
    //MARK: Configure TableView
    
    private func setupTable(){
        phoneBackUpTableView.delegate = self
        phoneBackUpTableView.dataSource = self
        phoneBackUpTableView.register(PhoneBackUpCell.self, forCellReuseIdentifier: PhoneBackUpCell.nibIdentifier)
    }
    
    //MARK: Setup Buttons
    
    private func setupButtons(){
        backButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.navigationController?.popViewController(animated: true)
        }.disposed(by: disposeBag)
        
        selectDeselectAllContactsButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.selectDeselectAllContactsForBackUpAction()
        }.disposed(by: disposeBag)
        
        restoreContactsButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.addNewContacts()
        }.disposed(by: disposeBag)
    }
    
    private func configureSelectedCell() {
        // Filling our array with selected cell
        selectedCellValue = []
        for contact in currentPhoneBackUp {
            selectedCellValue.append(contact.checkSelected ?? false)
        }
    }
    
    //MARK: Configure Selected BackUp Contacts
    
    private func contactSetup(){
        
        let transformationIntoContacts = NSKeyedUnarchiver.unarchiveObject(with: dataContact!) as? [CNContact]
        
        var contacts = [CNContact]()
        
        contacts = transformationIntoContacts ?? [CNContact]()
        currentContact = transformationIntoContacts ?? [CNContact]()
        
        for contact in contacts {
            
            let fullName = contact.givenName + " " + contact.familyName
            let number = contact.phoneNumbers.first?.value.stringValue ?? ""
            
            if let imageData = contact.thumbnailImageData {
                let imageString = String(describing: UIImage(data: imageData))
                let stringImage = String(decoding: imageData, as: UTF8.self)
                self.currentPhoneBackUp.append(PhoneBackUpModel(name: "\(fullName)", number: "\(number)", checkSelected: false, dataImage: imageData))
                self.selectAllContactsForBackUp.append(PhoneBackUpModel(name: "\(fullName)", number: "\(number)", checkSelected: true, dataImage: imageData))
                self.deselectAllContactsForBackUp.append(PhoneBackUpModel(name: "\(fullName)", number: "\(number)", checkSelected: false, dataImage: imageData))
            } else {
                var notImage = "contactImage"
                self.currentPhoneBackUp.append(PhoneBackUpModel(name: "\(fullName)", number: "\(number)", checkSelected: false, image: notImage))
                self.selectAllContactsForBackUp.append(PhoneBackUpModel(name: "\(fullName)", number: "\(number)", checkSelected: true, image: notImage))
                self.deselectAllContactsForBackUp.append(PhoneBackUpModel(name: "\(fullName)", number: "\(number)", checkSelected: false, image: notImage))
            }
        }
        phoneBackUpTableView.reloadData()
    }
    
    //MARK: Add New Contacts in Contacts Store
    private func addNewContacts(){
        if currentPhoneBackUp.filter({ $0.checkSelected == true}).count != 0 {
            var countDuplicateContact = 0
            var errorValue = false
            var mutableContact: [CNMutableContact] = []
            
            // Conversion CNContacts in CNMutbleContacts and add in CNContacts Array
            for contact in currentContact {
                mutableContact.append(contact.mutableCopy() as! CNMutableContact)
            }
            print("selected count ---->", selectedCellValue.count)
            selectedCellValue.enumerated().forEach({ (index, selected) in
                if selected == true {
                    print("Current index --->", index)
                    // Adding a contact to contacts in iphone
                    var contactForRecovery = mutableContact[index]
                    addContact(Contact: contactForRecovery) { (result) in
                        switch result{
                        case .Success(response: let bool):
                            if bool{
                                print("Contact Sucessfully Added")
                                AlertManager.shared().savedContact()
                            }
                            break
                        case .Error(error: let error):
                            print(error.localizedDescription)
                            countDuplicateContact += 1
                            errorValue = true
                            break
                        }
                    }
                }
            })
            
            if errorValue == true {
                AlertManager.shared().notSavedContact(count: countDuplicateContact)
            }
            
            currentPhoneBackUp = [PhoneBackUpModel]()
            deselectAllContactsForBackUp = [PhoneBackUpModel]()
            selectAllContactsForBackUp = [PhoneBackUpModel]()
            contactSetup()
            if selectDeselectAllContactsButton.currentTitle == "Deselect All" {
                selectedCellValue = []
                for value in deselectAllContactsForBackUp {
                    selectedCellValue.append(value.checkSelected ?? true)
                }
                selectDeselectAllContactsButton.setTitle("Select All", for: .normal)
                currentPhoneBackUp = deselectAllContactsForBackUp
                phoneBackUpTableView.reloadData()
            }
            selectCount()
            phoneBackUpTableView.reloadData()
        }
    }
    
    private func selectDeselectAllContactsForBackUpAction() {
        if selectDeselectAllContactsButton.currentTitle == "Select All" {
            selectedCellValue = []
            for value in selectAllContactsForBackUp {
                selectedCellValue.append(value.checkSelected ?? true)
            }
            selectDeselectAllContactsButton.setTitle("Deselect All", for: .normal)
            currentPhoneBackUp = selectAllContactsForBackUp
            phoneBackUpTableView.reloadData()
        } else {
            selectedCellValue = []
            for value in deselectAllContactsForBackUp {
                selectedCellValue.append(value.checkSelected ?? true)
            }
            selectDeselectAllContactsButton.setTitle("Select All", for: .normal)
            currentPhoneBackUp = deselectAllContactsForBackUp
            phoneBackUpTableView.reloadData()
        }
        
        selectCount()
    }
    
    private func selectCount(){
        var selectedValue = [Bool]()
        
        for contact in currentPhoneBackUp {
            if contact.checkSelected == true {
                selectedValue.append(contact.checkSelected ?? true)
            }
        }
        
        selectedCountLabel.text = "\(selectedValue.count) Selected"
    }
    
    deinit {
        currentPhoneBackUp.removeAll()
        selectAllContactsForBackUp.removeAll()
        selectedCellValue.removeAll()
        deselectAllContactsForBackUp.removeAll()
        currentContact.removeAll()
    }
}

//MARK: UITableViewDelegate, UITableViewDataSource

extension PhoneBackUpViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if currentPhoneBackUp[indexPath.row].checkSelected == true {
            currentPhoneBackUp[indexPath.row].checkSelected = false
            selectDeselectAllContactsButton.setTitle("Select All", for: .normal)
        } else {
            currentPhoneBackUp[indexPath.row].checkSelected = true
        }
        
        configureSelectedCell()
        
        if currentPhoneBackUp.filter({$0.checkSelected == false }).count == 0 {
            selectDeselectAllContactsButton.setTitle("Deselect All", for: .normal)
        }
        
        selectCount()
        
        phoneBackUpTableView.reloadData()
    }
}

extension PhoneBackUpViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return currentPhoneBackUp.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = phoneBackUpTableView.dequeueReusableCell(withIdentifier: PhoneBackUpCell.nibIdentifier, for: indexPath) as! PhoneBackUpCell
        let phoneBackUpModel = currentPhoneBackUp[indexPath.row]
        cell.phoneBackUpModel = phoneBackUpModel
        return cell
    }
}
