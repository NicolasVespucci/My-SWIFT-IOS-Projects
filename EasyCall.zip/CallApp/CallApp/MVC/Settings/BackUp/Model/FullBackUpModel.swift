import Foundation

struct FullBackUpModel {
    var name: String?
    var date: String?
    var count: String?
}
