import Foundation

struct PhoneBackUpModel {
    var name: String?
    var number: String?
    var checkSelected: Bool?
    var image: String?
    var dataImage: Data?
}

