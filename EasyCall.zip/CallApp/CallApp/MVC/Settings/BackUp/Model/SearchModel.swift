
import Foundation

struct SearchModel {
    var name: String?
}
