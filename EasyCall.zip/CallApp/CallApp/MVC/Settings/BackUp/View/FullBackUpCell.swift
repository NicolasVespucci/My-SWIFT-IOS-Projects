import UIKit

class FullBackUpCell: UITableViewCell {
    
    var fullBackUpCellModel: FullBackUpModel? {
        didSet { configureFullBackUpModel() }
    }
    
    private var cellView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.clipsToBounds = true
        view.layer.cornerRadius = 12
        view.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.05).cgColor
        view.layer.shadowOffset = CGSize(width: 2.0, height: 1.0)
        view.layer.shadowOpacity = 1
        view.layer.shadowRadius = 4
        view.layer.masksToBounds = false
        return view
    }()
    
    var nameLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.textColor = "3D485B".hexColor
        label.textAlignment = .left
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.text = "BACKUP 123"
        return label
    }()
    
    var dateLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 13, weight: .medium)
        label.textColor = "969696".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.text = "20.10.22"
        return label
    }()
    
    var countLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 13, weight: .medium)
        label.textColor = "007AFF".hexColor
        label.text = "8723" + " contacts"
        label.textAlignment = .right
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        selectionStyle = .none
        setupLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupLayout(){
        addSubview(cellView)
        cellView.addSubviews(nameLabel, dateLabel, countLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(48)
        }
        
        nameLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.height.equalTo(26)
            make.leading.equalToSuperview().offset(15)
            make.trailing.equalTo(dateLabel.snp.leading).offset(-5)
        }
        
        dateLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.height.equalTo(24)
            make.centerX.equalToSuperview()
            make.width.equalTo(72)
        }
        
        countLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.height.equalTo(24)
            make.trailing.equalToSuperview().offset(-15)
            make.leading.equalTo(dateLabel.snp.trailing).offset(5)
        }
    }
    
    private func configureFullBackUpModel() {
        guard let fullBackUpCell = fullBackUpCellModel else { return }
        nameLabel.text = fullBackUpCell.name
        dateLabel.text = fullBackUpCell.date
        countLabel.text = fullBackUpCell.count
    }
}
