import UIKit
import RxSwift
import Contacts
import SwiftyContacts

class NoNameNoNumberViewController: UIViewController {
    
    var optionCategoriesLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .semibold)
        label.textColor = "404147".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("back".image, for: .normal)
        return button
    }()
    
    private var selectAllButton: UIButton = {
        let button = UIButton()
        button.setTitle("Select All", for: .normal)
        button.setTitleColor("007AFF".hexColor, for: .normal)
        button.titleLabel?.adjustsFontSizeToFitWidth = true
        button.titleLabel?.minimumScaleFactor = 0.5
        return button
    }()
    
    private var noNameNoNumberTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 65
        table.backgroundColor = .clear
        table.isScrollEnabled = true
        table.separatorStyle = .none
        table.sectionIndexColor = .black
        return table
    }()
    
    private var deleteButton: UIButton = {
        let button = UIButton()
        button.setImage("deleteButton".image, for: .normal)
        button.layer.cornerRadius = 12
        button.backgroundColor = "007AFF".hexColor
        return button
    }()
    
    let disposeBag = DisposeBag()
    
    var currentContactsCN = [CNContact]()
    var currentContacts = [NoNameNoNumberModel]()
    
    var indexsesSelectedCell = [Int]()
    
    let valueForSelectedCell = false
    var selectedCellValue = [Bool]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup(){
        configurateCurrentOption(selected: false)
        setupLayout()
        configureTableView()
        setupButton()
    }
    
    private func setupLayout(){
        view.backgroundColor = .white
        
        view.addSubviews(optionCategoriesLabel, backButton, selectAllButton, noNameNoNumberTableView, deleteButton)
        
        optionCategoriesLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(68)
            make.width.equalTo(100)
            make.centerX.equalToSuperview()
            make.height.equalTo(33)
        }
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(68)
            make.leading.equalToSuperview().offset(19)
            make.width.equalTo(35)
            make.height.equalTo(35)
        }
        
        selectAllButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(68)
            make.leading.equalTo(optionCategoriesLabel.snp.trailing).offset(10)
            make.trailing.equalToSuperview().offset(-27)
            make.height.equalTo(33)
        }
        
        noNameNoNumberTableView.snp.makeConstraints { make in
            make.top.equalTo(optionCategoriesLabel.snp.bottom).offset(50)
            make.leading.equalToSuperview().offset(15)
            make.trailing.equalToSuperview().offset(-15)
            make.bottom.equalTo(deleteButton.snp.top).offset(-10)
        }
        
        deleteButton.snp.makeConstraints { make in
            make.height.equalTo(56)
            make.leading.equalToSuperview().offset(30)
            make.trailing.equalToSuperview().offset(-30)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-10)
        }
    }
    
    private func setupButton(){
        backButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.navigationController?.popViewController(animated: true)
        }.disposed(by: disposeBag)
        
        selectAllButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            if self.selectAllButton.currentTitle == "Select All" {
                self.selectedAllContacts()
            } else {
                self.deselectAllContacts()
            }
        }.disposed(by: disposeBag)
        
        deleteButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.deleteContacts()
        }.disposed(by: disposeBag)
    }
    
    private func configureTableView() {
        noNameNoNumberTableView.delegate = self
        noNameNoNumberTableView.dataSource = self
        noNameNoNumberTableView.register(NoNameNoNumberCell.self, forCellReuseIdentifier: NoNameNoNumberCell.nibIdentifier)
    }
    
    
    private func configurateCurrentOption(selected: Bool){
        for contact in currentContactsCN {
            
            let fullName = contact.givenName + " " + contact.familyName
            let number = contact.phoneNumbers.first?.value.stringValue ?? ""
            
            if let imageData = contact.thumbnailImageData {
                let imageString = String(describing: UIImage(data: imageData))
                let stringImage = String(decoding: imageData, as: UTF8.self)
                
                self.currentContacts.append(NoNameNoNumberModel(name: "\(fullName)", number: "\(number)", checkSelected: selected, dataImage: imageData))
            } else {
                var notImage = "contactImage"
                
                self.currentContacts.append(NoNameNoNumberModel(name: "\(fullName)", number: "\(number)", checkSelected: selected, image: notImage))
            }
        }
        noNameNoNumberTableView.reloadData()
    }
    
    private func configureSelectedCell() {
        // Filling our array with selected cell
        selectedCellValue = []
        for contact in currentContacts {
            selectedCellValue.append(contact.checkSelected ?? false)
        }
    }
    
    //MARK: Add New Contacts in Contacts Store
    private func deleteContacts(){
        
        var selectedCell = selectedCellValue.filter { ($0 == true)}
        
        if selectedCell.count == 0 {
            AlertManager.shared().nothingToDeletedContact()
        }
        
        currentContacts.enumerated().forEach { itemIndex, Contact in
            if Contact.checkSelected == true {
                indexsesSelectedCell.append(itemIndex)
            }
        }
        
        indexsesSelectedCell.forEach { indexSelected in
            if currentContacts[indexSelected].checkSelected == true {
                var countDuplicateContact = 0
                var errorValue = false
                var mutableContact: [CNMutableContact] = []
                
                // Conversion CNContacts in CNMutbleContacts and add in CNContacts Array
                for contact in currentContactsCN {
                    mutableContact.append(contact.mutableCopy() as! CNMutableContact)
                }
                
                selectedCellValue.enumerated().forEach({ (index, selected) in
                    if selected == true {
                        // Deleted a contact to contacts in iphone
                        var contactForRecovery = mutableContact[index]
                        
                        deleteContact(Contact: contactForRecovery) { result in
                            switch result{
                            case .Success(response: let bool):
                                if bool{
                                    print("Contact Sucessfully Deleted")
                                    AlertManager.shared().deletedContact()
                                }
                                break
                            case .Error(error: let error):
                                print(error.localizedDescription)
                                countDuplicateContact += 1
                                errorValue = true
                                break
                            }
                        }
                    }
                })
                
                if errorValue == true {
                }
            }
        }
        
        indexsesSelectedCell.removeAll()
        self.updatingConacts()
        noNameNoNumberTableView.reloadData()
        selectedCellValue.removeAll()
        
        if currentContacts.count == 0 {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    private func updatingConacts(){
        ContactManager.shared().cleanAndUpdateContacts()
        currentContacts.removeAll()
        
        if optionCategoriesLabel.text == "No name" {
            currentContactsCN = ContactManager.shared().noNamesCN
        } else {
            currentContactsCN = ContactManager.shared().noNumberCN
        }
        
        configurateCurrentOption(selected: false)
        noNameNoNumberTableView.reloadData()
    }
    
    //MARK: Selected All Action
    private func selectedAllContacts(){
        selectAllButton.setTitle("Deselect All", for: .normal)
        currentContacts.removeAll()
        configurateCurrentOption(selected: true)
        configureSelectedCell()
    }
    
    //MARK: Deselect All Action
    private func deselectAllContacts(){
        selectAllButton.setTitle("Select All", for: .normal)
        currentContacts.removeAll()
        configurateCurrentOption(selected: false)
        configureSelectedCell()
    }
    
    deinit {
        currentContacts.removeAll()
        currentContactsCN.removeAll()
        print("deinit - NoNameNoNumber")
    }
    
}

//MARK: UITableView

extension NoNameNoNumberViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if currentContacts[indexPath.row].checkSelected == true {
            currentContacts[indexPath.row].checkSelected = false
            configureSelectedCell()
            noNameNoNumberTableView.reloadData()
        } else {
            currentContacts[indexPath.row].checkSelected = true
            configureSelectedCell()
            noNameNoNumberTableView.reloadData()
        }
    }
}

extension NoNameNoNumberViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return currentContacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: NoNameNoNumberCell.nibIdentifier, for:  indexPath) as! NoNameNoNumberCell
        let noNameNoNumber = currentContacts[indexPath.row]
        cell.noNameNoNumberModel = noNameNoNumber
        
        return cell
    }
}
