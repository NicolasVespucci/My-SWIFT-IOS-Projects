import Foundation

struct NoNameNoNumberModel {
    var name: String?
    var number: String?
    var checkSelected: Bool?
    var dataImage: Data?
    var image: String?
}
