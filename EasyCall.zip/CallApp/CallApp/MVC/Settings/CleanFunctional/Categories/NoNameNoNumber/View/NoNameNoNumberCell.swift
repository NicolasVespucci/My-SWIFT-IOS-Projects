import UIKit
import BEMCheckBox

class NoNameNoNumberCell: UITableViewCell {
    
    var noNameNoNumberModel: NoNameNoNumberModel? {
        didSet { configureNoNameNoNumberModel() }
    }
    
    private var cellView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()
    
    private var contactImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.layer.masksToBounds = true
        imageView.layer.cornerRadius = 22
        return imageView
    }()
    
    private var nameLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15, weight: .regular)
        label.text = "Nov 15, 2021 23:05"
        label.textColor = "2F2E33".hexColor
        label.textAlignment = .left
        return label
    }()
    
    private var numberLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15, weight: .regular)
        label.text = "726"
        label.textColor = "2F2E33".hexColor
        label.textAlignment = .left
        return label
    }()
    
    public var checkContact: BEMCheckBox! = {
        let box = BEMCheckBox()
        box.boxType = .circle
        box.onAnimationType = .fill
        box.offAnimationType = .fill
        box.onFillColor = box.onTintColor
        box.onCheckColor = .white
        box.offFillColor = "5B616B".hexColor.withAlphaComponent(0.13)
        box.tintColor = .clear
        box.isUserInteractionEnabled = true
        return box
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        selectionStyle = .none
        setupLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupLayout(){
        addSubview(cellView)
        cellView.addSubviews(contactImageView, nameLabel, numberLabel, checkContact)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(50)
        }
        
        contactImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.size.equalTo(42)
            make.leading.equalToSuperview()
        }
        
        nameLabel.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.height.equalTo(24)
            make.leading.equalTo(contactImageView.snp.trailing).offset(15)
            make.trailing.equalTo(checkContact.snp.leading).offset(-10)
        }
        
        numberLabel.snp.makeConstraints { make in
            make.bottom.equalToSuperview()
            make.height.equalTo(24)
            make.leading.equalTo(contactImageView.snp.trailing).offset(15)
            make.trailing.equalTo(checkContact.snp.leading).offset(-10)
        }
        
        checkContact.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.size.equalTo(24)
            make.trailing.equalToSuperview().offset(-16)
        }
    }
    
    private func configureNoNameNoNumberModel() {
        guard let noNameNoNumberModel = noNameNoNumberModel else { return }
        nameLabel.text = noNameNoNumberModel.name
        numberLabel.text = noNameNoNumberModel.number
        checkContact.setOn(noNameNoNumberModel.checkSelected ?? false, animated: false)
        
        let image = noNameNoNumberModel.image
        
        let check = image?.contains("contactImage")
        
        if check == true {
            let imageString = noNameNoNumberModel.image
            contactImageView.image = noNameNoNumberModel.image?.image
        } else {
            let image = UIImage(data: noNameNoNumberModel.dataImage!)
            contactImageView.image = image
        }
        
        if nameLabel.text == " " {
            nameLabel.text = "No Name"
        } else if nameLabel.text == "" {
            nameLabel.text = "No Name"
        }
        
        if numberLabel.text == " " {
            numberLabel.text = "No Number"
        } else if numberLabel.text == "" {
            numberLabel.text = "No Number"
        }
        
    }
}
