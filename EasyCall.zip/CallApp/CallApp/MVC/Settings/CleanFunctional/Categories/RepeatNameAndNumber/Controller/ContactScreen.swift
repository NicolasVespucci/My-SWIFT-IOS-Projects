import UIKit
import SnapKit
import RxSwift
import RxCocoa
import Contacts
import SwiftyContacts
import IHProgressHUD
import CoreMIDI

struct ContactsToMerge {
    let section: Int
    var contacts: [CNContact]
}
//MARK: - Controller
class ContactScreen: UIViewController {
    
    var completionHeader: (()->())?
    
    private var topBackButton: UIButton = {
        let button = UIButton()
        button.setImage("back".image, for: .normal)
        return button
    }()
    
    private var topContactsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .heavy)
        label.text = "Contacts"
        label.textColor = "454D6A".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var emptyView: UIView = {
        let view = UIView()
        view.backgroundColor = .red
        return view
    }()
    
    private var scanningLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .heavy)
        label.text = "Scanning..."
        label.textColor = "007AFF".hexColor
        label.textAlignment = .center
        return label
    }()
    
    private var noDublicateLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 30, weight: .heavy)
        label.text = "Everything is clean, \n no duplicates contacts found on your phone"
        label.textColor = "007AFF".hexColor
        label.textAlignment = .center
        label.numberOfLines = 0
        label.isHidden = true
        return label
    }()
    
    var screenType: ContactsOptions?
    
    private lazy var contactsCollection: UICollectionView! = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.itemSize = CGSize(width: 335, height: 84)
        layout.collectionView?.layer.cornerRadius = 16
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        let collection = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collection.backgroundColor = .white
        collection.layer.cornerRadius = 16
        collection.delegate = self
        collection.dataSource = self
        collection.register(ContactCell.self, forCellWithReuseIdentifier: ContactCell.identifier)
        collection.register(ContactHeader.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: ContactHeader.identifier)
        collection.allowsMultipleSelection = true
        return collection
    }()
    
    private lazy var collectionsScrollView: UIScrollView! = {
        let scroll = UIScrollView()
        scroll.backgroundColor = "FFFFFF".hexColor
        let content = UIView()
        content.backgroundColor = "FFFFFF".hexColor
        scroll.addSubviews(content)
        content.snp.makeConstraints {
            $0.top.bottom.equalToSuperview()
            $0.leading.trailing.equalToSuperview()
            $0.centerX.equalToSuperview()
        }
        return scroll
    }()
    
    private lazy var deleteButton: UIButton! = {
        let button = UIButton()
        button.setTitle("Delete", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = "#212C89".hexColor
        button.layer.cornerRadius = 16
        return button
    }()
    
    private lazy var mergeButton: UIButton! = {
        let button = UIButton()
        button.setTitle("Merge", for: .normal)
        button.setTitleColor(.red, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 15, weight: .regular)
        button.titleLabel?.adjustsFontSizeToFitWidth = true
        button.titleLabel?.minimumScaleFactor = 0.5
        button.isHidden = true
        return button
    }()
    
    private var contentScrollView: UIView! {
        return collectionsScrollView.subviews.first
    }
    
    var isCollectionEditing: Bool = false
    
    let selectedContacts: BehaviorRelay<[CNContact]> = .init(value: [])
    let selectedDuplicates: BehaviorRelay<[ContactsToMerge]> = .init(value: [])
    
    var selectedAllOrDeselectedDuplicates = [[ContactsToMerge]]()
    
    private let disposeBag = DisposeBag()
    private let contactList: BehaviorRelay<[(letter: String, contacts: [CNContact])]> = .init(value: [])
    private let duplicatesList: BehaviorRelay<Array<[CNMutableContact]>> = .init(value: [])
    
    var CellCurrentSelectedCount = 1
    var SelectedAllHeaderCount = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = screenType?.title
        view.backgroundColor = "FFFFFF".hexColor
        configureViews()
        
        selectedDuplicates.bind { duplicates in
            self.mergeButton.transform = CGAffineTransform(translationX: 0, y: duplicates.count < 1 ? (60 + 34) : 0)
        }.disposed(by: disposeBag)
        
        mergeButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            IHProgressHUD.show()
//            self.selectedDuplicates.value.forEach { contactsToMerge in
//                let accountToMerge = LibraryMediaManager.shared.simpleMerge(duplicates: self.duplicatesList.value[contactsToMerge.section])
//
//                let mergedAccount = LibraryMediaManager.shared.simpleMerge(duplicates: contactsToMerge.contacts, into: accountToMerge)
//
//                contactsToMerge.contacts.compactMap({$0.mutableCopy() as? CNMutableContact}).forEach { contact in
//                    deleteContact(Contact: contact) { result in
//                    }
//                }
//
//                if contactsToMerge.contacts.count != 1 {
//                    addContact(Contact: mergedAccount) { [weak self] result in
//                        switch result {
//                        case .Success(response: let created):
//                            print("Account", mergedAccount.identifier, "created:", created)
//                            self?.fetchDuplicates()
//                        case .Error(error: let error):
//                            print("Account merge error", error)
//                        }
//                    }
//                    if self.duplicatesList.value.count == 0 {
//                        self.noDublicateLabel.isHidden = false
//                    } else {
//                        self.noDublicateLabel.isHidden = true
//                    }
//                    IHProgressHUD.dismiss()
//                } else {
//                    self.fetchDuplicates()
//                    if self.duplicatesList.value.count == 0 {
//                        self.noDublicateLabel.isHidden = false
//                    } else {
//                        self.noDublicateLabel.isHidden = true
//                    }
//                    IHProgressHUD.dismiss()
//                }
//            }
            
            if self.selectedDuplicates.value.count > 0 {
                for contacts in self.selectedDuplicates.value {
                    self.selectedAllOrDeselectedDuplicates.append([contacts])
                }
            }
            
            self.selectedAllOrDeselectedDuplicates.forEach { contactsToMerge in

                let accountToMerge = LibraryMediaManager.shared.simpleMerge(duplicates: self.duplicatesList.value[contactsToMerge[0].section])

                let mergedAccount = LibraryMediaManager.shared.simpleMerge(duplicates: contactsToMerge[0].contacts, into: accountToMerge)

                contactsToMerge[0].contacts.compactMap({$0.mutableCopy() as? CNMutableContact}).forEach { contact in
                    deleteContact(Contact: contact) { result in
                    }
                }
                
                if contactsToMerge[0].contacts.count != 1 {
                    addContact(Contact: mergedAccount) { [weak self] result in
                        switch result {
                        case .Success(response: let created):
                            print("Account", mergedAccount.identifier, "created:", created)
                            self?.fetchDuplicates()
                        case .Error(error: let error):
                            print("Account merge error", error)
                        }
                    }
                    if self.duplicatesList.value.count == 0 {
                        self.noDublicateLabel.isHidden = false
                    } else {
                        self.noDublicateLabel.isHidden = true
                    }
                    IHProgressHUD.dismiss()
                } else {
                    self.fetchDuplicates()
                    if self.duplicatesList.value.count == 0 {
                        self.noDublicateLabel.isHidden = false
                    } else {
                        self.noDublicateLabel.isHidden = true
                    }
                    IHProgressHUD.dismiss()
                }
            }
            self.selectedDuplicates.accept([])
            self.selectedAllOrDeselectedDuplicates.removeAll()
        }.disposed(by: disposeBag)
        
        topBackButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.navigationController?.popViewController(animated: true)
        }.disposed(by: disposeBag)
        
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if let contactsCleaner = (navigationController?.viewControllers[1] as? ContactsCleanerViewController) {
            contactsCleaner.viewWillAppear(true)
        } else {
            print("error")
        }
    }
    
    
    deinit {
        self.selectedDuplicates.accept([])
    }
}

extension ContactScreen {
    private func fetchDuplicates() {
        switch screenType {
        case .emails:
            LibraryMediaManager.shared.getDuplicateContacts(type: .email) { [weak self] result in
                DispatchQueue.main.async {
                    self?.resultHandler(result)
                }
            }
        case .names:
            LibraryMediaManager.shared.getDuplicateContacts(type: .name) { [weak self] result in
                DispatchQueue.main.async {
                    self?.resultHandler(result)
                }
            }
        case .phoneNumbers:
            LibraryMediaManager.shared.getDuplicateContacts(type: .phone) { [weak self] result in
                DispatchQueue.main.async { [weak self] in
                    self?.resultHandler(result)
                }
            }
        default: break
        }
    }
    
    private func configureViews() {
        switch screenType {
        case .contacts:
            view.addSubviews(contactsCollection, deleteButton)
        default:
            
            duplicatesList.bind { [weak self] duplicateValues in
                DispatchQueue.main.async {
                    self?.contentScrollView.subviews.forEach({$0.removeFromSuperview()})
                    self?.selectedDuplicates.accept([])
                    duplicateValues.enumerated().forEach { [weak self] object in
                        guard let self = self else { return }
                        let (index, _) = object
                        
                        let layout = UICollectionViewFlowLayout()
                        layout.minimumLineSpacing = 15
                        layout.minimumInteritemSpacing = 0
                        layout.itemSize = CGSize(width: (UIScreen.main.bounds.width - 48), height: 62)
                        layout.scrollDirection = .vertical
                        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
                        
                        let duplicateCollectionView: UICollectionView = {
                            let collection = UICollectionView(frame: .zero, collectionViewLayout: layout)
                            collection.backgroundColor = .white
                            collection.layer.cornerRadius = 16
                            collection.tag = index
                            collection.dataSource = self
                            collection.delegate = self
                            collection.isScrollEnabled = false
                            collection.register(DuplicateCell.self, forCellWithReuseIdentifier: "DuplicateCell")
                            collection.register(DuplicateHeader.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: DuplicateHeader.identifier)
                            collection.allowsMultipleSelection = true
                            collection.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
                            
                            return collection
                        }()
                        
                        self.contentScrollView.addSubviews(duplicateCollectionView)
                        duplicateCollectionView.snp.makeConstraints {
                            if index == 0 {
                                $0.top.equalToSuperview().offset(10)
                            } else {
                                $0.top.equalTo(self.contentScrollView.subviews[index - 1].snp.bottom).offset(20)
                            }
                            $0.centerX.equalToSuperview()
                            $0.leading.equalToSuperview().offset(24)
                            $0.trailing.equalToSuperview().offset(-24)
                            if index == self.duplicatesList.value.count - 1 {
                                $0.bottom.equalToSuperview().inset(10)
                            }
                            let height = duplicateCollectionView.collectionViewLayout.collectionViewContentSize.height
                            $0.height.equalTo(height <= 0 ? 50 : height)
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            duplicateCollectionView.snp.updateConstraints {
                                $0.height.equalTo(duplicateCollectionView.collectionViewLayout.collectionViewContentSize.height + 20)
                            }
                        }
                    }
                    
                    DispatchQueue.main.async {
                        self?.contentScrollView.subviews.compactMap({$0 as? UICollectionView}).forEach({$0.reloadData()})
                    }
                    
                }
            }.disposed(by: disposeBag)
            
            IHProgressHUD.show()
            DispatchQueue.main.async { [weak self] in
                guard let self = self else { return }
                self.view.addSubviews(self.topBackButton, self.topContactsLabel, self.mergeButton, self.collectionsScrollView, self.scanningLabel, self.noDublicateLabel)
                self.configureLayout()
                self.fetchDuplicates()
            }
        }
    }
    
    private func resultHandler(_ result: Result<Array<[CNMutableContact]>, Error>) {
        switch result {
        case .success(let contactListt):
            duplicatesList.accept(contactListt)
            if screenType == .phoneNumbers {
                Constants.ud.currentCountOfRepeatNumber = duplicatesList.value.count
            } else {
                Constants.ud.currentCountOfRepeatName = duplicatesList.value.count
            }
            IHProgressHUD.dismiss()
            scanningLabel.isHidden = true
            if duplicatesList.value.count == 0 {
                noDublicateLabel.isHidden = false
                mergeButton.isHidden = true
            } else {
                noDublicateLabel.isHidden = true
                mergeButton.isHidden = false
            }
            
        case .failure(let error):
            print(error)
            IHProgressHUD.dismiss()
        }
    }
    
    private func configureLayout() {
        switch screenType {
        case .contacts:
            contactsCollection.snp.updateConstraints {
                $0.top.equalTo(view.snp_topMargin)
                $0.bottom.equalToSuperview()
                $0.leading.trailing.equalToSuperview()
            }
            
            deleteButton.snp.updateConstraints {
                $0.size.equalTo(CGSize(width: 335, height: 60))
                $0.centerX.equalToSuperview()
                $0.bottom.equalTo(view.snp_bottomMargin)
            }
        default:
            topBackButton.snp.makeConstraints { make in
                make.top.equalToSuperview().offset(54)
                make.leading.equalToSuperview().offset(24)
                make.width.equalTo(35)
                make.height.equalTo(35)
            }
            
            topContactsLabel.snp.makeConstraints { make in
                make.top.equalToSuperview().offset(54)
                make.leading.equalToSuperview().offset(30)
                make.trailing.equalToSuperview().offset(-30)
                make.height.equalTo(24)
            }
            
            mergeButton.snp.updateConstraints {
                $0.top.equalToSuperview().offset(54)
                $0.trailing.equalToSuperview().offset(-14)
                $0.width.equalTo(100)
                $0.height.equalTo(24)
            }
            
            collectionsScrollView.snp.updateConstraints {
                $0.top.equalTo(topContactsLabel.snp.bottom).offset(22.resized())
                $0.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-10)
                $0.leading.trailing.equalToSuperview()
            }
            
            scanningLabel.snp.makeConstraints { make in
                make.centerY.equalToSuperview().offset(25)
                make.leading.equalToSuperview().offset(20)
                make.trailing.equalToSuperview().offset(-20)
                make.height.equalTo(50)
            }
            
            noDublicateLabel.snp.makeConstraints { make in
                make.centerY.equalToSuperview()
                make.leading.equalToSuperview().offset(20)
                make.trailing.equalToSuperview().offset(-20)
                make.height.equalTo(200)
            }
        }
    }
    
    private func setEditMode() {
        isCollectionEditing.toggle()
        switch screenType {
        case .contacts:
            contactsCollection.visibleCells.compactMap({$0 as? ContactCell}).forEach { [weak self] cell in
                guard let self = self else { return }
                cell.edit(self.isCollectionEditing)
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) { [weak contactsCollection] in
                contactsCollection?.reloadData()
            }
        default:
            break
        }
    }
 
    
}

extension ContactScreen: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    //MARK: - Did Selected Cell
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if indexPath.section != 0 {
            let merged = LibraryMediaManager.shared.simpleMerge(duplicates: duplicatesList.value[collectionView.tag])
            let filteredContactsOne = duplicatesList.value[collectionView.tag].filter{ $0.phoneNumbers.first?.identifier != merged.phoneNumbers.first?.identifier }
            let contact = filteredContactsOne[indexPath.row]
            var cache = selectedDuplicates.value
            if cache.compactMap({$0.section}).contains(collectionView.tag) {
                guard var merges = selectedDuplicates.value.first(where: {$0.section == collectionView.tag}) else { return }
                if !merges.contacts.contains(contact) { merges.contacts.append(contact) }
                cache.removeAll(where: {$0.section == collectionView.tag})
                cache.append(merges)
            } else {
                let newMerges = ContactsToMerge(section: collectionView.tag, contacts: [contact])
                cache.append(newMerges)
            }
            
            self.mergeButton.setTitle("Merge", for: .normal)
            cache.sort(by: {$0.section < $1.section})
            selectedDuplicates.accept(cache)
            let countOfAllSelectedItemInCell = ContactsToMerge(section: collectionView.tag, contacts: self.duplicatesList.value[collectionView.tag])
            if (countOfAllSelectedItemInCell.contacts.count - 1) == selectedDuplicates.value[selectedDuplicates.value.count - 1].contacts.count {
                let header = collectionView.supplementaryView(forElementKind: UICollectionView.elementKindSectionHeader, at: IndexPath(item: 0, section: indexPath.section)) as? DuplicateHeader
                header?.selectDeSelectButton.setTitle("Cancel", for: .normal)
            }
        }
    }
    
    //MARK: - Did DeSelected Cell
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        let merged = LibraryMediaManager.shared.simpleMerge(duplicates: duplicatesList.value[collectionView.tag])
        let filteredContactsOne = duplicatesList.value[collectionView.tag].filter{ $0.phoneNumbers.first?.identifier != merged.phoneNumbers.first?.identifier }
        let contact = filteredContactsOne[indexPath.row]
        var cache = selectedDuplicates.value
        if cache.compactMap({$0.section}).contains(collectionView.tag) {
            guard var merges = selectedDuplicates.value.first(where: {$0.section == collectionView.tag}) else { return }
            if merges.contacts.contains(contact) { merges.contacts.removeAll(where: {$0.identifier == contact.identifier}) }
            cache.removeAll(where: {$0.section == collectionView.tag})
            if !merges.contacts.isEmpty { cache.append(merges) }
        }
        
        self.mergeButton.setTitle("Merge", for: .normal)
        cache.sort(by: {$0.section < $1.section})
        selectedDuplicates.accept(cache)
        
        
        if  selectedDuplicates.value.count == 0 {
            let header = collectionView.supplementaryView(forElementKind: UICollectionView.elementKindSectionHeader, at: IndexPath(item: 0, section: indexPath.section)) as? DuplicateHeader
            header?.selectDeSelectButton.setTitle("Select All", for: .normal)
        }
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return section == 0 ? 1 : duplicatesList.value[collectionView.tag].count - 1
    }
    
    //MARK: - Cell For Item At
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DuplicateCell", for: indexPath) as! DuplicateCell
        
        let merged = LibraryMediaManager.shared.simpleMerge(duplicates: duplicatesList.value[collectionView.tag])
        cell.contactType = indexPath.section == 0 ? .merged : .duplicate
        
        if indexPath.section == 0 {
            cell.backgroundColor = "007AFF".hexColor
            cell.nameLabel.font = .systemFont(ofSize: 14, weight: .semibold)
            cell.nameLabel.textColor = .white
            cell.descriptionLabel.font = .systemFont(ofSize: 14, weight: .regular)
            cell.descriptionLabel.textColor = .white
            cell.contact = merged
        } else {
            let filteredContacts = duplicatesList.value[collectionView.tag].filter{ $0.phoneNumbers.first?.identifier != merged.phoneNumbers.first?.identifier }
            cell.contact = filteredContacts[indexPath.row]
            cell.option = screenType
            cell.backgroundColor = .clear
            cell.nameLabel.font = .systemFont(ofSize: 14, weight: .regular)
            cell.descriptionLabel.font = .systemFont(ofSize: 14, weight: .semibold)
        }
        return cell
    }
    
    //MARK: Header Select All
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let view = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: DuplicateHeader.identifier, for: indexPath) as! DuplicateHeader
        if indexPath.section == 0 {
            view.letterLabel.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
            view.selectDeSelectButton.isHidden = true
        } else {
            view.letterLabel.text = "Select contacts to merge"
            view.letterLabel.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
            view.completion = {
                var buttonName = view.selectDeSelectButton.currentTitle != "Cancel" ? "Cancel" : "Select All"
                view.selectDeSelectButton.setTitle(buttonName, for: .normal)
                var cache: [ContactsToMerge] = []
                let allSelected = buttonName == "Cancel"
                if allSelected {
                    collectionView.indexPathsForVisibleItems.forEach { indexPath in
                        collectionView.selectItem(at: indexPath, animated: true, scrollPosition: .left)
                    }
                    self.mergeButton.setTitle("Merge", for: .normal)
                    let newMerges = ContactsToMerge(section: collectionView.tag, contacts: self.duplicatesList.value[collectionView.tag])
                    cache.append(newMerges)
                    cache.sort(by: {$0.section < $1.section})
                    buttonName = "Cancel"
                   // self.selectedDuplicates.accept(cache)
                    self.selectedAllOrDeselectedDuplicates.append(cache)
                } else {
                    self.mergeButton.setTitle("Merge", for: .normal)
                    collectionView.indexPathsForVisibleItems.forEach { indexPath in
                        collectionView.deselectItem(at: indexPath, animated: true)
                    }
                    let sectionToDeselect = collectionView.tag
                    let filteredSelectedDuplicate = self.selectedAllOrDeselectedDuplicates.filter { ($0[0].section != sectionToDeselect)}
                    self.selectedAllOrDeselectedDuplicates = filteredSelectedDuplicate
                   //self.selectedDuplicates.accept([])
                }
            }
        }
        return view
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if section == 0 {
            return CGSize(width: 0, height: 0)
        } else {
            return CGSize(width: 0, height: 45)
        }
    }
}

