import UIKit
import Photos
import Contacts

enum ContactsOptions: Int, CaseIterable {
    case contacts = 0
    case names = 1
    case phoneNumbers = 2
    case emails = 3
    
    var image: UIImage? {
        switch self {
        case .contacts:
            return "ic_contacts".image
        case .emails:
            return "ic_contacts_3".image
        case .names:
            return "ic_contacts_1".image
        case .phoneNumbers:
            return "ic_contacts_2".image
        }
    }
    var title: String {
        switch self {
        case .contacts:
            return "Contacts"
        case .emails:
            return "Emails"
        case .names:
            return "Names"
        case .phoneNumbers:
            return "Phone Numbers"
        }
    }
}


enum CleaningOptions: Int, CaseIterable {
    case photos = 0
    case videos = 1
    case contacts = 2
    
    var image: UIImage? {
        switch self {
        case .photos:
            return "ic_photos".image
        case .contacts:
            return "ic_contacts".image
        case .videos:
            return "ic_video".image
        }
    }
    
    var title: String {
        switch self {
        case .contacts:
            return "Organize Contacts"
        case .photos:
            return "Photos"
        case .videos:
            return "Videos"
        }
    }
    
    var numberOfSections: Int {
        switch self {
        case .contacts:
            return 2
        default:
            return 1
        }
    }
    
    var contactsSections: [[ContactsOptions]]? {
        switch self {
        case .contacts:
            return [[ContactsOptions.contacts],
                    [ContactsOptions.names, ContactsOptions.phoneNumbers,
                     ContactsOptions.emails]]
        default:
            return nil
        }
    }
}

enum PhotoOptions: Int, CaseIterable {
    case similar = 0  //--------------------------------
    case screens = 1
    case live = 2
    case burst = 3
    
    var image: UIImage? {
        switch self {
        case .similar:
            return "ic_photo_similar".image   //--------------------------------
        case .screens:
            return "ic_photo_screens".image
        case .live:
            return "ic_photo_live".image
        case .burst:
            return "ic_photo_burst".image
        }
    }
    
    var title: String {
        switch self {
        case .similar:
            return "Similar Photos"  //--------------------------------
        case .screens:
            return "Screenshots"
        case .live:
            return "Similar Live Photos"
        case .burst:
            return "Similar Burst Photos"
        }
    }
    
    var fetchPredicate: NSPredicate {
        switch self {
        case .burst:
            return NSPredicate(format: "burstIdentifier != nil")
        case .live:
            return NSPredicate(format: "(mediaSubtype & %d) != 0", PHAssetMediaSubtype.photoLive.rawValue)
        case .screens:
            return NSPredicate(format: "(mediaSubtype & %d) != 0", PHAssetMediaSubtype.photoScreenshot.rawValue)
        case .similar:
            return NSPredicate(format: "burstIdentifier == nil")  //--------------------------------
        }
    }
}
