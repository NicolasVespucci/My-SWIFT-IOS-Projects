import UIKit
import RxSwift
import RxCocoa
import SnapKit
import Contacts
import BEMCheckBox

enum ContactType {
    case merged, duplicate
}

class DuplicateCell: UICollectionViewCell {
    
    public lazy var nameLabel: UILabel! = {
        let label = UILabel()
        label.textColor = .black
        label.textAlignment = .left
        label.text = "aa"
        return label
    }()
    
    public lazy var descriptionLabel: UILabel! = {
        let label = UILabel()
        label.textColor = .black
        label.textAlignment = .left
        label.text = "bb"
        return label
    }()
    
    private lazy var checkBox: BEMCheckBox! = {
        let box = BEMCheckBox()
        box.boxType = .circle
        box.onAnimationType = .fill
        box.offAnimationType = .fill
        box.lineWidth = 1
        box.onFillColor = "007AFF".hexColor
        box.onCheckColor = .white
        box.tintColor = "007AFF".hexColor
        box.onTintColor = "007AFF".hexColor
        box.layer.cornerRadius = 12
        
        box.isUserInteractionEnabled = false
        return box
    }()
    
    override var isSelected: Bool {
        didSet {
            if oldValue == isSelected { return }
            checkBox.setOn(isSelected, animated: true)
        }
    }
    
    var option: ContactsOptions! {
        didSet {
            if contact.isNil { return }
            var description: String = ""
            switch option {
            case .emails:
                contact.emailAddresses.compactMap({$0.value as String}).forEach { string in
                    description = description + " " + string
                }
                break
            default:
                contact.phoneNumbers.compactMap({$0.value.stringValue}).forEach { string in
                    description = description + " " + string
                }
            }
            descriptionLabel.text = description
        }
    }
    
    var contact: CNContact! {
        didSet {
            nameLabel.text = contact.givenName + " " +  contact.familyName
            var description: String = ""
            switch option {
            case .emails:
                contact.emailAddresses.compactMap({$0.value as String}).forEach { string in
                    description = description + " " + string
                }
                break
            default:
                contact.phoneNumbers.compactMap({$0.value.stringValue}).forEach { string in
                    description = description + " " + string
                }
            }
            if description == "" {
                descriptionLabel.text = description
            } else if description == " " {
                descriptionLabel.text = description
            } else {
                description.removeFirst(1)
                descriptionLabel.text = description
            }
        }
    }
    
    var contactType: ContactType! {
        didSet {
            commonInit()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }
}

extension DuplicateCell {
    private func commonInit() {
        backgroundColor = .clear
        
        nameLabel.removeFromSuperview()
        descriptionLabel.removeFromSuperview()
        
        if contactType == .some(.duplicate) {
            addSubviews(checkBox)
            
            checkBox.snp.makeConstraints {
                $0.centerY.equalToSuperview()
                $0.size.equalTo(24)
                $0.trailing.equalToSuperview().offset(-16)
            }
        }
        
        addSubviews(nameLabel, descriptionLabel)
        nameLabel.snp.makeConstraints {
            if contactType == .some(.merged) {
                $0.leading.equalToSuperview().offset(16)
                $0.top.equalToSuperview().offset(8)
                $0.trailing.equalToSuperview().offset(-20)
                $0.height.equalTo(24)
            } else {
                $0.leading.equalToSuperview().offset(16)
                $0.top.equalToSuperview().offset(8)
                $0.trailing.equalToSuperview().offset(-54)
                $0.height.equalTo(24)
            }
        }
        
        descriptionLabel.snp.makeConstraints {
            $0.top.equalTo(nameLabel.snp.bottom)
            $0.leading.trailing.equalTo(nameLabel)
            $0.height.equalTo(24)
        }
    }
}


