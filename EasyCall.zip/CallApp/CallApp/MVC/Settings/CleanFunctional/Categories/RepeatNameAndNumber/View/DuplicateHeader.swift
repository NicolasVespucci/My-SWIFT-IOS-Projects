import UIKit
import RxSwift

class DuplicateHeader: UICollectionReusableView {
    static var identifier = "DuplicateHeader"
    
    var letterLabel: UILabel! = {
        let label = UILabel()
        label.textColor = .black
        label.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    var selectDeSelectButton: UIButton! = {
        let button = UIButton()
        button.setTitle(NSLocalizedString("Select All", comment: ""), for: .normal)
        button.setTitleColor("007AFF".hexColor, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 15, weight: .regular)
        button.titleLabel?.textAlignment = .right
        return button
    }()
    
    let disposeBag = DisposeBag()
    var completion: (()->())?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
        configureButtons()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
        configureButtons()
    }
    
    private func commonInit() {
        
        addSubviews(letterLabel, selectDeSelectButton)
        
        letterLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(12)
            make.leading.equalToSuperview().offset(16)
            make.trailing.equalToSuperview().offset(-120)
            make.height.equalTo(24)
        }
        
        selectDeSelectButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(12)
            make.trailing.equalToSuperview().offset(-16)
            make.height.equalTo(24)
        }
    }
    
    private func configureButtons() {
        selectDeSelectButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.selectDeSelectButtonActions()
        }.disposed(by: disposeBag)
    }
    
    func selectDeSelectButtonActions() {
        completion?()
    }
}


