import UIKit
import RxSwift
import IHProgressHUD

class ContactsCleanerViewController: UIViewController {
    
    public var optionsOfClean = [CleanOptionModel(count: "\(Constants.ud.currentCountOfRepeatName ?? -1)", option: "Repeat name"), CleanOptionModel(count: "\(Constants.ud.currentCountOfRepeatNumber ?? -1)", option: "Repeat number"), CleanOptionModel(count: "\(ContactManager.shared().noNumberCN.count)", option: "No number"), CleanOptionModel(count: "\(ContactManager.shared().noNamesCN.count)", option: "No name")]
    
    private var contactsCleanerLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .semibold)
        label.text = "Contacts cleaner"
        label.textColor = "404147".hexColor
        label.textAlignment = .center
        return label
    }()
    
    private var procentLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 35, weight: .medium)
        label.text = ""
        label.textAlignment = .center
        label.textColor = "007AFF".hexColor
        return label
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("back".image, for: .normal)
        return button
    }()

    
    private var contactsCollectionView: UICollectionView = {
        let collection = UICollectionView(frame: .zero, collectionViewLayout: .init())
        collection.backgroundColor = .clear
        collection.showsHorizontalScrollIndicator = false
        collection.showsVerticalScrollIndicator = false
        collection.isScrollEnabled = true
        collection.clipsToBounds = false
        return collection
    }()
    
    private var contactsLayout: UICollectionViewLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 0
        layout.itemSize = .init(width: 100, height: 70)
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 30
        layout.sectionInset = .init(top: 0, left: 0, bottom: 0, right: 0)
        return layout
    }()
    
    let disposeBag = DisposeBag()
    private var currentSize = 0.0
    
    var currentProcentSize = Double(ContactManager.shared().allContactsCN.count) / 100.0 / 100.0 / 100.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        optionsOfClean = [CleanOptionModel(count: "\(Constants.ud.currentCountOfRepeatName ?? -1)", option: "Repeat name"), CleanOptionModel(count: "\(Constants.ud.currentCountOfRepeatNumber ?? -1)", option: "Repeat number"), CleanOptionModel(count: "\(ContactManager.shared().noNumberCN.count)", option: "No number"), CleanOptionModel(count: "\(ContactManager.shared().noNamesCN.count)", option: "No name")]
        contactsCollectionView.reloadData()
    }

    private func setup(){
        setupLayout()
        configureCollection()
        setupButton()
        
    }
    
    private func setupLayout() {
        view.backgroundColor = .white
        
        view.addSubviews(contactsCleanerLabel, procentLabel, backButton, contactsCollectionView)
        
        contactsCleanerLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(68)
            make.leading.equalToSuperview().offset(50)
            make.trailing.equalToSuperview().offset(-50)
            make.height.equalTo(33)
        }
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(68)
            make.leading.equalToSuperview().offset(19)
            make.width.equalTo(35)
            make.height.equalTo(35)
        }
        
        contactsCollectionView.snp.makeConstraints { make in
            make.top.equalTo(contactsCleanerLabel.snp.bottom).offset(46)
            make.width.equalTo(230)
            make.height.equalTo(170)
            make.centerX.equalToSuperview()
        }
        
        procentLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview().offset(-150)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(72)
        }
    }
    
    private func setupButton(){
        backButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.navigationController?.popViewController(animated: true)
        }.disposed(by: disposeBag)
        
    }
    
    private func configureCollection() {
        contactsCollectionView.setCollectionViewLayout(contactsLayout, animated: true)
        contactsCollectionView.dataSource = self
        contactsCollectionView.delegate = self
        contactsCollectionView.register(OptionsDuplicateCell.self, forCellWithReuseIdentifier: OptionsDuplicateCell.nibIdentifier)
    }
    
     func configuratePocenteProgress() {
         IHProgressHUD.show()
         contactsCollectionView.isHidden = true
         animateProgress()
         
         DispatchQueue.main.asyncAfter(deadline: .now() + 1.1) {
             ContactManager.shared().configurateDuplicateNameAndPhoneNumberForKnowCountDuplicate()
         }
         
         ContactManager.shared().complitionOne = { [weak self] in
             guard let self = self else { return }
            self.currentSize += (99.0 - self.currentSize)
             
         }
    }
    
     func animateProgress() {
         DispatchQueue.main.async {
             UIView.animate(withDuration: 1, animations: { [weak self] in
                 guard let self = self else { return }
                 self.currentSize += 0.0005
                 self.procentLabel.text = "\(Int(self.currentSize))%"
                 
             }) { [weak self] _ in
                 guard let self = self else { return }
                 if self.currentSize <= 100 {
                     self.animateProgress()
                 } else {
                     self.updateCollections()
                     IHProgressHUD.dismiss()
                 }
             }
         }
    }
    
    private func updateCollections() {
        self.procentLabel.isHidden = true
        self.optionsOfClean = [CleanOptionModel(count: "\(Constants.ud.currentCountOfRepeatName ?? -1)", option: "Repeat name"), CleanOptionModel(count: "\(Constants.ud.currentCountOfRepeatNumber ?? -1)", option: "Repeat number"), CleanOptionModel(count: "\(ContactManager.shared().noNumberCN.count)", option: "No number"), CleanOptionModel(count: "\(ContactManager.shared().noNamesCN.count)", option: "No name")]
        self.contactsCollectionView.isHidden = false
        self.contactsCollectionView.reloadData()
    }
}

extension ContactsCleanerViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        switch optionsOfClean[indexPath.item].option {
        case "Repeat name":
            IHProgressHUD.show()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
                guard let self = self else { return }
            if Constants.ud.currentCountOfRepeatName != 0 {
                let option: ContactsOptions = .names
                let vc = ContactScreen()
                vc.screenType = option
                self.navigationController?.pushViewController(vc, animated: true)
                print("Repeat name")
            }
                IHProgressHUD.dismiss()
            }
        case "Repeat number":
            IHProgressHUD.show()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
                guard let self = self else { return }
                if Constants.ud.currentCountOfRepeatNumber != 0 {
                    let option: ContactsOptions = .phoneNumbers
                    let vc = ContactScreen()
                    vc.screenType = option
                    self.navigationController?.pushViewController(vc, animated: true)
                    print("Repeat number")
                }
                IHProgressHUD.dismiss()
            }
            
        case "No number":
            IHProgressHUD.show()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
                guard let self = self else { return }
                if ContactManager.shared().noNumberCN.count != 0 {
                    let vc = NoNameNoNumberViewController()
                    vc.optionCategoriesLabel.text = "No number"
                    vc.currentContactsCN = ContactManager.shared().noNumberCN
                    self.navigationController?.pushViewController(vc, animated: true)
                } else {
                    print("Is Empty Category")
                }
                IHProgressHUD.dismiss()
            }
            
        case "No name":
            IHProgressHUD.show()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
                guard let self = self else { return }
                if ContactManager.shared().noNamesCN.count != 0 {
                    let vc = NoNameNoNumberViewController()
                    vc.optionCategoriesLabel.text = "No name"
                    vc.currentContactsCN = ContactManager.shared().noNamesCN
                    self.navigationController?.pushViewController(vc, animated: true)
                } else {
                    print("Is Empty Category")
                }
                IHProgressHUD.dismiss()
            }
            
        default:
            break
        }
    }
}

//MARK: UICollectionVew (Delegate, dataSourse)
extension ContactsCleanerViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return optionsOfClean.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: OptionsDuplicateCell.nibIdentifier, for: indexPath) as! OptionsDuplicateCell
        cell.cleanOptionModel = optionsOfClean[indexPath.item]
        return cell
    }
}
