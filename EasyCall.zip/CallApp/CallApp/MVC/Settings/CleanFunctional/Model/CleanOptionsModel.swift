import Foundation

struct CleanOptionModel {
    var count: String?
    var option: String?
}
