import UIKit
import RxSwift

class OptionsDuplicateCell: UICollectionViewCell {
    
    var cleanOptionModel: CleanOptionModel? {
        didSet { configureOptionsModel() }
    }
    
    var cellView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()
    
    private var countLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 21, weight: .bold)
        label.adjustsFontSizeToFitWidth = true
        label.textColor = "404147".hexColor
        label.textAlignment = .center
        return label
    }()
    
    private var optionsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .center
        label.textColor = "969696".hexColor
        return label
    }()
    
    private var cleanLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .center
        label.text = "Clean"
        label.textColor = "007AFF".hexColor
        return label
    }()
    
    let disposeBag = DisposeBag()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureLayout() {
        addSubview(cellView)
        cellView.addSubviews(countLabel, optionsLabel, cleanLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        countLabel.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(30)
        }
        
        optionsLabel.snp.makeConstraints { make in
            make.top.equalTo(countLabel.snp.bottom)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(20)
        }
        
        cleanLabel.snp.makeConstraints { make in
            make.top.equalTo(optionsLabel.snp.bottom)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(20)
        }
        
        layoutIfNeeded()
    }
    
    private func configureOptionsModel() {
        guard let cleanOptionModel = cleanOptionModel else { return }
        countLabel.text = cleanOptionModel.count
        optionsLabel.text = cleanOptionModel.option
        configureLayout()
    }
}
