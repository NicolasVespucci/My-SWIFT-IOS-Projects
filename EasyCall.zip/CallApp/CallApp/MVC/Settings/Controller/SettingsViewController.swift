import UIKit
import MessageUI
import AVFoundation
import AVKit
import AVFAudio
import MediaPlayer
import CoreAudio
import IHProgressHUD

class SettingsViewController: UIViewController {
    
    public var menuModel = [ MenuModel(title: "Contacts Backup"),
                             MenuModel(title: "Contacts Cleaner"),
                             MenuModel(title: "Share App With Friends"),
                             MenuModel(title: "Contact Us"),
                             MenuModel(title: "Privacy Policy"),
                             MenuModel(title: "Terms of Use")
    ]
    
    public var soundModel = [ PlaySoundModel(playSoundImage: "play", name: "Bell", checkDeselect: "deselect"),
                              PlaySoundModel(playSoundImage: "play", name: "Bicyclebell", checkDeselect: "deselect"),
                              PlaySoundModel(playSoundImage: "play", name: "Cardboard", checkDeselect: "deselect"),
                              PlaySoundModel(playSoundImage: "play", name: "Cat", checkDeselect: "deselect"),
                              PlaySoundModel(playSoundImage: "play", name: "Dog", checkDeselect: "deselect"),
                              PlaySoundModel(playSoundImage: "play", name: "Duck", checkDeselect: "deselect"),
                              PlaySoundModel(playSoundImage: "play", name: "Error", checkDeselect: "deselect"),
                              PlaySoundModel(playSoundImage: "play", name: "Frog", checkDeselect: "deselect"),
                              PlaySoundModel(playSoundImage: "play", name: "Icepick", checkDeselect: "deselect"),
                              PlaySoundModel(playSoundImage: "play", name: "Key1", checkDeselect: "deselect"),
                              PlaySoundModel(playSoundImage: "play", name: "Key2", checkDeselect: "deselect"),
                              PlaySoundModel(playSoundImage: "play", name: "Key3", checkDeselect: "deselect"),
                              PlaySoundModel(playSoundImage: "play", name: "Key4", checkDeselect: "deselect"),
                              PlaySoundModel(playSoundImage: "play", name: "Key5", checkDeselect: "deselect"),
                              PlaySoundModel(playSoundImage: "play", name: "Pig", checkDeselect: "deselect"),
                              PlaySoundModel(playSoundImage: "play", name: "Pigeon", checkDeselect: "deselect"),
                              PlaySoundModel(playSoundImage: "play", name: "Smallbell", checkDeselect: "deselect"),
                              PlaySoundModel(playSoundImage: "play", name: "Success", checkDeselect: "deselect"),
    ]
    
    private var soundName = ["bell", "bicyclebell", "cardboard", "cat", "dog", "duck", "error", "frog", "icepick", "key1", "key2", "key3", "key4", "key5", "pig", "pigeon", "smallbell", "success"]
    
    private lazy var scrollView: UIScrollView = {
        let view = UIScrollView()
        view.isPagingEnabled = false
        view.isScrollEnabled = true
        view.showsVerticalScrollIndicator = false
        view.backgroundColor = "F5F5F5".hexColor
        view.frame = self.view.bounds
        view.contentSize = CGSize(width: self.view.frame.width, height: 900)
        view.autoresizingMask = .flexibleTopMargin
        view.bounces = true
        return view
    }()
    
    private var settingsLabel: UILabel = {
        let label = UILabel()
        label.text = "Settings"
        label.textColor = "404147".hexColor
        label.font = .systemFont(ofSize: 24, weight: .semibold)
        label.textAlignment = .center
        return label
    }()
    
    private var firstEmptyView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 10
        return view
    }()
    
    private lazy var settingsTableView: UITableView = {
        let table = UITableView()
        table.backgroundColor = .white
        table.rowHeight = 48
        table.showsVerticalScrollIndicator = false
        table.separatorStyle = .singleLine
        table.separatorInset = .init(top: 0, left: 29, bottom: 0, right: 31)
        table.separatorColor = "D7D8DB".hexColor
        table.layer.cornerRadius = 10
        table.isScrollEnabled = false
        return table
    }()
    
    private lazy var soundTableView: UITableView = {
        let table = UITableView()
        table.backgroundColor = .white
        table.rowHeight = 46
        table.showsVerticalScrollIndicator = false
        table.separatorStyle = .none
        table.isScrollEnabled = true
        table.layer.cornerRadius = 10
        return table
    }()
    
    private var keyboardSoundsLabel: UILabel = {
        let label = UILabel()
        label.text = "Keyboard Sounds"
        label.textColor = "404147".hexColor
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.textAlignment = .center
        return label
    }()
    
    private var secondEmptyView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 10
        return view
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup(){
        setupLayout()
        configureTableView()
        configureTableView2()
        soundModel[Constants.ud.currentIndexSound ?? 0].checkDeselect = "select"
    }
    
    private func setupLayout(){
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = .white
        view.addSubview(scrollView)
        scrollView.addSubviews(settingsLabel, firstEmptyView, keyboardSoundsLabel, secondEmptyView)
        firstEmptyView.addSubview(settingsTableView)
        secondEmptyView.addSubviews(soundTableView)
        
        scrollView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.centerX.equalToSuperview()
            make.width.equalTo(UIScreen.main.bounds.width)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-10)
        }
        
        settingsLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(68)
            make.centerX.equalToSuperview()
            make.width.equalTo(UIScreen.main.bounds.width)
            make.height.equalTo(30)
        }
        
        firstEmptyView.snp.makeConstraints { make in
            make.top.equalTo(settingsLabel.snp.bottom).offset(36)
            make.centerX.equalToSuperview()
            make.width.equalTo(UIScreen.main.bounds.width - 30)
            make.height.equalTo(320)
        }
        
        settingsTableView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(15)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview().offset(-15)
        }
        
        keyboardSoundsLabel.snp.makeConstraints { make in
            make.top.equalTo(settingsTableView.snp.bottom).offset(38)
            make.centerX.equalToSuperview()
            make.width.equalTo(UIScreen.main.bounds.width)
            make.height.equalTo(24)
        }
        
        secondEmptyView.snp.makeConstraints { make in
            make.top.equalTo(keyboardSoundsLabel.snp.bottom).offset(12)
            make.centerX.equalToSuperview()
            make.width.equalTo(UIScreen.main.bounds.width - 30)
            make.height.equalTo(290)
            
        }
        
        soundTableView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(30)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview().offset(-30)
        }
    }
    
    private func configureTableView() {
        settingsTableView.delegate = self
        settingsTableView.dataSource = self
        settingsTableView.register(MenuCell.self, forCellReuseIdentifier: MenuCell.nibIdentifier)
    }
    
    private func configureTableView2() {
        soundTableView.delegate = self
        soundTableView.dataSource = self
        soundTableView.register(KeyboardSoundCell.self, forCellReuseIdentifier: KeyboardSoundCell.nibIdentifier)
    }
    
    func pushPoliciesVC(_ policiesType: Policies) {
        let termsVC = TermsAndPrivacy()
        termsVC.policiesType = policiesType
        navigationController?.pushViewController(termsVC, animated: true)
    }
    
    private func contact() {
        if MFMailComposeViewController.canSendMail() {
            let toRecipients = ["appeasycall@gmail.com"]
            let subject = "Feedback"
            let mail = configuredMailComposeViewController(recipients: toRecipients, subject: subject, body: "", isHtml: true, images: nil)
            presentMailComposeViewController(mailComposeViewController: mail)
        } else {
            print("You don't have email in Mail iOS App")
        }
    }
    
    func share() {
        UIGraphicsBeginImageContext(view.frame.size)
        view.layer.render(in: UIGraphicsGetCurrentContext()!)
        
        let textToShare = "Check out my app"
        
        if let myWebsite = URL(string: "http://itunes.apple.com/app/\(Constants.app.appid)") {//Enter link to your app here
            let objectsToShare = [textToShare, myWebsite] as [Any]
            let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            activityVC.excludedActivityTypes = [UIActivity.ActivityType.airDrop, UIActivity.ActivityType.addToReadingList]
            activityVC.popoverPresentationController?.sourceView = self.view
            self.present(activityVC, animated: true, completion: nil)
        }
    }
    
    func stopedAudioSession(){
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            let audioSession:AVAudioSession = AVAudioSession.sharedInstance()
            do {
                try audioSession.setActive(false)
            }
            catch{
                print("#configureAudioSessionToEarSpeaker Error \(error.localizedDescription)")
            }
        }
    }
    
    private func setupSpeaker(nameSound: String?){
        TestManager.shared().configureAudioSessionCategory()
        TestManager.shared().configureAudioSessionToSpeaker()
        MPVolumeView.setVolume(1)
        TestManager.shared().playSound(soundName: nameSound ?? "-1")
        stopedAudioSession()
    }
    
    private func contactsBackUpAction(){
        let vc = BackUpContactsViewController()
        navigationController?.pushViewController(vc, animated: true)
    }
    
    private func contactsCleanerAction(){
        let vc = ContactsCleanerViewController()
        vc.configuratePocenteProgress()
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension SettingsViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == settingsTableView {
            switch menuModel[indexPath.row].title {
            case "Contacts Backup":
                contactsBackUpAction()
            case "Contacts Cleaner":
                contactsCleanerAction()
            case "Share App With Friends":
                share()
            case "Contact Us":
                contact()
            case "Privacy Policy":
                pushPoliciesVC(.privacy)
            case "Terms of Use":
                pushPoliciesVC(.terms)
            default: print("Unknown")
            }
        } else {
            var currentIndexSound = Constants.ud.currentIndexSound
            currentIndexSound = indexPath.row
            Constants.ud.currentIndexSound = indexPath.row
            
            soundModel.enumerated().forEach { indexModel, sound in
                if indexModel == currentIndexSound {
                    soundModel[currentIndexSound ?? 0].playSoundImage = "stop"
                    soundModel[currentIndexSound ?? 0].checkDeselect = "select"
                } else {
                    soundModel[indexModel ?? 0].playSoundImage = "play"
                    soundModel[indexModel ?? 0].checkDeselect = "deselect"
                }
                print("jh")
            }
            
            setupSpeaker(nameSound: soundName[indexPath.row])
            
            soundTableView.reloadData()
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.soundModel[currentIndexSound!].playSoundImage = "play"
                self.soundTableView.reloadData()
            }
        }
    }
}

extension SettingsViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == settingsTableView {
            return menuModel.count
        } else {
            return soundModel.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == settingsTableView {
            let cell = tableView.dequeueReusableCell(withIdentifier: MenuCell.nibIdentifier, for:  indexPath) as! MenuCell
            let menuModelTwo = menuModel[indexPath.row]
            cell.menuModel = menuModelTwo
            
            if menuModel.count == indexPath.row  {
                tableView.separatorColor = .clear
            } else {
                tableView.separatorColor = "D7D8DB".hexColor
            }
            
            return cell
            
        } else {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: KeyboardSoundCell.nibIdentifier, for:  indexPath) as! KeyboardSoundCell
            let soundModel = soundModel[indexPath.row]
            cell.soundModel = soundModel
            return cell
        }
    }
}
