import Foundation

struct MenuModel {
    var title: String?
}
