import Foundation

struct PlaySoundModel {
    var playSoundImage: String?
    var name: String?
    var checkDeselect: String?
}
