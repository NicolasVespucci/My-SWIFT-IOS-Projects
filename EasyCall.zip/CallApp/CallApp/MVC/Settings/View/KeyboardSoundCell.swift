import UIKit

class KeyboardSoundCell: UITableViewCell {
    
    var soundModel: PlaySoundModel? {
        didSet { configureMenu() }
    }
    
    private lazy var fullView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 16
        return view
    }()
    
    private lazy var playOrStopImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    private lazy var checkCurrentSoundPlayImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    private lazy var nameSoundLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .semibold)
        label.textColor = "2F2E33".hexColor
        label.textAlignment = .left
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        backgroundColor = .clear
        setup()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setup() {
        configureLayout()
    }
    
    private func configureLayout() {
        addSubview(fullView)
        fullView.addSubviews(playOrStopImageView, nameSoundLabel, checkCurrentSoundPlayImageView)
        
        fullView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        playOrStopImageView.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(31)
            make.centerY.equalToSuperview()
            make.size.equalTo(31)
        }
        
        nameSoundLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalTo(playOrStopImageView.snp.trailing).offset(21)
            make.height.equalTo(24)
        }
        
        checkCurrentSoundPlayImageView.snp.makeConstraints { make in
            make.trailing.equalToSuperview().offset(-30)
            make.size.equalTo(20)
            make.centerY.equalToSuperview()
        }
    }
    
    private func configureMenu() {
        guard let sound = soundModel else { return }
        playOrStopImageView.image = sound.playSoundImage?.image
        nameSoundLabel.text = sound.name
        checkCurrentSoundPlayImageView.image = sound.checkDeselect?.image
    }
}
