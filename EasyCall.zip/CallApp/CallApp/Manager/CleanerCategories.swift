import Foundation
import UIKit

enum CleanerCategories: CaseIterable {
    case similar, screenshots, livephotos, burstphotos, videos, contacts
    
    var title: String {
        switch self {
        case .similar: return "Similar\nPhotos"
        case .screenshots: return "Screenshots"
        case .livephotos: return "Live\nPhotos"
        case .burstphotos: return "Burst\nPhotos"
        case .videos: return "Videos"
        case .contacts: return "Duplicated\nContacts"
        }
    }
}


