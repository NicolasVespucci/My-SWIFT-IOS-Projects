import Foundation
import UIKit
import Contacts

var UD = UserDefaults.standard

public struct Constants {
    
    static var app = AppConstants()
    static var analytics = AnalyticsConstants()
    static var ud = UDConstants()
    
    struct AnalyticsConstants {
    }
    
    struct AppConstants {
        let appid = "1615593164"
    }
    
    struct UDConstants {
        
        var dataContactsGroup: [Any] {
            set { UD.set(newValue, forKey: "dataContactsGroup") }
            get { return UD.array(forKey: "dataContactsGroup") ?? [] }
        }
        
        var datebackUpContacts: [String] {
            set { UD.set(newValue, forKey: "datebackUpContacts") }
            get { return UD.stringArray(forKey: "datebackUpContacts") ?? [] }
        }
        
        var dataContacts: [Any] {
            set { UD.set(newValue, forKey: "dataContacts") }
            get { return UD.array(forKey: "dataContacts") ?? [] }
        }
        
        var groupNames: [String] {
            set { UD.set(newValue, forKey: "groupNames") }
            get { return UD.stringArray(forKey: "groupNames") ?? [] }
        }
        
        var contactGroupNames: [String] {
            set { UD.set(newValue, forKey: "contactGroupNames") }
            get { return UD.stringArray(forKey: "contactGroupNames") ?? [] }
        }
        
        //MARK: Call History
        
        var historyOfContactsName: [String] {
            set { UD.set(newValue, forKey: "historyOfContactsName") }
            get { return UD.stringArray(forKey: "historyOfContactsName") ?? [] }
        }
        
        var historyOfContactsNumber: [String] {
            set { UD.set(newValue, forKey: "historyOfContactsNumber") }
            get { return UD.stringArray(forKey: "historyOfContactsNumber") ?? [] }
        }
        
        var historyOfContactsDate: [String] {
            set { UD.set(newValue, forKey: "historyOfContactsDate") }
            get { return UD.stringArray(forKey: "historyOfContactsDate") ?? [] }
        }
        
        var identifierOfContactInContacts: [String] {
            set { UD.set(newValue, forKey: "identifierOfContactInContacts") }
            get { return UD.stringArray(forKey: "identifierOfContactInContacts") ?? [] }
        }
        
        var currentCallContactOrNoName: Int? {
            set { UD.set(newValue, forKey: "currentCallContactOrNoName") }
            get { return UD.integer(forKey: "currentCallContactOrNoName") }
        }
        
        var cellCallName: String? {
            set { UD.set(newValue, forKey: "cellCallName") }
            get { return UD.string(forKey: "cellCallName") }
        }
        
        var cellCallNumber: String? {
            set { UD.set(newValue, forKey: "cellCallNumber") }
            get { return UD.string(forKey: "cellCallNumber") }
        }
        
        //MARK: Saved and Checking All Contacts in iPhone
        
        var savedAndCheckContacts: Data? {
            set { UD.set(newValue, forKey: "savedAndCheckContacts") }
            get { return UD.data(forKey: "savedAndCheckContacts") }
        }
        
        var firstStartApp: Bool {
            set { UD.set(newValue, forKey: "firstStartApp") }
            get { return UD.bool(forKey: "firstStartApp") }
        }
        
        var favoriteContacts: Data? {
            set { UD.set(newValue, forKey: "favoriteContacts") }
            get { return UD.data(forKey: "favoriteContacts") }
        }
        
        var currentCountOfRepeatName: Int? {
            set { UD.set(newValue, forKey: "currentCountOfRepeatName") }
            get { return UD.integer(forKey: "currentCountOfRepeatName") }
        }
        
        var currentCountOfRepeatNumber: Int? {
            set { UD.set(newValue, forKey: "currentCountOfRepeatNumber") }
            get { return UD.integer(forKey: "currentCountOfRepeatNumber") }
        }
        
        var didAcceptPrivacy: Bool {
            get { return UD.bool(forKey: UserDefaults.Keys.didAcceptPrivacy) }
            set { UD.set(newValue, forKey: UserDefaults.Keys.didAcceptPrivacy) }
        }
        
        var isPurchased : Bool {
            get { return UD.bool(forKey: UserDefaults.Keys.isPurchased) }
            set { UD.set(newValue, forKey: UserDefaults.Keys.isPurchased) }
        }
        
        // Idex current sound play
        
        var currentIndexSound: Int? {
            set { UD.set(newValue, forKey: "currentIndexSound") }
            get { return UD.integer(forKey: "currentIndexSound") }
        }
    }
    
    static var country: String = {
        let locale: NSLocale = NSLocale(localeIdentifier: "en_US")
        if let countryCode = locale.object(forKey: NSLocale.Key.countryCode) as? String,
           let country = locale.displayName(forKey: NSLocale.Key.countryCode, value: countryCode) {
            print(country)
            return country
        }
        return "unsigned"
    }()
}

