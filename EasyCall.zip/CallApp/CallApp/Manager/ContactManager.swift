import Foundation
import SwiftyContacts
import Contacts
import MessageUI
import RxSwift
import ContactsUI
import RxCocoa
import IHProgressHUD

class ContactManager {
    
    // MARK: Properties
    private static let sharedContactManager = ContactManager()
    
    static func shared() -> ContactManager {
        return sharedContactManager
    }
    
    //MARK: Complitions
    var complitionOne: (()->())?
    var complitionTwo: (()->())?
    
    //MARK: Contactas Properties
    var allContacts = [ContactsModel]()
    var sortedContacts = [ContactsModel]()
    var allContactsCN = [CNContact]()
    var copyAllContactsCN = [CNContact]()
    
    //MARK: Clean Properties
    var repeatNumberCN = [CNContact]()
    var repeatNameCN = [CNContact]()
    var noNumberCN = [CNContact]()
    var noNamesCN = [CNContact]()
    
    let duplicatesListNames: BehaviorRelay<Array<[CNMutableContact]>> = .init(value: [])
    let duplicatesListPhoneNumber: BehaviorRelay<Array<[CNMutableContact]>> = .init(value: [])
    
    var comlition: (()->())?
    
    //MARK: Fetch contacts
    
    func fetchContact(){
        let store = CNContactStore()
        store.requestAccess(for: .contacts) { acces, error in
            if let error = error {
                print("Error------>", error)
                return
            }
            
            if acces {
                print("Acces granted")
                let key = [CNContactGivenNameKey, CNContactFamilyNameKey, CNContactPhoneNumbersKey, CNContactImageDataAvailableKey, CNContactThumbnailImageDataKey]
                let request = CNContactFetchRequest(keysToFetch: key as [CNKeyDescriptor])
                do {
                    try store.enumerateContacts(with: request, usingBlock: { (contact, stopEnumerating) in
                        
                        let fullName = contact.givenName + " " +  contact.familyName
                        let number = contact.phoneNumbers.first?.value.stringValue ?? ""
                        let identy = contact.identifier
                        
                        if let imageData = contact.thumbnailImageData {
                            let imageString = String(describing: UIImage(data: imageData))
                            let stringImage = String(decoding: imageData, as: UTF8.self)
                            self.allContacts.append(ContactsModel(name: fullName, phoneNumber: number, dataImage: imageData, checkSelected: false, selectedNonSelectedImage: "nonSelectedCell", identifier: identy))
                        } else {
                            var notImage = "contactImage"
                            self.allContacts.append(ContactsModel(name: fullName, phoneNumber: number, image: notImage, checkSelected: false, selectedNonSelectedImage: "nonSelectedCell", identifier: identy))
                        }
                        self.allContactsCN.append(contact)
                        self.copyAllContactsCN.append(contact)
                    })
                } catch let error {
                    print("Error enumerated contacts:", error)
                }
                
                self.sortedContacts = self.allContacts.sorted { (($0.name) ?? "√").compare(($1.name) ?? "√", options: .numeric) == .orderedAscending }
                self.comlition?()
            } else {
                print("Acces denied...")
            }
        }
    }
    
    //MARK: Checking Access for Contacts
    
    func requestAccess(completionHandler: @escaping (_ accessGranted: Bool) -> Void) {
        let store = CNContactStore()
        switch CNContactStore.authorizationStatus(for: .contacts) {
        case .authorized:
            completionHandler(true)
            self.fetchContact()
            self.noName()
            self.noNumber()
            self.savedAllContactsForChecking()
        case .denied:
            print("denied")
        case .restricted, .notDetermined:
            store.requestAccess(for: .contacts) { granted, error in
                if granted {
                    completionHandler(true)
                    self.fetchContact()
                    self.noName()
                    self.noNumber()
                    self.savedAllContactsForChecking()
                }
            }
        }
    }
    
    //MARK: Clean Categories
    
    //Repeat name and Phone Number
    func configurateDuplicateNameAndPhoneNumberForKnowCountDuplicate () {
        
        LibraryMediaManager.shared.getDuplicateContacts(type: .name) { [weak self] result in
            DispatchQueue.main.async {
                self?.resultHandler(result)
            }
        }
        
        LibraryMediaManager.shared.getDuplicateContacts(type: .phone) { [weak self] result in
            DispatchQueue.main.async { [weak self] in
                self?.resultHandler2(result)
            }
        }
    }
    
    
    //No number
    
    func noNumber(){
        allContactsCN.forEach { ContactOne in
            let number = ContactOne.phoneNumbers.first?.value.stringValue ?? ""
            
            if number == "" {
                noNumberCN.append(ContactOne)
            }
        }
        //print("No Numbers -------->>>>>>",noNumberCN.count)
    }
    
    //No name
    func noName(){
        allContactsCN.forEach { ContactOne in
            let fullName = ContactOne.givenName + " " + ContactOne.familyName
            
            if fullName == " " {
                noNamesCN.append(ContactOne)
            }
        }
        // print("No Name -------->>>>>>",noNamesCN.count)
    }
    
    func cleanAndUpdateContacts(){
        ContactManager.shared().noNamesCN.removeAll()
        ContactManager.shared().noNumberCN.removeAll()
        ContactManager.shared().allContactsCN.removeAll()
        ContactManager.shared().copyAllContactsCN.removeAll()
        ContactManager.shared().sortedContacts.removeAll()
        ContactManager.shared().fetchContact()
        ContactManager.shared().noName()
        ContactManager.shared().noNumber()
    }
    
    
    func savedAllContactsForChecking() {
        
        var firstStart = Constants.ud.firstStartApp
        
        var contactsOld = [CNContact]()
        
        var newCN = [CNContact]()
        
        if firstStart == true {
            //Next Starts
            var data = Constants.ud.savedAndCheckContacts
            if (data.isNil) {
            } else {
                let transformationIntoContacts = NSKeyedUnarchiver.unarchiveObject(with: data!) as? [CNContact]
                contactsOld = transformationIntoContacts ?? [CNContact]()
            }
            
            print("Cout OLD----->", contactsOld.count)
            
            allContactsCN.forEach({ one in
                
                let numberOne = one.phoneNumbers.first?.value.stringValue ?? ""
                
                let ifFoundCount = (contactsOld.filter({ ($0.phoneNumbers.first?.value.stringValue ?? "") == numberOne})).count
                
                if ifFoundCount == 0 {
                    newCN.append(one)
                }
            })
            
            print("Cout new----->", newCN.count)
            
            for new in newCN {
                contactsOld.append(new)
            }
            
            let newData = NSKeyedArchiver.archivedData(withRootObject: contactsOld)
            
            Constants.ud.savedAndCheckContacts = newData
            
        } else {
            //First Start
            Constants.ud.firstStartApp = true
            
            let currentContacts = allContactsCN
            
            let dataBlob = NSKeyedArchiver.archivedData(withRootObject: currentContacts)
            
            Constants.ud.savedAndCheckContacts = dataBlob
            
            var data = Constants.ud.savedAndCheckContacts
            
            let transformationIntoContacts = NSKeyedUnarchiver.unarchiveObject(with: data!) as? [CNContact]
            
            contactsOld = transformationIntoContacts ?? [CNContact]()
            
            print("Cout OLD----->", contactsOld.count)
        }
    }
    
    //MARK: Configurate Duplicate Contacts Names and Phone number
    
    private func resultHandler(_ result: Result<Array<[CNMutableContact]>, Error>) {
        switch result {
        case .success(let contactListt):
            duplicatesListNames.accept(contactListt)
            Constants.ud.currentCountOfRepeatName = duplicatesListNames.value.count
        case .failure(let error):
            print(error)
        }
    }
    
    private func resultHandler2(_ result: Result<Array<[CNMutableContact]>, Error>) {
        switch result {
        case .success(let contactListt):
            duplicatesListPhoneNumber.accept(contactListt)
            Constants.ud.currentCountOfRepeatNumber = duplicatesListPhoneNumber.value.count
            complitionOne!()
        case .failure(let error):
            print(error)
            complitionOne!()
        }
    }
}

//MARK: Reload ViewController
extension UIViewController {
    func removeChild(){
        self.children.forEach {
            $0.willMove(toParent: nil)
            $0.view.removeFromSuperview()
            $0.removeFromParent()
        }
    }
}
