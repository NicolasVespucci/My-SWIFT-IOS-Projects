import Foundation
import UIKit
import Photos
import Contacts
import CocoaImageHashing
import SwiftyContacts
import RxSwift
import RxCocoa

struct Contact {
    var name: String?
    var phoneNumbers: [String?]
    var emails: [String?]
    var contactImage: UIImage?
    
    init(_ title: String?, _ image: UIImage?, _ mails: [String?], _ number: [String?]) {
        name = title
        contactImage = image
        phoneNumbers = number
        emails = mails
    }
}

typealias ItemToDelete = (asset: PHAsset?, indexPath: IndexPath)

final class LibraryMediaManager {
    
    private static let bcf = ByteCountFormatter()
    
    internal typealias SimilarObject = (asset: PHAsset?, originalID: Int)
    
    static var shared = LibraryMediaManager()
    
    internal var fetchResult: PHFetchResult<PHAsset>!
    internal var previousPreheatRect: CGRect = .zero
    internal var imageManager: PHCachingImageManager?
    
    private var fetchedCNContacts: [CNContact] = []
    public var fetchedContacts: [Contact] = []
    
    public var itemsToDelete: BehaviorRelay<[ItemToDelete]> = .init(value: [])
    private(set) var countedSize: BehaviorRelay<(Double, Bool)> = .init(value: (0.0, false))
    
    public var similars: [[SimilarObject]] = [[]]
    
    public var cleanerSimilars: [[SimilarObject]] = [[]]
    
    public var allSimilarAssets: [PHAsset] = []
    public var allScreenshotAssets: [PHAsset] = []
    public var allPhotoLiveAssets: [PHAsset] = []
    public var allBurstPhotoAssets: [PHAsset] = []
    public var allVideoAssets: [PHAsset] = []
    
    internal var fetchedAssets: [PHAsset] = []
    
    public var toDeleteCount: String {
        return "Delete \(itemsToDelete.value.count)"
    }
    
    private let bag = DisposeBag()
    
    public var toDeleteCounter: BehaviorRelay<String>! = .init(value: "")
    private init() {
        itemsToDelete
            .asObservable()
            .compactMap {
                return NSLocalizedString("Delete", comment: "") + "(\($0.count))"
            }
            .bind(to: toDeleteCounter)
            .disposed(by: bag)
    }
    
    func fetchPhotos(with predicate: NSPredicate, _ completion: (() -> Void)? = nil) {
        let fetchOptions = PHFetchOptions()
        fetchOptions.predicate = predicate
        
        fetchResult = PHAsset.fetchAssets(with: .image, options: fetchOptions)
        completion?()
    }
    
    
    
    
    func initialize(_ completion: (()-> Void)? = nil){
        imageManager = PHCachingImageManager()
        resetCachedAssets()
        //    completion?()
    }
    
    func resetCachedAssets(){
        imageManager?.stopCachingImagesForAllAssets()
        previousPreheatRect = .zero
    }
    
    public func appendToExistingAssets() {
        fetchedAssets.append(contentsOf: (0..<fetchResult.count)
            .compactMap { return fetchResult[$0] })
    }
    
}

//MARK:- Remove phassests from fetched assets
extension LibraryMediaManager {
    enum RemoveResult {
        case error(Error?)
        case success(Bool, [[SimilarObject]]?)
    }
    
    public func removeAssets(selectedOption: Bool, cleanerAssets: [[SimilarObject]]? = nil, _ selectedAssets: [PHAsset] ,_ completion: ((RemoveResult) -> Void)? = nil) {
        var newSimilarObjects = [SimilarObject]()
        var newCleanerAssets = cleanerAssets
        PHPhotoLibrary.shared().performChanges({
            PHAssetChangeRequest.deleteAssets(selectedAssets as NSArray)
            
            print("HEYEHY")
        }) { (success, error) in
            if let e = error {
                completion?(.error(e))
                return
            }
            
            if !selectedOption {
                selectedAssets.forEach { asset in
                    self.similars.enumerated().forEach({ (index, similarObjects) in
                        similarObjects.enumerated().forEach { (similarIndex, element) in
                            if asset != element.asset {
                                newSimilarObjects.append(element)
                            }
                            if similarIndex == similarObjects.count - 1 {
                                self.similars[index] = newSimilarObjects
                                newSimilarObjects.removeAll()
                            }
                        }
                    })
                }
                completion?(.success(success, nil))
            } else {
                selectedAssets.forEach { asset in
                    newCleanerAssets?.enumerated().forEach({ (index, similarObjects) in
                        similarObjects.enumerated().forEach { (similarIndex, element) in
                            if asset != element.asset {
                                newSimilarObjects.append(element)
                            }
                            if similarIndex == similarObjects.count - 1 {
                                newCleanerAssets?[index] = newSimilarObjects
                                newSimilarObjects.removeAll()
                            }
                        }
                    })
                }
                completion?(.success(success, newCleanerAssets))
            }
        }
    }
}


//MARK: - Contacts.
extension LibraryMediaManager {
    public func searchDuplicates(_ key: CNKeyDescriptor) {
        guard fetchedContacts.count != 0 else {
            return
        }
    }
    
    func ssss() {
        requestAccess { granted in
            if granted {
                fetch()
            } else {
                self.showPermissionAlert()
            }
        }
        
        func fetch() {
            fetchContacts { [weak self] res in
                switch res {
                case .Success(response: let contacts):
                    self?.fetchedCNContacts = contacts
                    self?.fetchedContacts = contacts.map { c -> Contact in
                        let name = "\(c.givenName) \(c.familyName)"
                        var image: UIImage?
                        if let imageData = c.imageData {
                            image = UIImage(data: imageData)
                        }
                        let cc = Contact(name, image, c.emailAddresses.compactMap {
                            return $0.value as String
                        }, c.phoneNumbers.compactMap {
                            return $0.value.stringValue
                        })
                        return cc
                    }
                    
                case .Error(error: let error):
                    print(error.localizedDescription)
                }
            }
        }
    }
    
    func fetchVideos(_ completion: (() -> Void)? = nil) {
        let library = PHAsset.fetchAssets(with: .video, options: PHFetchOptions())
        fetchResult = library
        similars = [(0..<library.count).map { index -> SimilarObject in
            return (library[index], index)
        }]
        
        allVideoAssets.removeAll()
        
        similars.forEach({ similarObject in
            similarObject.forEach { tuple in
                allVideoAssets.append(tuple.0 ?? PHAsset())
            }
        })
        
        
        completion?()
    }
    
    
    func removeSelectedContact(contact index: Int) {
        guard let contact = fetchedCNContacts[index].mutableCopy() as? CNMutableContact else { return }
        deleteContact(Contact: contact) { res in
            switch res {
            case .Success(response: let bool):
                if bool{
                    print("Contact Sucessfully Deleted")
                }
            case .Error(error: let error):
                print(error.localizedDescription)
            }
        }
    }
    
    private func showPermissionAlert() {
        let alert = UIAlertController(title: "Ooops..", message: "It looks like you don't have permission to access photos and videos", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Settings", style: .default, handler: { _ in
            guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else { return }
            if UIApplication.shared.canOpenURL(settingsUrl) {
                UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                    print("Settings opened: \(success)")
                })
            }
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        if let vc = UIApplication.shared.keyWindow?.rootViewController {
            vc.present(alert, animated: true)
        }
    }
}


//MARK: - Image sizes
extension LibraryMediaManager {
    public func requestForSize() {
        //      var totalCount: Double = 0.0
        //
        //      let allSimilars = similars.joined().compactMap {
        //        return $0.asset
        //      }
        //        if !allSimilars.isEmpty {
        //            allSimilars.enumerated().forEach { index, asset in
        //                self.imageManager?.requestImageDataAndOrientation(for: asset, options: nil, resultHandler: { [weak self] d, s, _, _ in
        //                    guard let self = self, let data = d else { return }
        //                    let bcf = ByteCountFormatter()
        //                    bcf.allowedUnits = [.useMB] // optional: restricts the units to MB only
        //                    bcf.countStyle = .file
        //                    let string = bcf.string(fromByteCount: Int64(data.count))
        //                      guard let count = Double(string.replacingOccurrences(of: " MB", with: "").replacingOccurrences(of: ",", with: ".")) else { return }
        //                    totalCount += count
        //                    self.countedSize.accept((totalCount/1024, index == allSimilars.count - 1))
        //                })
        //            }
        //        } else {
        //            self.countedSize.accept((-1, true))
        //        }
        
        
        let t = Array(similars.enumerated().compactMap { (offset, elements)  in
            return elements.enumerated().compactMap { (off, element) in
                return ItemToDelete(element.asset, IndexPath(item: off, section: offset))
            }.dropFirst()
        }.joined())
        itemsToDelete.accept(t)
    }
    
    func getSize(assets: [PHAsset]) -> String {
        var sizeOnDisk: Int64 = 0
        var totalCount: Double = 0.0
        
        if !assets.isEmpty {
            assets.enumerated().forEach { (index, asset) in
                let resources = PHAssetResource.assetResources(for: asset)
                
                guard let resource = resources.first,
                      let unsignedInt64 = resource.value(forKey: "fileSize") as? CLong else {
                    return
                }
                
                sizeOnDisk += Int64(bitPattern: UInt64(unsignedInt64))
                let sizeOnDiskMB = sizeOnDisk/Int64(1024.0)/Int64(1024.0)
                Self.bcf.allowedUnits = [sizeOnDiskMB < Int64(1024.0) ? .useMB : .useGB]
                Self.bcf.countStyle = .file
                totalCount += Double(sizeOnDiskMB)
                self.countedSize.accept((totalCount, index == assets.count - 1))
            }
        } else {
            self.countedSize.accept((-1.0, true))
        }
        
        //        let t = Array(assets.enumerated().compactMap { (offset, elements)  in
        //          return elements.enumerated().compactMap { (off, element) in
        //            return ItemToDelete(element.asset, IndexPath(item: off, section: offset))
        //          }.dropFirst()
        //        }.joined())
        
        
        return Self.bcf.string(fromByteCount: sizeOnDisk)
    }
    
    func getSize(asset: PHAsset) -> String {
        let resources = PHAssetResource.assetResources(for: asset)
        
        guard let resource = resources.first,
              let unsignedInt64 = resource.value(forKey: "fileSize") as? CLong else {
            return "Unknown"
        }
        
        let sizeOnDisk = Int64(bitPattern: UInt64(unsignedInt64))
        Self.bcf.allowedUnits = [.useMB]
        Self.bcf.countStyle = .file
        return Self.bcf.string(fromByteCount: sizeOnDisk)
    }
}

extension PHAsset {
    var thumbnailSync: UIImage? {
        var result: UIImage?
        let scale = UIScreen.main.scale
        let targetSize = CGSize(width: 100, height: 100)
        let options = PHImageRequestOptions()
        options.deliveryMode = .highQualityFormat
        options.resizeMode = .exact
        options.isSynchronous = true
        options.isNetworkAccessAllowed = true  // having the thumbnail isn't optional
        PHImageManager.default().requestImage(for: self, targetSize: targetSize, contentMode: .aspectFit, options: options) { (image, info) in
            result = image
        }
        defer {
            result = nil
        }
        return result
    }
}

// Contacts
extension LibraryMediaManager {
    enum DuplicateType {
        case name, phone, email
    }
    
    func getContacts(completion: @escaping (Result<Array<[CNMutableContact]>, Error>) -> Void) {
        authorizationStatus { [weak self] status in
            switch status {
            case .authorized:
                self?.fetchContactList(completion: completion)
            default:
                requestAccess { granted in
                    if granted { self?.fetchContactList(completion: completion); return }
                    completion(.failure(NSError(domain: "No access to contacts", code: -1, userInfo: nil)))
                }
            }
        }
    }
    
    func getDuplicateContacts(type: DuplicateType = .phone, completion: @escaping (Result<Array<[CNMutableContact]>, Error>) -> Void) {
        DispatchQueue.main.async { [weak self] in
            authorizationStatus { [weak self] status in
                switch status {
                case .authorized:
                    self?.fetchContactList(type: type, completion: completion)
                default:
                    requestAccess { granted in
                        if granted { self?.fetchContactList(type: type, completion: completion); return }
                        print("HHH")
                        completion(.failure(NSError(domain: "No access to contacts", code: -1, userInfo: nil)))
                        DispatchQueue.main.async {
                            self!.showContactPermissionAlert()
                        }
                    }
                }
            }
        }
    }
    //Alert changing the resolution
    private func showContactPermissionAlert() {
        let alert = UIAlertController(title: "Ooops..", message: "It looks like you don't have permissions to access your contacts.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Settings", style: .default, handler: { _ in
            guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else { return }
            if UIApplication.shared.canOpenURL(settingsUrl) {
                UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                    print("Settings opened: \(success)")
                })
            }
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        if let vc = UIApplication.shared.keyWindow?.rootViewController {
            vc.present(alert, animated: true)
        }
    }
    
    func merge(contactList: Array<[CNContact]>, into contact: CNContact? = nil) {
        // Merge into provided contact
        if let providedContact = contact {
            contactList.forEach { duplicates in
                print(LibraryMediaManager.shared.privateMerge(duplicates: duplicates, into: providedContact))
            }
            return
        }
        contactList.forEach { duplicates in
            print(LibraryMediaManager.shared.privateMerge(duplicates: duplicates))
        }
    }
    
    func simpleMerge(duplicates: [CNContact], into contact: CNContact? = nil) -> CNMutableContact {
        if let providedContact = contact {
            return LibraryMediaManager.shared.privateMerge(duplicates: duplicates, into: providedContact)
        }
        return LibraryMediaManager.shared.privateMerge(duplicates: duplicates)
    }
    
    private func fetchContactList(type: DuplicateType = .phone, completion: @escaping (Result<Array<[CNMutableContact]>, Error>) -> Void) {
        fetchContacts { [weak self] result in
            switch result {
            case .Success(response: let contacts):
                let mutableContacts = contacts.map({$0.mutableCopy() as! CNMutableContact})
                self?.findDuplicates(contacts: mutableContacts, type: type) { duplicateList in
                    completion(.success(duplicateList))
                }
                break;
            case .Error(error: let error):
                completion(.failure(error))
            }
        }
    }
    
    func fetchContactss(completion: @escaping ([CNContact]) -> Void) {
        fetchContacts { [weak self] result in
            switch result {
            case .Success(response: let contacts):
                completion(contacts)
                break;
            case .Error(error: let error):
                completion([])
            }
        }
    }
    
    
    private func privateMerge(duplicates: [CNContact], into contact: CNContact? = nil) -> CNMutableContact {
        var givenName: [String] = []
        var familyName: [String] = []
        var organizationName: [String] = []
        
        var phoneNumbers: [CNLabeledValue<CNPhoneNumber>] = []
        var emailAddresses: [CNLabeledValue<NSString>] = []
        var postalAddresses: [CNLabeledValue<CNPostalAddress>] = []
        var urlAddresses: [CNLabeledValue<NSString>] = []
        
        // COLLECT VALUES
        for contact in duplicates {
            givenName.append(contact.givenName)
            familyName.append(contact.familyName)
            organizationName.append(contact.organizationName)
            
            contact.phoneNumbers.forEach {
                if !phoneNumbers.map({$0.value.stringValue}).contains($0.value.stringValue) {
                    phoneNumbers.append($0)
                }
            }
            contact.emailAddresses.forEach { emailAddresses.append($0) }
            contact.postalAddresses.forEach { postalAddresses.append($0) }
            contact.urlAddresses.forEach { urlAddresses.append($0) }
        }
        
        // MERGE TO NEW CONTACT
        let newContact = (contact?.mutableCopy() as? CNMutableContact) ?? CNMutableContact()
        newContact.givenName = givenName.first ?? ""
        newContact.familyName = familyName.first ?? ""
        newContact.organizationName = organizationName.first ?? ""
        
        newContact.phoneNumbers = phoneNumbers
        newContact.emailAddresses = emailAddresses
        newContact.postalAddresses = postalAddresses
        newContact.urlAddresses = urlAddresses
        
        return newContact
    }
    
    func findDuplicates(contacts : [CNMutableContact], type: DuplicateType = .phone, completionHandler : @escaping (_ result : [Array<CNMutableContact>]) -> ()){
        let searchers: [String] = Array(contacts.compactMap { contact -> [String]? in
            switch type {
            case .phone:
                return contact.phoneNumbers.compactMap({$0.value.stringValue.phoneFormatted})
            case .name:
                //                if let name = CNContactFormatter.string(from: contact, style: .fullName) {
                //                    return [name]
                //                }
                
                let fullName = contact.givenName + " " +  contact.familyName
                if fullName != nil {
                    return [fullName]
                } else {
                    return []
                }
            case .email:
                return []
                //  return contact.emailAddresses.compactMap({$0.value as String})
            }
        }.joined()).withoutDuplicates
        
        var contactGroupedByDuplicated = [Array<CNMutableContact>]()
        var contactGroupedByUnique = [Array<CNMutableContact>]()
        DispatchQueue.main.async {
            searchers.forEach { search in
                var group: [CNMutableContact] = []
                switch type {
                case .phone:
                    group = contacts.filter { $0.phoneNumbers.compactMap({$0.value.stringValue.phoneFormatted}).contains(search) }
                case .name:
                    print("")
                    //group = contacts.filter { CNContactFormatter.string(from: $0, style: .fullName) == search }
                    group = contacts.filter { ($0.givenName + " " +  $0.familyName) == search }
                case .email:
                    
                    print("")
                    //group = contacts.filter { $0.emailAddresses.compactMap({$0.value as String}).contains(search) }
                }
                contactGroupedByUnique.append(group)
            }
            contactGroupedByUnique.forEach { contactList in
                if contactList.count > 1 { contactGroupedByDuplicated.append(contactList) }
            }
            completionHandler(contactGroupedByDuplicated)
        }
        
    }
}

extension Array where Element: Hashable {
    var withoutDuplicates: Array {
        var buffer = Array()
        var added = Set<Element>()
        for elem in self {
            if !added.contains(elem) {
                buffer.append(elem)
                added.insert(elem)
            }
        }
        return buffer
    }
}

extension Array where Element == String {
    
    var bestElement: String? {
        var options: [String : Int] = [:]
        
        for element in self {
            if let result = options[element] {
                options[element] = result + 1
            } else {
                options[element] = 1
            }
        }
        
        return options.sorted { $0.1 > $1.1 }.first?.key
    }
}

extension String {
    var phoneFormatted: String {
        return self
            .replacingOccurrences(of: "(", with: "")
            .replacingOccurrences(of: ")", with: "")
            .replacingOccurrences(of: " ", with: "")
    }
}

