   import UIKit
   
   extension CALayer {
    func addGradienBorder(colors: UIColor..., width: CGFloat = 1, cornerRadius: CGFloat) {
      let gradientLayer = CAGradientLayer()
      gradientLayer.frame =  CGRect(origin: .zero, size: self.bounds.size)
      gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
      gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
      gradientLayer.colors = colors.map({$0.cgColor})
      gradientLayer.cornerRadius = cornerRadius
      
      let shapeLayer = CAShapeLayer()
      shapeLayer.lineWidth = width
      shapeLayer.cornerRadius = cornerRadius
      shapeLayer.path = UIBezierPath(roundedRect: self.bounds, cornerRadius: cornerRadius).cgPath
      shapeLayer.fillColor = nil
      shapeLayer.strokeColor = UIColor.black.cgColor
      gradientLayer.mask = shapeLayer
      
      self.addSublayer(gradientLayer)
    }
    
   }
