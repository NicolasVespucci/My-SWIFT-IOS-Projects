

import Foundation

extension UserDefaults {
  enum Keys {
    static let userID = "userID"
    static let isPurchased = "isPurchased"
    static let purchasePath = "purchasePath"
    static let trackingURL = "trackingURL"
    static let shownUrus = "shownUrus"
    static let notifications = "notifications"
    static let isComingFromNotifications = "isComingFromNotifications"
    static let urusID = "urusID"
    static let whitePartners = "whitePartners"
    static let urusPartners = "urusPartners"
    static let blockedDomains = "blockedDomains"
    static let fbInstallSend = "fbInstallSend"
    static let trafficSource = "traffic_source"
    static let campaignName = "capmaign_name"
    static let siteID = "site_id"
    static let campaignID = "campaign_id"
    static let clickID = "click_id"
    static let deepLink = "deeplink"
    static let didAcceptPrivacy = "didAcceptPrivacy"
  }
}
