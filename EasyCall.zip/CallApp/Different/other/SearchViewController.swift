
import UIKit
import MessageUI

class SearchViewController: UIViewController, MFMessageComposeViewControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        sendMessage()
        // Do any additional setup after loading the view.
    }
    
    //MARK: Phone Called
    private func phoneCalled(){
        guard let number = URL(string: "tel://" + "+37368018609" ) else { return }
        
        UIApplication.shared.open(number)
    }
    
  //  MARK: Whatsapp
    private func whatsapp() {
        let myMessageWantToSendViaWhatsapp = "Hello:Technicalisto" // Note Message must to be without space
        
        let url  = NSURL(string: "whatsapp://send?phone=" + "\(self.whatsapp)" + "&text=" + "\(myMessageWantToSendViaWhatsapp)")
        
        if UIApplication.shared.canOpenURL(url! as URL) {
            // Open Whatsapp
            UIApplication.shared.open(url! as URL, options: [:]){ (success) in
                
                if success {
                    print("WhatsApp accessed successfully")
                } else {
                    print("Error accessing WhatsApp")
                }
            }
        }
        
        UIApplication.shared.open(url! as URL, options: [:]){ (success) in
            
            if success {
                print("WhatsApp accessed successfully")
            } else {
                print("Error accessing WhatsApp")
            }
        }
    }
    
    
    private func viber(){

        let appURL = NSURL(string: "viber://")!

            if #available(iOS 10.0, *) {
                UIApplication.shared.open(appURL as URL, options: [:], completionHandler: nil)
            } else {
                UIApplication.shared.openURL(appURL as URL)
            }
        
    }

    //MARK: Telegram
    private func telegram() {
        let screenName = "" 
        let appURL = NSURL(string: "tg://")!
        
        let webURL = NSURL(string: "https://t.me/\(screenName)")!
        
        if UIApplication.shared.canOpenURL(appURL as URL) {
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(appURL as URL, options: [:], completionHandler: nil)
            } else {
                UIApplication.shared.openURL(appURL as URL)
            }
        } else {
            //redirect to safari because user doesn't have Telegram
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(appURL as URL, options: [:], completionHandler: nil)
            } else {
                UIApplication.shared.openURL(appURL as URL)
            }
        }
    }

    //MARK: Twitter
    private func twitter() {
        guard let url = URL(string: "https://twitter.com/") else { return }

        UIApplication.shared.open(url)
    }
    
    //MARK: Send Message 

    private func sendMessage(){
        guard MFMessageComposeViewController.canSendText() else {
            print("Device is not capable to send message")
            return
        }
        
        let composer = MFMessageComposeViewController()
        composer.messageComposeDelegate = self
        composer.recipients = ["007"]
        composer.subject = "Hello Agent"
        present(composer, animated: true)
        
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        switch result {
        case .cancelled:
            print("cancelled")
        case .sent:
            print("sent")
        case .failed:
            print("failed")
        default:
            print("UNKOWN")
        }
    }
}
