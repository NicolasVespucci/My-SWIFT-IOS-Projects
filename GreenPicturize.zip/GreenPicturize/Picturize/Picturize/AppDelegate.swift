import UIKit
import SwiftyStoreKit
var showCurrentController = false

//@available(iOS 15.0, *)
@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
  
  func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
      SwiftyStoreKit.completeTransactions(atomically: true) { purchases in
          for purchase in purchases {
              switch purchase.transaction.transactionState {
              case .purchased, .restored:
                  if purchase.needsFinishTransaction {
                      // Deliver content from server, then:
                      SwiftyStoreKit.finishTransaction(purchase.transaction)
                  }
                  Constants.ud.isPurchased = true
              case .failed, .purchasing, .deferred:
                  Constants.ud.isPurchased = false
                  break // do nothing
              @unknown default: break
              }
          }
      }
      setMainVC()
    return true
  }
      
      func applicationWillTerminate(_ application: UIApplication) {
          UserDefaults.standard.synchronize()
      }
}

//@available(iOS 15.0, *)
extension AppDelegate {
        private func setMainVC() {
            window = UIWindow()
            let controller = LaunchVC()
            let navigationController = UINavigationController(rootViewController: controller)
            window?.rootViewController = navigationController
            self.window?.makeKeyAndVisible()
        }
    }
