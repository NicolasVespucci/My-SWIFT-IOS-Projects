import UIKit

class FirstShoppingCell: UITableViewCell {

    var FirstShoppingCellModel: AdvantagesModel? {
        didSet { configurePayFirstModel() }
    }
    
    private lazy var cellView: UIView = {
        let view = UIView()
        view.layer.masksToBounds = true
        return view
    }()
    
    private lazy var settingsImageView: UIImageView = {
        let imageView = UIImageView(image: "".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private lazy var firstLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .bold)
        label.adjustsFontSizeToFitWidth = true
        label.textColor = "1F1F1F".hexColor
        label.textAlignment = .left
        return label
    }()
    
    private var secondLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 13, weight: .semibold)
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textColor = "979797".hexColor
        label.textAlignment = .left
        return label
    }()
    

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        selectionStyle = .none
        configureLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureLayout() {
        addSubview(cellView)
        cellView.addSubviews(settingsImageView, firstLabel, secondLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(65)
        }
        
        settingsImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(20.resized())
            make.size.equalTo(30)
        }
        
        firstLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(10)
            make.leading.equalTo(settingsImageView.snp.trailing).offset(11.resized())
            make.height.equalTo(22)
        }
        
        secondLabel.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-10)
            make.height.equalTo(22)
            make.leading.equalTo(settingsImageView.snp.trailing).offset(11.resized())
            make.trailing.equalToSuperview().offset(-20.resized())
        }
        
    }
    
    private func configurePayFirstModel() {
        guard let advantagesModel = FirstShoppingCellModel else { return }
        settingsImageView.image = advantagesModel.image?.image
        firstLabel.text = advantagesModel.first
        secondLabel.text = advantagesModel.second
    }

}
