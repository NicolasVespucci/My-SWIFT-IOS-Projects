import UIKit
import StoreKit

//@available(iOS 15.0, *)
class SecondShoppingCell: UICollectionViewCell {
    
    var firstShoppingCellModel: ShoppingSubscribeModel? {
        didSet { configurePayFirstModel() }
    }
    
    private lazy var cellView: UIView = {
        let cell = UIView()
        cell.layoutIfNeeded()
        cell.backgroundColor = "208E92".hexColor.withAlphaComponent(0.03)
        cell.layer.cornerRadius = 16
        cell.clipsToBounds = false
        return cell
    }()
    
    private var subsriptionImageView: UIImageView = {
        let imageView = UIImageView()
        return imageView
    }()
    
    private lazy var trialLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15, weight: .bold)
        label.textColor = "595959".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .left
        label.minimumScaleFactor = 0.5
        label.text = "FREE TRIAL"
        return label
    }()
    
    private var periodLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15, weight: .bold)
        label.textColor = "595959".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .left
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var hereLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 13, weight: .bold)
        label.textColor = "3DA071".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .left
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private lazy var priceLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.textColor = "3DA071".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .center
        label.minimumScaleFactor = 0.5
        return label
    }()

    var product: Product?
    var shoppingModel: ShoppingSubscribeModel?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func configureTrialLayout() {
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubviews(subsriptionImageView, periodLabel, hereLabel, priceLabel, trialLabel)
    
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(88)
        }
        
        subsriptionImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(13)
            make.size.equalTo(31)
        }
        
        periodLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(18)
            make.leading.equalTo(subsriptionImageView.snp.trailing).offset(14)
            make.height.equalTo(32)
        }
        
        hereLabel.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-18)
            make.leading.equalTo(subsriptionImageView.snp.trailing).offset(14)
            make.height.equalTo(32)
        }
        
        priceLabel.snp.makeConstraints { make in
            make.trailing.equalToSuperview().offset(-19)
            make.centerY.equalToSuperview()
            make.height.equalTo(24)
        }
        
        trialLabel.snp.makeConstraints { make in
            make.top.equalTo(priceLabel.snp.bottom).offset(-12)
            make.trailing.equalToSuperview().offset(-19)
            make.height.equalTo(32)
        }
        
        cellView.backgroundColor = .white
        hereLabel.text =  "FREE TRIAL " + introductoryPeriod.capitalized
        hereLabel.textColor = "3DA071".hexColor
        priceLabel.text = price
        periodLabel.text = perPeriodString + " - subscription"
        priceLabel.textColor = "3DA071".hexColor
        periodLabel.textColor = "595959".hexColor
        trialLabel.textColor = "3DA071".hexColor
        subsriptionImageView.image = firstShoppingCellModel?.imageNotSelected?.image
        
        layer.masksToBounds = false
        layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.13).cgColor
        layer.shadowOffset = CGSize(width: 2.0, height: 4.0)
        layer.shadowOpacity = 1
        layer.shadowRadius = 15
        layoutSubviews()
    }
    
    public func configureCommonLayout() {
        
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubviews(subsriptionImageView, periodLabel, hereLabel, priceLabel)
    
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(88)
        }
        
        subsriptionImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(13)
            make.size.equalTo(31)
        }
        
        periodLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(18)
            make.leading.equalTo(subsriptionImageView.snp.trailing).offset(14)
            make.height.equalTo(32)
        }
        
        hereLabel.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-18)
            make.leading.equalTo(subsriptionImageView.snp.trailing).offset(14)
            make.height.equalTo(32)
        }
        
        priceLabel.snp.makeConstraints { make in
            make.trailing.equalToSuperview().offset(-19)
            make.centerY.equalToSuperview()
            make.height.equalTo(24)
        }
        
        subsriptionImageView.image = firstShoppingCellModel?.imageNotSelected?.image
        cellView.backgroundColor = .white
        hereLabel.text = ""
        priceLabel.text = price
        periodLabel.text = perPeriodString + " - subscription"
        priceLabel.textColor = "3DA071".hexColor
        periodLabel.textColor = "595959".hexColor
        trialLabel.textColor = "3DA071".hexColor
        
        layer.masksToBounds = false
        layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.13).cgColor
        layer.shadowOffset = CGSize(width: 2.0, height: 4.0)
        layer.shadowOpacity = 1
        layer.shadowRadius = 15
        layoutSubviews()
    }
    
    public func configureTrialSelectedLayout() {
        
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let perPeriodString2 = period.perFormattedString

        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubviews(cellView)
        cellView.addSubviews(subsriptionImageView, periodLabel, hereLabel, priceLabel, trialLabel)
        

        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(88)
        }
        
        subsriptionImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(13)
            make.size.equalTo(31)
        }
        
        periodLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(18)
            make.leading.equalTo(subsriptionImageView.snp.trailing).offset(14)
            make.height.equalTo(32)
        }
        
        hereLabel.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-18)
            make.leading.equalTo(subsriptionImageView.snp.trailing).offset(14)
            make.height.equalTo(32)
        }
        
        priceLabel.snp.makeConstraints { make in
            make.trailing.equalToSuperview().offset(-19)
            make.centerY.equalToSuperview()
            make.height.equalTo(24)
        }
        
        trialLabel.snp.makeConstraints { make in
            make.top.equalTo(priceLabel.snp.bottom).offset(-12)
            make.trailing.equalToSuperview().offset(-19)
            make.height.equalTo(32)
            
        }

        layoutIfNeeded()
        
        subsriptionImageView.image = firstShoppingCellModel?.imageSelected?.image
        hereLabel.text =  "FREE TRIAL " + introductoryPeriod.capitalized
       
        hereLabel.textColor = .white
        cellView.backgroundColor = "3DA071".hexColor
        priceLabel.text = price
        periodLabel.text = perPeriodString + " - subscription"
        priceLabel.textColor = .white
        periodLabel.textColor = .white
        trialLabel.textColor = .white
    
        layer.masksToBounds = false
        layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.21).cgColor
        layer.shadowOffset = CGSize(width: 2.0, height: 4.0)
        layer.shadowOpacity = 1
        layer.shadowRadius = 15
        layoutSubviews()
    }
    
    public func configureCommonSelectedLayout() {
        
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubviews(subsriptionImageView, periodLabel, hereLabel, priceLabel)
        

        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(88)
        }
        
        subsriptionImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(13)
            make.size.equalTo(31)
        }
        
        periodLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(18)
            make.leading.equalTo(subsriptionImageView.snp.trailing).offset(14)
            make.height.equalTo(32)
        }
        
        hereLabel.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-18)
            make.leading.equalTo(subsriptionImageView.snp.trailing).offset(14)
            make.height.equalTo(32)
        }
        
        priceLabel.snp.makeConstraints { make in
            make.trailing.equalToSuperview().offset(-19)
            make.centerY.equalToSuperview()
            make.height.equalTo(24)
        }
        
        subsriptionImageView.image = firstShoppingCellModel?.imageSelected?.image
        cellView.backgroundColor = "3DA071".hexColor
        hereLabel.text = ""
        priceLabel.text = price
        periodLabel.text = perPeriodString + " - subscription"
        priceLabel.textColor = .white
        periodLabel.textColor = .white
        trialLabel.textColor = .white
        
        layer.masksToBounds = false
        layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.21).cgColor
        layer.shadowOffset = CGSize(width: 2.0, height: 4.0)
        layer.shadowOpacity = 1
        layer.shadowRadius = 15
        layoutSubviews()
    }
    
    private func configurePayFirstModel() {
//        guard let advantagesModel = firstShoppingCellModel else { return }
    }
}

extension CALayer {
 func addGradienBorder(colors: UIColor..., width: CGFloat = 1, cornerRadius: CGFloat) {
   let gradientLayer = CAGradientLayer()
   gradientLayer.frame =  CGRect(origin: .zero, size: self.bounds.size)
   gradientLayer.startPoint = CGPoint(x: 0.0, y: 0.5)
   gradientLayer.endPoint = CGPoint(x: 1.0, y: 0.5)
   gradientLayer.colors = colors.map({$0.cgColor})
   gradientLayer.cornerRadius = cornerRadius
   
   let shapeLayer = CAShapeLayer()
   shapeLayer.lineWidth = width
   shapeLayer.cornerRadius = cornerRadius
   shapeLayer.path = UIBezierPath(roundedRect: self.bounds, cornerRadius: cornerRadius).cgPath
   shapeLayer.fillColor = nil
   shapeLayer.strokeColor = UIColor.black.cgColor
   gradientLayer.mask = shapeLayer
   
   self.addSublayer(gradientLayer)
 }
}
