
import Foundation
import UIKit

var UD = UserDefaults.standard

public struct Constants {
    
    static var app = AppConstants()
    static var analytics = AnalyticsConstants()
    static var ud = UDConstants()
    
    struct AnalyticsConstants {
        let week = "picturize.week.edit"
        let threeMonth = "picturize.month.edit"
        let year = "picturize.annaul.edit"
    }
    
    struct AppConstants {
        let appid = "1617530969"
    }
    
    struct UDConstants {
        var isPurchased : Bool {
            get { return UD.bool(forKey: UserDefaults.Keys.isPurchased) }
            set { UD.set(newValue, forKey: UserDefaults.Keys.isPurchased) }
        }
        
        var currentDismis: Int? {
            set { UD.set(newValue, forKey: "currentDismis") }
            get { return UD.integer(forKey: "currentDismis") }
        }
    }
    
    static var country: String = {
        let locale: NSLocale = NSLocale(localeIdentifier: "en_US")
        if let countryCode = locale.object(forKey: NSLocale.Key.countryCode) as? String,
           let country = locale.displayName(forKey: NSLocale.Key.countryCode, value: countryCode) {
            print(country)
            return country
        }
        return "unsigned"
    }()
}

extension UserDefaults {
  enum Keys {
    static let isPurchased = "isPurchased"
  }
}
