import Foundation
import UIKit

extension CALayer {
  func addGradientBorder(color: UIColor,width:CGFloat = 1) {
    let gradientLayer = CAGradientLayer()
    gradientLayer.frame =  CGRect(origin: CGPoint.zero, size: bounds.size)
    gradientLayer.startPoint = CGPoint(x:0.0, y:0.0)
    gradientLayer.endPoint = CGPoint(x:1.0,y:1.0)
    gradientLayer.colors = [color]
    
    let shapeLayer = CAShapeLayer()
    shapeLayer.lineWidth = width
    shapeLayer.path = UIBezierPath(rect: bounds).cgPath
    shapeLayer.fillColor = UIColor.red.cgColor
    shapeLayer.strokeColor = UIColor.red.cgColor
    gradientLayer.mask = shapeLayer
    
    addSublayer(gradientLayer)
  }
  
  func addBorder(color: UIColor, width: CGFloat) {
    borderColor = color.cgColor
    borderWidth = width
  }
}
