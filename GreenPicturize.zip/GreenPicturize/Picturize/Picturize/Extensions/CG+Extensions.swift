//
//  CG + Extensions.swift
//
//
//  Created by Baluta Eugen on 9/5/19.
//

import UIKit

extension CGPoint {
  func divided(by x: CGFloat) -> CGPoint {
    return CGPoint(x: self.x / x, y: self.y / x)
  }
  
  func multiplied(by x: CGFloat) -> CGPoint {
    return CGPoint(x: self.x * x, y: self.y * x)
  }
}

extension CGSize {
  func divided(by x: CGFloat) -> CGSize {
    return CGSize(width: self.width / x, height: self.height / x)
  }
  
  func multiplied(by x: CGFloat) -> CGSize {
    return CGSize(width: self.width * x, height: self.height * x)
  }
}

extension CGRect {
  func divided(by x: CGFloat) -> CGRect {
    return CGRect(origin: self.origin.divided(by: x), size: self.size.divided(by: x))
  }
  
  func multiplied(by x: CGFloat) -> CGRect {
    return CGRect(origin: self.origin.multiplied(by: x), size: self.size.multiplied(by: x))
  }
}

extension CGFloat {
  func rounded(to places:Int) -> CGFloat {
    let divisor = pow(10.0, CGFloat(places))
    return (self * divisor).rounded() / divisor
  }
}
