import Foundation
import UIKit

extension UIApplication {
  static var presentedViewController: UIViewController? {
    var presentViewController = UIApplication.shared.keyWindow?.rootViewController
    while let pVC = presentViewController?.presentedViewController {
      presentViewController = pVC
    }
    return presentViewController
  }
  
  public static func settingsAlert(message: String) {
    let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
    let settingsAction = UIAlertAction(title: "Settings", style: .default) { (_) in
      guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else { return }
      UIApplication.shared.open(settingsUrl, options: [:], completionHandler: nil)
    }
    let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: { _ in })
    alert.addAction(settingsAction)
    alert.addAction(cancelAction)
    UIApplication.presentedViewController?.present(alert, animated: true, completion: nil)
  }
}
