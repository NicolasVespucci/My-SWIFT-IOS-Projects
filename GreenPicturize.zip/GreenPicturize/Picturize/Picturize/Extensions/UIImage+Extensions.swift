import Foundation
import UIKit

extension Data {
  var image: UIImage? {
    return UIImage(data: self)
  }
}

extension UIImage{

  var data: Data? {
    return jpegData(compressionQuality: 1)
  }
  
  func resizeImage(targetSize: CGSize) -> UIImage {
    let size = self.size
    let widthRatio  = targetSize.width  / size.width
    let heightRatio = targetSize.height / size.height
    let newSize = widthRatio > heightRatio ?  CGSize(width: size.width * heightRatio, height: size.height * heightRatio) : CGSize(width: size.width * widthRatio,  height: size.height * widthRatio)
    let rect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height)

    UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
    self.draw(in: rect)
    let newImage = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()

    return newImage!
  }
  
  open func resizedImage(_ ratio: CGFloat) -> UIImage?{
    let resizedSize = CGSize(width: self.size.width * ratio, height: self.size.height * ratio)
    UIGraphicsBeginImageContext(resizedSize)
    self.draw(in: CGRect(x: 0, y: 0, width: resizedSize.width, height: resizedSize.height))
    let resizedImage = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    return resizedImage
  }
  
  open func alpha(_ value:CGFloat) -> UIImage {
    UIGraphicsBeginImageContextWithOptions(size, false, scale)
    draw(at: CGPoint.zero, blendMode: .normal, alpha: value)
    let newImage = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    return newImage!
  }
  
  public func acceptFilter(_ filter: CIFilter?) -> UIImage?{
    var context: CIContext? = nil
    if context == nil{
        guard let device = MTLCreateSystemDefaultDevice() else { /*assert(false, "Device does not support Metal.")*/
            return nil
        }
      context = CIContext(mtlDevice: device, options: [.workingColorSpace: CGColorSpace(name: CGColorSpace.sRGB)!, .priorityRequestLow: true])
    }
    
    var source = CIImage(image: self)
    defer {
      source = nil
      context = nil
    }
    guard let filter = filter else { return nil }
    if filter.inputKeys.contains(kCIInputImageKey){
      filter.setValue(source!, forKey: kCIInputImageKey)
    }
    let ciOutput = filter.outputImage!
    
    if let cgOutput = context?.createCGImage(ciOutput, from: ciOutput.extent){
      let outputImage = UIImage(cgImage: cgOutput, scale: self.scale,
                                orientation: self.imageOrientation)
      context?.clearCaches()
      return outputImage.alpha(1)
    }
    return nil
  }
}
