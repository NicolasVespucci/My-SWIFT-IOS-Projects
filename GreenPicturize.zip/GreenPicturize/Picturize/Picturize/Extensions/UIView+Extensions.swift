import Foundation
import UIKit

extension NSObject {
  func copyObject<T:NSObject>() throws -> T? {
    let data = try NSKeyedArchiver.archivedData(withRootObject:self, requiringSecureCoding:false)
    return try NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(data) as? T
  }
}

extension UIView {
    func removeBorders() {
      layer.borderColor = nil
      layer.borderWidth = 0
    }
    
    func addSubviews(_ views: UIView...) {
      views.forEach { addSubview($0) }
    }
    
    func addBorder(width: CGFloat, color: String, withAlphaComponent: CGFloat? = nil) {
    layer.borderWidth = width
    layer.borderColor = color.hexColor.withAlphaComponent(withAlphaComponent ?? 1.0).cgColor
    
  }
    
}
