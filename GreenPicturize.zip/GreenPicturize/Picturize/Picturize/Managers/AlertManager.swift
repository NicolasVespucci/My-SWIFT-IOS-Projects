import Foundation
import SwiftMessages

class AlertManager {
  
  // MARK: Properties
  private static let sharedAlertManager = AlertManager()
  
  static func shared() -> AlertManager {
    return sharedAlertManager
  }
  
  // MARK: Alert's
  private func showAlert(title: String,
                         body: String,
                         theme: Theme? = .warning,
                         iconImage: UIImage? = nil,
                         hideIconImage: Bool? = false,
                         buttonTitle: String? = "",
                         buttonTapHandler: (() -> Void)? = nil,
                         hideButton: Bool? = true) {
 
    DispatchQueue.main.async {
      var config = SwiftMessages.defaultConfig
      let view = MessageView.viewFromNib(layout: .cardView)
      view.configureTheme(theme!)
      view.configureContent(title: title, body: body)
      view.button?.isHidden = hideButton!
      view.button?.setTitle(buttonTitle, for: .normal)
      view.buttonTapHandler = { _ in
        buttonTapHandler?()
      }
      view.iconImageView?.isHidden = hideIconImage!
      if let icon = iconImage { view.iconImageView?.image = icon }
      config.presentationContext = .window(windowLevel: UIWindow.Level.statusBar)
      config.dimMode = .color(color: #colorLiteral(red: 0, green: 0, blue: 0, alpha: 0.2), interactive: false)
      config.duration = .automatic
      config.interactiveHide = false
      SwiftMessages.show(config: config, view: view)
    }
  }
  
  // PRODUCTS INFO
  func showFailRetriveProducts(buttonTapHandler: (() -> Void)? = nil) {
    showAlert(title: "Retrieve failed",
              body: "Failed to retrieve products information",
              theme: .warning,
              hideIconImage: true,
              buttonTitle: "Try again",
              buttonTapHandler: { SwiftMessages.hide(); buttonTapHandler?() },
              hideButton: false)
  }
  
  // RESTORE
  func showNoPurchasesToRestore() {
    showAlert(title: "Restore failed",
              body: "Sorry we didn't find your previous purchases",
              theme: .warning)
  }
  
  func showPurchasesWereRestored() {
    showAlert(title: "Restore succesful",
              body: "Purchases were restored",
              theme: .info)
  }
  
  func showPurchasesRestoreFail() {
    showAlert(title: "Restore failed",
              body: "Something went wrong, fail to restore purchases",
              theme: .warning)
  }
  
  // PURCHASE
  func showUnknown() {
    showAlert(title: "Unknown error",
              body: "Please contact support",
              theme: .warning)
  }
  
  func showClientInvalid() {
    showAlert(title: "",
              body: "Not allowed to make the payment",
              theme: .warning)
  }
  
  func showPaymentCancelled() {
    showAlert(title: "",
              body: "Payment was cancelled",
              theme: .warning)
  }
  
  func showPaymentInvalid() {
    showAlert(title: "",
              body: "The purchase identifier was invalid",
              theme: .warning)
  }
    
    func showCustom(message: String) {
        showAlert(title: "Unknown error",
                  body: message,
                  theme: .warning)
    }
  
  func showPaymentNotAllowed() {
    showAlert(title: "",
              body: "The device is not allowed to make the payment",
              theme: .warning)
  }
  
  func showStoreProductNotAvailable() {
    showAlert(title: "",
              body: "The product is not available in the current storefront",
              theme: .warning)
  }
  
  func showCloudServicePermissionDenied() {
    showAlert(title: "",
              body: "Access to cloud service information is not allowed",
              theme: .warning)
  }
  
  func showCloudServiceNetworkConnectionFailed() {
    showAlert(title: "",
              body: "Could not connect to the network",
              theme: .warning)
  }
  
  func showCloudServiceRevoked() {
    showAlert(title: "",
              body: "User has revoked permission to use this cloud service",
              theme: .warning)
  }
    
    func showSavingAlert() {
      showAlert(title: "Saved",
                body: "Successfully",
                theme: .info)
    }
    
    func showNotSavedAlert() {
      showAlert(title: ":-(",
                body: "Not saved",
                theme: .warning)
    }
    
    
    
    func showPurchaseComplite() {
      showAlert(title: "Successfully",
                body: "Purchase completed",
                theme: .info)
    }
    
    
      
  // GENERAL
  func showDeviceIsJailbroken() {
    showAlert(title: "",
              body: "Unknown error",
              theme: .warning)
  }
  
  func showSomethingWrong() {
    showAlert(title: ":-(",
              body: "Something went wrong",
              theme: .warning)
  }
  func ConnectingInternetOff() {
        showAlert(title: ":-(",
                  body: "Сonnection Error, Internet connection required",
                  theme: .warning)
  }
  func ConnectingInternetOn() {
        showAlert(title: ":-)",
                  body: "Internet connection is established",
                  theme: .warning)
  }
    
  
  func showNoInternetConnection() {
    showAlert(title: "Network error",
              body: "You need to turn on mobile data or Wi-Fi for some features.",
              theme: .warning)
  }
  
  // MARK: CUSTOM ALERT
}


