import StoreKit
import RxSwift
import RxCocoa
import UIKit
import UserNotifications
import SwiftyStoreKit
import IHProgressHUD
import Reachability

//@available(iOS 15.0, *)
class IAPManager {
  // MARK: PROPERTIES
  private static var sharedPurchaseManager: IAPManager = {
    let purchaseManager = IAPManager()
    return purchaseManager
  }()
  
  // INITIALIZATION
  private init() {}
  
  // MARK: - SINGLETON
  class func shared() -> IAPManager {
    return sharedPurchaseManager
  }
    
    private var localeID: String? {
        get { return UserDefaults.standard.string(forKey: "localeID") }
        set { UserDefaults.standard.set(newValue, forKey: "localeID") }
    }
    
  var isPurchased: Bool {
      //return true
      return Constants.ud.isPurchased
  }
  
    var isConnectedToNetwork: Bool {
      return try! Reachability().connection == .cellular || Reachability().connection == .wifi
    }
  
  var productsReceived: BehaviorRelay<Bool> = .init(value: false)
  var purchaseCompletion: ((Error?) -> Void)? = nil
  var restoreCompletion: ((Error?) -> Void)? = nil
    
  var products = [Product]()
  var skProducts = [SKProduct]()

  
    func purchase(rcPackage: String, quantity : Int, atomically: Bool) {
        IHProgressHUD.show()
        
        SwiftyStoreKit.purchaseProduct(rcPackage, quantity: quantity, atomically: atomically) { result in
            IHProgressHUD.dismiss()
            switch result {

            case .success(let purchase):
                print("Purchase Success: \(purchase.productId)")
                SwiftyStoreKit.finishTransaction(purchase.transaction)
                Constants.ud.isPurchased = true
                self.purchaseCompletion?(nil)
                
            case .error(let error):
                IHProgressHUD.dismiss()
                switch error.code {
                case .unknown: print("Unknown error. Please contact support")
                case .clientInvalid: print("Not allowed to make the payment")
                case .paymentCancelled: break
                case .paymentInvalid: print("The purchase identifier was invalid")
                case .paymentNotAllowed: print("The device is not allowed to make the payment")
                case .storeProductNotAvailable: print("The product is not available in the current storefront")
                case .cloudServicePermissionDenied: print("Access to cloud service information is not allowed")
                case .cloudServiceNetworkConnectionFailed: print("Could not connect to the network")
                case .cloudServiceRevoked: print("User has revoked permission to use this cloud service")
                default: print((error as NSError).localizedDescription)
                }
            }
        }
    }
  
  public func removeLocalNotifications() {
    if isPurchased{
      UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
      UNUserNotificationCenter.current().removeAllDeliveredNotifications()
    }
  }
    
    func checkIfPurchased(completion: @escaping ((Bool) -> ()), productId : String, sharedSecretKey: String) {
        let appleValidator = AppleReceiptValidator(service: .production, sharedSecret: sharedSecretKey)
        SwiftyStoreKit.verifyReceipt(using: appleValidator) { result in
            switch result {
            case .success(let receipt):
                // Verify the purchase of a Subscription
                let purchaseResult = SwiftyStoreKit.verifySubscription(
                    ofType: .autoRenewable, // or .nonRenewing (see below)
                    productId: productId,
                    inReceipt: receipt)
                    
                switch purchaseResult {
                case .purchased(let expiryDate, let items): completion(true)
                case .expired(let expiryDate, let items): completion(false)
                case .notPurchased: completion(false)
                }

            case .error(let error):
                print("Receipt verification failed: \(error)")
            }
        }
    }
  
    func restore() {
        IHProgressHUD.show()
        SwiftyStoreKit.restorePurchases(atomically: true) { results in
            IHProgressHUD.dismiss()
            if results.restoreFailedPurchases.count > 0 {
                AlertManager.shared().showCustom(message: "Restore failed")
            }
            else if results.restoredPurchases.count > 0 {
                AlertManager.shared().showPurchasesWereRestored()
                Constants.ud.isPurchased = true
                results.restoredPurchases.forEach({ SwiftyStoreKit.finishTransaction($0.transaction) })
                self.restoreCompletion?(nil)
            }
            else {
                AlertManager.shared().showCustom(message: "Nothing to restore")
            }
        }
    }
}

// MARK: NAVIGATION
//@available(iOS 15.0, *)
extension IAPManager {
  func presentSubscriptionVC(viewController: UIViewController? = nil, animated: Bool? = true) {
    if !isConnectedToNetwork { AlertManager.shared().showNoInternetConnection() ;return }
    
    let premiumVC = SecondShoppingViewController()
    let premiumNC = UINavigationController(rootViewController: premiumVC)
    premiumNC.modalPresentationStyle = .fullScreen
    UIApplication.getPresentedViewController()?.present(premiumNC, animated: true)
  }
    
    func presentSingleSubscriptionVC(viewController: UIViewController? = nil, animated: Bool? = true) {
        if !isConnectedToNetwork { AlertManager.shared().showNoInternetConnection() ;return }
        
        let premiumVC = FirstSubscribeViewController()
        let premiumNC = UINavigationController(rootViewController: premiumVC)
        premiumNC.modalPresentationStyle = .fullScreen
        UIApplication.getPresentedViewController()?.present(premiumNC, animated: true)
    }
  
  func dismissSubscriptionVC(animated: Bool? = true, completion: (() -> Void)? = nil) {
    UIApplication.getPresentedViewController()?.dismiss(animated: animated!, completion: {
      
      self.purchaseCompletion = nil
      self.restoreCompletion = nil
      completion?()
    })
  }
}

//MARK: - SKError
//@available(iOS 15.0, *)
extension IAPManager {
  private func getError(product: SKProduct, error: Error?) -> String {
    var failureReason = product.productIdentifier
    if let skError = error as? SKError {
        switch skError.code {  // https://developer.apple.com/reference/storekit/skerror.code
        case .unknown: failureReason += ", Unknown, \(error?.localizedDescription ?? "nil")"
        case .paymentCancelled: failureReason += ", Payment cancelled by user"
        case .clientInvalid: failureReason += ", Invalid Client"
        case .paymentInvalid: failureReason += ", Invalid Payment"
        case .paymentNotAllowed: failureReason += ", Payment not allowed"
        case .cloudServiceNetworkConnectionFailed: failureReason += ", Cloud service network connection failed"
        case .cloudServicePermissionDenied: failureReason += ", Cloud service permission denied"
        case .storeProductNotAvailable: failureReason += ", Store product not available"
        case .cloudServiceRevoked: failureReason += ", Cloud service revoked"
        case .privacyAcknowledgementRequired: failureReason += ", Privacy Acknowledgement Required"
        case .unauthorizedRequestData:failureReason += ", Unauthorized Request Data"
        case .invalidOfferIdentifier: failureReason += ", Invalid offer identifier"
        case .invalidSignature: failureReason += ", Invalid signature"
        case .missingOfferParams: failureReason += ", Missing offer params"
        case .invalidOfferPrice: failureReason += ", Invalid offer price"
        @unknown default: failureReason += "\(error.debugDescription)"
      }
      return failureReason
    } else {
      failureReason = "\(error.debugDescription)"
      return failureReason
    }
  }
}

extension UIApplication {
  class func getPresentedViewController() -> UIViewController? {
    var presentViewController = UIApplication.shared.keyWindow?.rootViewController
    while let pVC = presentViewController?.presentedViewController {
      presentViewController = pVC
    }
    return presentViewController
  }
  
  static var applicationVersion: String {
    return Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String
  }
  
  static var applicationBuild: String {
    return Bundle.main.object(forInfoDictionaryKey: kCFBundleVersionKey as String) as! String
  }
  
  static var versionBuild: String {
    return "v\(self.applicationVersion)(\(self.applicationBuild))"
  }
}
