import Foundation
import UIKit
import StoreKit
import SwiftyAttributes

enum IAPType: Equatable {
  case renewable(_ type: RenewableIAPType)
  case nonRenewable
  case consumable
  case nonConsumable
}

enum RenewableIAPType {
  case `default`
  case trial
  case introductory
}

enum PeriodType {
  case day, week, month, year
  
  var string: String {
    switch self {
    case .day: return "day"
    case .week: return "week"
    case .month: return "month"
    case .year: return "year"
    }
  }
}

enum Style {
  case minimal
  case `default`
}

class Product: NSObject {
  
  // MARK: PROPERTIES
  var priceLocale: Locale?
  var identifier            = "Unknown"
  var localizedTitle        = "Unknown"
  var localizedDescription  = "Unknown"
  var price                 = 0.0
  var localizedPrice        = "Unknown"
  var currencyCode          = "Unknown"
  var type                  = IAPType.nonRenewable
  var period: SubscriptionPeriod?
  var introductory: Introductory?
  
  // MARK: LIFE CYCLE
  init(identifier: String) {
    self.identifier = identifier
  }
  
  convenience init(product: SKProduct) {
    self.init(identifier: product.productIdentifier)
    
    priceLocale           = product.priceLocale
    localizedTitle        = product.localizedTitle
    localizedDescription  = product.localizedDescription
    price                 = product.price.doubleValue
    localizedPrice        = self.localizedPrice(self.price) ?? "0"
    period                = SubscriptionPeriod(period: product.subscriptionPeriod)
    introductory          = Introductory(discount: product.introductoryPrice)
    type                  = iapType(of: product.productIdentifier)
  }
  
  public func localizedPrice(_ price: Double, localeIdentifier: String? = nil) -> String? {
    let formatter = NumberFormatter()
    formatter.numberStyle = .currency
    formatter.locale = priceLocale
    return formatter.string(from: NSNumber(value: price))
  }
  
  private func iapType(of identifier: String) -> IAPType {
    guard let _ = introductory?.period else { return .renewable(.default) }
    return .renewable(introductory?.price == 0 ? .trial : .introductory)
  }
}

// MARK: PRODUCT STYLE
extension Product {
  struct IAPStyle {
    
    static var attributes: (prefix: [Attribute], suffix: [Attribute]) {
      let prefixAttributes: [Attribute] = [
        .font(Font(name: "Helvetica-Bold", size: 17)!),
        .textColor(.red)
      ]
      let suffixAttributes: [Attribute] = [
        .font(Font(name: "Helvetica", size: 15)!),
        .textColor(.white)
      ]
      return (prefix: prefixAttributes, suffix: suffixAttributes)
    }
    
    static func trialString(for product: Product,
                            attributes: (prefix: [Attribute], suffix: [Attribute]),
                            style: Style) -> NSAttributedString {
      let period = product.introductory?.period?.formattedString ?? ""
      let prefix = (style == .default ? "Try " : "") + period + " for free"
      let suffix = "then " + product.localizedPrice + "/" + (product.period?.perFormattedString ?? "")
      let separator = style == .default ? "\n" : " "
      return
        prefix.withAttributes(attributes.prefix) +
          NSAttributedString(string: separator) +
          suffix.withAttributes(attributes.suffix)
    }
    
    static func introductoryString(for product: Product,
                                   attributes: (prefix: [Attribute], suffix: [Attribute]),
                                   style: Style) -> NSAttributedString {
      let period = product.introductory?.period?.formattedString ?? ""
      let price = product.introductory?.localizedPrice ?? ""
      let prefix = "First " + period + (style == .default ? ": " : " ") + price
      let suffix = "then " + product.localizedPrice + "/" + (product.period?.perFormattedString ?? "")
      let separator = style == .default ? "\n" : " "
      return
        prefix.withAttributes(attributes.prefix) +
          separator.withAttributes(attributes.prefix) +
          suffix.withAttributes(attributes.suffix)
    }
    
    static func renewableString(for product: Product,
                                attributes: (prefix: [Attribute], suffix: [Attribute]),
                                style: Style) -> NSAttributedString {
      let prefix = product.period?.formattedString ?? ""
      let suffix = product.localizedPrice + "/" + (product.period?.unit.string ?? "")
      if style == .minimal { return NSAttributedString(string: suffix) }
      return
        prefix.withAttributes(attributes.prefix) +
          ": ".withAttributes(attributes.prefix) +
          suffix.withAttributes(attributes.suffix)
    }
    
    static func consumableString(for product: Product,
                                 attributes: (prefix: [Attribute], suffix: [Attribute]),
                                 style: Style) -> NSAttributedString {
      let prefix = "Consumable: "
      let suffix = product.localizedPrice
      if style == .minimal { return NSAttributedString(string: suffix) }
      return prefix.withAttributes(attributes.prefix) + suffix.withAttributes(attributes.suffix)
    }
    
    static func nonConsumableString(for product: Product,
                                    attributes: (prefix: [Attribute], suffix: [Attribute]),
                                    style: Style) -> NSAttributedString {
      let prefix = "Lifetime: "
      let suffix = product.localizedPrice
      if style == .minimal { return NSAttributedString(string: suffix) }
      return prefix.withAttributes(attributes.prefix) + suffix.withAttributes(attributes.suffix)
    }
  }
}

@objc class SubscriptionPeriod: NSObject {
  var numberOfUnits = 0
  var formattedString = ""
  var perFormattedString = ""
  var unit = PeriodType.day
  
  init(period: SKProductSubscriptionPeriod?) {
    guard let period = period else { return }
    self.numberOfUnits = period.numberOfUnits
    
    switch period.unit {
    case .day:
      unit = .day
      formattedString = "\(period.numberOfUnits) day"
      perFormattedString = "\(period.numberOfUnits) day"
      if period.numberOfUnits > 1 { formattedString += "s" }
      if period.numberOfUnits == 7 {
        formattedString = "Weekly"
        perFormattedString = "week"
        unit = .week
      }
    case .week:
      unit = .week
      formattedString = "\(period.numberOfUnits) week"
      perFormattedString = "\(period.numberOfUnits) week"
      if period.numberOfUnits == 1 {
        formattedString = "Weekly"
        perFormattedString = "week"
      }
      if period.numberOfUnits > 1 { formattedString += "s"; perFormattedString += "s" }
    case .month:
      unit = .month
      formattedString = "\(period.numberOfUnits) month"
      perFormattedString = "\(period.numberOfUnits) month"
      if period.numberOfUnits == 1 {
        formattedString = "Monthly"
        perFormattedString = "month"
      }
      if period.numberOfUnits > 1 { formattedString += "s"; perFormattedString += "s" }
    case .year:
      unit = .year
      formattedString = "\(period.numberOfUnits) year"
      perFormattedString = "year"
      if period.numberOfUnits == 1 { formattedString = "Yearly"}
      if period.numberOfUnits > 1 { formattedString += "s" }
    }
  }
}

@objc class Introductory: NSObject {
  var price = 0.0
  var localizedPrice = ""
  var period: DiscountSubscriptionPeriod?
  var isTrial = true
  
  init(discount: SKProductDiscount?) {
    super.init()
    guard let discount = discount else { return }
    
    price = discount.price.doubleValue
    isTrial = price == 0 ? true : false
    localizedPrice = self.localizedPrice(self.price) ?? "0.0"
    period = DiscountSubscriptionPeriod(period: discount.subscriptionPeriod,
                                        numberOfPeriods: discount.numberOfPeriods,
                                        isTrial: isTrial)
  }
  
  private func localizedPrice(_ price: Double, localeIdentifier: String? = nil) -> String? {
    let identifier = UserDefaults.standard.string(forKey: "localeIdentifier")
    guard let uIdentifier = identifier else { return nil }
    let formatter = NumberFormatter()
    formatter.numberStyle = .currency
    formatter.locale = Locale(identifier: uIdentifier)
    return formatter.string(from: NSNumber(value: price))
  }
}


@objc class DiscountSubscriptionPeriod: NSObject {
  var numberOfUnits = 0
  var formattedString = ""
  var unit = PeriodType.day
  var promoPeriod = ""
  
  init(period: SKProductSubscriptionPeriod?, numberOfPeriods: Int, isTrial: Bool) {
    guard let period = period else { return }
    numberOfUnits = numberOfPeriods == 1 ? period.numberOfUnits : numberOfPeriods
    
    switch period.unit {
    case .day:
      unit = .day
      formattedString = "\(numberOfUnits) day"
      if numberOfUnits == 7, !isTrial { formattedString = "week"; unit = .week }
      if numberOfUnits > 1 { formattedString += "s" }
      
      promoPeriod = "\(numberOfUnits) day"
      if numberOfUnits > 1 { promoPeriod += "s" }
      if numberOfUnits == 7 { promoPeriod = "1 week" }
    case .week:
      unit = .week
      formattedString = "\(numberOfUnits) week"
      if numberOfUnits == 1, !isTrial { formattedString = "week"}
      if numberOfUnits > 1 { formattedString += "s" }
      
      promoPeriod = "\(numberOfUnits) week"
      if numberOfUnits > 1 { promoPeriod += "s" }
    case .month:
      unit = .month
      formattedString = "\(numberOfUnits) month"
      if numberOfUnits == 1, !isTrial { formattedString = "month"}
      if numberOfUnits > 1 { formattedString += "s" }
      
      promoPeriod = "\(numberOfUnits) month"
      if numberOfUnits > 1 { promoPeriod += "s" }
    case .year:
      unit = .year
      formattedString = "\(numberOfUnits) year"
      if numberOfUnits == 1, !isTrial { formattedString = "year"}
      if numberOfUnits > 1 { formattedString += "s" }
      
      promoPeriod = "\(numberOfUnits) year"
      if numberOfUnits > 1 { promoPeriod += "s" }
    }
  }
}

