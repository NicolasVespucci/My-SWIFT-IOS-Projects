import UIKit

class ShareManager {
  
  // MARK: Properties
  private static let shareManager = ShareManager()
  
  // MARK: Life cycle
  private init() {}
  
  // MARK: Share
  static func shared() -> ShareManager {
    return shareManager
  }
  
  func share(image: UIImage, url: URL? = nil, completion: (() -> Void)? = nil) {
    if let url = url, let _ = try? Data(contentsOf: url) {
//      IHProgressHUD.show()
      
      let objectsToShare = [url] //comment!, imageData!, myWebsite!]
      let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
      activityVC.setValue("Video", forKey: "subject")
      activityVC.completionWithItemsHandler = { _1, _2, _3, _4 in
        completion?()
      }
      activityVC.excludedActivityTypes = [.airDrop,
                                          .addToReadingList,
                                          .assignToContact,
                                          .copyToPasteboard,
                                          .mail,
                                          .message,
                                          .openInIBooks,
                                          .postToTencentWeibo,
                                          .postToVimeo,
                                          .postToWeibo,
                                          .print]
      
      UIApplication.presentedViewController?.present(activityVC, animated: true, completion: {
//        IHProgressHUD.dismiss()
      })
    } else {
      let objectsToShare = [image]
      let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            activityVC.setValue("Photo", forKey: "subject")
            activityVC.completionWithItemsHandler = { _1, _2, _3, _4 in
              completion?()
            }
            activityVC.excludedActivityTypes = [.airDrop,
                                                .addToReadingList,
                                                .assignToContact,
                                                .copyToPasteboard,
                                                .mail,
                                                .message,
                                                .openInIBooks,
                                                .postToTencentWeibo,
                                                .postToVimeo,
                                                .postToWeibo,
                                                .print]
            
            UIApplication.presentedViewController?.present(activityVC, animated: true, completion: {
      //        IHProgressHUD.dismiss()
            })
    }
  }
  
//  func shareThisApp() {
//    IHProgressHUD.show()
//    let url = URL(string: "https://itunes.apple.com/us/app/id" + Constants.app.appID)!
//    let activityVC = UIActivityViewController(activityItems: [url], applicationActivities: nil)
//    if let app = UIApplication.shared.delegate as? AppDelegate, let window = app.window {
//
//      UIApplication.presentedViewController?.present(activityVC, animated: true, completion: {
//        IHProgressHUD.dismiss()
//      })
//
//      if let popover = activityVC.popoverPresentationController {
//        popover.sourceView = window.rootViewController?.view
//      }
//    }
//  }
}
