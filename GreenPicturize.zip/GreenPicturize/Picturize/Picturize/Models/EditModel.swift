
import Foundation
import UIKit

//MARK: - Object Models

/// Asset edition mode
enum EditType {
  case filter
  case background
  case grid
}

struct EditCategory {
  var title: String
  var objects: [EditObject]
}

struct EditObject: Equatable {
  var type: EditType
  var image: UIImage? = nil
  var imageNotSelected: UIImage? = nil
  var filter: CIFilter? = nil
  var gridObject: GridObject? = nil
  var cost: Int
}

class EditModel {
  
  static func configureFilter(_ url: URL?) -> CIFilter? {
    let filter = CIFilter(name: "YUCIColorLookup", parameters: [:])
    guard let url = url else { return nil }
    let loot = CIImage(contentsOf: url)
    filter?.setValue(loot, forKey: "inputColorLookupTable")
    return filter
  }
  
   
  var typeArray = [
    EditCategory(title: "FILTERS", objects: [EditObject(type: .filter, filter: nil, cost: 0),
                                             EditObject(type: .filter, filter: EditModel.configureFilter(Bundle.main.url(forResource: "fl_0", withExtension: "png")), cost: 0),
                                             EditObject(type: .filter, filter: EditModel.configureFilter(Bundle.main.url(forResource: "fl_1", withExtension: "png")), cost: 0),
                                             EditObject(type: .filter, filter: EditModel.configureFilter(Bundle.main.url(forResource: "fl_2", withExtension: "png")), cost: 40),
                                             EditObject(type: .filter, filter: EditModel.configureFilter(Bundle.main.url(forResource: "fl_3", withExtension: "png")), cost: 40),
                                             EditObject(type: .filter, filter: EditModel.configureFilter(Bundle.main.url(forResource: "fl_4", withExtension: "png")), cost: 40),
                                             EditObject(type: .filter, filter: EditModel.configureFilter(Bundle.main.url(forResource: "fl_5", withExtension: "png")), cost: 40),
                                             EditObject(type: .filter, filter: EditModel.configureFilter(Bundle.main.url(forResource: "fl_6", withExtension: "png")), cost: 40),
                                             EditObject(type: .filter, filter: EditModel.configureFilter(Bundle.main.url(forResource: "fl_7", withExtension: "png")), cost: 40),
                                             EditObject(type: .filter, filter: EditModel.configureFilter(Bundle.main.url(forResource: "fl_8", withExtension: "png")), cost: 40),
                                             EditObject(type: .filter, filter: EditModel.configureFilter(Bundle.main.url(forResource: "fl_9", withExtension: "png")), cost: 40),
                                             EditObject(type: .filter, filter: EditModel.configureFilter(Bundle.main.url(forResource: "fl_10", withExtension: "png")), cost: 40)]),
    EditCategory(title: "BACKGROUNDS", objects: [EditObject(type: .background, image: "0".image, cost: 0),
                                                 EditObject(type: .background, image: "1".image, cost: 0),
                                                 EditObject(type: .background, image: "2".image, cost: 0),
                                                 EditObject(type: .background, image: "3".image, cost: 60),
                                                 EditObject(type: .background, image: "4".image, cost: 40),
                                                 EditObject(type: .background, image: "5".image, cost: 40),
                                                 EditObject(type: .background, image: "6".image, cost: 40),
                                                 EditObject(type: .background, image: "7".image, cost: 40),
                                                 EditObject(type: .background, image: "8".image, cost: 40),
                                                 EditObject(type: .background, image: "9".image, cost: 40),
                                                 EditObject(type: .background, image: "10".image, cost: 40),
                                                 EditObject(type: .background, image: "11".image, cost: 40),
                                                 EditObject(type: .background, image: "FFCC00".hexColor.image(CGSize(width: 1080, height: 1920)), cost: 20)
                                                 ]),
    EditCategory(title: "GRID", objects: [])
  ]

  var subTypesArray = [
    EditCategory(title: "TWO", objects: [EditObject(type: .grid, image: "gr_1_1".image, imageNotSelected: "green_1_1".image, cost: 0),
                                         EditObject(type: .grid, image: "gr_2_1".image, imageNotSelected: "green_2_1".image, gridObject: GridObject(mainDirection: .row, firstDirection: .column, secondDirection: .column, firstPartsNum: 1, secondPartsNum: 1), cost: 0),
                                         EditObject(type: .grid, image: "gr_2_2".image, imageNotSelected: "green_2_2".image, gridObject: GridObject(mainDirection: .column, firstDirection: .column, secondDirection: .column, firstPartsNum: 1, secondPartsNum: 1), cost: 0),
                                         EditObject(type: .grid, image: "gr_2_3".image,imageNotSelected: "green_2_3".image, gridObject: GridObject(mainDirection: .column, firstDirection: .column, secondDirection: .column, firstPartsNum: 1, secondPartsNum: 1, outerPriorityDirection: .top, outerPrioritySize: 2/3), cost: 0),
                                         EditObject(type: .grid, image: "gr_2_4".image, imageNotSelected: "green_2_4".image, gridObject: GridObject(mainDirection: .row, firstDirection: .column, secondDirection: .column, firstPartsNum: 1, secondPartsNum: 1, outerPriorityDirection: .right, outerPrioritySize: 2/3), cost: 0),
                                         EditObject(type: .grid, image: "gr_2_5".image,imageNotSelected: "green_2_5".image, gridObject: GridObject(mainDirection: .column, firstDirection: .column, secondDirection: .column, firstPartsNum: 1, secondPartsNum: 1, outerPriorityDirection: .bottom, outerPrioritySize: 2/3), cost: 0)
                                        ]),
    EditCategory(title: "THREE", objects: [EditObject(type: .grid, image: "gr_1_1".image, imageNotSelected: "green_1_1".image, cost: 0),
                                           EditObject(type: .grid, image: "gr_3_1".image, imageNotSelected: "green_3_1".image, gridObject: GridObject(mainDirection: .row, firstDirection: .row, secondDirection: .column, firstPartsNum: 1, secondPartsNum: 2), cost: 30),
                                           EditObject(type: .grid, image: "gr_3_2".image, imageNotSelected: "green_3_2".image, gridObject: GridObject(mainDirection: .column, firstDirection: .column, secondDirection: .row, firstPartsNum: 1, secondPartsNum: 2), cost: 30),
                                           EditObject(type: .grid, image: "gr_3_3".image, imageNotSelected: "green_3_3".image, gridObject: GridObject(mainDirection: .row, firstDirection: .column, secondDirection: .row, firstPartsNum: 2, secondPartsNum: 1), cost: 30),
                                           EditObject(type: .grid, image: "gr_3_4".image, imageNotSelected: "green_3_4".image, gridObject: GridObject(mainDirection: .column, firstDirection: .row, secondDirection: .row, firstPartsNum: 2, secondPartsNum: 1), cost: 30)
                                          ]),
    EditCategory(title: "FOUR", objects: [EditObject(type: .grid, image: "gr_1_1".image,imageNotSelected: "green_1_1".image, cost: 0),
                                          EditObject(type: .grid, image: "gr_4_1".image, imageNotSelected: "green_4_1".image, gridObject: GridObject(mainDirection: .column, firstDirection: .row, secondDirection: .row, firstPartsNum: 2, secondPartsNum: 2), cost: 40),
                                          EditObject(type: .grid, image: "gr_4_2".image, imageNotSelected: "green_4_2".image, gridObject: GridObject(mainDirection: .column, firstDirection: .row, secondDirection: .row, firstPartsNum: 1, secondPartsNum: 3), cost: 40),
                                          EditObject(type: .grid, image: "gr_4_3".image, imageNotSelected: "green_4_3".image, gridObject: GridObject(mainDirection: .row, firstDirection: .row, secondDirection: .column, firstPartsNum: 1, secondPartsNum: 3), cost: 40),
                                          EditObject(type: .grid, image: "gr_4_4".image, imageNotSelected: "green_4_4".image, gridObject: GridObject(mainDirection: .row, firstDirection: .column, secondDirection: .row, firstPartsNum: 3, secondPartsNum: 1), cost: 40),
                                          EditObject(type: .grid, image: "gr_4_5".image, imageNotSelected: "green_4_5".image, gridObject: GridObject(mainDirection: .column, firstDirection: .row, secondDirection: .row, firstPartsNum: 3, secondPartsNum: 1), cost: 40)
                                         ]),
    EditCategory(title: "FIVE", objects: [EditObject(type: .grid, image: "gr_1_1".image, imageNotSelected: "green_1_1".image, cost: 0),
                                          EditObject(type: .grid, image: "gr_5_1".image, imageNotSelected: "green_5_1".image, gridObject: GridObject(mainDirection: .row, firstDirection: .column, secondDirection: .column, firstPartsNum: 2, secondPartsNum: 3), cost: 50),
                                          EditObject(type: .grid, image: "gr_5_2".image, imageNotSelected: "green_5_2".image, gridObject: GridObject(mainDirection: .column, firstDirection: .row, secondDirection: .row, firstPartsNum: 2, secondPartsNum: 3), cost: 50),
                                          EditObject(type: .grid, image: "gr_5_3".image, imageNotSelected: "green_5_3".image, gridObject: GridObject(mainDirection: .row, firstDirection: .column, secondDirection: .column, firstPartsNum: 3, secondPartsNum: 2), cost: 50),
                                          EditObject(type: .grid, image: "gr_5_4".image, imageNotSelected: "green_5_4".image, gridObject: GridObject(mainDirection: .column, firstDirection: .row, secondDirection: .row, firstPartsNum: 3, secondPartsNum: 2), cost: 50)
                                         ])
  ]
}
