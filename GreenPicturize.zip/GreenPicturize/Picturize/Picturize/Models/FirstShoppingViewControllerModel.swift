import Foundation
import UIKit

struct FirstShoppingViewControllerModel {
    var image: String?
    var title: String?
}

