import Foundation
import UIKit
import YogaKit
import RxSwift
import RxCocoa
import MediaWatermark

enum OuterPriorityDirection {
  case equal
  case top
  case bottom
  case left
  case right
}

struct GridObject: Equatable {
  var mainDirection: YGFlexDirection
  var firstDirection: YGFlexDirection
  var secondDirection: YGFlexDirection
  var firstPartsNum: Int
  var secondPartsNum: Int
  var outerPriorityDirection: OuterPriorityDirection? = .equal
  var outerPrioritySize: CGFloat? = nil
  
//  init(from decoder: Decoder) throws {
//    if let values = try? decoder.container(keyedBy: CodingKeys.self){
//      if let mainDirection = try? values.decode(Int.self, forKey: .mainDirection) {
//        self.mainDirection = YGFlexDirection(
//      }
//
//      if let name = try? values.decode(String.self, forKey: .name) {
//        self.name = name
//      }
//
//      if let email = try? values.decode(String.self, forKey: .email) {
//        self.email = email
//      }
//
//      if let phone = try? values.decode(String.self, forKey: .phone) {
//        self.phone = phone
//      }
//
//      if let location = try? values.decode(UserLocation.self, forKey: .location) {
//        self.location = location
//      }
//
//      if let imageURL = try? values.decode(String.self, forKey: .imageURL) {
//        self.imageURL = imageURL
//      }
//
//      if let friends = try? values.decode([User].self, forKey: .friends) {
//        self.friends = friends
//      }
//
//      if let visible = try? values.decode(Bool.self, forKey: .visible) {
//        self.visible = visible
//      }
//
//      if let battery = try? values.decode(Double.self, forKey: .battery) {
//        self.battery = battery
//      }
//    }
//  }
  
  private enum CodingKeys: String, CodingKey {
    case mainDirection
    case firstDirection
    case secondDirection
    case firstPartsNum
    case secondPartsNum
    case outerPriorityDirection
    case outerPrioritySize
  }
}

class GridConstructor {
  
  public var space: YGValue = 5
  
  public lazy var mainView: UIImageView = {
    let view = UIImageView()
    view.backgroundColor = "3EA071".hexColor
    view.isUserInteractionEnabled = true
    view.contentMode = .scaleAspectFill
    return view
  }()
  
  private let disposeBag = DisposeBag()
  
  public var imagesArray: [UIImageView] = [UIImageView]()
  
  public func configure(parentView: UIView, object: GridObject? = nil) {
    mainView.configureLayout { [weak self] layout in
      layout.isEnabled = true
      layout.flexDirection = .row
      layout.width = YGValue(parentView.frame.width)
      layout.height = YGValue(parentView.frame.height)
      layout.padding = self?.space ?? 0
    }
    parentView.addSubview(mainView)
    mainView.yoga.applyLayout(preservingOrigin: true)
    setLayout(object: object)
  }
  
  public func setLayout(object: GridObject?) {
    mainView.subviews.forEach { $0.removeFromSuperview() }
    imagesArray.removeAll()
    guard let object = object else { setOneLayout(); return }
    
    mainView.yoga.flexDirection = object.mainDirection
    
    let firstChildView = UIImageView()
    firstChildView.configureLayout { [weak self] layout in
      guard let self = self else { return }
      layout.isEnabled = true
      layout.flexDirection = object.firstDirection
      self.mainView.yoga.flexDirection == .row ? (layout.marginRight = YGValue(self.space.value / 2)) : (layout.marginBottom = YGValue(self.space.value / 2))
      if self.mainView.yoga.flexDirection == .row {
        layout.width = YGValue(Float(self.mainView.frame.width / 2) - self.space.value * 2)
      } else {
        layout.height = YGValue(Float(self.mainView.frame.height / 2) - self.space.value * 2)
      }
      layout.flexGrow = 1
    }
    mainView.addSubview(firstChildView)
    setPartImages(quantity: object.firstPartsNum, parentView: firstChildView)
    if object.firstPartsNum == 1 {
      configureEmptyImage(firstChildView)
      imagesArray.append(firstChildView)
    }
    
    let secondChildView = UIImageView()
    secondChildView.configureLayout { layout in
      layout.isEnabled = true
      layout.flexDirection = object.secondDirection
      self.mainView.yoga.flexDirection == .row ? (layout.marginLeft = YGValue(self.space.value / 2)) : (layout.marginTop = YGValue(self.space.value / 2))
      if self.mainView.yoga.flexDirection == .row {
        layout.width = YGValue(Float(self.mainView.frame.width / 2) - self.space.value * 2)
      } else {
        layout.height = YGValue(Float(self.mainView.frame.height / 2) - self.space.value * 2)
      }
      layout.flexGrow = 1
    }
    mainView.addSubview(secondChildView)
    setPartImages(quantity: object.secondPartsNum, parentView: secondChildView)
    if object.secondPartsNum == 1 {
      configureEmptyImage(secondChildView)
      imagesArray.append(secondChildView)
    }
    
    if let direction = object.outerPriorityDirection, let factor = object.outerPrioritySize {
      enlargeView(direction: direction, factor: factor)
    }
    
    mainView.yoga.applyLayout(preservingOrigin: false)
  }
  
  private func setOneLayout() {
    let imageView = UIImageView()
    imageView.tag = 777
    configureEmptyImage(imageView)
    imageView.configureLayout { layout in
      layout.isEnabled = true
      layout.flexGrow = 1
    }
    mainView.addSubview(imageView)
    imagesArray.append(imageView)
    mainView.yoga.applyLayout(preservingOrigin: false)
  }
  
  private func setPartImages(quantity: Int, parentView: UIView) {
    parentView.isUserInteractionEnabled = true
    parentView.clipsToBounds = true
    if quantity == 1 { return }
    (1...quantity).forEach { position in
      let view = UIImageView()
      view.tag = 666
      view.clipsToBounds = true
      configureEmptyImage(view)
      view.configureLayout { [weak self] layout in
        guard let self = self else { return }
        layout.isEnabled = true
        layout.flexGrow = 1
        if quantity != 1 {
          self.setMargins(layout: layout,
                          position: position,
                          quantity: quantity,
                          parent: parentView)
        }
      }
      parentView.addSubview(view)
      imagesArray.append(view)
    }
  }
  
  private func configureEmptyImage(_ view: UIView) {
      view.backgroundColor = "F3F3F3".hexColor
    view.contentMode = .scaleAspectFill
    view.clipsToBounds = true
    view.isUserInteractionEnabled = true
    let button = UIButton()
    button.setImage("greenPlus".image, for: .normal)
    button.tag = 666333
    button.configureLayout { (layout) in
      layout.isEnabled = true
      layout.flexGrow = 1
    }
    view.addSubview(button)
    
    (view as? UIImageView)?
    .rx
    .observe(UIImage.self, "image")
    .skip(1)
    .take(1)
    .bind { image in
    if image != nil {
      view.subviews.first?.removeFromSuperview()
    }
    }.disposed(by: disposeBag)
    mainView.yoga.applyLayout(preservingOrigin: false)
  }
 
  private func setMargins(layout: YGLayout, position: Int, quantity: Int, parent: UIView) {
    if quantity == 1 { return }
    switch parent.yoga.flexDirection {
    case .row:
      if position == 1 {
        layout.marginRight = YGValue(space.value / 2)
        layout.width = YGValue(Float(parent.frame.width / CGFloat(quantity)) - layout.marginRight.value)
      } else if position == quantity {
        layout.marginLeft = YGValue(space.value / 2)
        layout.width = YGValue(Float(parent.frame.width / CGFloat(quantity)) - layout.marginLeft.value)
      } else {
        layout.marginLeft = YGValue(space.value / 2)
        layout.marginRight = YGValue(space.value / 2)
        layout.width = YGValue(Float(parent.frame.width / CGFloat(quantity)) - layout.marginLeft.value - layout.marginRight.value)
      }
    case .column:
      if position == 1 {
        layout.marginBottom = YGValue(space.value / 2)
        layout.height = YGValue(Float(parent.frame.height / CGFloat(quantity)) - layout.marginBottom.value)
      } else if position == quantity {
        layout.marginTop = YGValue(space.value / 2)
        layout.height = YGValue(Float(parent.frame.height / CGFloat(quantity)) - layout.marginTop.value)
      } else {
        layout.marginBottom = YGValue(space.value / 2)
        layout.marginTop = YGValue(space.value / 2)
        layout.height = YGValue(Float(parent.frame.height / CGFloat(quantity)) - layout.marginBottom.value - layout.marginTop.value)
      }
    default: break
    }
  }
  
  public func changeSpaces(mainView: UIView, value: Float, object: GridObject? = nil) {
    space = YGValue(value)
    mainView.yoga.padding = space
    if mainView.subviews.count == 1 { mainView.yoga.applyLayout(preservingOrigin: false); return }
    guard let firstPart = mainView.subviews.first, let secondPart = mainView.subviews.last else { return }
    mainView.yoga.flexDirection == .row ? (firstPart.yoga.marginRight = YGValue(space.value / 2))
                                        : (firstPart.yoga.marginBottom = YGValue(space.value / 2))
    mainView.yoga.flexDirection == .row ? (secondPart.yoga.marginLeft = YGValue(space.value / 2))
                                        : (secondPart.yoga.marginTop = YGValue(space.value / 2))
    if let object = object, let direction = object.outerPriorityDirection, let size = object.outerPrioritySize {
      enlargeView(direction: direction, factor: size)
    } else {
      if self.mainView.yoga.flexDirection == .row {
        let width = YGValue(Float(self.mainView.frame.width / 2) - self.space.value * 2)
        firstPart.yoga.width = width
        secondPart.yoga.width = width
      } else {
        let height = YGValue(Float(self.mainView.frame.height / 2) - self.space.value * 2)
        firstPart.yoga.height = height
        secondPart.yoga.height = height
      }
    }
    
    [firstPart, secondPart].forEach { partView in
      partView.subviews.enumerated().forEach { (index, element) in
        setMargins(layout: element.yoga,
                   position: index + 1,
                   quantity: partView.subviews.count,
                   parent: partView)
      }
    }
    mainView.yoga.applyLayout(preservingOrigin: false)
  }
  
  private func enlargeView(direction: OuterPriorityDirection, factor: CGFloat) {
    guard let first = mainView.subviews.first, let second = mainView.subviews.last else { return }
    switch direction {
    case .top:
      first.yoga.height = YGValue(mainView.frame.height * factor)
      second.yoga.height = YGValue(Float(mainView.frame.height) - first.yoga.height.value - space.value * 3)
    case .left:
      first.yoga.width = YGValue(mainView.frame.width * factor)
      second.yoga.width = YGValue(Float(mainView.frame.width) - first.yoga.width.value - space.value * 3)
      first.yoga.flexGrow = 0
    case .right:
      second.yoga.width = YGValue(mainView.frame.width * factor)
      first.yoga.width = YGValue(Float(mainView.frame.width) - second.yoga.width.value - space.value * 3)
      second.yoga.flexGrow = 0
    case .bottom:
      second.yoga.height = YGValue(mainView.frame.height * factor)
      first.yoga.height = YGValue(Float(mainView.frame.height) - second.yoga.height.value - space.value * 3)
      second.yoga.flexGrow = 0
    case .equal: break
    }
  }
  
  public func configureFinalImage(parentView: UIView, object: GridObject?, completion: @escaping (UIImage?) -> Void) {
    let fullItem = MediaItem(image: UIColor.clear.image(CGSize(width: 1080, height: 1920)))
    
    mainView.yoga.width = YGValue(fullItem.size.width)
    mainView.yoga.height = YGValue(fullItem.size.height)
    let mainItem = MediaElement(view: mainView)
    
    mainView.subviews.forEach { view in
      if view is UIImageView {
        if (view as! UIImageView).image == nil { view.alpha = 0 }
      }
      view.subviews.forEach {
        if $0 is UIImageView {
          if ($0 as! UIImageView).image == nil { $0.alpha = 0 } else { view.alpha = 1 }
        }
      }
    }
    
    mainItem.frame = CGRect(origin: .zero, size: fullItem.size)
    fullItem.add(element: mainItem)
    
    let mediaProcessor = MediaProcessor()
    
    object?.outerPriorityDirection != nil ? changeSpaces(mainView: mainView, value: space.value * 3, object: object)
                                          : changeSpaces(mainView: mainView, value: space.value * 3)
    
    mediaProcessor.processElements(item: fullItem) { result, error in
      DispatchQueue.main.async { [weak self] in
        self?.mainView.isHidden = true
        guard let image = result.image, let self = self else { return }
        parentView.subviews.first?.removeFromSuperview()
        self.space.value /= 3
        self.configure(parentView: parentView, object: object)
        self.mainView.isHidden = false
        completion(image)
      }
    }
  }
}
