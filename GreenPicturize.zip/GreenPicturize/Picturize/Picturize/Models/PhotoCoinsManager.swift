import UIKit
import RxCocoa
import RxSwift

final class PhotoCoinsManager {
  enum CoinsAction {
    case addCoins(count: Int)
    case withdrawCoins(count: Int)
  }

  private(set) var photosCount: BehaviorRelay<Int> = .init(value: 1000)//UserDefaults.standard.value(forKey: "coins") as? Int ?? 1000)

  static let shared = PhotoCoinsManager()

  private init() { }
  
  public func hasEnough(cost: Int) -> Bool! {
    return photosCount.value > cost
  }

  public func coinsAction(_ action: CoinsAction) {
    switch action {
    case .addCoins(count: let additionalCoins):
      self.photosCount.accept(self.photosCount.value + additionalCoins)
    case .withdrawCoins(count: let withdrawCoins):
      self.photosCount.accept(self.photosCount.value - withdrawCoins)
    }
    UserDefaults.standard.set(self.photosCount.value, forKey: "coins")
  }
}
