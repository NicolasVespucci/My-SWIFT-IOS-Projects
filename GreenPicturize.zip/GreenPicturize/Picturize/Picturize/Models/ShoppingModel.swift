import Foundation

struct ShoppingModel {
    var image : String?
    var first: String?
    var second: String?
}
