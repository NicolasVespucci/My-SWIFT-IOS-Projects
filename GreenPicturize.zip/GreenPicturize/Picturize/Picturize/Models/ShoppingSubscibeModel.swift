import Foundation
struct ShoppingSubscribeModel {
    var second: String?
    var imageSelected: String?
    var imageNotSelected: String?
}
