import Foundation

struct AdvantagesModel {
    var first: String?
    var second: String?
    var image: String?
}
