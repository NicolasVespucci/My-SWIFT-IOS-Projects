import UIKit
import RxSwift
import SwiftyStoreKit
import IHProgressHUD
import SwiftyAttributes

//@available(iOS 15.0, *)
class FirstSubscribeViewController: UIViewController {
    
    var identifiers = Constants.analytics.week
    
    public var advantagesModelTwo = [AdvantagesModel(first: "Unlimited filtres", second: "Get more stylish filters & effects", image: "firstStep"),                           AdvantagesModel(first: "Unlimited custom backgrounds", second: "Get more beautiful backgrounds for your collage", image: "twoStep"),
                                  AdvantagesModel(first: "Unlimited grid layouts", second: "Get more layouts for your collage", image: "threeStep")]


    private var fullImageView: UIImageView = {
        let imageView = UIImageView(image: "fullSubsribeImage".image)
        return imageView
    }()
    
    private var topBackButton: UIButton = {
        let button = UIButton()
        button.setImage("backButton".image, for: .normal)
        return button
    }()

    private var restoreButton: UIButton = {
        let button = UIButton()
        button.setImage("restoreBlack".image, for: .normal)
        return button
    }()
    
    private var subscriptionsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 28, weight: .semibold)
        label.textColor = .black
        label.text = "Subscriptions"
        label.textAlignment = .center
        return label
    }()
    
    private var topImageView: UIImageView = {
        let imageView = UIImageView(image: "subscribeSecond".image)
        return imageView
    }()
    
    private lazy var trialLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.textColor = "0F4345".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .center
        label.numberOfLines = 2
        return label
    }()
    
    private var emptyView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()
    
    public var pricePeriodLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.numberOfLines = 0
        return label
    }()
    
    private var centerDignitiesView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 20
        view.clipsToBounds = false
        return view
    }()
    
    private lazy var topDignitiesTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 70
        table.backgroundColor = .clear
        table.isScrollEnabled = false
        table.separatorStyle = .none
        return table
    }()

    private lazy var subscribeButton: UIButton = {
        let button = UIButton()
        button.setTitle(NSLocalizedString("SUBSCRIBE", comment: ""), for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = "3DA071".hexColor
        button.layer.cornerRadius = 32
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .semibold)
        button.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.25).cgColor
        button.layer.shadowOffset = CGSize(width: 3.0, height: 6.0)
        button.layer.shadowOpacity = 1
        button.layer.shadowRadius = 12
        button.layer.masksToBounds = false
        return button
    }()
    
    var productsDescription: NSAttributedString {
        let terms = NSLocalizedString("Terms", comment: "") + " " + NSLocalizedString("of", comment: "") + " " + NSLocalizedString("Use", comment: "")
        let privacy = NSLocalizedString("Privacy", comment: "") + NSLocalizedString(" ", comment: "") + NSLocalizedString("Policy", comment: "")
        let and = " & "
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        
        let textAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12, weight: .medium)),
            .textColor(.black.withAlphaComponent(0.47)),
            .paragraphStyle(paragraphStyle)
        ]
        
        let andAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12, weight: .medium)),
            .textColor(.black.withAlphaComponent(0.25)),
            .paragraphStyle(paragraphStyle)
        ]
        
        let attributedDescription =
        terms.withAttributes(textAttributes)
        + and.withAttributes(andAttributes)
        + privacy.withAttributes(textAttributes)
        return attributedDescription
    }
    
    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.layoutIfNeeded()
        textView.isEditable = false
        textView.isSelectable = false
        textView.isScrollEnabled = false
        textView.backgroundColor = .clear
        textView.showsVerticalScrollIndicator = true
        textView.attributedText = productsDescription
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapResponse(recognizer:)))
        textView.addGestureRecognizer(tap)
        return textView
    }()
    
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if Constants.ud.isPurchased {
            if Constants.ud.currentDismis == 1 {
                AlertManager.shared().showPurchasesWereRestored()
                self.nextButtonActions()
            } else {
                IAPManager.shared().dismissSubscriptionVC()
                AlertManager.shared().showPurchasesWereRestored()
            }
        }
    }
    private func setup() {
        configureLayout()
        configureTrialLabel()
        setupTableView()
        setupButton()
    }
    
    private func configureLayout() {
        view.backgroundColor = "3DA071".hexColor
        navigationController?.isNavigationBarHidden = true
        view.addSubviews(fullImageView, topBackButton, restoreButton, subscriptionsLabel, topImageView, centerDignitiesView, emptyView, subscribeButton, textView)
    
        centerDignitiesView.addSubview(topDignitiesTableView)
        emptyView.addSubview(pricePeriodLabel)
        
        fullImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        topBackButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54.resized())
            make.leading.equalToSuperview().offset(26)
            make.width.equalTo(30)
            make.height.equalTo(22)
        }
        
        restoreButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54.resized())
            make.trailing.equalToSuperview().offset(-26)
            make.size.equalTo(22)
        }
        
        subscriptionsLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(45.resized())
            make.leading.equalToSuperview().offset(30)
            make.trailing.equalToSuperview().offset(-30)
            make.height.equalTo(32)
        }
        
        topImageView.snp.makeConstraints { make in
            make.top.equalTo(subscriptionsLabel.snp.top).offset(5)
            make.centerX.equalToSuperview()
            make.width.equalTo(319.resized())
            make.height.equalTo(306.resized())
        }
    
        centerDignitiesView.snp.makeConstraints { make in
            make.top.equalTo(topImageView.snp.bottom).offset(-36)
            make.height.equalTo(228)
            make.leading.equalToSuperview().offset(37)
            make.trailing.equalToSuperview().offset(-36)
        }
        
        topDignitiesTableView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(20)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview().offset(-5)
        }
        
        emptyView.snp.makeConstraints { make in
            make.top.equalTo(centerDignitiesView.snp.bottom).offset(5)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalTo(subscribeButton.snp.top).offset(-5)
        }
        
        pricePeriodLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.height.equalTo(96)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
        }
        
        subscribeButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-44.resized())
            make.leading.equalToSuperview().offset(16)
            make.trailing.equalToSuperview().offset(-16)
            make.height.equalTo(64)
        }
        
        textView.snp.makeConstraints { make in
            make.top.equalTo(subscribeButton.snp.bottom).offset(4.resized())
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(30)
        }
    }
    
  
    
    private func setupButton() {
        topBackButton.rx.tap.bind { [weak self] in
            if Constants.ud.currentDismis == 1 {
                self?.nextButtonActions()
            } else {
                self?.dismiss(animated: true)
            }
        }.disposed(by: disposeBag)
        
        restoreButton.rx.tap.bind {
            IAPManager.shared().restore()
            IAPManager.shared().restoreCompletion = { subscription in
                if Constants.ud.isPurchased {
                    if Constants.ud.currentDismis == 1 {
                        AlertManager.shared().showPurchasesWereRestored()
                        self.nextButtonActions()
                    } else {
                        IAPManager.shared().dismissSubscriptionVC()
                        AlertManager.shared().showPurchasesWereRestored()
                    }
                }
            }
        }.disposed(by: disposeBag)
        
        subscribeButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            let product = self.identifiers
            IAPManager.shared().purchase(rcPackage: product, quantity: 1, atomically: true)
            IAPManager.shared().purchaseCompletion = { subscription in
                if Constants.ud.isPurchased {
                    if Constants.ud.currentDismis == 1 {
                        AlertManager.shared().showPurchaseComplite()
                        self.nextButtonActions()
                    } else {
                        AlertManager.shared().showPurchaseComplite()
                        IAPManager.shared().dismissSubscriptionVC()
                    }
                }
            }
        }.disposed(by: disposeBag)
    }
    
    private func nextButtonActions(){
        let vc = ViewController()
        let nc = UINavigationController(rootViewController: vc)
        guard let window = UIApplication.shared.windows.first else { return }
        window.rootViewController = nc
    }
    
    private func setupTableView() {
        topDignitiesTableView.delegate = self
        topDignitiesTableView.dataSource = self
        topDignitiesTableView.register(FirstShoppingCell.self, forCellReuseIdentifier: FirstShoppingCell.nibIdentifier)
    }

    private func configureTrialLabel() {
        IHProgressHUD.show()
        SwiftyStoreKit.retrieveProductsInfo([Constants.analytics.week]) { result in
            if(!result.retrievedProducts.isEmpty) {
                let testProduct = Product(product: result.retrievedProducts.first!)
                guard let period = testProduct.period else { return }
                let periodString = period.formattedString // MONTHLY
                let perPeriodString = period.perFormattedString.capitalized // MONTH
                let price = testProduct.localizedPrice
                let introductoryPeriod = testProduct.introductory?.period?.formattedString ?? ""

                if introductoryPeriod == "" {
                    self.pricePeriodLabel.text = price + NSLocalizedString(" per ", comment: "") + perPeriodString
                    IHProgressHUD.dismiss()
                } else {
                    let paragraphStyle = NSMutableParagraphStyle()
                    paragraphStyle.alignment = .center
                    let attributedTitle = (NSLocalizedString("Enjoy your ", comment: "")
                                            .withAttributes([.textColor("1F1F1F".hexColor),
                                            .font(.systemFont(ofSize: 14, weight: .regular))])
                                           + introductoryPeriod
                                            .withAttributes([.textColor("1F1F1F".hexColor),
                                            .font(.systemFont(ofSize: 14, weight: .regular))])
                                           + NSLocalizedString("\n free trial,\nthen ", comment: "")
                                            .withAttributes([.textColor("1F1F1F".hexColor),
                                            .font(.systemFont(ofSize: 14, weight: .regular))])
                                           +  price
                                            .withAttributes([.textColor("3DA071".hexColor),
                                            .font(.systemFont(ofSize: 14, weight: .regular))])
                                           + NSLocalizedString(" per ", comment: "")
                                            .withAttributes([.textColor("3DA071".hexColor),
                                            .font(.systemFont(ofSize: 14, weight: .regular))])
                                           + perPeriodString
                                            .withAttributes([.textColor("3DA071".hexColor),
                                            .font(.systemFont(ofSize: 14, weight: .regular))])).withAttribute(.paragraphStyle(paragraphStyle))
                    self.pricePeriodLabel.attributedText = attributedTitle
                    IHProgressHUD.dismiss()
                }
            }
        }
    }
}

//MARK: - Text View
//@available(iOS 15.0, *)
extension FirstSubscribeViewController {
    @objc func tapResponse(recognizer: UITapGestureRecognizer) {
        let location: CGPoint = recognizer.location(in: textView)
        let position: CGPoint = CGPoint(x: location.x, y: location.y)
        let tapPosition: UITextPosition? = textView.closestPosition(to: position)
        if tapPosition != nil {
            let textRange: UITextRange? = textView.tokenizer.rangeEnclosingPosition(tapPosition!, with: UITextGranularity.word, inDirection: UITextDirection(rawValue: 1))
            if textRange != nil
            {
                let tappedWord: String? = textView.text(in: textRange!)
                guard let word = tappedWord else { return }
                wordAction(word)
            }
        }
    }
    
    private func wordAction(_ word: String) {
        switch word {
        case NSLocalizedString("Terms", comment: ""), NSLocalizedString("of", comment: ""), NSLocalizedString("Use", comment: ""): pushPoliciesVC(.terms)
            
        case NSLocalizedString("Privacy", comment: ""),NSLocalizedString(" ", comment: ""), NSLocalizedString("Policy", comment: ""): pushPoliciesVC(.privacy)
        default: break
        }
    }
    
    func pushPoliciesVC(_ policiesType: Policies) {
        let termsVC = TermsAndPrivacy()
        termsVC.policiesType = policiesType
        navigationController?.pushViewController(termsVC, animated: true)
    }
}

//@available(iOS 15.0, *)
extension FirstSubscribeViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}

//@available(iOS 15.0, *)
extension FirstSubscribeViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return advantagesModelTwo.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cellOne = topDignitiesTableView.dequeueReusableCell(withIdentifier: FirstShoppingCell.nibIdentifier, for:  indexPath) as! FirstShoppingCell
            let settingModelTwo = advantagesModelTwo[indexPath.row]
            cellOne.FirstShoppingCellModel = settingModelTwo
            return cellOne
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }

}
