import UIKit
import RxSwift

//@available(iOS 15.0, *)
class GreetingViewController: UIViewController, UIScrollViewDelegate {
    
    
    private let firstView = PresentScrollView(image: "firstScreen".image ?? UIImage(), generalImage: "firstG".image ?? UIImage(), topText: NSLocalizedString("Picturize", comment: ""), bottomText: NSLocalizedString(" Save and share your favourites looks", comment: ""))
    private let secondView = PresentScrollView(image: "secondScreen".image ?? UIImage(), generalImage: "secondG".image ?? UIImage(), topText: NSLocalizedString("Filter library", comment: ""), bottomText: NSLocalizedString("Make stunning transformations", comment: ""))
    
    
    private var scrollView: UIScrollView = {
        let view = UIScrollView()
        view.isPagingEnabled = true
        view.isScrollEnabled = false
        view.showsHorizontalScrollIndicator = false
        return view
    }()

    private var nextButton: UIButton = {
        let button = UIButton()
        button.setTitle(NSLocalizedString("Continue", comment: ""), for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = "3DA071".hexColor
        button.layer.cornerRadius = 32
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .semibold)
        button.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.25).cgColor
        button.layer.shadowOffset = CGSize(width: 3.0, height: 6.0)
        button.layer.shadowOpacity = 1
        button.layer.shadowRadius = 12
        button.layer.masksToBounds = false
        return button
    }()
    
    private lazy var pageControl: UIPageControl = {
        let pageControl = UIPageControl()
        pageControl.numberOfPages = 2
        pageControl.currentPage = 0
        pageControl.pageIndicatorTintColor = .black.withAlphaComponent(0.08)
        pageControl.currentPageIndicatorTintColor = "3DA071".hexColor
        pageControl.isUserInteractionEnabled = false
        return pageControl
    }()
    
    var xOffSet: CGFloat = 0
    var contentWidth: CGFloat = 0.0
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup (){
        configureLayout()
        setupButtons()
        configureScrollView()
    }
    
    private func configureLayout() {
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = "F3F3F3".hexColor
        view.addSubview(scrollView)
        view.addSubviews(nextButton, pageControl)
        
        scrollView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(-50)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        nextButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-44.resized())
            make.height.equalTo(63)
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
        }
        
        pageControl.snp.makeConstraints { make in
            make.top.equalTo(nextButton.snp.bottom).offset(14.resized())
            make.centerX.equalToSuperview()
            make.height.equalTo(8)
            make.width.equalTo(200)
        }
        view.layoutIfNeeded()
    }
    
    private func setupButtons() {
        nextButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.continueStartButtonAction()
        }.disposed(by: disposeBag)
    }
    
    private func continueStartButtonAction(){
        if self.xOffSet < UIScreen.main.bounds.width {

            DispatchQueue.main.async {
                self.xOffSet += UIScreen.main.bounds.width
                self.scrollView.contentOffset.x = self.xOffSet
                self.nextButton.setTitle(NSLocalizedString("Start", comment: ""), for: .normal)
            }
        } else {
            if IAPManager.shared().isPurchased {
                nextButtonActions()
            } else {
                Constants.ud.currentDismis = 1
                IAPManager.shared().presentSingleSubscriptionVC()
                IAPManager.shared().purchaseCompletion = { _ in
                    IAPManager.shared().dismissSubscriptionVC()
                }
                IAPManager.shared().restoreCompletion = { subscription in
                    IAPManager.shared().dismissSubscriptionVC()
                    if Constants.ud.isPurchased {
                        AlertManager.shared().showPurchasesWereRestored()
                    }
                }
            }
            showCurrentController = true
            UserDefaults.standard.set(showCurrentController, forKey: "showCurrentController")
            self.xOffSet = UIScreen.main.bounds.width
        }
    }
    
    private func configureScrollView() {
        scrollView.delegate = self
        let viewsForScroll = [firstView, secondView]
        for (index, view) in viewsForScroll.enumerated() {
            scrollView.addSubview(view)
            view.snp.makeConstraints { make in
                make.top.equalToSuperview()
                make.bottom.equalToSuperview()
                make.leading.equalToSuperview().offset(CGFloat(index) * UIScreen.main.bounds.width)
                make.width.equalToSuperview()
            }
            self.view.layoutIfNeeded()
            self.scrollView.layoutIfNeeded()
            contentWidth += self.view.frame.width
        }
        scrollView.contentSize = CGSize(width: contentWidth, height: scrollView.frame.height)
    }
    
    private func nextButtonActions(){
        let vc = ViewController()
        let nc = UINavigationController(rootViewController: vc)
        if #available(iOS 14, *) {
            guard let window = UIApplication.shared.windows.first else { return }
            window.rootViewController = nc
        } else {
            guard let window = UIApplication.shared.keyWindow else { return }
            window.rootViewController = nc
        }
        
    }
    
    internal func scrollViewDidScroll(_ scrollView: UIScrollView){
        pageControl.currentPage = Int(scrollView.contentOffset.x / UIScreen.main.bounds.width)
//        if pageControl.currentPage == 1 {
//            nextButton.setTitle("START", for: .normal)
//        } else if pageControl.currentPage == 0  {
//            nextButton.setTitle("CONTINUE", for: .normal)
//            print("ok")
//        }
    }

}
