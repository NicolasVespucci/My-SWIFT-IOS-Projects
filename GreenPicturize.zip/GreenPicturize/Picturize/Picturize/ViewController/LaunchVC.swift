import UIKit

//@available(iOS 15.0, *)
class LaunchVC: UIViewController {
    
    private var topImageView: UIImageView = {
        let imageView = UIImageView(image: "fullLaunch".image )
        imageView.contentMode = .scaleAspectFill
        imageView.isUserInteractionEnabled = true
        imageView.layer.masksToBounds = false
        imageView.clipsToBounds = false
        return imageView
    }()
    
    //MARK: - LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        pushNativeApp()
    }
    
    private func setup(){
        configureLayout()
    }
    
    private func configureLayout(){
        view.addSubviews(topImageView)
        topImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    }
    
    private func pushNativeApp() {
        if UserDefaults.standard.value(forKey: "showCurrentController") != nil {
            showCurrentController = UserDefaults.standard.value(forKey: "showCurrentController") as! Bool
        }
        
        let controller = showCurrentController ? ViewController() : GreetingViewController()
        let navigationController = UINavigationController(rootViewController: controller)
        UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.rootViewController = navigationController
        UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.makeKeyAndVisible()
    }
}
