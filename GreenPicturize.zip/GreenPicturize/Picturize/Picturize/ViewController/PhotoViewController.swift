import UIKit
import RxCocoa
import RxSwift

//@available(iOS 15.0, *)
class PhotoViewController: UIViewController {
    
    let disposeBag = DisposeBag()
    
    var imageCost: BehaviorRelay<Int> = .init(value: 200)
    
    public var image: UIImage? {
        didSet { mainImageView.image = image }
    }
    
    private var fullImageView: UIImageView = {
        let imageView = UIImageView(image: "mainFull".image)
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    private var premiumButton: UIButton = {
        let button = UIButton()
        button.setImage("corona".image, for: .normal)
        button.backgroundColor = "D6FCA6".hexColor.withAlphaComponent(0.63)
        button.layer.cornerRadius = 10
        return button
    }()
    
    private var popButton: UIButton = {
        let button = UIButton()
        button.setImage("pop".image, for: .normal)
        button.backgroundColor = "F3F3F3".hexColor
        button.layer.cornerRadius = 10
        return button
    }()
    
    private lazy var mainImageView: UIImageView! = {
        let imageView = UIImageView()
        imageView.clipsToBounds = true
        imageView.contentMode = .scaleAspectFill
        imageView.backgroundColor = .clear
        imageView.layer.cornerRadius = 12
        return imageView
    }()
    
    private var shareButton: UIButton = {
        let button = UIButton()
        button.setImage("share".image, for: .normal)
        button.backgroundColor = "3DA071".hexColor
        button.layer.cornerRadius = 10
        return button
    }()
    
    private var settingsButton: UIButton = {
        let button = UIButton()
        button.setImage("settingsSeve".image, for: .normal)
        button.backgroundColor = "3DA071".hexColor
        button.layer.cornerRadius = 10
        return button
    }()
    
    private var emptyButtonView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        view.addBorder(width: 2, color: "404147")
        view.layer.cornerRadius = 28
        
        return view
    }()
    
    private var saveInLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.text = "SAVE IN LIBRARY"
        label.textColor = "404147".hexColor
        label.textAlignment = .center
        return label
    }()
    
    private var saveImageView: UIImageView = {
        let imageView = UIImageView(image: "saveIn".image)
        return imageView
    }()
    
    private var saveButton: UIButton = {
        let button = UIButton()
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if IAPManager.shared().isPurchased {
            premiumButton.isHidden = true
        } else {
            premiumButton.isHidden = false
        }
    }
    
    private func setup() {
        configureLayout()
        setupButton()
    }
    
    private func configureLayout() {
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = .lightGray
        view.addSubview(fullImageView)
        
        fullImageView.addSubviews(premiumButton, popButton, mainImageView, settingsButton, shareButton, saveButton, emptyButtonView)
        
        emptyButtonView.addSubviews(saveImageView, saveInLabel, saveButton)
        
        fullImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        premiumButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(39)
            make.trailing.equalToSuperview().offset(-16)
            make.height.equalTo(44)
            make.width.equalTo(95)
        }
        
        popButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(39)
            make.leading.equalToSuperview().offset(16)
            make.height.equalTo(44)
            make.width.equalTo(95)
        }
        
        mainImageView.snp.makeConstraints {
            $0.top.equalTo(popButton.snp.bottom).offset(20)
            $0.leading.equalTo(53.resized)
            $0.trailing.equalTo(-53.resized)
            $0.height.equalTo(451.resized())
        }
        
        settingsButton.snp.makeConstraints { make in
            make.top.equalTo(mainImageView.snp.bottom).offset(23)
            make.height.equalTo(44)
            make.width.equalTo(95)
            make.leading.equalTo(51.resized)
        }
        
        shareButton.snp.makeConstraints { make in
            make.top.equalTo(mainImageView.snp.bottom).offset(23)
            make.height.equalTo(44)
            make.width.equalTo(95)
            make.trailing.equalTo(-51.resized)
        }
        
        emptyButtonView.snp.makeConstraints { make in
            make.top.equalTo(shareButton.snp.bottom).offset(28)
            make.width.equalTo(273)
            make.height.equalTo(56)
            make.centerX.equalToSuperview()
        }
        
        saveImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.height.equalTo(22)
            make.width.equalTo(18)
            make.leading.equalToSuperview().offset(55)
        }
        
        saveInLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.height.equalTo(19)
            make.trailing.equalToSuperview().offset(-55)
        }
        
        saveButton.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        mainImageView.layoutIfNeeded()
        
        DispatchQueue.main.async {
            self.view.layoutIfNeeded()
            self.premiumButton.layer.masksToBounds = false
            self.premiumButton.layer.shadowColor = UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.52).cgColor
            self.premiumButton.layer.shadowOffset = CGSize(width: -5.0, height: 0.0)
            self.premiumButton.layer.shadowOpacity = 1
            self.premiumButton.layer.shadowRadius = 22
        }
    }
    
    //MARK: setup Button
    
    private func setupButton(){
        premiumButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.presentSubscription()
        }.disposed(by: disposeBag)
        
        popButton.rx.tap.bind{ [weak self] in
            guard let self = self else { return }
            self.navigationController?.popViewController(animated: true)
        }.disposed(by: disposeBag)
        
        saveButton.rx.tap.bind { [weak self] in
                guard let self = self, let image = self.image else { return }
            AlertManager.shared().showSavingAlert()
                UIImageWriteToSavedPhotosAlbum(image, nil, #selector(self.image(image:didFinishSavingWithError:contextInfo:)), nil)
            }.disposed(by: disposeBag)
        
        shareButton.rx.tap.bind { [weak self] in
                guard let self = self, let image = self.image else { return }
                ShareManager.shared().share(image: image)
            }.disposed(by: disposeBag)
        
        settingsButton.rx.tap.bind { [weak self] in
            let vc = SettingsVC()
            self?.navigationController?.pushViewController(vc, animated: true)
            }.disposed(by: disposeBag)
    }
    
    private func presentSubscription() {
        if !IAPManager.shared().isPurchased {
            Constants.ud.currentDismis = 2
            IAPManager.shared().presentSingleSubscriptionVC()
            IAPManager.shared().purchaseCompletion = { _ in
                IAPManager.shared().dismissSubscriptionVC()
            }
            IAPManager.shared().restoreCompletion = { subscription in
                IAPManager.shared().dismissSubscriptionVC()
                if Constants.ud.isPurchased {
                    AlertManager.shared().showPurchasesWereRestored()
                }
            }
        }
    }
    
    @objc func image(image: UIImage, didFinishSavingWithError error: Error?, contextInfo: AnyObject) {
        guard error == nil else {
            print(error?.localizedDescription)
            AlertManager.shared().showNotSavedAlert()
            return
        }
        
    }
}
