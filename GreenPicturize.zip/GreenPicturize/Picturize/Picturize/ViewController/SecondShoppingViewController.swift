import UIKit
import SnapKit
import RxSwift
import StoreKit
import SwiftyStoreKit
import SwiftyAttributes
import NetworkExtension
import Network
import IHProgressHUD

//@available(iOS 15.0, *)
class SecondShoppingViewController: UIViewController {
    
    var identifiers = [Constants.analytics.week, Constants.analytics.threeMonth, Constants.analytics.year]
    
    public var shoppingModel = [ShoppingSubscribeModel(second: "Subscription description here", imageSelected: "weekSelected", imageNotSelected: "weekNotSelected"),
                                ShoppingSubscribeModel(second: "Subscription description here", imageSelected: "monthSelected", imageNotSelected: "monthNotSelected"),
                                ShoppingSubscribeModel( second: "Subscription description here", imageSelected: "yearSelected", imageNotSelected: "yearNotSelected")]
    
    
    public var advantagesModel = [AdvantagesModel(first: "Unlimited filtres", second: "Get more stylish filters & effects", image: "firstStep"),                                          AdvantagesModel(first: "Unlimited custom backgrounds", second: "Get more beautiful backgrounds for your collage", image: "twoStep"),
                                  AdvantagesModel(first: "Unlimited grid layouts", second: "Get more layouts for your collage", image: "threeStep")]
    
    private var fullImageView: UIImageView = {
        let imageView = UIImageView(image: "fullSubsribeImage".image)
        return imageView
    }()
    
    private var topBackButton: UIButton = {
        let button = UIButton()
        button.setImage("backButton".image, for: .normal)
        return button
    }()
    
    private var restoreButton: UIButton = {
        let button = UIButton()
        button.setImage("restoreBlack".image, for: .normal)
        return button
    }()
    
    private var subscriptionsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 28, weight: .semibold)
        label.textColor = .black
        label.text = "Subscriptions"
        label.textAlignment = .center
        return label
    }()
    
    private var topImageView: UIImageView = {
        let imageView = UIImageView(image: "subscribeSecond".image)
        return imageView
    }()
    
    private var centerDignitiesView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 20
        view.clipsToBounds = false
        return view
    }()
    
    private lazy var topDignitiesTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 70
        table.backgroundColor = .clear
        table.isScrollEnabled = false
        table.separatorStyle = .none
        return table
    }()
    
    private var arrowImageView: UIImageView = {
        let imageView = UIImageView(image: "Arrow".image)
        return imageView
    }()
    
    private lazy var payCollectionView: UICollectionView = {
        let collection = UICollectionView(frame: .zero, collectionViewLayout: .init())
        collection.backgroundColor = .clear
        collection.showsHorizontalScrollIndicator = false
        collection.showsVerticalScrollIndicator = false
        collection.isScrollEnabled = true
        collection.clipsToBounds = false
        collection.isScrollEnabled = false
        return collection
    }()
    
    private lazy var payLayout: UICollectionViewLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 0
        layout.itemSize = .init(width: (UIScreen.main.bounds.width - 32), height: 88)
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 13.resized()
        layout.sectionInset = .init(top: 0, left: 0, bottom: 0, right: 0)
        return layout
    }()
        
    private lazy var subscribeButton: UIButton = {
        let button = UIButton()
        button.setTitle(NSLocalizedString("SUBSCRIBE", comment: ""), for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = "3DA071".hexColor
        button.layer.cornerRadius = 32
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .semibold)
        button.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.25).cgColor
        button.layer.shadowOffset = CGSize(width: 3.0, height: 6.0)
        button.layer.shadowOpacity = 1
        button.layer.shadowRadius = 12
        button.layer.masksToBounds = false
        return button
    }()
    
    private var emptyView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        view.isUserInteractionEnabled = true
        return view
    }()
    
    var productsDescription: NSAttributedString {
        let terms = NSLocalizedString("Terms", comment: "") + " " + NSLocalizedString("of", comment: "") + " " + NSLocalizedString("Use", comment: "")
        let privacy = NSLocalizedString("Privacy", comment: "") + NSLocalizedString(" ", comment: "") + NSLocalizedString("Policy", comment: "")
        let and = " & "
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        
        let textAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12, weight: .medium)),
            .textColor(.black.withAlphaComponent(0.47)),
            .paragraphStyle(paragraphStyle)
        ]
        
        let andAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12, weight: .medium)),
            .textColor(.black.withAlphaComponent(0.25)),
            .paragraphStyle(paragraphStyle)
        ]
        
        let attributedDescription =
        terms.withAttributes(textAttributes)
        + and.withAttributes(andAttributes)
        + privacy.withAttributes(textAttributes)
        return attributedDescription
    }
    
    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.layoutIfNeeded()
        textView.isEditable = false
        textView.isSelectable = false
        textView.isScrollEnabled = false
        textView.backgroundColor = .clear
        textView.showsVerticalScrollIndicator = true
        textView.attributedText = productsDescription
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapResponse(recognizer:)))
        textView.addGestureRecognizer(tap)
        return textView
    }()
    
    let bag = DisposeBag()
    
    var products = [SKProduct]()
    var selectedIndex = 0
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        navigationController?.isNavigationBarHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
        configureUpdateProducts()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    private func setup(){
        configureUpdateProducts()
        configureLayout()
        setupShoppingCollection()
        configureButtons()
        setupTableView()
    }
    
    private func setupTableView() {
        topDignitiesTableView.delegate = self
        topDignitiesTableView.dataSource = self
        topDignitiesTableView.register(FirstShoppingCell.self, forCellReuseIdentifier: FirstShoppingCell.nibIdentifier)
    }
    
    private func setupShoppingCollection() {
            payCollectionView.setCollectionViewLayout(payLayout, animated: true)
            payCollectionView.dataSource = self
            payCollectionView.delegate = self
            payCollectionView.register(SecondShoppingCell.self, forCellWithReuseIdentifier: SecondShoppingCell.nibIdentifier)
    }
    
    private func configureLayout(){
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = "3EA071".hexColor
        view.addSubviews(fullImageView, topBackButton, restoreButton, subscriptionsLabel, topImageView, payCollectionView, centerDignitiesView, subscribeButton, textView)
        
        fullImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        topBackButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54.resized())
            make.leading.equalToSuperview().offset(26)
            make.width.equalTo(30)
            make.height.equalTo(22)
        }
        
        restoreButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54.resized())
            make.trailing.equalToSuperview().offset(-26)
            make.size.equalTo(22)
        }
        
        subscriptionsLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(45.resized())
            make.leading.equalToSuperview().offset(30)
            make.trailing.equalToSuperview().offset(-30)
            make.height.equalTo(32)
        }
        
        topImageView.snp.makeConstraints { make in
            make.top.equalTo(subscriptionsLabel.snp.top).offset(5.resized())
            make.centerX.equalToSuperview()
            make.width.equalTo(318.resized())
            make.height.equalTo(306.resized())
        }
        
        payCollectionView.snp.makeConstraints { make in
            make.top.equalTo(topImageView.snp.bottom).offset(-25.resized())
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(303)
        }
            
        subscribeButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-44.resized())
            make.leading.equalToSuperview().offset(16)
            make.trailing.equalToSuperview().offset(-16)
            make.height.equalTo(64)
        }
        
        textView.snp.makeConstraints { make in
            make.top.equalTo(subscribeButton.snp.bottom).offset(4.resized())
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(30)
        }
        
        view.layoutIfNeeded()
    
        centerDignitiesView.clipsToBounds = false
        centerDignitiesView.layer.shadowRadius = 20
        centerDignitiesView.layer.cornerRadius = 20
        
        view.layoutSubviews()
        
            IAPManager.shared().productsReceived.bind { [weak self] received in
                if received {
                    self?.payCollectionView.reloadData()
                } else {
                    self?.configureUpdateProducts()
                }
            }.disposed(by: disposeBag)
        
            IAPManager.shared().productsReceived.bind { [weak self] received in
                if received {
                    self?.payCollectionView.reloadData()
                } else {
                    self?.configureUpdateProducts()
                    self?.payCollectionView.reloadData()
                }
            }.disposed(by: disposeBag)
    }
    
    private func configureButtons() {
        topBackButton.rx.tap.bind { [weak self] in
            self?.dismiss(animated: true)
        }.disposed(by: disposeBag)
        
        restoreButton.rx.tap.bind {
            IAPManager.shared().restore()
            IAPManager.shared().restoreCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                    AlertManager.shared().showPurchasesWereRestored()
                }
            }
        }.disposed(by: disposeBag)
        
        subscribeButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            let product = self.identifiers[self.selectedIndex]
            IAPManager.shared().purchase(rcPackage: product, quantity: 1, atomically: true)
            IAPManager.shared().purchaseCompletion = { subscription in
                if Constants.ud.isPurchased {
                    AlertManager.shared().showPurchaseComplite()
                    IAPManager.shared().dismissSubscriptionVC()
                }
            }
        }.disposed(by: disposeBag)
    }

    private func configureUpdateProducts() {
        IHProgressHUD.show()
        SwiftyStoreKit.retrieveProductsInfo([Constants.analytics.week, Constants.analytics.threeMonth, Constants.analytics.year]) { result in
            if(!result.retrievedProducts.isEmpty) {
                self.products = Array(result.retrievedProducts).sorted(by: { Product(product: $0).price < Product(product: $1).price })
                self.payCollectionView.reloadData()
                IHProgressHUD.dismiss()
            } else {
                
                IHProgressHUD.dismiss()
                self.configureUpdateProducts()
            }
        }
    }
}

//MARK: - Text View
//@available(iOS 15.0, *)
extension SecondShoppingViewController {
    @objc func tapResponse(recognizer: UITapGestureRecognizer) {
        let location: CGPoint = recognizer.location(in: textView)
        let position: CGPoint = CGPoint(x: location.x, y: location.y)
        let tapPosition: UITextPosition? = textView.closestPosition(to: position)
        if tapPosition != nil {
            let textRange: UITextRange? = textView.tokenizer.rangeEnclosingPosition(tapPosition!, with: UITextGranularity.word, inDirection: UITextDirection(rawValue: 1))
            if textRange != nil
            {
                let tappedWord: String? = textView.text(in: textRange!)
                guard let word = tappedWord else { return }
                wordAction(word)
            }
        }
    }
    
    private func wordAction(_ word: String) {
        switch word {
        case NSLocalizedString("Terms", comment: ""), NSLocalizedString("of", comment: ""), NSLocalizedString("Use", comment: ""): pushPoliciesVC(.terms)
            
        case NSLocalizedString("Privacy", comment: ""),NSLocalizedString(" ", comment: ""), NSLocalizedString("Policy", comment: ""): pushPoliciesVC(.privacy)
        default: break
        }
    }
    
    func pushPoliciesVC(_ policiesType: Policies) {
        let termsVC = TermsAndPrivacy()
        termsVC.policiesType = policiesType
        navigationController?.pushViewController(termsVC, animated: true)
    }
}
//MARK: - TableView

//@available(iOS 15.0, *)
extension SecondShoppingViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}
//@available(iOS 15.0, *)
extension SecondShoppingViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return advantagesModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cellOne = topDignitiesTableView.dequeueReusableCell(withIdentifier: FirstShoppingCell.nibIdentifier, for:  indexPath) as! FirstShoppingCell
            let settingModelTwo = advantagesModel[indexPath.row]
            cellOne.FirstShoppingCellModel = settingModelTwo
            return cellOne
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }

}

//MARK: - CollectionView
//@available(iOS 15.0, *)
extension SecondShoppingViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedIndex = indexPath.item
        let apphudProduct = self.products[selectedIndex]
        payCollectionView.reloadData()
        
            if IAPManager.shared().isPurchased {
                IAPManager.shared().dismissSubscriptionVC()
            }
    
    }
}

//@available(iOS 15.0, *)
extension SecondShoppingViewController: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return products.count
    }
   
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
       
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SecondShoppingCell.nibIdentifier, for: indexPath) as! SecondShoppingCell
            let apphudProduct = products[indexPath.item]
            let product = Product(product: apphudProduct)
            print(product)
            cell.product = product
        cell.firstShoppingCellModel = shoppingModel[indexPath.item]
            if indexPath.item == self.selectedIndex {
                product.type == .renewable(.trial) ? cell.configureTrialSelectedLayout() : cell.configureCommonSelectedLayout()
//                indexPath.item
//                cell.FirstShoppingCellModel = shoppingModel[]
            } else {
                product.type == .renewable(.trial) ? cell.configureTrialLayout() : cell.configureCommonLayout()
            }
            

        return cell
    }
}

