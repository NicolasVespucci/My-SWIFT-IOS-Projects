import UIKit
import SnapKit
import RxSwift
import RxCocoa
import MessageUI

//@available(iOS 15.0, *)
class SettingsVC: UIViewController {
    
    let disposeBag = DisposeBag()
    var settings = ["Share app with friends","Privacy Policy","Terms of Use", "Contact us", "Restore Purchases"]
    
    private var fullImageView: UIImageView = {
        let imageView = UIImageView(image: "settingsFull".image)
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    private var topBackButton: UIButton = {
        let button = UIButton()
        button.setImage("back".image, for: .normal)
        return button
    }()
    
    private var settingsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 28, weight: .semibold)
        label.text = "Settings"
        label.textColor = .white
        label.textAlignment = .center
        return label
    }()
    
    private lazy var topEmptyView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 12
        view.isUserInteractionEnabled = true
        return view
    }()
    
    private lazy var tableView: UITableView = {
        let table = UITableView()
        table.separatorStyle = .singleLine
        table.separatorColor = "D7D8DB".hexColor
        table.rowHeight = 48
        table.isScrollEnabled = false
        table.backgroundColor = .clear
        return table
    }()
    
    private lazy var emptyView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 12
        view.isUserInteractionEnabled = true
        return view
    }()
    
    private lazy var premiumLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .bold)
        label.text = "Upgrade \nto premium"
        label.textColor = .black
        label.numberOfLines = 2
        label.textAlignment = .left
        return label
    }()
    
    private lazy var premiumImageView: UIImageView = {
        let imageView = UIImageView(image: "settingsPremium".image)
        return imageView
    }()
    
    private var premiumButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = .clear
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureTableView()
        configureButtons()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
        if IAPManager.shared().isPurchased {
            emptyView.isHidden = true
        }
    }
    
    private func configureTableView() {
        navigationController?.isNavigationBarHidden = true
        view.addSubviews(fullImageView)
        fullImageView.addSubviews(topBackButton, settingsLabel, topEmptyView, emptyView)
        topEmptyView.addSubview(tableView)
        emptyView.addSubviews(premiumImageView, premiumLabel, premiumButton)
        
        fullImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        topBackButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54.resized())
            make.leading.equalToSuperview().offset(26)
            make.width.equalTo(10)
            make.height.equalTo(17)
        }
        
        settingsLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(45.resized())
            make.leading.equalToSuperview().offset(30)
            make.trailing.equalToSuperview().offset(-30)
            make.height.equalTo(32)
        }
        
        topEmptyView.snp.makeConstraints { make in
            make.top.equalTo(settingsLabel.snp.bottom).offset(45.resized())
            make.height.equalTo(272)
            make.leading.equalToSuperview().offset(16)
            make.trailing.equalToSuperview().offset(-16)
        }
        
        tableView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(16)
            make.leading.equalToSuperview().offset(29)
            make.trailing.equalToSuperview().offset(-29)
            make.bottom.equalToSuperview().offset(-16)
        }
        
        emptyView.snp.makeConstraints { make in
            make.top.equalTo(topEmptyView.snp.bottom).offset(20.resized())
            make.leading.equalToSuperview().offset(17)
            make.trailing.equalToSuperview().offset(-17)
            make.height.equalTo(120)
        }
        
        premiumImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.width.equalTo(187)
            make.height.equalTo(120)
        }
        
        premiumLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.height.equalTo(64)
            make.leading.equalTo(premiumImageView.snp.trailing)
        }
        
        premiumButton.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        view.layoutIfNeeded()
        
        emptyView.layer.masksToBounds = false
        emptyView.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.33).cgColor
        emptyView.layer.shadowOffset = CGSize(width: 3.0, height: 4.0)
        emptyView.layer.shadowOpacity = 1
        emptyView.layer.shadowRadius = 30
        
        tableView.register(SettingsCell.self, forCellReuseIdentifier: SettingsCell.identifier)
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    
    private func configureButtons() {
        topBackButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.navigationController?.popViewController(animated: true)
        }.disposed(by: disposeBag)
        
        premiumButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.presentSubscriptionsViewController()
        }.disposed(by: disposeBag)
    }
    
    func presentSubscriptionsViewController() {
        IAPManager.shared().presentSubscriptionVC()
        IAPManager.shared().purchaseCompletion = { _ in
            IAPManager.shared().dismissSubscriptionVC()
        }
        IAPManager.shared().restoreCompletion = { subscription in
            IAPManager.shared().dismissSubscriptionVC()
            if Constants.ud.isPurchased {
                AlertManager.shared().showPurchasesWereRestored()
            }
        }
    }
    
    func pushPoliciesVC(_ policiesType: Policies) {
        let termsVC = TermsAndPrivacy()
        termsVC.policiesType = policiesType
        navigationController?.pushViewController(termsVC, animated: true)
    }
    
    func share() {
        UIGraphicsBeginImageContext(view.frame.size)
        view.layer.render(in: UIGraphicsGetCurrentContext()!)
        
        let textToShare = "Check out my app"
        
        if let myWebsite = URL(string: "http://itunes.apple.com/app/\(Constants.app.appid)") {//Enter link to your app here
            let objectsToShare = [textToShare, myWebsite] as [Any]
            let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            activityVC.excludedActivityTypes = [UIActivity.ActivityType.airDrop, UIActivity.ActivityType.addToReadingList]
            activityVC.popoverPresentationController?.sourceView = self.view
            self.present(activityVC, animated: true, completion: nil)
        }
    }
    
    private func contact() {
        if MFMailComposeViewController.canSendMail() {
            let toRecipients = ["support@picturize-editor.com"]
            let subject = "Feedback"
            let mail = configuredMailComposeViewController(recipients: toRecipients, subject: subject, body: "", isHtml: true, images: nil)
            presentMailComposeViewController(mailComposeViewController: mail)
        } else {
            print("You don't have email in Mail iOS App")
        }
    }
    
    private func restore() {
        if Constants.ud.isPurchased {
            AlertManager.shared().showNoPurchasesToRestore()
        } else {
            IAPManager.shared().restore()
            IAPManager.shared().restoreCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                    AlertManager.shared().showPurchasesWereRestored()
                    self.tableView.reloadData()
                }
            }
        }
    }
}

//@available(iOS 15.0, *)
extension SettingsVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
            switch settings[indexPath.row] {
            case "Share app with friends": share()
            case "Privacy Policy": pushPoliciesVC(.privacy)
            case "Terms of Use":  pushPoliciesVC(.terms)
            case "Contact us": contact()
            case "Restore Purchases": restore()
            default: break
            }
    }
}

//@available(iOS 15.0, *)
extension SettingsVC: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return settings.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: SettingsCell.identifier, for: indexPath) as? SettingsCell else { return UITableViewCell() }
            cell.type = settings[indexPath.row]
    
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
}
