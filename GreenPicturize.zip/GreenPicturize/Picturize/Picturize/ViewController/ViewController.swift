import UIKit
import SnapKit
import RxSwift
import RxCocoa
import RxDataSources
import RxGesture
import Permission
import Photos
import MobileCoreServices
import MetalKit
import MediaWatermark
import YogaKit
import IHProgressHUD

//@available(iOS 15.0, *)
class ViewController: UIViewController {

    //MARK: - Properties
    let disposeBag = DisposeBag()
    let viewModel = EditViewModel()
    let sliderView = SliderView()
    var constructor = GridConstructor()
    var constructor2 = GridConstructor()
    
    private var fullImageView: UIImageView = {
        let imageView = UIImageView(image: "mainFull".image)
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    private var premiumButton: UIButton = {
        let button = UIButton()
        button.setImage("corona".image, for: .normal)
        button.backgroundColor = "D6FCA6".hexColor.withAlphaComponent(0.63)
        button.layer.cornerRadius = 10
        return button
    }()
 
    //MARK: - pushButton
    private lazy var pushButton: UIButton = {
        let button = UIButton()
        button.setImage("push".image, for: .normal)
        button.backgroundColor = "F3F3F3".hexColor
        button.layer.cornerRadius = 10
        DispatchQueue.main.async {
            button.rx.tap.bind { [weak self] in
                if self?.currentGrid == false {
                    self?.constructor.imagesArray.dropLast()
                    self?.constructor.imagesArray.enumerated().forEach { index, imageView in
                            imageView.image = self?.viewModel.currentQualityImage
                    }
                }
                let parentView = self?.backgroundImageView ?? UIView()
                let object = self?.viewModel.selectedGrid.value?.gridObject
                self?.constructor.configureFinalImage(parentView: parentView, object: object) { [weak self] image in
                    self?.bindImageViews()
                    let vc = PhotoViewController()
                    self?.viewModel.selectedFilter = nil
                    self?.viewModel.selectedImage = nil
                    self?.viewModel.selectedImageView = nil
                    self?.contentCollectionView.reloadData()
                    self?.navigationController?.pushViewController(vc, animated: false)
                    vc.imageCost.accept(self?.getImageCost() ?? 200)
                    vc.image = image   
                }
            }.disposed(by: self.disposeBag)
        }
        return button
    }()
    
    //MARK: Center AddButtom
    
    private var emptyView: UIView = {
        let view = UIView()
        view.backgroundColor = "3DA071".hexColor
        view.layer.cornerRadius = 26
        view.clipsToBounds = false
        return view
    }()
    
    private var addButtonLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.text = "ADD IMAGE"
        label.textAlignment = .center
        label.textColor = .white
        return label
    }()
    
    private var addImageView: UIImageView = {
        let imageView = UIImageView(image: "ic_plus".image)
        return imageView
    }()
    
    private var addButton: UIButton = {
        let button = UIButton()
        return button
    }()
    //---
    
    private lazy var backgroundImageView: UIImageView! = {
        let imageView = UIImageView()
        imageView.clipsToBounds = true
        imageView.contentMode = .scaleAspectFill
        imageView.backgroundColor = .yellow
        imageView.isUserInteractionEnabled = true
        imageView.layer.cornerRadius = 12
        return imageView
    }() 
    
    private lazy var typesCollectionView: UICollectionView = {
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: UICollectionViewLayout())
        collectionView.backgroundColor = .clear
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.isScrollEnabled = false
        return collectionView
    }()
    
    private lazy var gridCollectionView: UICollectionView = {
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: UICollectionViewLayout())
        collectionView.backgroundColor = .clear
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.isScrollEnabled = false
        return collectionView
    }()
    
    private lazy var contentCollectionView: UICollectionView = {
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: UICollectionViewLayout())
        collectionView.backgroundColor = .white
        collectionView.layer.cornerRadius = 10
        collectionView.showsHorizontalScrollIndicator = false
        return collectionView
    }()
    
    private lazy var typesLayout: UICollectionViewLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: (UIScreen.main.bounds.width - 32) / 3, height: 20.resized)
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        return layout
    }()
    
    private lazy var gridsLayout: UICollectionViewLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: (UIScreen.main.bounds.width - 132) / 4, height: 20.resized)
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        return layout
    }()
    
    private lazy var contentLayout: UICollectionViewLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: 72.resized(.width), height: 106)
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 16
        layout.minimumInteritemSpacing = 16
        layout.sectionInset = .init(top: 0, left: 16, bottom: 0, right: 16)
        return layout
    }()
    
    private lazy var imagePicker: UIImagePickerController! = {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.mediaTypes = [kUTTypeImage as String]
        return imagePicker
    }()
    
    //MARK: - Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.sliderView.isHidden = true
        setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if IAPManager.shared().isPurchased {
            premiumButton.isHidden = true
            self.gridCollectionView.reloadData()
            self.typesCollectionView.reloadData()
            self.contentCollectionView.reloadData()
        } else {
            premiumButton.isHidden = false
        }
        navigationController?.isNavigationBarHidden = true
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
    }
    
    var currentGrid = false
    
    
    //MARK: - Setup
    private func setup() {
        setAppearance()
        viewModel.selectedImageView = constructor.imagesArray.first
        bindButtons()
    }
    
    //MARK: - Configure Layout
    private func setAppearance() {
        backgroundImageView.isHidden = true
        configureCollections()
        configureViews()
        setupButton()
        //hideAdditional()
        constructor.configure(parentView: backgroundImageView)
    }
    
    private func configureViews() {
        
        typesCollectionView.setCollectionViewLayout(typesLayout, animated: true)
        gridCollectionView.setCollectionViewLayout(gridsLayout, animated: true)
        contentCollectionView.setCollectionViewLayout(contentLayout, animated: true)
    
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = .red
        view.addSubview(fullImageView)
        
        fullImageView.addSubviews(premiumButton, pushButton, backgroundImageView, emptyView, typesCollectionView, sliderView, gridCollectionView, contentCollectionView)
        emptyView.addSubviews(addButtonLabel, addImageView, addButton)
        bindSlider()
        
        fullImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        premiumButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(39)
            make.leading.equalToSuperview().offset(16)
            make.height.equalTo(44)
            make.width.equalTo(95)
        }
        
        pushButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(39)
            make.trailing.equalToSuperview().offset(-16)
            make.height.equalTo(44)
            make.width.equalTo(95)
        }
        
        emptyView.snp.makeConstraints {
            $0.bottom.equalTo(typesCollectionView.snp.top).offset(-138.resized()) 
            $0.width.equalTo(123)
            $0.height.equalTo(113)
            $0.centerX.equalToSuperview()
        }
        
        addButtonLabel.snp.makeConstraints {
            $0.top.equalToSuperview().offset(28)
            $0.leading.equalToSuperview().offset(10)
            $0.trailing.equalToSuperview().offset(-10)
            $0.height.equalTo(20)
        }
        
        addImageView.snp.makeConstraints {
            $0.bottom.equalToSuperview().offset(-28)
            $0.size.equalTo(31)
            $0.centerX.equalToSuperview()
        }
        
        addButton.snp.makeConstraints {
            $0.top.equalToSuperview()
            $0.leading.equalToSuperview()
            $0.trailing.equalToSuperview()
            $0.bottom.equalToSuperview()
        }
        
        backgroundImageView.snp.makeConstraints {
            $0.top.equalToSuperview().offset(103.resized())
            $0.leading.equalTo(53.resized)
            $0.trailing.equalTo(-53.resized)
            $0.bottom.equalToSuperview().offset(-350.resized())
        }
        
        backgroundImageView.layoutIfNeeded()
        
        sliderView.snp.makeConstraints {
            $0.top.equalTo(typesCollectionView.snp.bottom).offset(20)
            $0.leading.equalTo(16)
            $0.trailing.equalTo(-16)
            $0.height.equalTo(30)
        }
        
        typesCollectionView.snp.makeConstraints {
            $0.leading.equalTo(16.resized(.width))
            $0.trailing.equalTo(-16.resized(.width))
            $0.bottom.equalToSuperview().offset(-250.resized())
            $0.height.equalTo(20.resized)
        }
        
        gridCollectionView.snp.makeConstraints {
            $0.leading.equalTo(66.resized(.width))
            $0.trailing.equalTo(-66.resized(.width))
            $0.top.equalTo(typesCollectionView.snp.bottom).offset(30.resized)
            $0.height.equalTo(20.resized)
        }
        
        contentCollectionView.snp.makeConstraints {
            $0.leading.equalTo(16.resized(.width))
            $0.trailing.equalTo(-16.resized(.width))
            $0.top.equalTo(gridCollectionView.snp.bottom).offset(20.resized)
            $0.height.equalTo(146.resized)
        }
        
       
        DispatchQueue.main.async {
            self.view.layoutIfNeeded()
            self.premiumButton.layer.masksToBounds = false
            self.premiumButton.layer.shadowColor = UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.52).cgColor
            self.premiumButton.layer.shadowOffset = CGSize(width: -5.0, height: 0.0)
            self.premiumButton.layer.shadowOpacity = 1
            self.premiumButton.layer.shadowRadius = 22
        }
        
        emptyView.layer.masksToBounds = false
        emptyView.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.25).cgColor
        emptyView.layer.shadowOffset = CGSize(width: 3.0, height: 4.0)
        emptyView.layer.shadowOpacity = 1
        emptyView.layer.shadowRadius = 36
    }
    
    private func hideAdditional() {
        gridCollectionView.isHidden = self.viewModel.selectedTypeIndex != typesCollectionView.numberOfItems(inSection: 0) - 1
        sliderView.isHidden = !gridCollectionView.isHidden
    }
    
    private func hideAdditionalTwo() {
  
        gridCollectionView.isHidden = self.viewModel.selectedTypeIndex != typesCollectionView.numberOfItems(inSection: 0) - 1
//        sliderView.isHidden = !gridCollectionView.isHidden
    }
    
    //MARK: Resise photo
    func resizeImage(image: UIImage) -> UIImage {
            var actualHeight: Float = Float(image.size.height)
            var actualWidth: Float = Float(image.size.width)
            let maxHeight: Float = 150.0
            let maxWidth: Float = 250.0
            var imgRatio: Float = actualWidth / actualHeight
            let maxRatio: Float = maxWidth / maxHeight
        let compressionQuality: Float = 0.6
            //50 percent compression
            if actualHeight > maxHeight || actualWidth > maxWidth {
                if imgRatio < maxRatio {
                    //adjust width according to maxHeight
                    imgRatio = maxHeight / actualHeight
                    actualWidth = imgRatio * actualWidth
                    actualHeight = maxHeight
                } else if imgRatio > maxRatio {
                    //adjust height according to maxWidth
                    imgRatio = maxWidth / actualWidth
                    actualHeight = imgRatio * actualHeight
                    actualWidth = maxWidth
                } else {
                    actualHeight = maxHeight
                    actualWidth = maxWidth
                }
            }
        
            let rect = CGRect(x: 0.0, y: 0.0, width: Double(actualWidth), height: Double(actualHeight))
            UIGraphicsBeginImageContext(rect.size)
            image.draw(in: rect)
            let img = UIGraphicsGetImageFromCurrentImageContext()
            let imageData = img!.jpegData(compressionQuality: CGFloat(compressionQuality))
            UIGraphicsEndImageContext()
            return UIImage(data: imageData!)!
        }
    
//MARK: setup Button
    
    private func setupButton(){
        premiumButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.presentSubscription()
        }.disposed(by: disposeBag)
    }
    
    private func presentSubscription() {
        if !IAPManager.shared().isPurchased {
            Constants.ud.currentDismis = 2
            IAPManager.shared().presentSingleSubscriptionVC()
            IAPManager.shared().purchaseCompletion = { _ in
                IAPManager.shared().dismissSubscriptionVC()
            }
            IAPManager.shared().restoreCompletion = { subscription in
                IAPManager.shared().dismissSubscriptionVC()
                if Constants.ud.isPurchased {
                    AlertManager.shared().showPurchasesWereRestored()
                }
            }
        }
    }
    
    private func configureCollections() {
        typesCollectionView.register(TypeCell.self, forCellWithReuseIdentifier: TypeCell.nibIdentifier)
        gridCollectionView.register(TypeCell.self, forCellWithReuseIdentifier: TypeCell.nibIdentifier)
        contentCollectionView.register(ObjectCell.self, forCellWithReuseIdentifier: ObjectCell.nibIdentifier)
        contentCollectionView.register(GridCell.self, forCellWithReuseIdentifier: GridCell.nibIdentifier)
        
        configureDataSources()
        bindCollectionSelections()
    }
    
    private func configureDataSources() {
        let typesDataSource = RxCollectionViewSectionedReloadDataSource<SectionModel<String, EditCategory>>(configureCell: { [weak self] (datasource, collectionView, indexPath, category) in
            guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: TypeCell.nibIdentifier, for: indexPath) as? TypeCell else { return UICollectionViewCell() }
            cell.style = .type
            cell.titleLabel.textColor = self?.viewModel.selectedTypeIndex == indexPath.item ? "3EA071".hexColor : .black
            cell.titleLabel.text = category.title
            return cell
        })
        
        let gridDataSource = RxCollectionViewSectionedReloadDataSource<SectionModel<String, EditCategory>>(configureCell: { [weak self] (datasource, collectionView, indexPath, category) in
            guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: TypeCell.nibIdentifier, for: indexPath) as? TypeCell else { return UICollectionViewCell() }
            cell.style = .subType
            cell.titleLabel.textColor = self?.viewModel.selectedSubTypeIndex == indexPath.item ? "3EA071".hexColor : .black
            cell.titleLabel.text = category.title
            return cell
        })
        
        let contentDataSource = RxCollectionViewSectionedReloadDataSource<SectionModel<String, EditObject>>(configureCell: { [weak self] (datasource, collectionView, indexPath, object) in
            if object.type == .background || object.type == .filter {
                guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ObjectCell.nibIdentifier, for: indexPath) as? ObjectCell else { return UICollectionViewCell() }
                switch object.type {
                case .background:
                    self?.viewModel.selectedBackgroundIndex == indexPath.item ? cell.setSelected() : cell.setOriginal()
                    self?.hideAdditional()
                case .filter:
                    
                    let filter = object.filter
                    self?.viewModel.selectedFilter == filter ? cell.setSelected() : cell.setOriginal()
                    cell.mainImage = self?.viewModel.selectedImage != nil ? self?.viewModel.selectedImage?.resizedImage(0.2) : nil
//                    cell.mainImage =  self?.viewModel.selectedImage != nil ? self?.viewModel.currentQualityImage  : nil
                    cell.filter = filter
                    self?.hideAdditionalTwo()
                default: break
                }
                cell.object = object
              
                return cell
            } else {
                guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: GridCell.nibIdentifier, for: indexPath) as? GridCell else { return UICollectionViewCell() }
                cell.object = object
                cell.objectView.backgroundColor = self?.viewModel.selectedGrid.value == object ? "3EA071".hexColor : "F0F0F0".hexColor
                var congigure = self?.viewModel.selectedGrid.value == object ? cell.configureViewsSelectedGrid() : cell.configureViewsNotSelectedGrid()
            
                return cell
            }
        })
        
        viewModel.types
            .bind(to: typesCollectionView.rx.items(dataSource: typesDataSource))
            .disposed(by: disposeBag)
        
        viewModel.subTypes
            .bind(to: gridCollectionView.rx.items(dataSource: gridDataSource))
            .disposed(by: disposeBag)
        
    
        viewModel.content
                .bind(to: contentCollectionView.rx.items(dataSource: contentDataSource))
                .disposed(by: disposeBag)
        
    }
    
    func presentSubscriptionsViewController() {
        Constants.ud.currentDismis = 2
        IAPManager.shared().presentSingleSubscriptionVC()
        IAPManager.shared().purchaseCompletion = { _ in
            IAPManager.shared().dismissSubscriptionVC()
        }
        IAPManager.shared().restoreCompletion = { subscription in
            IAPManager.shared().dismissSubscriptionVC()
            if Constants.ud.isPurchased {
                AlertManager.shared().showPurchasesWereRestored()
            }
        }
    }
    
    private func bindCollectionSelections() {

            self.typesCollectionView.rx.itemSelected.bind { [weak self] indexPath in
            self?.viewModel.selectedTypeIndex = indexPath.item
            self?.contentCollectionView.setContentOffset(.zero, animated: false)
            if indexPath.item != EditModel().typeArray.count - 1 {
                let category = EditModel().typeArray[indexPath.item]
                self?.viewModel.content.accept([SectionModel(model: "", items: category.objects)])
                self?.sliderView.setType(type: category.title == "FILTERS" ? .opacity : .rescale)
                if indexPath.item == 0 {
                    self?.sliderView.isHidden = true
                } else {
                    self?.sliderView.isHidden = false
                }
            } else {
                let category = EditModel().subTypesArray[self?.viewModel.selectedSubTypeIndex ?? 0]
                let objects = category.objects
                self?.viewModel.content.accept([SectionModel(model: "", items: objects)])
                self?.gridCollectionView.reloadData()
                self?.hideAdditional()
            }
            
            self?.typesCollectionView.reloadData()
        }.disposed(by: self.disposeBag)
        
        
        
            self.gridCollectionView.rx.itemSelected.bind { [weak self] indexPath in
            self?.viewModel.selectedSubTypeIndex = indexPath.item
            let category = EditModel().subTypesArray[indexPath.item]
            self?.viewModel.content.accept([SectionModel(model: "", items: category.objects)])
            self?.gridCollectionView.reloadData()
            }.disposed(by: self.disposeBag)
        
        
//        DispatchQueue.main.async {
            self.contentCollectionView
            .rx
            .itemSelected
            .compactMap({ [weak self] index -> (EditObject, IndexPath)? in
                if let cell = self?.contentCollectionView.cellForItem(at: index) as? ObjectCell, let object = cell.object {
                    return (object, index)
                } else if let cell = self?.contentCollectionView.cellForItem(at: index) as? GridCell, let object = cell.object {
                    return (object, index)
                } else {
                    return nil
                }
                
            })
            .bind { [weak self] object, indexPath in
                if PhotoCoinsManager.shared.hasEnough(cost: object.cost) {
                    DispatchQueue.main.async {
                        switch object.type {
                        case .background:
                            self?.sliderView.isHidden = false
                            if !IAPManager.shared().isPurchased {
                                if indexPath.item < 3 {
                                    self?.constructor.mainView.image = object.image
                                    self?.viewModel.selectedBackgroundIndex = indexPath.item
                                    self?.viewModel.backgroundPrice.accept(object.cost)
                                } else {
                                    if !IAPManager.shared().isPurchased {
                                        self?.presentSubscriptionsViewController()
                                    } else {
                                        self?.constructor.mainView.image = object.image
                                        self?.viewModel.selectedBackgroundIndex = indexPath.item
                                        self?.viewModel.backgroundPrice.accept(object.cost)
                                    }
                                }
                            } else {
                                self?.constructor.mainView.image = object.image
                                self?.viewModel.selectedBackgroundIndex = indexPath.item
                                self?.viewModel.backgroundPrice.accept(object.cost)
                            }
                            
                            break
                        case .filter:
                           
                            if !IAPManager.shared().isPurchased {
                                if indexPath.item == 0 {
                                    self?.sliderView.isHidden = true
                                } else {
                                    self?.sliderView.isHidden = false
                                }
                                if indexPath.item < 3 {

                                    let filter = object.filter
                                    self?.constructor.imagesArray.enumerated().forEach { (arg) in
                                        let (index, imageView) = arg
                                        if imageView.image != nil {
                                            imageView.image = indexPath.item == 0 ? self?.viewModel.imagesArray?[index] : self?.viewModel.imagesArray?[index].acceptFilter(filter)
                                            
                                            self?.viewModel.currentQualityImage = indexPath.item == 0 ? self?.viewModel.imagesArray?[index] : self?.viewModel.imagesArray?[index].acceptFilter(filter)
                                        }
                                    }
                                    self?.viewModel.filterPrice.accept(object.cost)
                                    self?.sliderView.slider.value = self?.sliderView.slider.maximumValue ?? 0
                                    self?.viewModel.selectedFilter = filter
                                } else {
                                    if !IAPManager.shared().isPurchased {
                                        self?.presentSubscriptionsViewController()
                                    } else {
                                        let filter = object.filter
                                        self?.constructor.imagesArray.enumerated().forEach { (arg) in
                                            let (index, imageView) = arg
                                            if imageView.image != nil {
                                                imageView.image = indexPath.item == 0 ? self?.viewModel.imagesArray?[index] : self?.viewModel.imagesArray?[index].acceptFilter(filter)
                                                
                                                self?.viewModel.currentQualityImage = indexPath.item == 0 ? self?.viewModel.imagesArray?[index] : self?.viewModel.imagesArray?[index].acceptFilter(filter)
                                            }
                                        }
                                        self?.viewModel.filterPrice.accept(object.cost)
                                        self?.sliderView.slider.value = self?.sliderView.slider.maximumValue ?? 0
                                        self?.viewModel.selectedFilter = filter
                                    }
                                }
                            } else {
                                if indexPath.item == 0 {
                                    self?.sliderView.isHidden = true
                                } else {
                                    self?.sliderView.isHidden = false
                                }
                                let filter = object.filter
                                self?.constructor.imagesArray.enumerated().forEach { (arg) in
                                    let (index, imageView) = arg
                                    if imageView.image != nil {
                                        imageView.image = indexPath.item == 0 ? self?.viewModel.imagesArray?[index] : self?.viewModel.imagesArray?[index].acceptFilter(filter)
                                        
                                        self?.viewModel.currentQualityImage = indexPath.item == 0 ? self?.viewModel.imagesArray?[index] : self?.viewModel.imagesArray?[index].acceptFilter(filter)
                                    }
                                }
                                self?.viewModel.filterPrice.accept(object.cost)
                                self?.sliderView.slider.value = self?.sliderView.slider.maximumValue ?? 0
                                self?.viewModel.selectedFilter = filter
                            }
                            
                            break
                        case .grid:
                            self?.currentGrid = true
                            self?.sliderView.isHidden = true
                            if object.cost > 0 {
                                if !IAPManager.shared().isPurchased {
                                    self?.presentSubscriptionsViewController()
                                } else {
                                    self?.backgroundImageView.isHidden = false
                                    self?.emptyView.isHidden = true
                                    self?.viewModel.selectedGrid.accept(object)
                                    self?.constructor.setLayout(object: object.gridObject)
                                    self?.bindImageViews()
                                    self?.viewModel.imagesArray?.removeAll()
                                    self?.constructor.imagesArray.forEach { _ in
                                        self?.viewModel.imagesArray?.append(UIImage())
                                    }
                                }
                            } else {
                                self?.backgroundImageView.isHidden = false
                                self?.emptyView.isHidden = true
                                self?.viewModel.selectedGrid.accept(object)
                                self?.constructor.setLayout(object: object.gridObject)
                                self?.bindImageViews()
                                self?.viewModel.imagesArray?.removeAll()
                                self?.constructor.imagesArray.forEach { _ in
                                    self?.viewModel.imagesArray?.append(UIImage())
                                }
                                self?.contentCollectionView.reloadData()
                            }
                            
                            break
                        }
                        self?.contentCollectionView.reloadData()
                    }
                }
            }.disposed(by: self.disposeBag)
    }
    
    private func bindSlider() {
        sliderView.slider.rx.value
            .observeOn(ConcurrentDispatchQueueScheduler(qos: .userInteractive))
            .debounce(.milliseconds(50), scheduler: ConcurrentDispatchQueueScheduler(qos: .userInteractive))
            .bind { [weak self] value in
                DispatchQueue.main.async { [weak self] in
                    guard let self = self else { return }
                    let type = self.sliderView.type.value
                    switch type {
                    case .opacity:
                        DispatchQueue.global(qos: .userInteractive).async {
                            if self.viewModel.selectedFilter == nil { return }
                            self.viewModel.selectedFilter?.setValue(value, forKey: "inputIntensity")
                            self.constructor.imagesArray.enumerated().forEach { index, imageView in
                                DispatchQueue.main.async {
                                    if imageView.image == nil { return }
                                    imageView.image = self.viewModel.imagesArray?[index].acceptFilter(self.viewModel.selectedFilter)
       
                                    self.viewModel.currentQualityImage = self.viewModel.imagesArray?[index].acceptFilter(self.viewModel.selectedFilter)
                                }
                            }
                        }
                        break
                    case .rescale:
                        let object = self.viewModel.selectedGrid.value?.gridObject
                        object?.outerPriorityDirection != nil ? self.constructor.changeSpaces(mainView: self.constructor.mainView, value: value, object: object)
                        : self.constructor.changeSpaces(mainView: self.constructor.mainView, value: value)
                    }
                }
            }.disposed(by: disposeBag)
    }
    
    //MARK: - Actions
    private func bindButtons() {
        addButton
            .rx
            .tap
            .bind { [weak self] in
                self?.viewModel.imagesArray?.append(UIImage())
                self?.chooseAction()
            }.disposed(by: disposeBag)
        
        bindImageViews()
    }
    
    private func bindImageViews() {
        constructor.imagesArray.forEach { imgView in
            print(imgView.tag)
            imgView
                .rx
                .gesture(UITapGestureRecognizer())
                .when(.recognized)
                .bind { [weak self] _ in
                    self?.viewModel.selectedImageView = imgView
                    self?.chooseAction()
                }.disposed(by: disposeBag)
            
            (imgView.subviews.first as? UIButton)?
                .rx
                .tap
                .debug("\((imgView.subviews.first as? UIButton)!.tag)")
                .bind { [weak self] _ in
                    self?.viewModel.selectedImageView = imgView
                    self?.chooseAction()
                }.disposed(by: disposeBag)
        }
    }
    
    private func chooseAction() {
        let alertController = UIAlertController(title: "Choose option", message: "", preferredStyle: .actionSheet)
        let cameraAction = UIAlertAction(title: "Camera", style: .default) { [weak self] _ in
          
            self?.openMedia(sourceType: .camera)
        }
        let galleryAction = UIAlertAction(title: "Photos", style: .default) { [weak self] _ in
            IHProgressHUD.show()
            self?.openMedia(sourceType: .photoLibrary)
            
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { _ in
            IHProgressHUD.dismiss()
            alertController.dismiss(animated: true, completion: nil)
        }
        alertController.addAction(cameraAction)
        alertController.addAction(galleryAction)
        alertController.addAction(cancelAction)
        present(alertController, animated: true, completion: nil)
    }
    
    private func openMedia(sourceType: UIImagePickerController.SourceType) {
        imagePicker.sourceType = sourceType
        switch sourceType {
        case .camera: setupCamera()
           
        case .photoLibrary:
            IHProgressHUD.show()
            setupGallery()
            
        default: break
        }
        present(imagePicker, animated: true, completion: nil)
    }
    
    private func setupCamera() {
        if viewModel.cameraStatus != .authorized {
            if viewModel.cameraStatus == .denied || viewModel.cameraStatus == .disabled {
                UIApplication.settingsAlert(message: "Can't initialize camera. Please go to settings.")
                return
            }
            Permission.camera.request { [weak self] status in
                self?.viewModel.cameraStatus = status
               
                if status == .denied {
                    self?.imagePicker.dismiss(animated: true, completion: nil)
                   
                }
            }
        }
    }
    
    private func setupGallery() {
        
        if viewModel.photoStatus != .authorized {
            if viewModel.photoStatus == .denied || viewModel.photoStatus == .restricted {
                UIApplication.settingsAlert(message: "Can't initialize camera. Please go to settings.")
                return
            }
        }
        PHPhotoLibrary.requestAuthorization { [weak self] status in
            self?.viewModel.photoStatus = status
            IHProgressHUD.dismiss()
            if status == .denied {
                self?.imagePicker.dismiss(animated: true, completion: nil)
                IHProgressHUD.dismiss()
            }
        }
    }
    
    private func getImageCost() -> Int {
        let imageCost = viewModel.backgroundPrice.value + viewModel.filterPrice.value + 200 + (viewModel.selectedGrid.value?.cost ?? 0)
        return imageCost
    }
}

//@available(iOS 15.0, *)
extension ViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let image = info[.originalImage] as? UIImage else { return }
        var lastIndex = 0
        viewModel.currentQualityImage = image
        viewModel.selectedImage = image.resizedImage(0.3)
        picker.dismiss(animated: true, completion: nil)
        viewModel.selectedImageView?.image = viewModel.selectedImage
        constructor.imagesArray.enumerated().forEach { index, imageView in
            if viewModel.selectedImageView == imageView { lastIndex = index }
        }
        viewModel.imagesArray?[lastIndex] = viewModel.selectedImage ?? UIImage()
        backgroundImageView.isHidden = false
        emptyView.isHidden = true
        sliderView.slider.setValue(viewModel.selectedTypeIndex == 0 ? sliderView.slider.maximumValue : sliderView.slider.maximumValue / 4, animated: true)
        
        if viewModel.selectedTypeIndex == 1 {
            let object = viewModel.selectedGrid.value?.gridObject
            object?.outerPriorityDirection != nil ? constructor.changeSpaces(mainView: constructor.mainView, value: sliderView.slider.value, object: object)
            : constructor.changeSpaces(mainView: constructor.mainView, value: sliderView.slider.value)
        }
        
        guard let category = EditModel().typeArray.first, let filter = category.objects.first?.filter else { contentCollectionView.reloadData(); return }
        viewModel.selectedFilter = filter
        contentCollectionView.reloadData()
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
