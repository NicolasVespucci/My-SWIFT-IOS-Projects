import Foundation
import RxDataSources
import RxCocoa
import RxSwift
import Photos
import Permission
import CoreImage

class EditViewModel {
  
  //MARK: - Layout models
  public let types: BehaviorRelay<[SectionModel<String, EditCategory>]> = .init(value: [SectionModel(model: "", items: EditModel().typeArray)])
  public let subTypes: BehaviorRelay<[SectionModel<String, EditCategory>]> = .init(value: [SectionModel(model: "", items: EditModel().subTypesArray)])
  public var content: BehaviorRelay<[SectionModel<String, EditObject>]> = .init(value: [SectionModel(model: "", items: EditModel().typeArray.first!.objects)])
  
  public var selectedTypeIndex = 0
  public var selectedSubTypeIndex = 0
  public var selectedBackgroundIndex = -1
  public lazy var selectedGrid: BehaviorRelay<EditObject?> = {
    guard let category = EditModel().subTypesArray.first, let object = category.objects.first else { return .init(value: nil) }
    return .init(value: object)
  }()
  
  //MARK: - Image models
  public var backgroundPrice: BehaviorRelay<Int> = .init(value: 0)
  public var filterPrice: BehaviorRelay<Int> = .init(value: 0)
  public var selectedImage: UIImage? = nil
  public var currentQualityImage: UIImage? = nil
  public var selectedImageView: UIImageView? = nil
  public var imagesArray: [UIImage]? = [UIImage]()
  public var imagesArray2: [UIImage]? = [UIImage]()
  public var cameraStatus: PermissionStatus = .notDetermined
  public var photoStatus: PHAuthorizationStatus = .notDetermined
  
  //MARK: - Filter models
  public var selectedFilter: CIFilter?
  
  public func configureFilter(_ url: URL?) -> CIFilter? {
    let filter = CIFilter(name: "YUCIColorLookup", parameters: [:])
    guard let url = url else { return nil }
    let loot = CIImage(contentsOf: url)
    filter?.setValue(loot, forKey: "inputColorLookupTable")
    return filter
  }
}
