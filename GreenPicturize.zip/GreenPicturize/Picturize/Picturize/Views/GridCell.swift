import UIKit
import SnapKit

//@available(iOS 15.0, *)
class GridCell: UICollectionViewCell {
  
  var object: EditObject? {
    didSet {
      guard let object = object else { return }
     // objectImageView.image = object.image
      costLabel.text = ""
      updateLayout()
    }
  }
  
  public lazy var objectView: UIView = {
    let view = UIView()
    view.backgroundColor = .clear
    view.layer.cornerRadius = 10
    return view
  }()
  
  private lazy var objectImageView: UIImageView = {
    let imageView = UIImageView()
    imageView.contentMode = .scaleAspectFit
    return imageView
  }()
  
  private lazy var costLabel: UILabel! = {
    let label = UILabel()
    label.textColor = .white
    label.font = UIFont.systemFont(ofSize: 13, weight: .semibold)
    label.adjustsFontSizeToFitWidth = true
    label.textAlignment = .left
    label.text = "20"
    label.minimumScaleFactor = 0.5
    return label
  }()
  
  private lazy var coinImageView: UIImageView! = {
    let imageView = UIImageView(image: "castle".image)
    imageView.contentMode  = .scaleAspectFill
    return imageView
  }()
  
  private lazy var costView: UIView! = {
    let view = UIView()
    view.backgroundColor = .clear
    return view
  }()
  
  override init(frame: CGRect) {
    super.init(frame: frame)
    //configureViewsSelected()
  }
  
  required init?(coder: NSCoder) {
    super.init(coder: coder)
  }
  
  public func configureViewsSelectedGrid() {
      costView.subviews.forEach({
          $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
          $0.removeFromSuperview()
      })
      
      objectView.subviews.forEach({
          $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
          $0.removeFromSuperview()
      })
      
      subviews.forEach({
          $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
          $0.removeFromSuperview()
      })
      
    addSubview(objectView)
    addSubview(costView)
    
    costView.addSubview(coinImageView)
    objectView.addSubview(objectImageView)
    
    objectView.snp.makeConstraints {
      $0.top.equalToSuperview()
      $0.leading.equalToSuperview()
      $0.size.equalTo(72)
    }
    
    objectImageView.snp.makeConstraints {
      $0.size.equalTo(32)
      $0.center.equalToSuperview()
    }

    costView.snp.makeConstraints {
      $0.top.equalTo(objectView.snp.bottom).offset(19)
      $0.leading.equalToSuperview()
      $0.width.equalToSuperview()
      $0.height.equalTo(15)
    }
    
    costView.addSubview(coinImageView)
    
    coinImageView.snp.makeConstraints {
        $0.top.equalToSuperview().offset(-7)
        $0.centerX.equalToSuperview()
        $0.width.equalTo(13)
        $0.height.equalTo(20)
    }
      
      objectImageView.image = object?.image
  }
    
    public func configureViewsNotSelectedGrid() {
        costView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeFromSuperview()
        })
        
        objectView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeFromSuperview()
        })
      addSubview(objectView)
      addSubview(costView)
      
      costView.addSubview(coinImageView)
      objectView.addSubview(objectImageView)
      
      objectView.snp.makeConstraints {
        $0.top.equalToSuperview()
        $0.leading.equalToSuperview()
        $0.size.equalTo(72)
      }
      
      objectImageView.snp.makeConstraints {
        $0.size.equalTo(32)
        $0.center.equalToSuperview()
      }

      costView.snp.makeConstraints {
        $0.top.equalTo(objectView.snp.bottom).offset(19)
        $0.leading.equalToSuperview()
        $0.width.equalToSuperview()
        $0.height.equalTo(15)
      }
      
      costView.addSubview(coinImageView)
      
      coinImageView.snp.makeConstraints {
          $0.top.equalToSuperview().offset(-7)
          $0.centerX.equalToSuperview()
          $0.width.equalTo(13)
          $0.height.equalTo(20)
      }
        objectImageView.image = object?.imageNotSelected
    }
  
  private func updateLayout() {
    guard let object = object else { return }
    if object.cost == 0 {
      coinImageView.isHidden = true
    } else {
        if IAPManager.shared().isPurchased {
            coinImageView.isHidden = true
        } else {
            coinImageView.isHidden = false
        }
      
    }
  }
}
