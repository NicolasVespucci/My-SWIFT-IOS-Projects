import UIKit
import SnapKit
import CoreImage

//@available(iOS 15.0, *)
class ObjectCell: UICollectionViewCell {
  
  //MARK: - Properties
  public var object: EditObject? {
    didSet {
      guard let object = object else { return }
      guard let _ = object.image else { configureURL(object: object); updateLayout(); return }
      configureImage(object: object)
      updateLayout()
    }
  }
  
  public var mainImage: UIImage?
  
  public var filter: CIFilter?
  
  private lazy var objectView: UIView! = {
    let view = UIView()
    view.backgroundColor = .clear
    view.layer.cornerRadius = 12
    return view
  }()
  
  private lazy var objectImageView: UIImageView! = {
    let imageView = UIImageView()
    imageView.contentMode = .scaleAspectFill
    imageView.clipsToBounds = true
    imageView.layer.cornerRadius = 10
    return imageView
  }()
  
  private lazy var costLabel: UILabel! = {
    let label = UILabel()
    label.textColor = .white
    label.font = UIFont.systemFont(ofSize: 13, weight: .semibold)
    label.adjustsFontSizeToFitWidth = true
    label.textAlignment = .left
    label.text = "20"
    label.minimumScaleFactor = 0.5
    return label
  }()
  
  private lazy var coinImageView: UIImageView! = {
    let imageView = UIImageView(image: "castle".image)
    imageView.contentMode  = .scaleAspectFill
    return imageView
  }()
  
  private lazy var costView: UIView! = {
    let view = UIView()
    view.backgroundColor = .clear
    return view
  }()
  
  required init?(coder: NSCoder) {
    fatalError("HEY")
  }
  
  override init(frame: CGRect) {
    super.init(frame: frame)
    clipsToBounds = false
    addSubview(objectView)
    addSubview(costView)
    
    objectView.snp.makeConstraints {
      $0.size.equalTo(78)
      $0.top.equalToSuperview().inset(-3)
      $0.leading.equalToSuperview().inset(-3)
    }
    
    objectView.addSubview(objectImageView)
    
    objectImageView.snp.makeConstraints {
      $0.top.equalToSuperview().offset(3)
      $0.leading.equalToSuperview().offset(3)
      $0.size.equalTo(72)
    }
    
    costView.snp.makeConstraints {
      $0.top.equalTo(objectImageView.snp.bottom).offset(19)
      $0.leading.equalToSuperview()
      $0.width.equalToSuperview()
      $0.height.equalTo(15)
    }
    
    
    costView.addSubview(coinImageView)
    
    coinImageView.snp.makeConstraints {
        $0.top.equalToSuperview().offset(-7)
        $0.centerX.equalToSuperview()
        $0.width.equalTo(13)
        $0.height.equalTo(20)
    }
    
  
  }
  
  func setSelected() {
    objectView.layer.addBorder(color: .lightGray, width: 1)
  }
  
  func setOriginal() {
    objectView.layer.borderWidth = 0
  }
  
  private func configureImage(object: EditObject) {
    objectImageView.image = object.image; costLabel.text = ""
  }
  
  private func configureURL(object: EditObject) {
    if let image = mainImage {
      let readyImage = object.filter == nil ? image.resizedImage(0.5) : image.resizedImage(0.5)!.acceptFilter(filter)
      objectImageView.image = readyImage
    } else {
      let placeHolder = UIColor.white.image(CGSize(width: 72, height: 72))
      objectImageView.image = filter != nil ? placeHolder.acceptFilter(filter) : placeHolder
    }
  }
  
  private func updateLayout() {
    guard let object = object else { return }
    if object.cost == 0 {
      coinImageView.isHidden = true
    } else {
        if IAPManager.shared().isPurchased {
            coinImageView.isHidden = true
        } else {
            coinImageView.isHidden = false
        }
    }
  }
}
