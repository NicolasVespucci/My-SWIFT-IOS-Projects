import UIKit

class PresentScrollView: UIView {

    var image: UIImage?
    var generalImage: UIImage?
    var topText: String?
    var bottomText: String?
    
    
    private lazy var centerImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private lazy var generalImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private lazy var firstLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 28, weight: .semibold)
        label.textColor = "404147".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .center
        return label
    }()
    
    private lazy var secondLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.textColor = "74757A".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()
    
    private var nextButton: UIButton = {
        let button = UIButton()
        button.setTitle("NEXT", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 18, weight: .semibold)
        button.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.25).cgColor
        button.layer.shadowOffset = CGSize(width: 3.0, height: 6.0)
        button.layer.shadowOpacity = 1
        button.layer.shadowRadius = 12
        button.layer.masksToBounds = false
        return button
    }()
    
    init(image: UIImage, generalImage: UIImage, topText: String, bottomText: String) {
        super.init(frame: .zero)
        self.image = image
        self.generalImage = generalImage
        self.topText = topText
        self.bottomText = bottomText
        isUserInteractionEnabled = true
        launch()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func launch() {
        configureLayout()
        configureViewContent()
    }
    
    private func configureLayout() {
        addSubviews(centerImageView)
        centerImageView.addSubviews(generalImageView, firstLabel, secondLabel)
        
        centerImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview().offset(10)
            make.bottom.equalToSuperview()
        }
        
        generalImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(90)
            make.centerX.equalToSuperview()
            make.width.equalTo(292)
            make.height.equalTo(304)
        }
    
        firstLabel.snp.makeConstraints { make in
            make.top.equalTo(generalImageView.snp.bottom).offset(27.resized())
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(32)
        }
        
        secondLabel.snp.makeConstraints { make in
            make.top.equalTo(firstLabel.snp.bottom).offset(12)
            make.leading.equalToSuperview().offset(22)
            make.trailing.equalToSuperview().offset(-22)
            make.height.equalTo(90)
            
        }
    }
    
    private func configureViewContent() {
        centerImageView.image = image
        generalImageView.image = generalImage
        firstLabel.text = topText
        secondLabel.text = bottomText
    }

}


