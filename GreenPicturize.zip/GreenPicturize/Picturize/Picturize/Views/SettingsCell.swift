import UIKit
import SnapKit

class SettingsCell: UITableViewCell {
  
  static var identifier: String { return String(describing: self) }
  
  private lazy var fullView: UIView = {
    let view = UIView()
    view.backgroundColor = .clear
    return view
  }()
  
  private lazy var chevronImageView: UIImageView = {
    let imageView = UIImageView()
    imageView.contentMode = .scaleAspectFit
    imageView.image = "ic_chevron".image
    return imageView
  }()
  
  private lazy var typeLabel: UILabel = {
    let label = UILabel()
    label.textColor = "404147".hexColor
    label.adjustsFontSizeToFitWidth = true
    label.font = UIFont.systemFont(ofSize: 17)
    label.minimumScaleFactor = 0.5
    return label
  }()
  
  public var type: String = "" {
    didSet { typeLabel.text = type }
  }
  
  override func layoutSubviews() {
    super.layoutSubviews()
      selectionStyle = .none
    configure()
  }
  
  private func configure() {
      addSubview(fullView)
      fullView.addSubviews(typeLabel, chevronImageView)
      
      fullView.snp.makeConstraints { make in
          make.top.equalToSuperview()
          make.leading.equalToSuperview()
          make.trailing.equalToSuperview()
          make.bottom.equalToSuperview()
      }
      
      typeLabel.snp.makeConstraints {
          $0.leading.equalToSuperview().offset(15)
          $0.height.equalTo(24)
          $0.centerY.equalToSuperview()
      }
      
      chevronImageView.snp.makeConstraints {
          $0.size.equalTo(24)
          $0.trailing.equalToSuperview()
          $0.centerY.equalToSuperview()
      }
  }
}
