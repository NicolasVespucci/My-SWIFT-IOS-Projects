import UIKit
import RxSwift
import RxCocoa
import SnapKit

enum SliderType {
  case rescale
  case opacity
}

class SliderView: UIView {
  
  public var type: BehaviorRelay<SliderType> = .init(value: .opacity)
  private var disposeBag = DisposeBag()
  
  public lazy var slider: UISlider! = {
    let slider = UISlider()
      slider.tintColor = "3DA071".hexColor
    slider.minimumValue = 0
    slider.maximumValue = 20
    slider.value = slider.maximumValue
      slider.maximumTrackTintColor = .white
    return slider
  }()
  
  private lazy var typeImageView: UIImageView! = {
    let imageView = UIImageView()
    imageView.contentMode = .scaleAspectFit
    return imageView
  }()
  
  override init(frame: CGRect) {
    super.init(frame: frame)
    configureViews()
    bindType()
  }
  
  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  private func bindType() {
    type.bind { [weak self] type in
      self?.typeImageView.image = type == .opacity ? "ic_opacity".image : "ic_rescale".image
      self?.slider.maximumValue = type == .opacity ? 1 : 20
    }.disposed(by: disposeBag)
  }
  
  private func configureViews() {
    addSubview(typeImageView)
    addSubview(slider)
    
    typeImageView.snp.makeConstraints {
      $0.centerY.equalToSuperview()
      $0.leading.equalToSuperview()
      $0.size.equalTo(24)
    }
    
    slider.snp.makeConstraints {
      $0.leading.equalTo(typeImageView.snp.trailing).offset(9)
      $0.trailing.equalToSuperview()
      $0.centerY.equalToSuperview()
    }
  }
  
  public func setType(type: SliderType) {
    self.type.accept(type)
  }
}
