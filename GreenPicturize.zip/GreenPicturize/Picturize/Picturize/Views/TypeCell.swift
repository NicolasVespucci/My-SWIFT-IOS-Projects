import UIKit
import SnapKit

class TypeCell: UICollectionViewCell {
  override var reuseIdentifier: String? {
    return "\(self)"
  }
  
  var style: Style? {
    didSet { setStyle() }
  }
  
  enum Style {
    case type
    case subType
  }
  
  public lazy var titleLabel: UILabel = {
    let label = UILabel()
    label.textAlignment = .center
    label.adjustsFontSizeToFitWidth = true
    label.minimumScaleFactor = 0.5
    return label
  }()
  
  override init(frame: CGRect) {
    super.init(frame: frame)
    backgroundColor = .clear
    addSubview(titleLabel)
    titleLabel.snp.makeConstraints {
      $0.size.equalToSuperview()
      $0.center.equalToSuperview()
    }
  }
  
  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  private func setStyle() {
    guard let style = style else { return }
    switch style {
    case .type:
      titleLabel.font = UIFont.systemFont(ofSize: 13, weight: .bold)
      titleLabel.textColor = "#EFEFF4".hexColor
    case .subType:
      titleLabel.font = UIFont.systemFont(ofSize: 13, weight: .semibold)
      titleLabel.textColor = .white
    }
  }
}
