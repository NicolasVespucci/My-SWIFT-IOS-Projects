//
//  ContentBlockerRequestHandler.swift
//  ContentBlocker
//
//  Created by Mac on 14.03.22.
//

import UIKit
import MobileCoreServices

class ContentBlockerRequestHandler: NSObject, NSExtensionRequestHandling {

    func beginRequest(with context: NSExtensionContext) {
      guard let url = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: "group.com.app.hotlocker")?
      .appendingPathComponent("customblockerList.json") else { return }
      guard let attachment = NSItemProvider(contentsOf: url) else { return }

      let item = NSExtensionItem()
      item.attachments = [attachment]

      context.completeRequest(returningItems: [item], completionHandler: nil)
    }
    
}
