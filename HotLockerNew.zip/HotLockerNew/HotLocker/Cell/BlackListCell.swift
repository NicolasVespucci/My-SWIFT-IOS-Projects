import UIKit

class BlackListCell: UITableViewCell {

    var customDomain: String? {
        didSet {
            guard let domain = customDomain else { return }
            urlLabel.text = domain
        }
    }
    
    private lazy var cellView: UIView = {
        let view = UIView()
        view.layer.masksToBounds = true
        view.backgroundColor = "208E92".hexColor.withAlphaComponent(0.03)
        view.layer.cornerRadius = 16
        view.addBorder(width: 1, color: "208E92", withAlphaComponent: 0.1)
        return view
    }()
    
    private lazy var blackListImageView: UIImageView = {
        let imageView = UIImageView(image: "internet".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private lazy var urlLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.textAlignment = .left
        label.adjustsFontSizeToFitWidth = true
        label.textColor = "0F4345".hexColor
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        selectionStyle = .none
        configureLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureLayout() {
        addSubviews(cellView)
        cellView.addSubviews(blackListImageView, urlLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(48)
        }
        
        blackListImageView.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(12)
            make.size.equalTo(24)
            make.centerY.equalToSuperview()
        }
        
        urlLabel.snp.makeConstraints { make in
            make.leading.equalTo(blackListImageView.snp.trailing).offset(12)
            make.centerY.equalToSuperview()
            make.height.equalTo(24)
        }
    }
}
