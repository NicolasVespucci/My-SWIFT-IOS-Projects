import UIKit
import SnapKit
import RxSwift

class BlockedAdsCollectionViewCell: UICollectionViewCell {
    
    var blockedAdsModel: BlockedAdsCollectionModel? {
        didSet { configureBlockedAdsModel() }
    }
    
    var completion: (()->())? = nil
    
    private lazy var cellView: UIView = {
        let cell = UIView()
        cell.layoutIfNeeded()
        cell.addBorder(width: 1, color: "208E92", withAlphaComponent: 0.1)
        cell.backgroundColor = "208E92".hexColor.withAlphaComponent(0.03)
        cell.layer.cornerRadius = 16
        return cell
    }()
    
    private lazy var topView: UIView = {
        let view = UIView()
        view.addBorder(width: 1, color: "208E92", withAlphaComponent: 0.15)
        view.backgroundColor = .clear
        view.layer.cornerRadius = 10
        return view
    }()
    
    private lazy var topIconImageView: UIImageView = {
        let imageView = UIImageView(image: "".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()

    private lazy var topNameOptionsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.textColor = "0F4345".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .left
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    //MARK: BUTTON TurnOffOn
    
    private var turnOffOnButtonView: UIView = {
        let view = UIView()
        view.backgroundColor = "208E92".hexColor.withAlphaComponent(0.1)
        view.layer.cornerRadius = 20
        view.isUserInteractionEnabled = true
        view.clipsToBounds = true
        return view
    }()
    
    private var vectorButtonLeftImageView: UIImageView = {
        let imageView = UIImageView(image: "vectorButtonLeft".image)
        return imageView
    }()
    
    private var vectorButtonRightImageView: UIImageView = {
        let imageView = UIImageView(image: "vectorButtonRight".image)
        return imageView
    }()
    
    public var turnOffOnButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = .white
        button.setTitleColor("208E92".hexColor, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 11, weight: .regular)
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = 16
        return button
    }()
    
    let disposeBag = DisposeBag()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupButtons()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    public func configureLayoutOff() {
        topView.subviews.forEach({
            $0.removeFromSuperview()
        })
        
        turnOffOnButtonView.subviews.forEach({
            $0.removeFromSuperview()
        })
        
        cellView.subviews.forEach({
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.removeFromSuperview()
        })

        clipsToBounds = true
        
        addSubview(cellView)
        
        cellView.addSubviews(topView, topNameOptionsLabel, turnOffOnButtonView)
        
        turnOffOnButtonView.addSubviews(vectorButtonLeftImageView, vectorButtonRightImageView, turnOffOnButton)
        
        topView.addSubview(topIconImageView)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        topView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(16.resized())
            make.leading.equalToSuperview().offset(16)
            make.size.equalTo(40)
        }
        
        topIconImageView.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.size.equalTo(24)
        }
        
        topNameOptionsLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(16.resized())
            make.leading.equalTo(topView.snp.trailing).offset(12.resized())
            make.trailing.equalToSuperview().offset(-10)
            make.height.equalTo(40)
        }
        
        turnOffOnButtonView.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(16)
            make.trailing.equalToSuperview().offset(-16)
            make.bottom.equalToSuperview().offset(-16.resized())
            make.height.equalTo(40)
        }
    
        vectorButtonLeftImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(8)
            make.height.equalTo(8)
            make.width.equalTo(28)
        }
        
        vectorButtonRightImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-8)
            make.height.equalTo(8)
            make.width.equalTo(28)
        }
        
        turnOffOnButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(4)
            make.trailing.equalToSuperview().offset(-104)
            make.height.equalTo(32)
        }
        
        self.vectorButtonLeftImageView.isHidden = true
        self.vectorButtonRightImageView.isHidden = false
        turnOffOnButton.setTitle(NSLocalizedString("Turn On", comment: ""), for: .normal)
        layoutIfNeeded()
        turnOffOnButton.layer.applySketchShadow(color: UIColor(red: 0.13, green: 0.56, blue: 0.57, alpha: 0.2), alpha: 1, x: 0, y: 10, blur: 1, spread: 1)

        turnOffOnButton.layer.shadowRadius = 20
    
        layoutSubviews()
    }
    
    
    public func configureLayoutOn() {
        
        topView.subviews.forEach({
            $0.removeFromSuperview()
        })
        
        turnOffOnButtonView.subviews.forEach({
            $0.removeFromSuperview()
        })
        
        cellView.subviews.forEach({
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        
        addSubview(cellView)
        
        cellView.addSubviews(topView, topNameOptionsLabel, turnOffOnButtonView)
        
        turnOffOnButtonView.addSubviews(vectorButtonLeftImageView, vectorButtonRightImageView,  turnOffOnButton)
        
        topView.addSubview(topIconImageView)
       
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        topView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(16.resized())
            make.leading.equalToSuperview().offset(16)
            make.size.equalTo(40)
        }
        
        topIconImageView.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.size.equalTo(24)
        }
        
        topNameOptionsLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(16.resized())
            make.leading.equalTo(topView.snp.trailing).offset(12.resized())
            make.trailing.equalToSuperview().offset(-10)
            make.height.equalTo(40)
        }
        
        turnOffOnButtonView.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(16)
            make.trailing.equalToSuperview().offset(-16)
            make.bottom.equalToSuperview().offset(-16.resized())
            make.height.equalTo(40)
        }
    
        vectorButtonLeftImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(8)
            make.height.equalTo(8)
            make.width.equalTo(28)
        }
        
        vectorButtonRightImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-8)
            make.height.equalTo(8)
            make.width.equalTo(28)
        }
        
        turnOffOnButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-4)
            make.leading.equalToSuperview().offset(104)
            make.height.equalTo(32)
        }
        
        self.vectorButtonLeftImageView.isHidden = false
        self.vectorButtonRightImageView.isHidden = true
        turnOffOnButton.setTitle(NSLocalizedString("Turn Off", comment: ""), for: .normal)
        layoutIfNeeded()
        turnOffOnButton.layer.applySketchShadow(color: UIColor(red: 0.13, green: 0.56, blue: 0.57, alpha: 0.2), alpha: 1, x: 0, y: 2, blur: 1, spread: 1)
        turnOffOnButton.layer.shadowRadius = 20
        layoutSubviews()
    }
    
    private func setupButtons(){
        turnOffOnButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.turnOffOnButtonAction()
        }.disposed(by: disposeBag)
    }
    
    public func turnOffOnButtonAction(){
        
        if self.vectorButtonLeftImageView.isHidden == true {
            UIView.animate(withDuration: 0.7) { [weak self] in
                guard let self = self else { return }
                self.turnOffOnButton.snp.remakeConstraints { make in
                    make.height.equalTo(32)
                    make.centerY.equalToSuperview()
                    make.leading.equalToSuperview().offset(104)
                    make.trailing.equalToSuperview().offset(-4)
                }
                self.layoutIfNeeded()
                self.vectorButtonLeftImageView.isHidden = false
                self.vectorButtonRightImageView.isHidden = true
                self.turnOffOnButton.setTitle(NSLocalizedString("Turn Off", comment: ""), for: .normal)
            } completion: { finished in
                if finished {
                    self.completion?()
                }
            }
        } else {
            UIView.animate(withDuration: 0.7) { [weak self] in
                guard let self = self else { return }
                self.turnOffOnButton.snp.remakeConstraints { make in
                    make.height.equalTo(32)
                    make.centerY.equalToSuperview()
                    make.leading.equalToSuperview().offset(4)
                    make.trailing.equalToSuperview().offset(-104)
                }
                self.layoutIfNeeded()
                self.vectorButtonLeftImageView.isHidden = true
                self.vectorButtonRightImageView.isHidden = false
                self.turnOffOnButton.setTitle(NSLocalizedString("Turn On", comment: ""), for: .normal)
            } completion: { finished in
                if finished {
                    self.completion?()
                }
            }
        }
    }

    private func configureBlockedAdsModel() {
        guard let blockedAdsModelCell = blockedAdsModel else { return }
        topIconImageView.image = blockedAdsModelCell.image?.image
        topNameOptionsLabel.text = blockedAdsModelCell.title
        vectorButtonRightImageView.isHidden = blockedAdsModelCell.value ?? false
    }
}
