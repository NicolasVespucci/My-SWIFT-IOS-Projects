import UIKit

class FirstShoppingCell: UITableViewCell {

    var FirstShoppingCellModel: FirstShoppingViewControllerModel? {
        didSet { configurePayFirstModel() }
    }
    
    private lazy var cellView: UIView = {
        let view = UIView()
        view.layer.masksToBounds = true
        return view
    }()
    
    private lazy var settingsImageView: UIImageView = {
        let imageView = UIImageView(image: "".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private lazy var cellLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .regular)
        label.adjustsFontSizeToFitWidth = true
        label.textColor = "0F4345".hexColor
        label.textAlignment = .left
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        selectionStyle = .none
        configureLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureLayout() {
        addSubview(cellView)
        cellView.addSubviews(settingsImageView, cellLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(24)
        }
        
        settingsImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(20.resized())
            make.size.equalTo(24.resized())
        }
        
        cellLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalTo(settingsImageView.snp.trailing).offset(16.resized())
            make.height.equalTo(24)
        }
    }
    
    private func configurePayFirstModel() {
        guard let firstShoppingCellModel = FirstShoppingCellModel else { return }
        settingsImageView.image = firstShoppingCellModel.image?.image
        cellLabel.text = firstShoppingCellModel.title
    }
}
