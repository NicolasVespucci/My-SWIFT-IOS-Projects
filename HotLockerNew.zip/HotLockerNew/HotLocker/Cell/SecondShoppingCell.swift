import UIKit
import StoreKit

class SecondShoppingCell: UICollectionViewCell {
    
    private lazy var cellView: UIView = {
        let cell = UIView()
        cell.layoutIfNeeded()
        cell.layer.addGradienBorder(colors: "AAED88".hexColor, "5CC8CC".hexColor, width: 1, cornerRadius: 16)
        cell.backgroundColor = "208E92".hexColor.withAlphaComponent(0.03)
        cell.layer.cornerRadius = 16
        return cell
    }()
    
    private lazy var periodLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.textColor = "0F4345".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .left
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private lazy var priceLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.textColor = "0F4345".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .left
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private lazy var trialLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.textColor = "0F4345".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .right
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private lazy var vectorLeftImageView: UIImageView = {
        let imageView = UIImageView(image: "VectorLeft".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private lazy var vectorRightImageView: UIImageView = {
        let imageView = UIImageView(image: "VectorRight".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    var product: Product?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func configureTrialLayout() {
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubviews(periodLabel, priceLabel, trialLabel)
    
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.bottom.equalToSuperview()
        }
        
        periodLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(20)
            make.height.equalTo(24)
        }
        
        priceLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview()
            make.height.equalTo(24)
        }
        
        trialLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-20)
            make.leading.equalTo(priceLabel.snp.trailing).offset(10)
            make.height.equalTo(24)
        }
        
        cellView.addBorder(width: 1, color: "208E92", withAlphaComponent: 0.1)
        cellView.backgroundColor = "208E92".hexColor.withAlphaComponent(0.03)
        
        trialLabel.text = NSLocalizedString("Free trial", comment: "")
        periodLabel.text = perPeriodString
        priceLabel.text = price
        layoutSubviews()
    }
    
    public func configureCommonLayout() {
        
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubviews(periodLabel, priceLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.bottom.equalToSuperview()
        }
        
        periodLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(20)
            make.height.equalTo(24)
        }
        
        priceLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview()
            make.height.equalTo(24)
        }
        
        cellView.addBorder(width: 1, color: "208E92", withAlphaComponent: 0.1)
        cellView.backgroundColor = "208E92".hexColor.withAlphaComponent(0.03)
        periodLabel.text = perPeriodString
        priceLabel.text = price
        layoutSubviews()
    }
    
    public func configureTrialSelectedLayout() {
        
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubviews(vectorLeftImageView, cellView, vectorRightImageView)
        cellView.addSubviews(periodLabel, priceLabel, trialLabel)
        
        vectorLeftImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.size.equalTo(8)
            make.leading.equalToSuperview().offset(8)
        }
        
        vectorRightImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-8)
            make.size.equalTo(8)
        }
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalTo(vectorLeftImageView.snp.trailing).offset(8)
            make.trailing.equalTo(vectorRightImageView.snp.leading).offset(-8)
            make.bottom.equalToSuperview()
        }
    
        periodLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(20)
            make.height.equalTo(24)
        }
        
        priceLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview()
            make.height.equalTo(24)
        }
        
        trialLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-20)
            make.leading.equalTo(priceLabel.snp.trailing).offset(10)
            make.height.equalTo(24)
        }

        layoutIfNeeded()
        cellView.layer.addGradienBorder(colors: "AAED88".hexColor, "5CC8CC".hexColor, width: 1, cornerRadius: 16)
        cellView.backgroundColor = "208E92".hexColor.withAlphaComponent(0.03)
    
        trialLabel.text = NSLocalizedString("Free trial", comment: "")
        periodLabel.text = perPeriodString
        priceLabel.text = price
        layoutSubviews()
    }
    
    public func configureCommonSelectedLayout() {
        
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubviews(vectorLeftImageView, cellView, vectorRightImageView)
        cellView.addSubviews(periodLabel, priceLabel)
        
        vectorLeftImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.size.equalTo(8)
            make.leading.equalToSuperview().offset(8)
        }
        
        vectorRightImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-8)
            make.size.equalTo(8)
        }
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalTo(vectorLeftImageView.snp.trailing).offset(8)
            make.trailing.equalTo(vectorRightImageView.snp.leading).offset(-8)
            make.bottom.equalToSuperview()
        }
        
        periodLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(20)
            make.height.equalTo(24)
        }
        
        priceLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview()
            make.height.equalTo(24)
        }
        
        cellView.layer.addGradienBorder(colors: "AAED88".hexColor, "5CC8CC".hexColor, width: 1, cornerRadius: 15)
        cellView.backgroundColor = "208E92".hexColor.withAlphaComponent(0.03)
        
        periodLabel.text = perPeriodString
        priceLabel.text = price
        layoutSubviews()
    }
}
