
import Foundation
import UIKit

extension Int {
  func nextDay(daysAfter: Int) -> Int {
    if self == 7 {
      return daysAfter
    } else if self + daysAfter < 7 {
      return self + daysAfter
    } else if self + daysAfter > 7 {
      return self - 7 + daysAfter
    } else {
      return self + daysAfter
    }
  }
}
