import Foundation
import UIKit

struct SettingViewControllerModel {
    var image: String?
    var title: String?
}

