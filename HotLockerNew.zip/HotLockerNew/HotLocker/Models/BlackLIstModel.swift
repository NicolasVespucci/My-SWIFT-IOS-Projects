import Foundation
import UIKit

struct BlackListModel: Codable {
  var trigger: Trigger
  var action: Action
  
  enum CodingKeys: String, KeyedKey {
    case trigger
    case action
  }
  
  var formattedWebsite: String {
    return trigger.urlFilter.removingPrefix("https?://(www.)?").removingSuffix("*")
  }
}

struct Action: Codable {
  var type: String
  var selector: String?
  
  enum CodingKeys: String, KeyedKey {
    case type
    case selector
  }
}

struct Trigger: Codable {
  var urlFilter: String
  
  enum CodingKeys: String, KeyedKey {
    case urlFilter = "url-filter"
  }
}


