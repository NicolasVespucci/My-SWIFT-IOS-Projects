import UIKit
import RxCocoa
import RxSwift

class ExceptionsBlockWebSitesView: UIView {

    private var fullView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 20
        view.addBorder(width: 1, color: "FFFFFF", withAlphaComponent: 0.5)
        view.clipsToBounds = false
        view.isUserInteractionEnabled = true
        return view
    }()
    
    private var ellipseImageView: UIImageView = {
        let imageView = UIImageView(image: "EllipseOrange".image)
        return imageView
    }()
    
    private var minusInEllipseImageView: UIImageView = {
        let imageView = UIImageView(image: "minusInEllipse".image)
        return imageView
    }()
    
    private var exceptionsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 12, weight: .semibold)
        label.textColor = "208E92".hexColor
        label.text = NSLocalizedString("EXCEPTIONS", comment: "")
        label.textAlignment = .left
        return label
    }()
    
    public var exceptionsNumberLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .regular)
        label.textColor = "0F4345".hexColor
        label.textAlignment = .left
        return label
    }()
    
    private var blockWebSitesLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 11, weight: .regular)
        label.textColor = "208E92".hexColor
        label.text = NSLocalizedString("Block websites you don’t \nwant to visit.", comment: "")
        label.textAlignment = .left
        label.numberOfLines = 2
        label.adjustsFontSizeToFitWidth = true
        return label
    }()
    
    let disposeBag = DisposeBag()

    override init(frame: CGRect) {
        super.init(frame: frame)
        isUserInteractionEnabled = true
        launch()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func launch() {
        configureLayout()
        
    }
    
    private func configureLayout() {
        addSubview(fullView)
        fullView.addSubviews(ellipseImageView, exceptionsLabel, exceptionsNumberLabel, blockWebSitesLabel)
        ellipseImageView.addSubview(minusInEllipseImageView)
        
        fullView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        ellipseImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(20)
            make.size.equalTo(40)
        }
        
        minusInEllipseImageView.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.size.equalTo(24)
        }
        
        exceptionsLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(20.resized())
            make.leading.equalToSuperview().offset(80)
            make.height.equalTo(16)
        }
        
        exceptionsNumberLabel.snp.makeConstraints { make in
            make.top.equalTo(exceptionsLabel.snp.bottom).offset(4.resized())
            make.leading.equalTo(exceptionsLabel.snp.leading)
            make.height.equalTo(24)
        }
        
        blockWebSitesLabel.snp.makeConstraints { make in
            make.top.equalTo(exceptionsNumberLabel.snp.bottom).offset(8.resized())
            make.leading.equalTo(exceptionsLabel.snp.leading)
            make.height.equalTo(32)
        }
        
        layoutIfNeeded()
    }
}
