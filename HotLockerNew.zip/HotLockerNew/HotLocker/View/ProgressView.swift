import UIKit

class ProgressView: UIView {
    
    enum Theme {
        case light
        case dark
    }
    
    var theme: Theme
    var container: UIStackView
    var activityIndicator: UIActivityIndicatorView
    var label: UILabel
    var glass: UIView
    
    
    private var message: String
    private var isModal: Bool
    
    init(message: String, theme: Theme, isModal: Bool) {
        self.message = message
        self.theme = theme
        self.isModal = isModal
        
        self.container = UIStackView()
        self.activityIndicator = UIActivityIndicatorView()
        self.label = UILabel()
        self.glass = UIView()
        
        let fontName = self.label.font.fontName
        let fontSize = self.label.font.pointSize
        if let font = UIFont(name: fontName, size: fontSize) {
            let fontAttributes = [NSAttributedString.Key.font: font]
            let size = (message as NSString).size(withAttributes: fontAttributes)
            super.init(frame: CGRect(x: 0, y: 0, width: size.width + 50, height: 50))
        } else {
            super.init(frame: CGRect(x: 0, y: 0, width: 200, height: 50))
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(onRotate), name: UIDevice.orientationDidChangeNotification, object: nil)
        
        self.layer.cornerRadius = 10
        if (self.theme == .dark) {
            self.backgroundColor = .darkGray
        } else {
            self.backgroundColor = .lightGray
        }
    
        if self.theme == .dark {
            self.label.textColor = .white
        }else{
            self.label.textColor = .black
        }
        self.label.text = self.message
        
        self.container.frame = self.frame
        self.container.spacing = 0
        self.container.layoutMargins = UIEdgeInsets(top: 18, left: 16, bottom: 15, right: 15)
        self.container.isLayoutMarginsRelativeArrangement = true
        
        if (self.theme == .dark) {
            self.activityIndicator = UIActivityIndicatorView(style: .large)
            self.activityIndicator.color = .white
        } else {
            self.activityIndicator = UIActivityIndicatorView(style:.large)
            self.activityIndicator.color = .black
        }
        self.activityIndicator.startAnimating()
        
        if let superview = UIApplication.shared.keyWindow {
            if (self.isModal) {
                
                self.glass.frame = superview.frame;
                if (self.theme == .dark) {
                    self.glass.backgroundColor = UIColor.black.withAlphaComponent(0.5)
                } else {
                    self.glass.backgroundColor = UIColor.white.withAlphaComponent(0.5)
                }
                superview.addSubview(glass)
            }
        }
        
        container.addArrangedSubview(self.activityIndicator)
        container.addArrangedSubview(self.label)
        
        self.addSubview(container)
        if let superview = UIApplication.shared.keyWindow {
            self.center = superview.center
            superview.addSubview(self)
        }
        
        self.hide()
    }
    
    required init(coder: NSCoder) {
        self.theme = .dark
        self.message = "Not set!"
        self.isModal = true
        self.container = UIStackView()
        self.activityIndicator = UIActivityIndicatorView()
        self.label = UILabel()
        self.glass = UIView()
        super.init(coder: coder)!
    }
    
    @objc func onRotate() {
        if let superview = self.superview {
            self.glass.frame = superview.frame
            self.center = superview.center
        }
    }
    
    public func show() {
        UIApplication.shared.keyWindow?.bringSubviewToFront(self)
        self.glass.isHidden = false
        self.isHidden = false
    }
    
    public func show(_ duration: CFTimeInterval) {
        self.show()
        DispatchQueue.main.asyncAfter(deadline: .now() + duration) { [weak self] in
            self?.hide()
        }
    }
    
    public func hide() {
        self.glass.isHidden = true
        self.isHidden = true
    }
    
    public func setMessage(_ text: String, _ duration: CFTimeInterval? = 2.5) {
        self.message = text
        self.show(duration!)
    }
}

