//
//  ViewController.swift
//  HotLocker
//
//  Created by Mac on 14.03.22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

