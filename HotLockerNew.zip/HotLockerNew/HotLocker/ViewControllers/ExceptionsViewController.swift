import UIKit
import RxCocoa
import RxSwift
import SnapKit
import SafariServices

class ExceptionsViewController: UIViewController {

    private var ExceptionsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.textColor = "0F4345".hexColor
        label.text = NSLocalizedString("Exceptions", comment: "")
        label.textAlignment = .center
        return label
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("backSettings".image, for: .normal)
        return button
    }()
    
    private lazy var addNewButton: UIButton = {
        let button = UIButton()
        button.setTitle(NSLocalizedString("Add new", comment: ""), for: .normal)
        button.backgroundColor = .clear
        button.setTitleColor("5CC8CC".hexColor, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .semibold)
        button.layer.cornerRadius = 12
        button.titleLabel?.minimumScaleFactor = 0.5
        button.titleLabel?.adjustsFontSizeToFitWidth = true
        button.titleLabel?.textAlignment = .right
        return button
    }()
    
    private var ellipseImageView: UIImageView = {
        let imageView = UIImageView(image: "EllipseOrange".image)
        return imageView
    }()
    
    private var minusInEllipseImageView: UIImageView = {
        let imageView = UIImageView(image: "minusInEllipse".image)
        return imageView
    }()
    
    private lazy var tutorialBlackListLabel: UILabel = {
        let label = UILabel()
        label.text = NSLocalizedString("Tap “Add New” Button below to \ncreate URL exception", comment: "")
        label.font = .systemFont(ofSize: 14, weight: .regular)
        label.layer.masksToBounds = true
        label.textColor = "74757A".hexColor
        label.textAlignment = .center
        label.minimumScaleFactor = 0.5
        label.numberOfLines = 0
        return label
    }()
    
    private lazy var tableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 64
        table.backgroundColor = .clear
        table.separatorStyle = .none
        return table
    }()
    
    var blockListDomains: [String] {
        get {
            if let domains = UserDefaults.standard.stringArray(forKey: UserDefaults.Keys.blockedDomains), !domains.isEmpty {
                ellipseImageView.isHidden = true
                tutorialBlackListLabel.isHidden = true
                return domains
            }
            ellipseImageView.isHidden = false
            tutorialBlackListLabel.isHidden = false
            return []
        }
        set { UserDefaults.standard.set(newValue, forKey: UserDefaults.Keys.blockedDomains) }
    }
    
    var blockerList: [BlackListModel]? {
        set {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            guard let newValue = newValue else { return }
            guard let data = try? encoder.encode(newValue) else { return }
            guard let url = Constants.app.blockerJsonUrl else { return }
            try? data.write(to: url)
        }
        get {
            guard let url = Constants.app.blockerJsonUrl else { return nil }
            guard let data = try? Data(contentsOf: url) else { return nil }
            return try? JSONDecoder().decode([BlackListModel].self, from: data)
        }
    }
    
       
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        launch()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if let homeController = (presentingViewController as! UINavigationController).viewControllers.first as? HomeViewController {
            homeController.exceptionsBlockWebSitesView.exceptionsNumberLabel.text = "\(blockListDomains.count)"
        }
    }
    
    private func launch() {
        configureLayout()
        configureButtons()
        configureTable()
    }
    
    private func configureLayout(){
        view.backgroundColor = .white
        
        view.addSubviews(ExceptionsLabel, backButton, addNewButton, tutorialBlackListLabel,ellipseImageView, tableView)
        
        ellipseImageView.addSubviews(minusInEllipseImageView)
        
        ExceptionsLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(14)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(24)
        }
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(16)
            make.leading.equalToSuperview().offset(26)
            make.size.equalTo(24)
        }
        
        addNewButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(14)
            make.trailing.equalToSuperview().offset(-24.resized())
            make.width.equalTo(110)
            make.height.equalTo(24)
        }
        
        tableView.snp.makeConstraints { make in
            make.top.equalTo(ExceptionsLabel.snp.bottom).offset(32)
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.bottom.equalToSuperview().offset(-50)
        }
        
        ellipseImageView.snp.makeConstraints { make in
            make.top.equalTo(ExceptionsLabel.snp.bottom).offset(283)
            make.centerX.equalToSuperview()
            make.size.equalTo(64)
        }
        
        minusInEllipseImageView.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.size.equalTo(32)
        }
    
        tutorialBlackListLabel.snp.makeConstraints { make in
            make.top.equalTo(ellipseImageView.snp.bottom).offset(24)
            make.leading.equalToSuperview().offset(10)
            make.trailing.equalToSuperview().offset(-10)
            make.height.equalTo(78.resized())
        }
    }
    
    private func configureButtons(){
        addNewButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.showInputDialog(title: NSLocalizedString("Add exception", comment: ""), subtitle: NSLocalizedString("Enter URL address you want to \nexclude from browsing safari", comment: ""), inputPlaceholder: "http://example.org", actionHandler: { [weak self] url in
                guard let self = self, let url = url else { return }
                if IAPManager.shared().isPurchased {
                    self.appendBlockItem(urlString: url)
                } else {
                    if self.blockListDomains.count < 5 {
                        self.appendBlockItem(urlString: url)
                    } else {
                        IAPManager.shared().presentSingleSubscriptionVC()
                        IAPManager.shared().purchaseCompletion = { [weak self] _ in
                            IAPManager.shared().dismissSubscriptionVC(animated: true, completion: nil)
                            self?.appendBlockItem(urlString: url)
                        }
                    }
                }
            })
        }.disposed(by: disposeBag)
        
        backButton.rx.tap.bind { [weak self] in
            self?.dismiss(animated: true)
        }.disposed(by: disposeBag)
    }
    
    private func configureTable() {
        tableView.register(BlackListCell.self, forCellReuseIdentifier: BlackListCell.nibIdentifier)
        tableView.rx.setDelegate(self).disposed(by: disposeBag)
        tableView.rx.setDataSource(self).disposed(by: disposeBag)
        tableView.contentInset.top = 30
    }
    
}
//MARK: - Content blocker
extension ExceptionsViewController {
    private func appendBlockItem(urlString: String) {
        let text = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        self.addBlockItem(text: text.replacingOccurrences(of: "http://", with: "").replacingOccurrences(of: "https://", with: "").replacingOccurrences(of: "www.", with: ""))
        self.blockListDomains.append(text)
        self.tableView.reloadData()
    }
    
    private func removeBlockItem(index: Int) {
        let valueToRemove = blockListDomains[index].replacingOccurrences(of: "http://", with: "").replacingOccurrences(of: "https://", with: "").replacingOccurrences(of: "www.", with: "")
        if let indexToRemove = blockerList?.firstIndex(where: {  $0.trigger.urlFilter.contains(valueToRemove) }) {
            blockListDomains.removeAll(where: { $0.contains(valueToRemove) })
            blockerList?.remove(at: indexToRemove)
        }
        tableView.reloadData()
        reloadContentBlocker()
    }
    
    private func blockItem(websiteString: String) -> BlackListModel {
        let website = String(format: "https?://(www.)?%@*", websiteString)
        let blockItem = BlackListModel(trigger: Trigger(urlFilter: website), action: Action(type: "block"))
        return blockItem
    }
    
    private func addBlockItem(text: String) {
        let item = blockItem(websiteString: text)
        blockerList?.append(item)
        reloadContentBlocker()
    }
    
    private func reloadContentBlocker(completion: (() -> (Void))? = nil) {
        DispatchQueue.main.async {
            SFContentBlockerManager.reloadContentBlocker(withIdentifier: Constants.app.contentBlockerExtensionName) { (error) in
                if error == nil {
                    print("Rules activated.")
                } else {
                    print("ERROR activating rules")
                    print(error)
                }
                completion?()
            }
        }
    }
}

//MARK: - UITableViewDelegate
extension ExceptionsViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
}

//MARK: - UITableViewDataSource
extension ExceptionsViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return blockListDomains.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: BlackListCell.nibIdentifier, for: indexPath) as! BlackListCell
        cell.customDomain = blockListDomains[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            removeBlockItem(index: indexPath.row)
            ellipseImageView.isHidden = !blockListDomains.isEmpty
            tutorialBlackListLabel.isHidden = !blockListDomains.isEmpty
        }
    }
}

//MARK: - Letter spacing
extension UILabel {
    func addCharactersSpacing(spacing:CGFloat, text:String) {
        let attributedString = NSMutableAttributedString(string: text)
        attributedString.addAttribute(NSAttributedString.Key.kern, value: spacing, range: NSMakeRange(0, text.count-1))
        self.attributedText = attributedString
    }
}
