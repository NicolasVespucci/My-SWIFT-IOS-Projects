import UIKit
import RxSwift
import RxCocoa
import SwiftyAttributes
import StoreKit
import SwiftyStoreKit


class FirstShoppingViewController: UIViewController {
    
    var identifiers = Constants.analytics.threeMonth
    
    public var firstShoppingViewControllerModel = [FirstShoppingViewControllerModel(image: "eye", title: NSLocalizedString("No tracking", comment: "")),
                                             FirstShoppingViewControllerModel(image: "minus", title: NSLocalizedString("Block custom URLs", comment: "")),
                                             FirstShoppingViewControllerModel(image: "file", title: NSLocalizedString("Advanced database with Ads", comment: "")),
                                             FirstShoppingViewControllerModel(image: "radio", title: NSLocalizedString("Do not be disturbed by Ads", comment: "")),
                                             FirstShoppingViewControllerModel(image: "profit", title: NSLocalizedString("Less traffic usage", comment: ""))
    ]
    
    private var topImageView: UIImageView = {
        let imageView = UIImageView(image: "TopView".image )
        imageView.contentMode = .scaleAspectFill
        imageView.isUserInteractionEnabled = true
        imageView.layer.masksToBounds = false
        imageView.clipsToBounds = false
        return imageView
    }()
    
    private var bottonView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.clipsToBounds = false
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.applySketchShadow()
        return view
    }()
    
    private var topBackButton: UIButton = {
        let button = UIButton()
        button.setImage("backFirstShopping".image, for: .normal)
        return button
    }()
    
    private var topRestoreButton: UIButton = {
        let button = UIButton()
        button.setTitle(NSLocalizedString("Restore", comment: ""), for: .normal)
        return button
    }()
    
    private var topStarImageView: UIImageView = {
        let imageView = UIImageView(image: "StarFirstShopping".image)
        return imageView
    }()
    
    private var AdvancedProtectionLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .regular)
        label.textAlignment = .center
        label.text = NSLocalizedString("Advanced protection", comment: "")
        label.textColor = .white
        return label
    }()
    
    private var centerDignitiesView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 20
        view.addBorder(width: 1, color: "FFFFFF", withAlphaComponent: 0.5)
        view.clipsToBounds = false
        return view
    }()
    
    private var emptyButton: UIButton = {
        let buttton = UIButton()
        buttton.backgroundColor = .clear
        return buttton
    }()
    
    private lazy var FirstShoppingTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 40
        table.backgroundColor = .clear
        table.isScrollEnabled = false
        table.separatorStyle = .none
        return table
    }()
    
    private lazy var trialLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.textColor = "0F4345".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .center
        label.numberOfLines = 2
        return label
    }()
    
    private var emptyView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        view.isUserInteractionEnabled = true
        return view
    }()
    
    private lazy var subscribeButton: UIButton = {
        let button = UIButton()
        button.layer.cornerRadius = 16
        button.setTitle(NSLocalizedString("Subscribe", comment: ""), for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .medium)
        button.titleLabel?.textColor = .white
        return button
    }()
    
    var productsDescription: NSAttributedString {
        let terms = NSLocalizedString("Terms", comment: "") + " " + NSLocalizedString("of", comment: "") + " " + NSLocalizedString("Use", comment: "")
        let privacy = NSLocalizedString("Privacy", comment: "") + NSLocalizedString("and", comment: "") + NSLocalizedString("Policy", comment: "")
        let and = " & "
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        
        let textAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12, weight: .medium)),
            .textColor("0F4345".hexColor.withAlphaComponent(0.8)),
            .paragraphStyle(paragraphStyle)
        ]
        
        let andAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12, weight: .medium)),
            .textColor("0F4345".hexColor.withAlphaComponent(0.5)),
            .paragraphStyle(paragraphStyle)
        ]
        
        let attributedDescription =
        terms.withAttributes(textAttributes)
        + and.withAttributes(andAttributes)
        + privacy.withAttributes(textAttributes)
        return attributedDescription
    }
    
    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.layoutIfNeeded()
        textView.isEditable = false
        textView.isSelectable = false
        textView.isScrollEnabled = false
        textView.backgroundColor = .clear
        textView.showsVerticalScrollIndicator = true
        textView.attributedText = productsDescription
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapResponse(recognizer:)))
        textView.addGestureRecognizer(tap)
        return textView
    }()
    
    public lazy var progressView = ProgressView(message: "", theme: .dark, isModal: true)
    
    let bag = DisposeBag()

    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
        configureTrialLabel()
        if IAPManager.shared().isPurchased {
            self.dismiss(animated: true)
        }
    }
    
    private func setup(){
        configureLayout()
        setupTableView()
        configureTrialLabel()
        configureButtons()
    }
    
    private func configureLayout(){
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = .white
        view.addSubviews(topImageView, bottonView, topBackButton, topRestoreButton, topStarImageView, AdvancedProtectionLabel, centerDignitiesView, trialLabel, emptyView, subscribeButton, textView)
        centerDignitiesView.addSubview(FirstShoppingTableView)
        
    
        topImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo((UIScreen.main.bounds.height) / 2)
        }
        
        bottonView.snp.makeConstraints { make in
            make.top.equalTo(topImageView.snp.bottom)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        topBackButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.leading.equalToSuperview().offset(24)
            make.size.equalTo(24)
        }
        
        topRestoreButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(24)
        }
        
        topStarImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(102.resized())
            make.size.equalTo(50)
            make.centerX.equalToSuperview()
        }
        
        AdvancedProtectionLabel.snp.makeConstraints { make in
            make.top.equalTo(topStarImageView.snp.bottom).offset(16.resized())
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(32)
        }
        
        centerDignitiesView.snp.makeConstraints { make in
            make.top.equalTo(AdvancedProtectionLabel.snp.bottom).offset(40.resized())
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(224)
        }
        
        FirstShoppingTableView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(20)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview().offset(-20)
        }
        
        trialLabel.snp.makeConstraints { make in
            make.top.equalTo(centerDignitiesView.snp.bottom).offset(34.resized())
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(48)
        }
        
        subscribeButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-116.resized())
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(56)
        }
        
        textView.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-30.resized())
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(50)
        }
        
        view.layoutIfNeeded()
        bottonView.layer.applySketchShadow()
        
        subscribeButton.addGradient(.leftRight, ["FF9A62".hexColor, "5CC8CC".hexColor], 16)
        
        centerDignitiesView.addGradient(.leftRight, ["5CC8CC".hexColor, "AAED88".hexColor], 20)
        
        centerDignitiesView.addGradient(.bottomTop, ["FFFFFF".hexColor, "FFFFFF".hexColor.withAlphaComponent(0.05)], 20)
        
        
        centerDignitiesView.layer.applySketchShadow(color: UIColor(red: 0.36, green: 0.78, blue: 0.8, alpha: 0.2), alpha: 1, x: 0, y: 7, blur: 30, spread: 1)
        centerDignitiesView.clipsToBounds = false
        centerDignitiesView.layer.shadowRadius = 20
        centerDignitiesView.layer.cornerRadius = 20
    }
    
    private func setupTableView() {
        FirstShoppingTableView.delegate = self
        FirstShoppingTableView.dataSource = self
        FirstShoppingTableView.register(FirstShoppingCell.self, forCellReuseIdentifier: FirstShoppingCell.nibIdentifier)
    }
    
    private func configureButtons() {
        subscribeButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            let product = self.identifiers
            IAPManager.shared().purchase(rcPackage: product, quantity: 1, atomically: true)
        }.disposed(by: bag)
        
        topBackButton.rx.tap.bind { [weak self] in
            self?.dismiss(animated: true)
        }.disposed(by: bag)
        
        topRestoreButton.rx.tap.bind {
            IAPManager.shared().restore()
        }.disposed(by: bag)
    }
 

    private func configureTrialLabel() {
        self.progressView.show()
        SwiftyStoreKit.retrieveProductsInfo([Constants.analytics.threeMonth]) { result in
            if(!result.retrievedProducts.isEmpty) {
                let testProduct = Product(product: result.retrievedProducts.first!)
                guard let period = testProduct.period else { return }
                let periodString = period.formattedString // MONTHLY
                let perPeriodString = period.perFormattedString.capitalized // MONTH
                let price = testProduct.localizedPrice
                let introductoryPeriod = testProduct.introductory?.period?.formattedString ?? ""

                if introductoryPeriod == "" {
                    self.trialLabel.text = price + NSLocalizedString(" per ", comment: "") + perPeriodString
                    self.subscribeButton.setTitle(NSLocalizedString("Subscribe", comment: ""), for: .normal)
                    self.progressView.hide()
                } else {
                    self.trialLabel.text = "\(introductoryPeriod)" + NSLocalizedString(" free trial,\nthen ", comment: "") + "\(price) \(periodString)"
                    self.subscribeButton.setTitle("\(introductoryPeriod)" + NSLocalizedString(" free trial", comment: ""), for: .normal)
                    self.progressView.hide()
                }
            }
        }
    }
}

extension FirstShoppingViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}
extension FirstShoppingViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return firstShoppingViewControllerModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = FirstShoppingTableView.dequeueReusableCell(withIdentifier: FirstShoppingCell.nibIdentifier, for:  indexPath) as! FirstShoppingCell
        let settingModelTwo = firstShoppingViewControllerModel[indexPath.row]
        cell.FirstShoppingCellModel = settingModelTwo
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }

}
//MARK: - Text View
extension FirstShoppingViewController {
    @objc func tapResponse(recognizer: UITapGestureRecognizer) {
        let location: CGPoint = recognizer.location(in: textView)
        let position: CGPoint = CGPoint(x: location.x, y: location.y)
        let tapPosition: UITextPosition? = textView.closestPosition(to: position)
        if tapPosition != nil {
            let textRange: UITextRange? = textView.tokenizer.rangeEnclosingPosition(tapPosition!, with: UITextGranularity.word, inDirection: UITextDirection(rawValue: 1))
            if textRange != nil
            {
                let tappedWord: String? = textView.text(in: textRange!)
                guard let word = tappedWord else { return }
                wordAction(word)
            }
        }
    }
    
    private func wordAction(_ word: String) {
        switch word {
        case NSLocalizedString("Terms", comment: ""), NSLocalizedString("of", comment: ""), NSLocalizedString("Use", comment: ""): pushPoliciesVC(.terms)
            
        case NSLocalizedString("Privacy", comment: ""),NSLocalizedString("and", comment: ""), NSLocalizedString("Policy", comment: ""): pushPoliciesVC(.privacy)
        default: break
        }
    }
    
    func pushPoliciesVC(_ policiesType: Policies) {
        let termsVC = TermsAndPrivacy()
        termsVC.policiesType = policiesType
        navigationController?.pushViewController(termsVC, animated: true)
    }
}


