import UIKit
import RxCocoa
import SnapKit
import RxSwift
import LocalAuthentication
import SafariServices
import SwiftyAttributes

class HomeViewController: UIViewController {
    
    var isProtected = true
    var isActivated = false
    
    var blackList: [BlackListModel]? {
        set {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            guard let newValue = newValue else { return }
            guard let data = try? encoder.encode(newValue) else { return }
            guard let url = Constants.app.blockerJsonUrl else { return }
            try? data.write(to: url)
        }
        get {
            guard let url = Constants.app.blockerJsonUrl else { return nil }
            guard let data = try? Data(contentsOf: url) else { return nil }
            return try? JSONDecoder().decode([BlackListModel].self, from: data)
        }
    }
    
    public var blockedAdsCollectionModel = [BlockedAdsCollectionModel(image: "ads",
                                                                      title: NSLocalizedString("Block Ads", comment: ""),
                                                                      value: Constants.ud.blockAdsSwitchValue),
                                            BlockedAdsCollectionModel(image: "social",
                                                                      title: NSLocalizedString("Widgets Social", comment: ""),
                                                                      value: Constants.ud.blockSocialSwitchValue),
                                            BlockedAdsCollectionModel(image: "scripts",
                                                                      title: NSLocalizedString("Block Scripts", comment: ""),
                                                                      value: Constants.ud.blockScriptsSwitchValue),
                                            BlockedAdsCollectionModel(image: "tracking",
                                                                      title: NSLocalizedString("Block Tracking", comment: ""),
                                                                      value: Constants.ud.blockTrackingSwitchValue),
                                            BlockedAdsCollectionModel(image: "url",
                                                                      title: NSLocalizedString("Block URLs", comment: ""),
                                                                      value: Constants.ud.blockURLSSwitchValue)
    ]
    
    private var topImageView: UIImageView = {
        let imageView = UIImageView(image: "TopView".image )
        imageView.contentMode = .scaleAspectFill
        imageView.isUserInteractionEnabled = true
        imageView.layer.masksToBounds = false
        imageView.clipsToBounds = false
        return imageView
    }()
    
    private var bottonView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.clipsToBounds = false
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.applySketchShadow()
        return view
    }()
    
    private var topMenuButton: UIButton = {
        let button = UIButton()
        button.setImage("menuButton".image, for: .normal)
        return button
    }()
    
    private var topCircleImageView: UIImageView = {
        let imageView = UIImageView(image: "logoHome".image )
        imageView.contentMode = .scaleAspectFill
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    //MARK: - Access advanced protection View
    
    private var topProtectionButtonView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()
    
    private var topProtectionButtonImageView: UIImageView = {
        let imageView = UIImageView(image: "StarPremium".image)
        return imageView
    }()
    
    private var AccessAdvancedProtectionLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.text = NSLocalizedString("Access advanced protection", comment: "")
        label.textAlignment = .left
        label.textColor = .white
        label.adjustsFontSizeToFitWidth = true
        return label
    }()
    
    private var topProtectionButton: UIButton = {
        let button = UIButton()
        return button
    }()
    
    //MARK: ExceptionsBlockWebSitesView
    
    public var exceptionsBlockWebSitesView = ExceptionsBlockWebSitesView()
    
    private var editButton: UIButton = {
        let button = UIButton()
        button.setTitle(NSLocalizedString("Edit", comment: ""), for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 12, weight: .medium)
        button.titleLabel?.textAlignment = .center
        button.tintColor = .white
        button.layer.cornerRadius = 14
        return button
    }()
    
    private var blockedAdsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.text = NSLocalizedString("Blocked Ads", comment: "")
        label.textAlignment = .left
        label.textColor = "208E92".hexColor
        label.adjustsFontSizeToFitWidth = true
        return label
    }()
    
    private var blockedAdsNumberLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .regular)
        label.textAlignment = .right
        label.textColor = "0F4345".hexColor
        label.adjustsFontSizeToFitWidth = true
        return label
    }()
    
    private lazy var blockedAdsCollectionView: UICollectionView = {
        let collection = UICollectionView(frame: .zero, collectionViewLayout: .init())
        collection.backgroundColor = .clear
        collection.showsHorizontalScrollIndicator = false
        collection.showsVerticalScrollIndicator = false
        collection.clipsToBounds = false
        return collection
    }()
    
    private lazy var blockedAdsLayout: UICollectionViewLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 0
        layout.itemSize = .init(width: 221.resized(.width), height: 136.resized())
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 16
        layout.scrollDirection = .horizontal
        layout.sectionInset = .init(top: 0, left: 24, bottom: 0, right: 24)
        return layout
    }()

    //MARK: TurnOffOn Button
    
    private var turnOffOnButtonView: UIView = {
        let view = UIView()
        view.backgroundColor = "208E92".hexColor.withAlphaComponent(0.2)
        view.layer.cornerRadius = 26
        view.isUserInteractionEnabled = true
        view.clipsToBounds = true
        return view
    }()
    
    private var vectorButtonLeftImageView: UIImageView = {
        let imageView = UIImageView(image: "vectorButtonLeft".image)
        return imageView
    }()
    
    private var vectorButtonRightImageView: UIImageView = {
        let imageView = UIImageView(image: "vectorButtonRight".image)
        return imageView
    }()
    
    private var turnOffOnButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = .white
        button.setTitleColor("208E92".hexColor, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 14, weight: .regular)
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = 20.8
        button.isHidden = false
        return button
    }()
    
    private var adBlockedOffOnLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .regular)
        label.textColor = "208E92".hexColor
        label.textAlignment = .center
        label.text = NSLocalizedString("HotLocker Disabled", comment: "")
        return label
    }()
    
    var selectedIndex = 0
    private lazy var progressView = ProgressView(message: "", theme: .dark, isModal: true)
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        if !IAPManager.shared().isPurchased {
            IAPManager.shared().presentSingleSubscriptionVC(animated: true)
            IAPManager.shared().purchaseCompletion = { _ in
                IAPManager.shared().dismissSubscriptionVC()
            }
            IAPManager.shared().restoreCompletion = { subscription in
                IAPManager.shared().dismissSubscriptionVC()
                if Constants.ud.isPurchased {
                    AlertManager.shared().showPurchasesWereRestored()
                }
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true

        currentAdBlockerSatus()
        
        if IAPManager.shared().isPurchased {
            view.layoutIfNeeded()
            self.checkSubscriptions()
        } else {
            view.layoutIfNeeded()
            self.topProtectionButtonView.addGradient(.topLeftBottomRight, ["FF9A62".hexColor, "5CC8CC".hexColor], 16)

            self.AccessAdvancedProtectionLabel.text = NSLocalizedString("Access advanced protection", comment: "")
        }
    
        let exceptionVC = ExceptionsViewController()
        exceptionsBlockWebSitesView.exceptionsNumberLabel.text = "\(exceptionVC.blockListDomains.count)"
        blockedAdsNumberLabel.text = "\(Constants.ud.adsBlockedCount ?? 0)"
    }
    
    private func setup() {
        configureLayout()
        setupButtons()
        setupBlackAdsCollection()
        configureBindBlockAction()
        configureAdblockAction()
    }
    
    private func configureLayout() {
        view.backgroundColor = .white
        view.addSubviews(topImageView, bottonView, topMenuButton, topCircleImageView, topProtectionButtonView, exceptionsBlockWebSitesView, blockedAdsLabel, blockedAdsNumberLabel,blockedAdsCollectionView, turnOffOnButtonView, adBlockedOffOnLabel)
        
        exceptionsBlockWebSitesView.addSubview(editButton)
        
        turnOffOnButtonView.addSubviews(vectorButtonLeftImageView, vectorButtonRightImageView, turnOffOnButton)
        
        topProtectionButtonView.addSubviews(topProtectionButtonImageView, topProtectionButton, AccessAdvancedProtectionLabel)
        
        topImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo((UIScreen.main.bounds.height) / 2)
        }
        
        bottonView.snp.makeConstraints { make in
            make.top.equalTo(topImageView.snp.bottom)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        topMenuButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54.resized())
            make.leading.equalToSuperview().offset(24)
            make.size.equalTo(24)
        }
        
        topCircleImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(44.resized())
            make.size.equalTo(64.resized())
            make.centerX.equalToSuperview()
        }
        //MARK: - Constraints Access advanced protection View
        
        topProtectionButtonView.snp.makeConstraints { make in
            make.top.equalTo(topCircleImageView.snp.bottom).offset(54.resized())
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(56.resized())
        }
        
        topProtectionButtonImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(15.resized())
            make.trailing.equalToSuperview().offset(-5)
            make.width.equalTo(50)
            make.height.equalTo(41)
        }
        
        AccessAdvancedProtectionLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(20)
            make.height.equalTo(24)
        }
        
        topProtectionButton.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        //MARK: - Constraints exceptionsBlockWebSitesView
        
        exceptionsBlockWebSitesView.snp.makeConstraints { make in
            make.top.equalTo(topProtectionButtonView.snp.bottom).offset(40.resized())
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(120)
        }
        
        editButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(48.resized())
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(28)
            make.width.equalTo(editButton.currentTitle!.width(constrainedBy: 28, with: .systemFont(ofSize: 12, weight: .medium)) + 20)
        }
        
        blockedAdsLabel.snp.makeConstraints { make in
            make.top.equalTo(exceptionsBlockWebSitesView.snp.bottom).offset(40.resized())
            make.leading.equalToSuperview().offset(24)
            make.height.equalTo(24)
        }
        
        blockedAdsNumberLabel.snp.makeConstraints { make in
            make.top.equalTo(exceptionsBlockWebSitesView.snp.bottom).offset(32.resized())
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(32)
        }
        
        blockedAdsCollectionView.snp.makeConstraints { make in
            make.top.equalTo(blockedAdsLabel.snp.bottom).offset(16.resized())
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(140.resized())
        }
        
        //MARK: TurnOffOn Button Constraints
        
        turnOffOnButtonView.snp.makeConstraints { make in
            make.top.equalTo(blockedAdsCollectionView.snp.bottom).offset(46.resized())
            make.width.equalTo(234)
            make.height.equalTo(52)
            make.centerX.equalToSuperview()
        }
        
        vectorButtonLeftImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(16)
            make.height.equalTo(8)
            make.width.equalTo(28)
        }
        
        vectorButtonRightImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-16)
            make.height.equalTo(8)
            make.width.equalTo(28)
        }
        
        turnOffOnButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(5)
            make.trailing.equalToSuperview().offset(-135)
            make.height.equalTo(42)
        }
        
        adBlockedOffOnLabel.snp.makeConstraints { make in
            make.top.equalTo(turnOffOnButtonView.snp.bottom).offset(16.resized())
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(24)
        }
        
        view.layoutIfNeeded()
        
        editButton.addGradient(.leftRight, ["FF9A62".hexColor, "FA4141".hexColor], 14)
        bottonView.layer.applySketchShadow()
        turnOffOnButton.layer.applySketchShadow(color: UIColor(red: 0.13, green: 0.56, blue: 0.57, alpha: 0.2), alpha: 1, x: 0, y: 2, blur: 1, spread: 1)
        turnOffOnButton.layer.shadowRadius = 20
    
        exceptionsBlockWebSitesView.addGradient(.leftRight, ["5CC8CC".hexColor, "AAED88".hexColor], 20)
        
        exceptionsBlockWebSitesView.addGradient(.bottomTop, ["FFFFFF".hexColor.withAlphaComponent(0.8), "FFFFFF".hexColor.withAlphaComponent(0.05)], 20)
        
        exceptionsBlockWebSitesView.layer.applySketchShadow(color: UIColor(red: 0.36, green: 0.78, blue: 0.8, alpha: 0.2), alpha: 1, x: 0, y: 7, blur: 30, spread: 1)
        exceptionsBlockWebSitesView.clipsToBounds = false
        exceptionsBlockWebSitesView.layer.shadowRadius = 20
        exceptionsBlockWebSitesView.layer.cornerRadius = 20
    }
    
    private func setupBlackAdsCollection() {
        blockedAdsCollectionView.setCollectionViewLayout(blockedAdsLayout, animated: true)
        blockedAdsCollectionView.dataSource = self
        blockedAdsCollectionView.delegate = self
        blockedAdsCollectionView.register(BlockedAdsCollectionViewCell.self, forCellWithReuseIdentifier: BlockedAdsCollectionViewCell.nibIdentifier)
    }
    
    
    private func setupButtons() {
        topMenuButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.SettingButtonAction()
        }.disposed(by: disposeBag)
        
        turnOffOnButtonAction()
        
        editButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.presentExceptions()
        }.disposed(by: disposeBag)
        
        topProtectionButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.premiumButtonImageAction()
        }.disposed(by: disposeBag)
    }
    
    
    //MARK: TurnOffOnButton actions
    private func turnOffOnButtonAction(){
        let swipeGesture = createSwipeGestureRecognizer(for: .right)
        let swipeGesture2 = createSwipeGestureRecognizer(for: .left)
        turnOffOnButton.addGestureRecognizer(swipeGesture)
        turnOffOnButton.addGestureRecognizer(swipeGesture2)
    }
    
    private func createSwipeGestureRecognizer(for direction: UISwipeGestureRecognizer.Direction) -> UISwipeGestureRecognizer {
        let swipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(didSwipe(_:)))
        swipeGestureRecognizer.direction = direction
        return swipeGestureRecognizer
    }
    
    @objc private func didSwipe(_ sender: UISwipeGestureRecognizer) {
        var frame = turnOffOnButton.frame
        switch sender.direction {
        case .left:
            switch self.topCircleImageView.image {
            case "InActive".image:
                self.isActivated = true
                self.setActiveLayout()
            case "Disable".image:
                self.presentTutorialViewController()
            case "Active".image:
                self.isActivated = false
                self.setUnactiveLayout()
                frame.origin.x -= 130.0
                frame.origin.x = max(0.0, frame.origin.x)
                UIView.animate(withDuration: 0.50) {
                    self.vectorButtonLeftImageView.isHidden = true
                    self.vectorButtonRightImageView.isHidden = false
                    Constants.ud.currentAdBlockerValue = 0
                }
            default:break
            }
        case .right:
            switch self.topCircleImageView.image {
            case "InActive".image:
                self.isActivated = true
                self.setActiveLayout()
                frame.origin.x += 130.0
                if frame.maxX > view.bounds.maxX {
                    frame.origin.x = view.bounds.width - frame.width
                }
                UIView.animate(withDuration: 0.50) {
                    self.vectorButtonLeftImageView.isHidden = false
                    self.vectorButtonRightImageView.isHidden = true
                    Constants.ud.currentAdBlockerValue = 1
                }
            case "Disable".image:
                self.presentTutorialViewController()
                Constants.ud.currentAdBlockerValue = 2
                if self.vectorButtonRightImageView.isHidden == true {
                        self.turnOffOnButton.snp.updateConstraints { make in
                            make.leading.equalToSuperview().offset(5)
                            make.trailing.equalToSuperview().offset(-135)
                        }
                        self.view.layoutIfNeeded()
                    UIView.animate(withDuration: 0.50) {
                        self.vectorButtonLeftImageView.isHidden = true
                        self.vectorButtonRightImageView.isHidden = false
                        //Constants.ud.currentAdBlockerValue = 0
                    }
                }
            case "Active".image:
                self.isActivated = false
                self.setUnactiveLayout()
            default:break
            }
        default:
            break
        }
        UIView.animate(withDuration: 0.50) {
            self.turnOffOnButton.frame = frame
        }
    }
    
    
    private func SettingButtonAction(){
        var vc: UIViewController!
        vc = SettingViewController()
        vc.modalPresentationStyle = .pageSheet
        self.present(vc, animated: true, completion: nil)
    }
    
    func presentTutorialViewController() {
        var vc: UIViewController!
        vc = TutorialViewController()
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }

    public func presentExceptions(){
        var vc: UIViewController!
        vc = ExceptionsViewController()
        vc.modalPresentationStyle = .pageSheet
        self.present(vc, animated: true, completion: nil)
    }
    
    private func premiumButtonImageAction(){
        if IAPManager.shared().isPurchased {
            print("Subscriptions succesful")
        } else {
            IAPManager.shared().presentSubscriptionVC()
            IAPManager.shared().purchaseCompletion = { [weak self] _ in
                IAPManager.shared().dismissSubscriptionVC()
                guard let self = self else { return }
                self.checkSubscriptions()
            }
            IAPManager.shared().restoreCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                    AlertManager.shared().showPurchasesWereRestored()
                    self.checkSubscriptions()
                }
            }
        }
    }
    
    public func checkSubscriptions(){
        self.topProtectionButton.isHidden = true
        self.topProtectionButtonView.addGradient(.topLeftBottomRight, ["FFFFFF".hexColor.withAlphaComponent(0.1), "FFFFFF".hexColor.withAlphaComponent(0.1)], 16)
        self.topProtectionButtonView.backgroundColor = "FFFFFF".hexColor.withAlphaComponent(0.1)
        self.topProtectionButtonView.addBorder(width: 1, color: "FFFFFF", withAlphaComponent: 0.5)
        self.topProtectionButtonView.layer.cornerRadius = 16
        self.AccessAdvancedProtectionLabel.text = NSLocalizedString("Advanced protection applied", comment: "")
        self.topProtectionButtonView.layer.addGradienBorder(colors: "FFFFFF".hexColor.withAlphaComponent(0.9), "FFFFFF".hexColor.withAlphaComponent(0.15), width: 1, cornerRadius: 16)
    }
    
    func currentAdBlockerSatus() {
        if Constants.ud.currentAdBlockerValue == 1 {
            UIView.animate(withDuration: 0.7) { [weak self] in
                guard let self = self else { return }
                self.turnOffOnButton.snp.remakeConstraints { make in
                    make.height.equalTo(42)
                    make.centerY.equalToSuperview()
                    make.leading.equalToSuperview().offset(135)
                    make.trailing.equalToSuperview().offset(-5)
                }
                self.view.layoutIfNeeded()
                self.vectorButtonLeftImageView.isHidden = false
                self.vectorButtonRightImageView.isHidden = true
                self.turnOffOnButton.setTitle(NSLocalizedString("Turn Off", comment: ""), for: .normal)
                self.isActivated = true
            }
        } else {
            UIView.animate(withDuration: 0.7) { [weak self] in
                guard let self = self else { return }
                self.turnOffOnButton.snp.remakeConstraints { make in
                    make.height.equalTo(42)
                    make.centerY.equalToSuperview()
                    make.leading.equalToSuperview().offset(5)
                    make.trailing.equalToSuperview().offset(-135)
                }
                self.view.layoutIfNeeded()
                self.vectorButtonLeftImageView.isHidden = true
                self.vectorButtonRightImageView.isHidden = false
                self.turnOffOnButton.setTitle(NSLocalizedString("Turn On", comment: ""), for: .normal)
                self.isActivated = false
            }
        }
    }
}



extension CALayer {
  func applySketchShadow(
    color: UIColor = .white,
    alpha: Float = 1,
    x: CGFloat = 0,
    y: CGFloat = -40,
    blur: CGFloat = 140,
    spread: CGFloat = 150)
  {
    masksToBounds = false
    shadowColor = color.cgColor
    shadowOpacity = alpha
    shadowOffset = CGSize(width: x, height: y)
    shadowRadius = blur / 2.0
    if spread == 0 {
      shadowPath = nil
    } else {
      let dx = -spread
      let rect = bounds.insetBy(dx: dx, dy: dx)
      shadowPath = UIBezierPath(rect: rect).cgPath
    }
  }
}

//MARK: - CollectionView
extension HomeViewController: UICollectionViewDelegate {
    
    func adsActiveNonActiveValue (index: Int) {
        Constants.ud.blockAdsSwitchValue = !Constants.ud.blockAdsSwitchValue
        blockedAdsCollectionModel[index].value = Constants.ud.blockAdsSwitchValue
    }

    func ads (){
        if Constants.ud.blockAdsSwitchValue {
            Constants.ud.adsBlockedCount? += 5679
        } else {
            Constants.ud.adsBlockedCount? -= 5679
        }
    }
    
    func socialActiveNonActiveValue(index: Int) {
        Constants.ud.blockSocialSwitchValue = !Constants.ud.blockSocialSwitchValue
        blockedAdsCollectionModel[index].value = Constants.ud.blockSocialSwitchValue
    }

    func social() {
        if Constants.ud.blockSocialSwitchValue {
            Constants.ud.adsBlockedCount? += 7213
        } else {
            Constants.ud.adsBlockedCount? -= 7213
        }
    }
    
    func scriptActiveNonActiveValue(index: Int) {
        if !IAPManager.shared().isPurchased {
            IAPManager.shared().presentSingleSubscriptionVC()
        } else {
            IAPManager.shared().dismissSubscriptionVC()
            Constants.ud.blockScriptsSwitchValue = !Constants.ud.blockScriptsSwitchValue
            blockedAdsCollectionModel[index].value = Constants.ud.blockScriptsSwitchValue

            if Constants.ud.blockScriptsSwitchValue {
                Constants.ud.adsBlockedCount? += 4521
            } else {
                Constants.ud.adsBlockedCount? -= 4521
            }
        }
    }
    
    func trackingActiveNonActiveValue(index: Int) {
        if !IAPManager.shared().isPurchased {
            IAPManager.shared().presentSingleSubscriptionVC()
        } else {
            IAPManager.shared().dismissSubscriptionVC()
            Constants.ud.blockTrackingSwitchValue = !Constants.ud.blockTrackingSwitchValue
            blockedAdsCollectionModel[index].value = Constants.ud.blockTrackingSwitchValue

            if Constants.ud.blockTrackingSwitchValue {
                Constants.ud.adsBlockedCount? += 12567
            } else {
                Constants.ud.adsBlockedCount? -= 12567
            }
        }
    }
    
    func URLsActiveNonActiveValue(index: Int) {
        if !IAPManager.shared().isPurchased {
            IAPManager.shared().presentSingleSubscriptionVC()
        } else {
            IAPManager.shared().dismissSubscriptionVC()
            Constants.ud.blockURLSSwitchValue = !Constants.ud.blockURLSSwitchValue
            blockedAdsCollectionModel[index].value = Constants.ud.blockURLSSwitchValue

            if Constants.ud.blockURLSSwitchValue {
                Constants.ud.adsBlockedCount? += 39621
            } else {
                Constants.ud.adsBlockedCount? -= 39621
            }
        }
    }
}

extension HomeViewController: UICollectionViewDataSource{
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return blockedAdsCollectionModel.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: BlockedAdsCollectionViewCell.nibIdentifier, for: indexPath) as! BlockedAdsCollectionViewCell
        let blockedAdsCollectionModel = blockedAdsCollectionModel[indexPath.item]
        cell.blockedAdsModel = blockedAdsCollectionModel
    
        blockedAdsCollectionModel.value ?? false ? cell.configureLayoutOn() : cell.configureLayoutOff()
        cell.completion = {
            switch self.topCircleImageView.image {
            case "InActive".image, "Active".image:
               switch self.blockedAdsCollectionModel[indexPath.item].title {
               case NSLocalizedString("Block Ads", comment: ""):
                   self.adsActiveNonActiveValue(index: indexPath.item)
                   self.ads()
               case NSLocalizedString("Widgets Social", comment: ""):
                   self.socialActiveNonActiveValue(index: indexPath.item)
                   self.social()
               case NSLocalizedString("Block Scripts", comment: ""):
                   self.scriptActiveNonActiveValue(index: indexPath.item)
               case NSLocalizedString("Block Tracking", comment: ""):
                   self.trackingActiveNonActiveValue(index: indexPath.item)
               case NSLocalizedString("Block URLs", comment: ""):
                   self.URLsActiveNonActiveValue(index: indexPath.item)
               default: break
               }
               self.blockedAdsCollectionView.reloadData()
            case "Disable".image:
                cell.turnOffOnButtonAction()
                self.presentTutorialViewController()
            default:break
            }
    
            self.blockedAdsNumberLabel.text = "\(Constants.ud.adsBlockedCount ?? 0)"
        }
        return cell
    }
}

//MARK: - Safari Services
extension HomeViewController {
    func configureAdblockAction() {
        progressView.show()
        SFContentBlockerManager.getStateOfContentBlocker(withIdentifier: Constants.app.contentBlockerExtensionName) { [weak self] (state, error) in
            if let state = state {
                if state.isEnabled {
                    SFContentBlockerManager.reloadContentBlocker(withIdentifier: Constants.app.contentBlockerExtensionName) { [weak self] (error) in
                        guard let self = self else { return }
                        if error == nil {
                            print("Rules activated.")
                            print(self.blackList?.count)
                            self.isProtected = true
                            self.isActivated ? self.setActiveLayout() : self.setUnactiveLayout()

                        } else {
                            print("ERROR activating rules")
                            print(error)
                            self.isProtected = false
                            self.setDisabledLayout()
                        }
                    }
                } else {
                    self?.isProtected = false
                    self?.setDisabledLayout()
                }
            } else if let error = error {
                print(error)
                self?.isProtected = false
                self?.setDisabledLayout()
            }
        }
    }

    func configureBindBlockAction() {
        UIApplication.shared.rx.applicationDidBecomeActive.bind { [weak self] _ in
            self?.configureAdblockAction()
        }.disposed(by: disposeBag)
    }

    func setDisabledLayout() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.topCircleImageView.image = "Disable".image
            self.turnOffOnButton.setTitle(NSLocalizedString("Turn On", comment: ""), for: .normal)
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.alignment = .center
            let attributedTitle = (NSLocalizedString("HotLocker ", comment: "").withAttributes([.textColor("208E92".hexColor),
                .font(.systemFont(ofSize: 14, weight: .regular))]) + NSLocalizedString("Disabled", comment: "").withAttributes([.textColor("#F11E01".hexColor),
                .font(.systemFont(ofSize: 14, weight: .regular))])).withAttribute(.paragraphStyle(paragraphStyle))
            self.adBlockedOffOnLabel.attributedText = attributedTitle
            if IAPManager.shared().isPurchased {
                IAPManager.shared().dismissSubscriptionVC()
            }
            
            if self.vectorButtonRightImageView.isHidden == true {
                    self.turnOffOnButton.snp.updateConstraints { make in
                        make.leading.equalToSuperview().offset(5)
                        make.trailing.equalToSuperview().offset(-135)
                    }
                    self.view.layoutIfNeeded()
                UIView.animate(withDuration: 0.50) {
                    self.vectorButtonLeftImageView.isHidden = true
                    self.vectorButtonRightImageView.isHidden = false
                }
            }
            self.progressView.hide()
        }
    }

    func setUnactiveLayout() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.topCircleImageView.image = "InActive".image
            self.turnOffOnButton.setTitle(NSLocalizedString("Turn On", comment: ""), for: .normal)

            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.alignment = .center
            let attributedTitle = (NSLocalizedString("HotLocker Disabled", comment: "").withAttributes([
                .textColor("208E92".hexColor),
                .font(.systemFont(ofSize: 14, weight: .regular)),
                .paragraphStyle(paragraphStyle)]))
            self.adBlockedOffOnLabel.attributedText = attributedTitle
            if IAPManager.shared().isPurchased {
                IAPManager.shared().dismissSubscriptionVC()
            }
            self.currentAdBlockerSatus()
            self.progressView.hide()
        }
    }

    func setActiveLayout() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.topCircleImageView.image = "Active".image
            self.turnOffOnButton.setTitle(NSLocalizedString("Turn Off", comment: ""), for: .normal)
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.alignment = .center
            let attributedTitle = (NSLocalizedString("HotLocker Enabled", comment: "").withAttributes([
                .textColor("208E92".hexColor),
                .font(.systemFont(ofSize: 14, weight: .regular)),
                .paragraphStyle(paragraphStyle)]))
            self.adBlockedOffOnLabel.attributedText = attributedTitle
            if IAPManager.shared().isPurchased {
                IAPManager.shared().dismissSubscriptionVC()
            }
            self.currentAdBlockerSatus()
            self.progressView.hide()
        }
    }

    func openSettings() {
        if let URL = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(URL)
        }
    }
}


