import UIKit

class LaunchViewController: UIViewController {
    
    private var topImageView: UIImageView = {
        let imageView = UIImageView(image: "FullView".image )
        imageView.contentMode = .scaleAspectFill
        imageView.isUserInteractionEnabled = true
        imageView.layer.masksToBounds = false
        imageView.clipsToBounds = false
        return imageView
    }()
    
    private var centerImageView: UIImageView = {
        let imageView = UIImageView(image: "logo".image )
        imageView.contentMode = .scaleAspectFill
        imageView.isUserInteractionEnabled = true
        imageView.layer.masksToBounds = false
        imageView.clipsToBounds = false
        return imageView
    }()
    
    private var appNameLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .medium)
        label.textAlignment = .center
        label.text = NSLocalizedString("HotLocker", comment: "")
        label.textColor = "208E92".hexColor
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup(){
        configureLayout()
        setHomeViewController()
    }
    
    private func configureLayout(){
        view.backgroundColor = .yellow
        
        view.addSubviews(topImageView, centerImageView,  appNameLabel)
        
        topImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        centerImageView.snp.makeConstraints { make in
            make.center.equalToSuperview()
            make.size.equalTo(375)
        }
        
        appNameLabel.snp.makeConstraints { make in
            make.top.equalTo(centerImageView.snp.bottom)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(24)
        }
    }
    
    private func setHomeViewController() {
        if UserDefaults.standard.value(forKey: "showCurrentController") != nil {
            showCurrentController = UserDefaults.standard.value(forKey: "showCurrentController") as! Bool
        }
        
        let controller = showCurrentController ? HomeViewController() : PresentViewController()
        let navigationController = UINavigationController(rootViewController: controller)
        UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.rootViewController = navigationController
        UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.makeKeyAndVisible()
    }
}
