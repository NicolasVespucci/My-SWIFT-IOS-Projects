import UIKit
import RxSwift
import RxCocoa
import RxRelay
import SnapKit
import AppTrackingTransparency

class PresentViewController: UIViewController, UIScrollViewDelegate {
    
    private let firstView = PresentView(image: "first".image ?? UIImage(), topText: NSLocalizedString("Adblock for safari", comment: ""), bottomText: NSLocalizedString("Protect your internet data & information", comment: ""))
    private let secondView = PresentView(image: "second".image ?? UIImage(), topText: NSLocalizedString("Complete adware blocking", comment: ""), bottomText: NSLocalizedString("Your personal data is protected,\nany unauthorized interference is excluded", comment: ""))
    
    private var topImageView: UIImageView = {
        let imageView = UIImageView(image: "TopView".image )
        imageView.contentMode = .scaleAspectFill
        imageView.isUserInteractionEnabled = true
        imageView.layer.masksToBounds = false
        imageView.clipsToBounds = false
        return imageView
    }()
    
    private var bottonView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.clipsToBounds = false
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.applySketchShadow()
        return view
    }()
    
    private var scrollView: UIScrollView = {
        let view = UIScrollView()
        view.isPagingEnabled = true
        view.isScrollEnabled = false
        view.showsHorizontalScrollIndicator = false
        return view
    }()
    
    private var continueStartButton: UIButton = {
        let button = UIButton()
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .medium)
        button.titleLabel?.textColor = "FFFFFF".hexColor
        button.titleLabel?.textAlignment = .center
        button.backgroundColor = "02008C".hexColor
        button.layer.cornerRadius = 16
        button.setTitle(NSLocalizedString("Continue", comment: ""), for: .normal)
        return button
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("backPresent".image, for: .normal)
        button.isUserInteractionEnabled = true
        button.isHidden = true
        return button
    }()
    
    var xOffSet: CGFloat = 0
    var contentWidth: CGFloat = 0.0
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup(){
        configureLayout()
        configureScrollView()
        configureButtons()
    }
    
    private func configureLayout(){
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = .white
        view.addSubviews(topImageView, bottonView, backButton, scrollView, continueStartButton )
    
        topImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo((UIScreen.main.bounds.height) / 2)
        }
        
        bottonView.snp.makeConstraints { make in
            make.top.equalTo(topImageView.snp.bottom)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.leading.equalToSuperview().offset(24)
            make.size.equalTo(24)
        }
        
        scrollView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(102.resized())
            make.leading.equalToSuperview()
            make.width.equalTo(375.resized(.width))
            make.height.equalTo(482.resized())
        }
        
        continueStartButton.snp.makeConstraints { make in 
            make.bottom.equalToSuperview().offset(-116.resized())
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(56)
        }
        
        view.layoutIfNeeded()
        bottonView.layer.applySketchShadow()
        
        continueStartButton.addGradient(.leftRight, ["FF9A62".hexColor, "5CC8CC".hexColor], 16)
    }
    
    private func configureButtons() {
        continueStartButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.continueStartButtonAction()
        }.disposed(by: disposeBag)
        
        backButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.backBattonsActions()
        }.disposed(by: disposeBag)
    }
    
    private func homeViewControllerAction(){
        let vc = HomeViewController()
        let nc = UINavigationController(rootViewController: vc)
        guard let window = UIApplication.shared.windows.first else { return }
        window.rootViewController = nc
    }
    
    private func backBattonsActions() {
        self.xOffSet = 0
        self.scrollView.contentOffset.x = self.xOffSet
        backButton.isHidden = true
        self.continueStartButton.setTitle(NSLocalizedString("Continue", comment: ""), for: .normal)
    }

    private func continueStartButtonAction(){
        if self.xOffSet < UIScreen.main.bounds.width {
            requestPermission()
            DispatchQueue.main.async {
                self.xOffSet += UIScreen.main.bounds.width
                self.scrollView.contentOffset.x = self.xOffSet
                self.continueStartButton.setTitle(NSLocalizedString("Start", comment: ""), for: .normal)
                self.backButton.isHidden = false
            }
        } else {
            showCurrentController = true
            UserDefaults.standard.set(showCurrentController, forKey: "showCurrentController")
            homeViewControllerAction()
            self.xOffSet = UIScreen.main.bounds.width
        }
    }
    
    func requestPermission() {
        if #available(iOS 14, *) {
            ATTrackingManager.requestTrackingAuthorization { status in
                switch status {
                case .authorized:
                    // Tracking authorization dialog was shown
                    // and we are authorized
                    print("Authorized")
                    // Now that we are authorized we can get the IDFA
                case .denied:
                    // Tracking authorization dialog was
                    // shown and permission is denied
                    print("Denied")
                case .notDetermined:
                    // Tracking authorization dialog has not been shown
                    print("Not Determined")
                case .restricted:
                    print("Restricted")
                @unknown default:
                    print("Unknown")
                }
            }
        }
    }
    
    private func configureScrollView() {
        scrollView.delegate = self
        let viewsForScroll = [firstView, secondView]
        for (index, view) in viewsForScroll.enumerated() {
            scrollView.addSubview(view)
            view.snp.makeConstraints { make in
                make.top.equalToSuperview()
                make.bottom.equalToSuperview()
                make.leading.equalToSuperview().offset(CGFloat(index) * UIScreen.main.bounds.width)
                make.width.equalToSuperview()
            }
            self.view.layoutIfNeeded()
            self.scrollView.layoutIfNeeded()
            contentWidth += self.view.frame.width
        }
        scrollView.contentSize = CGSize(width: contentWidth, height: scrollView.frame.height)
    }
}
