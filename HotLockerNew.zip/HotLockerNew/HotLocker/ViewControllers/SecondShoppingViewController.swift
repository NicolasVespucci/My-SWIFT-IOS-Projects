import UIKit
import SnapKit
import RxSwift
import StoreKit
import SwiftyStoreKit
import SwiftyAttributes
import NetworkExtension
import Network
import Reachability

class SecondShoppingViewController: UIViewController {
    
    var identifiers = [Constants.analytics.week, Constants.analytics.threeMonth, Constants.analytics.year]
    
    public var secondShoppingViewControllerModel = [FirstShoppingViewControllerModel(image: "eye", title:                                                        NSLocalizedString("No tracking", comment: "")),
                                                   FirstShoppingViewControllerModel(image: "minus", title: NSLocalizedString("Block custom URLs", comment: "")),
                                                   FirstShoppingViewControllerModel(image: "file", title: NSLocalizedString("Advanced database with Ads", comment: ""))
    ]
    
    private var topImageView: UIImageView = {
        let imageView = UIImageView(image: "TopView".image )
        imageView.contentMode = .scaleAspectFill
        imageView.isUserInteractionEnabled = true
        imageView.layer.masksToBounds = false
        imageView.clipsToBounds = false
        return imageView
    }()
    
    private var bottonView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.clipsToBounds = false
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.applySketchShadow()
        return view
    }()
    
    private var topBackButton: UIButton = {
        let button = UIButton()
        button.setImage("backFirstShopping".image, for: .normal)
        return button
    }()
    
    private var topRestoreButton: UIButton = {
        let button = UIButton()
        button.setTitle(NSLocalizedString("Restore", comment: ""), for: .normal)
        return button
    }()
    
    private var topStarImageView: UIImageView = {
        let imageView = UIImageView(image: "StarFirstShopping".image)
        return imageView
    }()
    
    private var AdvancedProtectionLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .regular)
        label.textAlignment = .center
        label.text = NSLocalizedString("Advanced protection", comment: "")
        label.textColor = .white
        return label
    }()
    
    private var centerDignitiesView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 20
        view.addBorder(width: 1, color: "FFFFFF", withAlphaComponent: 0.5)
        view.clipsToBounds = false
        return view
    }()
    
    private lazy var topDignitiesTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 40
        table.backgroundColor = .clear
        table.isScrollEnabled = false
        table.separatorStyle = .none
        return table
    }()
    
    private lazy var payCollectionView: UICollectionView = {
        let collection = UICollectionView(frame: .zero, collectionViewLayout: .init())
        collection.backgroundColor = .clear
        collection.showsHorizontalScrollIndicator = false
        collection.showsVerticalScrollIndicator = false
        collection.isScrollEnabled = true
        collection.clipsToBounds = false
        return collection
    }()
    
    private lazy var payLayout: UICollectionViewLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 0
        layout.itemSize = .init(width: UIScreen.main.bounds.width, height: 56.resized())
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 16.resized()
        layout.sectionInset = .init(top: 0, left: 0, bottom: 0, right: 0)
        return layout
    }()
    
    public var pricePeriodLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.textColor = "0F4345".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private lazy var subscribeButton: UIButton = {
        let button = UIButton()
        button.layer.cornerRadius = 16
        button.setTitle(NSLocalizedString("Subscribe", comment: ""), for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .medium)
        button.titleLabel?.textColor = .white
        return button
    }()
    
    private var emptyView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        view.isUserInteractionEnabled = true
        return view
    }()
    
    var productsDescription: NSAttributedString {
        let terms = NSLocalizedString("Terms", comment: "") + " " + NSLocalizedString("of", comment: "") + " " + NSLocalizedString("Use", comment: "")
        let privacy = NSLocalizedString("Privacy", comment: "") + NSLocalizedString("and", comment: "") + NSLocalizedString("Policy", comment: "")
        let and = " & "
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        
        let textAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12, weight: .medium)),
            .textColor("0F4345".hexColor.withAlphaComponent(0.8)),
            .paragraphStyle(paragraphStyle)
        ]
        
        let andAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12, weight: .medium)),
            .textColor("0F4345".hexColor.withAlphaComponent(0.5)),
            .paragraphStyle(paragraphStyle)
        ]
        
        let attributedDescription =
        terms.withAttributes(textAttributes)
        + and.withAttributes(andAttributes)
        + privacy.withAttributes(textAttributes)
        return attributedDescription
    }
    
    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.layoutIfNeeded()
        textView.isEditable = false
        textView.isSelectable = false
        textView.isScrollEnabled = false
        textView.backgroundColor = .clear
        textView.showsVerticalScrollIndicator = true
        textView.attributedText = productsDescription
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapResponse(recognizer:)))
        textView.addGestureRecognizer(tap)
        return textView
    }()
    
    public lazy var progressView = ProgressView(message: "", theme: .dark, isModal: true)
    
    let bag = DisposeBag()
    
    var products = [SKProduct]()
    var selectedIndex = 0
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
        configureUpdateProducts()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if let homeController = (presentingViewController as? UINavigationController)?.viewControllers.first as? HomeViewController {
            
            if IAPManager.shared().isPurchased {
                homeController.viewDidLoad() 
            }
        }
    }
    
    private func setup(){
        configureUpdateProducts()
        configureLayout()
        setupShoppingCollection()
        configureButtons()
        setupTableView()
    }
    
    private func setupTableView() {
        topDignitiesTableView.delegate = self
        topDignitiesTableView.dataSource = self
        topDignitiesTableView.register(FirstShoppingCell.self, forCellReuseIdentifier: FirstShoppingCell.nibIdentifier)
    }
    
    private func setupShoppingCollection() {
        payCollectionView.setCollectionViewLayout(payLayout, animated: true)
        payCollectionView.dataSource = self
        payCollectionView.delegate = self
        payCollectionView.register(SecondShoppingCell.self, forCellWithReuseIdentifier: SecondShoppingCell.nibIdentifier)
    }
    
    private func configureLayout(){
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = .white
        view.addSubviews(topImageView, bottonView, topBackButton, topRestoreButton, topStarImageView, AdvancedProtectionLabel, centerDignitiesView, payCollectionView, pricePeriodLabel, emptyView, textView)
        
        emptyView.addSubview(subscribeButton)
        
        centerDignitiesView.addSubview(topDignitiesTableView)
        
        topImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo((UIScreen.main.bounds.height) / 2)
        }
        
        bottonView.snp.makeConstraints { make in
            make.top.equalTo(topImageView.snp.bottom)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        topBackButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(56)
            make.leading.equalToSuperview().offset(26)
            make.size.equalTo(20)
        }
        
        topRestoreButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(24)
        }
        
        topStarImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(72.resized())
            make.size.equalTo(50)
            make.centerX.equalToSuperview()
        }
        
        AdvancedProtectionLabel.snp.makeConstraints { make in
            make.top.equalTo(topStarImageView.snp.bottom).offset(16.resized())
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(32)
        }
        
        centerDignitiesView.snp.makeConstraints { make in
            make.top.equalTo(AdvancedProtectionLabel.snp.bottom).offset(24.resized())
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(144)
        }
        
        topDignitiesTableView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(20)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview().offset(-20)
        }
        
        payCollectionView.snp.makeConstraints { make in
            make.top.equalTo(topDignitiesTableView.snp.bottom).offset(32.resized())
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(200.resized())
        }
        
        pricePeriodLabel.snp.makeConstraints { make in
            make.top.equalTo(payCollectionView.snp.bottom).offset(32.resized())
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(24)
        }
        
        emptyView.snp.makeConstraints { make in
            make.top.equalTo(pricePeriodLabel.snp.bottom).offset(10)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalTo(textView.snp.top).offset(-10)
        }
        
        subscribeButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(56)
        }
        
        textView.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-10.resized())
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(50)
        }
        
        view.layoutIfNeeded()
        bottonView.layer.applySketchShadow()
        
        centerDignitiesView.addGradient(.leftRight, ["5CC8CC".hexColor, "AAED88".hexColor], 20)
        
        centerDignitiesView.addGradient(.bottomTop, ["FFFFFF".hexColor.withAlphaComponent(0.8), "FFFFFF".hexColor.withAlphaComponent(0.05)], 20)
        
        centerDignitiesView.layer.applySketchShadow(color: UIColor(red: 0.36, green: 0.78, blue: 0.8, alpha: 0.2), alpha: 1, x: 0, y: 7, blur: 30, spread: 1)
        centerDignitiesView.clipsToBounds = false
        centerDignitiesView.layer.shadowRadius = 20
        centerDignitiesView.layer.cornerRadius = 20
        
        subscribeButton.addGradient(.leftRight, ["FF9A62".hexColor, "5CC8CC".hexColor], 16)
        
        view.layoutSubviews()
        
        IAPManager.shared().productsReceived.bind { [weak self] received in
            if received {
                self?.payCollectionView.reloadData()
            } else {
                self?.configureUpdateProducts()
            }
        }.disposed(by: disposeBag)
        
        IAPManager.shared().productsReceived.bind { [weak self] received in
            if received {
                self?.payCollectionView.reloadData()
            } else {
                self?.configureUpdateProducts()
                self?.payCollectionView.reloadData()
            }
        }.disposed(by: disposeBag)
    }
    
    private func configureButtons() {
       
        topRestoreButton.rx.tap.bind {
            IAPManager.shared().restore()
            IAPManager.shared().restoreCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                    AlertManager.shared().showPurchasesWereRestored()
                }
            }
        }.disposed(by: bag)
        
        topBackButton.rx.tap.bind { [weak self] in
            self?.dismiss(animated: true)
        }.disposed(by: disposeBag)
        
        subscribeButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            let product = self.identifiers[self.selectedIndex]
            IAPManager.shared().purchase(rcPackage: product, quantity: 1, atomically: true)
        }.disposed(by: disposeBag)
    }

    private func configurePriceLabel(product: SKProduct?) {
        guard let appHudproduct = product else { return }
        let product = Product(product: appHudproduct)
        guard let period = product.period else { return }
        let price = product.localizedPrice
        let perPeriodString = period.perFormattedString.capitalized
        
        if product.introductory?.period != nil {
            pricePeriodLabel.text = (product.introductory?.period?.formattedString ?? "asda") + NSLocalizedString(" free trial then ", comment: "") + price + NSLocalizedString(" per ", comment: "") + perPeriodString
            subscribeButton.setTitle(NSLocalizedString("Start ", comment: "") + (product.introductory?.period?.formattedString ?? "asda") + NSLocalizedString(" free trial", comment: ""), for: .normal)
        } else {
            pricePeriodLabel.text = price + NSLocalizedString(" per ", comment: "") + perPeriodString
            subscribeButton.setTitle(NSLocalizedString("Subscribe", comment: ""), for: .normal)
        }
    }
    
    private func configureUpdateProducts() {
        progressView.show()
        SwiftyStoreKit.retrieveProductsInfo([Constants.analytics.week, Constants.analytics.threeMonth, Constants.analytics.year]) { result in
            if(!result.retrievedProducts.isEmpty) {
                self.products = Array(result.retrievedProducts).sorted(by: { Product(product: $0).price < Product(product: $1).price })
                self.payCollectionView.reloadData()
                self.configurePriceLabel(product: self.products[0])
                self.progressView.hide()
            } else {
                self.progressView.hide()
                self.configureUpdateProducts()
            }
        }
    }
}

//MARK: - Text View
extension SecondShoppingViewController {
    @objc func tapResponse(recognizer: UITapGestureRecognizer) {
        let location: CGPoint = recognizer.location(in: textView)
        let position: CGPoint = CGPoint(x: location.x, y: location.y)
        let tapPosition: UITextPosition? = textView.closestPosition(to: position)
        if tapPosition != nil {
            let textRange: UITextRange? = textView.tokenizer.rangeEnclosingPosition(tapPosition!, with: UITextGranularity.word, inDirection: UITextDirection(rawValue: 1))
            if textRange != nil
            {
                let tappedWord: String? = textView.text(in: textRange!)
                guard let word = tappedWord else { return }
                wordAction(word)
            }
        }
    }
    
    private func wordAction(_ word: String) {
        switch word {
        case NSLocalizedString("Terms", comment: ""), NSLocalizedString("of", comment: ""), NSLocalizedString("Use", comment: ""): pushPoliciesVC(.terms)
            
        case NSLocalizedString("Privacy", comment: ""),NSLocalizedString("and", comment: ""), NSLocalizedString("Policy", comment: ""): pushPoliciesVC(.privacy)
        default: break
        }
    }
    
    func pushPoliciesVC(_ policiesType: Policies) {
        let termsVC = TermsAndPrivacy()
        termsVC.policiesType = policiesType
        navigationController?.pushViewController(termsVC, animated: true)
    }
}
//MARK: - TableView

extension SecondShoppingViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}
extension SecondShoppingViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return secondShoppingViewControllerModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cellOne = topDignitiesTableView.dequeueReusableCell(withIdentifier: FirstShoppingCell.nibIdentifier, for:  indexPath) as! FirstShoppingCell
            let settingModelTwo = secondShoppingViewControllerModel[indexPath.row]
            cellOne.FirstShoppingCellModel = settingModelTwo
            return cellOne
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }

}

//MARK: - CollectionView
extension SecondShoppingViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedIndex = indexPath.item
        let apphudProduct = self.products[selectedIndex]
        configurePriceLabel(product: apphudProduct)
        payCollectionView.reloadData()
        if IAPManager.shared().isPurchased {
            IAPManager.shared().dismissSubscriptionVC()
        }
    }
}

extension SecondShoppingViewController: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return products.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SecondShoppingCell.nibIdentifier, for: indexPath) as! SecondShoppingCell
        let apphudProduct = products[indexPath.item]
        let product = Product(product: apphudProduct)
        print(product)
        cell.product = product
        if indexPath.item == self.selectedIndex {
            product.type == .renewable(.trial) ? cell.configureTrialSelectedLayout() : cell.configureCommonSelectedLayout()
        } else {
            product.type == .renewable(.trial) ? cell.configureTrialLayout() : cell.configureCommonLayout()
        }
        return cell
    }
}
