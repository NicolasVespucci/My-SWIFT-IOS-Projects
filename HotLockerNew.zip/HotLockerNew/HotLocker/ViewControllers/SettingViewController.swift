import UIKit
import RxCocoa
import RxSwift
import SnapKit
import NetworkExtension
import Network
import MessageUI

class SettingViewController: UIViewController {
    
    public var settingViewControllerModel = [SettingViewControllerModel(image: "lock", title: NSLocalizedString("Privacy policy", comment: "")),
                                             SettingViewControllerModel(image: "document", title: NSLocalizedString("Terms and Conditions", comment: "")),
                                             SettingViewControllerModel(image: "chat", title: NSLocalizedString("Contact us", comment: "")),
                                             SettingViewControllerModel(image: "share", title: NSLocalizedString("Share app", comment: "")),
                                             SettingViewControllerModel(image: "transaction", title: NSLocalizedString("Restore purchases", comment: ""))
    ]
    
    private var appNameLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.textColor = "0F4345".hexColor
        label.text = NSLocalizedString("Settings", comment: "")
        label.textAlignment = .center
        return label
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("backSettings".image, for: .normal)
        return button
    }()
    
    private lazy var tableViewTwo: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 64
        table.backgroundColor = .clear
        table.isScrollEnabled = false
        table.separatorStyle = .none
        return table
    }()

    let userDefaults = UserDefaults.standard
    var selectedIndex = 0
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        launch()
    }
    
    private func launch() {
        configureLayout()
        configureTableViewTwo()
        configureButtons()
    }

    private func configureTableViewTwo() {
        tableViewTwo.delegate = self
        tableViewTwo.dataSource = self
        tableViewTwo.register(SettingsCell.self, forCellReuseIdentifier: SettingsCell.nibIdentifier)
    }
    
    private func configureLayout(){
        self.navigationController?.isNavigationBarHidden = true
        view.backgroundColor = "#F7F9FC".hexColor
        
        view.addSubviews(appNameLabel, backButton, tableViewTwo)
        
        appNameLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(14)
            make.leading.equalToSuperview().offset(153)
            make.trailing.equalToSuperview().offset(-154)
            make.height.equalTo(24)
        }
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(16)
            make.leading.equalToSuperview().offset(26)
            make.size.equalTo(24)
        }
        
        tableViewTwo.snp.makeConstraints { make in
            make.top.equalTo(appNameLabel.snp.bottom).offset(32.resized())
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(304)
        }
    }
    
    private func configureButtons() {
        backButton.rx.tap.bind { [weak self] in
            self?.dismiss(animated: true)
        }.disposed(by: disposeBag)
    }

    func pushPoliciesVC(_ policiesType: Policies) {
        let termsVC = TermsAndPrivacy()
        termsVC.policiesType = policiesType
        termsVC.modalPresentationStyle = .pageSheet
        self.present(termsVC, animated: true, completion: nil)
    }
    
    private func contact() {
        if MFMailComposeViewController.canSendMail() {
            let toRecipients = ["support@hotlocker-app.com"]
            let subject = "Feedback"
            let mail = configuredMailComposeViewController(recipients: toRecipients, subject: subject, body: "", isHtml: true, images: nil)
            presentMailComposeViewController(mailComposeViewController: mail)
        } else {
            print("You don't have email in Mail iOS App")
        }
    }
    
    private func restore() {
        if Constants.ud.isPurchased {
            AlertManager.shared().showNoPurchasesToRestore()
        } else {
            IAPManager.shared().restore()
            IAPManager.shared().restoreCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                    AlertManager.shared().showPurchasesWereRestored()
                }
            }
        }
    }
}

extension SettingViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch settingViewControllerModel[indexPath.row].title {
        case NSLocalizedString("Privacy policy", comment: ""):
            pushPoliciesVC(.privacy)
        case NSLocalizedString("Terms and Conditions", comment: ""):
            pushPoliciesVC(.terms)
        case NSLocalizedString("Contact us", comment: ""):
            contact()
        case NSLocalizedString("Share app", comment: ""):
            share()
        case NSLocalizedString("Restore purchases", comment: ""):
            restore()
        default: print("Unknown")
        }
    }
}

extension SettingViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return settingViewControllerModel.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableViewTwo.dequeueReusableCell(withIdentifier: SettingsCell.nibIdentifier, for:  indexPath) as! SettingsCell
        let settingModelTwo = settingViewControllerModel[indexPath.row]
        cell.settingCellModel = settingModelTwo
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
    
    func share() {
        UIGraphicsBeginImageContext(view.frame.size)
        view.layer.render(in: UIGraphicsGetCurrentContext()!)
        
        let textToShare = "Check out my app"

        if let myWebsite = URL(string: "http://itunes.apple.com/app/\(Constants.app.appid)") {//Enter link to your app here
            let objectsToShare = [textToShare, myWebsite] as [Any]
            let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            activityVC.excludedActivityTypes = [UIActivity.ActivityType.airDrop, UIActivity.ActivityType.addToReadingList]
            activityVC.popoverPresentationController?.sourceView = self.view
            self.present(activityVC, animated: true, completion: nil)
        }
    }
}
