import UIKit
import SnapKit
import RxSwift

class TutorialViewController: UIViewController {
    
    public var firstShoppingViewControllerModel = [FirstShoppingViewControllerModel(image: "Step1", title: NSLocalizedString("Open Settings", comment: "")),
                                             FirstShoppingViewControllerModel(image: "Step2", title: NSLocalizedString("Locate Safari", comment: "")),
                                             FirstShoppingViewControllerModel(image: "Step3", title: NSLocalizedString("Go to Extensions", comment: "")),
                                             FirstShoppingViewControllerModel(image: "Step4", title: NSLocalizedString("Switch On HotLocker", comment: ""))
    ]
    
    private var topImageView: UIImageView = {
        let imageView = UIImageView(image: "TopView".image )
        imageView.contentMode = .scaleAspectFill
        imageView.isUserInteractionEnabled = true
        imageView.layer.masksToBounds = false
        imageView.clipsToBounds = false
        return imageView
    }()
    
    private var bottonView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.clipsToBounds = false
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.applySketchShadow()
        return view
    }()
    
    private var topBackButton: UIButton = {
        let button = UIButton()
        button.setImage("backFirstShopping".image, for: .normal)
        return button
    }()
    
    private var HowToEnableLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .regular)
        label.textAlignment = .center
        label.text = NSLocalizedString("How to enable", comment: "")
        label.textColor = .white
        return label
    }()
    
    private var appNameLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 12, weight: .semibold)
        label.textAlignment = .center
        label.text = NSLocalizedString("HotLocker", comment: "")
        label.textColor = .white
        return label
    }()
    
    private var centerImageView: UIImageView = {
        let imageView = UIImageView(image: "coin".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private var centerDignitiesView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 20
        view.layer.masksToBounds = true
        view.addBorder(width: 1, color: "FFFFFF", withAlphaComponent: 0.5)
        return view
    }()
    
    private lazy var tutorialTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 40
        table.backgroundColor = .clear
        table.isScrollEnabled = false
        table.separatorStyle = .none
        return table
    }()
    
    private lazy var openSettingsButton: UIButton = {
        let button = UIButton()
        button.layer.cornerRadius = 16
        button.setTitle(NSLocalizedString("Open settings", comment: ""), for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .medium)
        button.titleLabel?.textColor = .white
        return button
    }()

    let bag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup(){
        configureLayout()
        setupTableView()
        configureButtons()
    }
    
    private func configureLayout(){
        view.backgroundColor = .yellow
        
        view.addSubviews(topImageView, bottonView, topBackButton, HowToEnableLabel, appNameLabel, centerImageView, centerDignitiesView, openSettingsButton)
        
        centerDignitiesView.addSubview(tutorialTableView)
        
        topImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo((UIScreen.main.bounds.height / 4) * 3)
        }
        
        bottonView.snp.makeConstraints { make in
            make.top.equalTo(topImageView.snp.bottom)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        topBackButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(56)
            make.leading.equalToSuperview().offset(26)
            make.size.equalTo(20)
        }
        
        HowToEnableLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(78.resized())
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(32)
        }
        
        appNameLabel.snp.makeConstraints { make in
            make.top.equalTo(HowToEnableLabel.snp.bottom).offset(8.resized())
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(16)
        }
        
        centerImageView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.size.equalTo(226)
            make.top.equalTo(appNameLabel.snp.bottom).offset(8.resized())
        }
        
        centerDignitiesView.snp.makeConstraints { make in
            make.top.equalTo(centerImageView.snp.bottom).offset(16.resized())
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(183)
        }
        
        tutorialTableView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(20)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview().offset(-20)
        }
        
        openSettingsButton.snp.makeConstraints { make in
            make.top.equalTo(tutorialTableView.snp.bottom).offset(82.resized())
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(56)
        }
        
        view.layoutIfNeeded()
        bottonView.layer.applySketchShadow()
        
        openSettingsButton.addGradient(.leftRight, ["FF9A62".hexColor, "5CC8CC".hexColor], 16)
        
        centerDignitiesView.addGradient(.leftRight, ["5CC8CC".hexColor, "AAED88".hexColor], 20)
        
        centerDignitiesView.addGradient(.bottomTop, ["FFFFFF".hexColor.withAlphaComponent(0.8), "FFFFFF".hexColor.withAlphaComponent(0.05)], 20)
        
        centerDignitiesView.layer.applySketchShadow(color: UIColor(red: 0.36, green: 0.78, blue: 0.8, alpha: 0.2), alpha: 1, x: 0, y: 7, blur: 30, spread: 1)
        centerDignitiesView.clipsToBounds = false
        centerDignitiesView.layer.shadowRadius = 20
        centerDignitiesView.layer.cornerRadius = 20
    }
    
    private func setupTableView() {
        tutorialTableView.delegate = self
        tutorialTableView.dataSource = self
        tutorialTableView.register(FirstShoppingCell.self, forCellReuseIdentifier: FirstShoppingCell.nibIdentifier)
    }
    
    private func configureButtons() {
        openSettingsButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.openSettings()
        }.disposed(by: bag)
        
        topBackButton.rx.tap.bind { [weak self] in
            self?.dismiss(animated: true)
        }.disposed(by: bag)
    }

    func openSettings() {
        if let URL = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(URL)
        }
    }
}

extension TutorialViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}
extension TutorialViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return firstShoppingViewControllerModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tutorialTableView.dequeueReusableCell(withIdentifier: FirstShoppingCell.nibIdentifier, for:  indexPath) as! FirstShoppingCell
        let settingModelTwo = firstShoppingViewControllerModel[indexPath.row]
        cell.FirstShoppingCellModel = settingModelTwo
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
}
