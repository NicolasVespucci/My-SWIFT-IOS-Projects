//
//  ContentBlockerRequestHandler.swift
//  ContentBlocker
//
//  Created by Mac on 04.04.22.
//

import UIKit
import MobileCoreServices

class ContentBlockerRequestHandler: NSObject, NSExtensionRequestHandling {

    func beginRequest(with context: NSExtensionContext) {
      guard let url = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: "group.com.hyper.shell")?
      .appendingPathComponent("customblockerList.json") else { return }
      guard let attachment = NSItemProvider(contentsOf: url) else { return }

      let item = NSExtensionItem()
      item.attachments = [attachment]

      context.completeRequest(returningItems: [item], completionHandler: nil)
    }
    
}
