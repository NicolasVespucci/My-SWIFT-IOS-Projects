import UIKit
import StoreKit
import RxSwift
import RxCocoa
import AdSupport
import AppTrackingTransparency
import SwiftyStoreKit

var showCurrentController = false

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    class var shared: AppDelegate {
        return UIApplication.shared.delegate as! AppDelegate
    }

    var window: UIWindow?

    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        SwiftyStoreKit.completeTransactions(atomically: true) { purchases in
            for purchase in purchases {
                switch purchase.transaction.transactionState {
                case .purchased, .restored:
                    if purchase.needsFinishTransaction {
                        // Deliver content from server, then:
                        SwiftyStoreKit.finishTransaction(purchase.transaction)
                    }
                    Constants.ud.isPurchased = true
                case .failed, .purchasing, .deferred:
                    Constants.ud.isPurchased = false
                    break // do nothing
                @unknown default: break
                }
            }
        }
        
        setMainVC()
        checkJson()
        // Override point for customization after application launch.
        return true
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        UserDefaults.standard.synchronize()
    }
}

extension AppDelegate {
    private func setMainVC() {
        let controller = LaunchScreenViewController()
        let navigationController = UINavigationController(rootViewController: controller)
        window?.rootViewController = navigationController
        self.window?.makeKeyAndVisible()
    }
}

//MARK: - Block List
extension AppDelegate {
    private func checkJson() {
        if !FileManager
            .default
            .fileExists(atPath: FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: Constants.app.appGroupName)?.appendingPathComponent(Constants.app.blockerListFile).path ?? "") {
            loadJson()
        }
    }
    
    func loadJson() {
        if let path = Bundle.main.path(forResource: "customblockerList", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let blockItems = try JSONDecoder().decode([BlackListModel].self, from: data)
                let encoder = JSONEncoder()
                encoder.outputFormatting = .prettyPrinted
                guard let dataToWrite = try? encoder.encode(blockItems) else { return }
                guard let url = Constants.app.blockerJsonUrl else { return }
                try dataToWrite.write(to: url)
            } catch {
                print(error.localizedDescription)
            }
        }
    }
}


