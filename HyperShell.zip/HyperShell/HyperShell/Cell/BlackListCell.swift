import UIKit

class BlackListCell: UITableViewCell {

    var customDomain: String? {
        didSet {
            guard let domain = customDomain else { return }
            urlLabel.text = domain
        }
    }
    
    private lazy var cellView: UIView = {
        let view = UIView()
        view.layer.masksToBounds = true
        view.backgroundColor = "F6F6F6".hexColor
        view.layer.cornerRadius = 14
        return view
    }()
    
    private lazy var blackListImageView: UIImageView = {
        let imageView = UIImageView(image: "Safari".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private lazy var urlLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.textAlignment = .left
        label.minimumScaleFactor = 0.5
        label.textColor = "404147".hexColor
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        selectionStyle = .none
        configureLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureLayout() {
        addSubviews(cellView)
        cellView.addSubviews(blackListImageView, urlLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(52)
        }
        
        blackListImageView.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(14)
            make.size.equalTo(22)
            make.centerY.equalToSuperview()
        }
        
        urlLabel.snp.makeConstraints { make in
            make.leading.equalTo(blackListImageView.snp.trailing).offset(10)
            make.trailing.equalToSuperview().offset(-10)
            make.centerY.equalToSuperview()
            make.height.equalTo(24)
        }
    }
}
