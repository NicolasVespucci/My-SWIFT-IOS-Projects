import UIKit
import StoreKit

class SecondShoppingCell: UICollectionViewCell {
    
    private lazy var cellView: UIView = {
        let cell = UIView()
        cell.layoutIfNeeded()
        cell.layer.addGradienBorder(colors: "AAED88".hexColor, "5CC8CC".hexColor, width: 1, cornerRadius: 16)
        cell.backgroundColor = "208E92".hexColor.withAlphaComponent(0.03)
        cell.layer.cornerRadius = 16
        return cell
    }()
    
    private lazy var periodPeriodLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.textColor = "0F4345".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .center
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private lazy var priceLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.textColor = "0F4345".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .left
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private lazy var trialLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 12, weight: .medium)
        label.textColor = "404147".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .center
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    var product: Product?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func configureTrialLayout() {
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubview(periodPeriodLabel)
        

        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(49)
        }
        
        periodPeriodLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
            make.height.equalTo(24)
        }
        
        cellView.addBorder(width: 1, color: "404147")
        cellView.backgroundColor = .clear
        periodPeriodLabel.text = perPeriodString + " • " + price
        periodPeriodLabel.textColor = .black
        layoutSubviews()
    }
    
    public func configureCommonLayout() {
        
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubviews(periodPeriodLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(49)
        }
        
        periodPeriodLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
            make.height.equalTo(24)
        }
       
        
        cellView.addBorder(width: 1, color: "404147")
        cellView.backgroundColor = .clear
        periodPeriodLabel.text = perPeriodString + " • " + price
        periodPeriodLabel.textColor = .black
        layoutSubviews()
    }
    
    public func configureTrialSelectedLayout() {
        
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let perPeriodString2 = period.perFormattedString

        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubviews(cellView, trialLabel)
        cellView.addSubview(periodPeriodLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(49)
        }
    
        periodPeriodLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
            make.height.equalTo(24)
        }
        
        trialLabel.snp.makeConstraints { make in
            make.top.equalTo(cellView.snp.bottom).offset(5)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(20)
        }

        layoutIfNeeded()
        
        cellView.backgroundColor = "35D7B7".hexColor
    
        trialLabel.text = NSLocalizedString("(free trial ", comment: "") + (product.introductory?.period?.formattedString ?? "asda") + NSLocalizedString(",after", comment: "") + price + "/" + perPeriodString2 + ")"
        periodPeriodLabel.text = perPeriodString + " • " + price
        periodPeriodLabel.textColor = .white
        
        layoutSubviews()
    }
    
    public func configureCommonSelectedLayout() {
        
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubview(periodPeriodLabel)

        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(49)
        }
        
        periodPeriodLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
            make.height.equalTo(24)
        }

        cellView.backgroundColor = "35D7B7".hexColor
        periodPeriodLabel.text = perPeriodString + " • " + price
        periodPeriodLabel.textColor = .white
        layoutSubviews()
    }
}

