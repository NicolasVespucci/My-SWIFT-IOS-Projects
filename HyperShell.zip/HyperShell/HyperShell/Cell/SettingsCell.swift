import UIKit

class SettingsCell: UITableViewCell {

    var settingModel: SettingModel? {
        didSet { configurePayModel() }
    }
    
    private lazy var mainView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 14
        return view
    }()
    
    private lazy var settingsImageView: UIImageView = {
        let imageView = UIImageView(image: "".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private lazy var nameCellLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16)
        label.textColor = "404147".hexColor
        label.minimumScaleFactor = 0.5
        label.adjustsFontSizeToFitWidth = true
        return label
    }()
    
    public lazy var switchButton: UISwitch = {
        let button = UISwitch()
        button.tintColor = .black
        button.onTintColor = "35D7B7".hexColor
        button.isUserInteractionEnabled = false
        return button
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        selectionStyle = .none
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func configureLayoutWithSwitch() {
        mainView.subviews.forEach({
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.removeFromSuperview()
        })
        
        addSubview(mainView)
        mainView.addSubviews(settingsImageView, nameCellLabel, switchButton)
        
        mainView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(58)
        }
        
        settingsImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(16)
            make.size.equalTo(20)
        }
        
        nameCellLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalTo(settingsImageView.snp.trailing).offset(8)
            make.trailing.equalTo(switchButton.snp.leading).offset(-1)
            make.height.equalTo(24)
        }
        
        switchButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-16)
            make.height.equalTo(31)
            make.width.equalTo(51)
        }
    }
    
    public func configureLayoutWithoutSwitch() {
        mainView.subviews.forEach({
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.removeFromSuperview()
        })
        
        addSubview(mainView)
        mainView.addSubviews(settingsImageView, nameCellLabel)
        
        mainView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(58)
        }
        
        settingsImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(16)
            make.size.equalTo(24)
        }
        
        nameCellLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalTo(settingsImageView.snp.trailing).offset(8)
            make.height.equalTo(24)
        }
    }

    private func configurePayModel() {
        guard let settingModel = settingModel else { return }
        settingsImageView.image = settingModel.image?.image
        nameCellLabel.text = settingModel.title
        switchButton.isOn = settingModel.value ?? false
    }
}
