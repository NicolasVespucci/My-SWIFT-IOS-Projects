

import Foundation
import UIKit

extension UIApplication {
  class func getPresentedViewController() -> UIViewController? {
    var presentViewController = UIApplication.shared.keyWindow?.rootViewController
    while let pVC = presentViewController?.presentedViewController {
      presentViewController = pVC
    }
    return presentViewController
  }
  
  static var applicationVersion: String {
    return Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String
  }
  
  static var applicationBuild: String {
    return Bundle.main.object(forInfoDictionaryKey: kCFBundleVersionKey as String) as! String
  }
  
  static var versionBuild: String {
    return "v\(self.applicationVersion)(\(self.applicationBuild))"
  }
}
