import Foundation

struct BlockedAdsCollectionModel {
    var image: String?
    var title: String?
    var value: Bool?
}
