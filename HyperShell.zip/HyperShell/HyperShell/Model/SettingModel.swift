import Foundation
import UIKit

struct SettingModel{
    var image: String?
    var title: String?
    var value: Bool?
}
