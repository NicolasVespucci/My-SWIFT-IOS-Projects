import UIKit

class PresentScrollView: UIView {

    var topText: String?
    var bottomText: String?
    
    private lazy var firstLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 28, weight: .semibold)
        label.textColor = "404147".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .left
        return label
    }()
    
    private lazy var secondLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.textColor = "74757A".hexColor.withAlphaComponent(0.7)
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .left
        label.numberOfLines = 0
        return label
    }()
   
    init(topText: String, bottomText: String) {
        super.init(frame: .zero)
        self.topText = topText
        self.bottomText = bottomText
        isUserInteractionEnabled = true
        launch()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func launch() {
        configureLayout()
        configureViewContent()
    }
    
    private func configureLayout() {
        addSubviews(firstLabel, secondLabel)
    
        firstLabel.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(28)
            make.trailing.equalToSuperview().offset(-28)
            make.height.equalTo(30.resized())
            make.top.equalToSuperview()
        }
        
        secondLabel.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(28)
            make.trailing.equalToSuperview().offset(-28)
            make.height.equalTo(50.resized())
            make.bottom.equalToSuperview()
        }
    }
    
    private func configureViewContent() {
        firstLabel.text = topText
        secondLabel.text = bottomText
        
//        print("First--->", firstLabel.text = topText)
//        print("Second--->", secondLabel.text = bottomText)
    }

}

