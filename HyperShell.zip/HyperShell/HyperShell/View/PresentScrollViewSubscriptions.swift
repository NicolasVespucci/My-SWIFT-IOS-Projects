//import UIKit
//
//class PresentScrollViewSubscriptions: UIView {
//
//    var image: UIImage?
//    
//    private lazy var centerImageView: UIImageView = {
//        let imageView = UIImageView()
//        imageView.contentMode = .scaleToFill
//        return imageView
//    }()
//    
//    private var topBackButton: UIButton = {
//        let button = UIButton()
//        button.setImage("backTutorial".image, for: .normal)
//        return button
//    }()
//    
//    private lazy var shildImage: UIImageView = {
//        let imageView = UIImageView(image: "data".image)
//        imageView.contentMode = .scaleToFill
//        return imageView
//    }()
//    
//    private lazy var adImage: UIImageView = {
//        let imageView = UIImageView(image: "adsfree".image)
//        imageView.contentMode = .scaleToFill
//        return imageView
//    }()
//    
//    private lazy var listImage: UIImageView = {
//        let imageView = UIImageView(image: "whiteList".image)
//        imageView.contentMode = .scaleToFill
//        return imageView
//    }()
//    
//    private lazy var shildLabel: UILabel = {
//        let label = UILabel()
//        label.font = .systemFont(ofSize: 14, weight: .medium)
//        label.text = NSLocalizedString("Data usage protected", comment: "")
//        label.textColor = "404147".hexColor
//        label.adjustsFontSizeToFitWidth = true
//        label.minimumScaleFactor = 0.5
//        label.textAlignment = .left
//        label.numberOfLines = 1
//        return label
//    }()
//    
//    private lazy var adLabel: UILabel = {
//        let label = UILabel()
//        label.font = .systemFont(ofSize: 14, weight: .medium)
//        label.text = NSLocalizedString("Ads free browsing", comment: "")
//        label.textColor = "404147".hexColor
//        label.adjustsFontSizeToFitWidth = true
//        label.minimumScaleFactor = 0.5
//        label.textAlignment = .left
//        label.numberOfLines = 1
//        return label
//    }()
//    
//    private lazy var listLabel: UILabel = {
//        let label = UILabel()
//        label.font = .systemFont(ofSize: 14, weight: .medium)
//        label.text = NSLocalizedString("Whitelist websites", comment: "")
//        label.textColor = "404147".hexColor
//        label.adjustsFontSizeToFitWidth = true
//        label.minimumScaleFactor = 0.5
//        label.textAlignment = .left
//        label.numberOfLines = 1
//        return label
//    }()
//    
//    init(image: UIImage) {
//        super.init(frame: .zero)
//        self.image = image
//        isUserInteractionEnabled = true
//        configureLayout()
//    }
//    
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//    
//    private func configureLayout() {
//        addSubviews(centerImageView)
//        centerImageView.addSubviews(topBackButton, shildImage, shildLabel, adImage, adLabel, listImage, listLabel)
//    
//        centerImageView.snp.makeConstraints { make in
//            make.top.equalToSuperview()
//            make.leading.equalToSuperview()
//            make.trailing.equalToSuperview()
//            make.bottom.equalToSuperview().offset(-10)
//        }
//        
//        topBackButton.snp.makeConstraints { make in
//            make.top.equalToSuperview().offset(53)
//            make.leading.equalToSuperview().offset(35)
//            make.height.equalTo(24)
//        }
//        
//        shildImage.snp.makeConstraints { make in
//            make.top.equalTo(topBackButton.snp.bottom).offset(383.resized())
//            make.leading.equalToSuperview().offset(32)
//            make.size.equalTo(24.resized())
//        }
//        
//        shildLabel.snp.makeConstraints { make in
//            make.top.equalTo(topBackButton.snp.bottom).offset(383.resized())
//            make.leading.equalTo(shildImage.snp.trailing).offset(16)
//            make.height.equalTo(24.resized())
//        }
//        
//        adImage.snp.makeConstraints { make in
//            make.top.equalTo(shildImage.snp.bottom).offset(16.resized())
//            make.leading.equalTo(shildImage.snp.leading)
//            make.size.equalTo(24.resized())
//        }
//        
//        adLabel.snp.makeConstraints { make in
//            make.top.equalTo(shildLabel.snp.bottom).offset(16.resized())
//            make.leading.equalTo(shildImage.snp.trailing).offset(16)
//            make.height.equalTo(24.resized())
//        }
//        
//        listImage.snp.makeConstraints { make in
//            make.top.equalTo(adImage.snp.bottom).offset(16.resized())
//            make.leading.equalTo(adImage.snp.leading)
//            make.size.equalTo(24.resized())
//        }
//        
//        listLabel.snp.makeConstraints { make in
//            make.top.equalTo(adLabel.snp.bottom).offset(16.resized())
//            make.leading.equalTo(shildImage.snp.trailing).offset(16)
//            make.height.equalTo(24.resized())
//        }
//    }
//    
//    private func configureViewContent() {
//        centerImageView.image = image
//    }
//}
