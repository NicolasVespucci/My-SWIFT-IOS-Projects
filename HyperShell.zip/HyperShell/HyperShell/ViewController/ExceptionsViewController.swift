import UIKit
import RxSwift
import SafariServices

class ExceptionsViewController: UIViewController {
    
    private lazy var scrollView: UIScrollView = {
        let view = UIScrollView()
        view.isPagingEnabled = true
        view.isScrollEnabled = true
        view.showsVerticalScrollIndicator = false
        view.backgroundColor = "F7F8FC".hexColor
        view.frame = self.view.bounds
        view.contentSize = CGSize(width: self.view.frame.width, height: 854)
        view.autoresizingMask = .flexibleTopMargin
        view.bounces = true
        return view
    }()
    
    private var topImageView: UIImageView = {
        let imageView = UIImageView(image: "squaresExceptions".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private var exceptionsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 32, weight: .heavy)
        label.textColor = "404147".hexColor
        label.text = NSLocalizedString("Exceptions", comment: "")
        label.textAlignment = .left
        return label
    }()
    
    private var tapAddLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .regular)
        label.textColor = "74757A".hexColor
        label.text = NSLocalizedString("Tap “Add” Button below to \ncreate URL exception", comment: "")
        label.textAlignment = .left
        label.numberOfLines = 0
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var blacklistView: UIButton = {
        let button = UIButton()
        button.setTitle(NSLocalizedString("Blacklist", comment: ""), for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.25).cgColor
        button.layer.shadowOffset = CGSize(width: 3.0, height: 6.0)
        button.layer.shadowOpacity = 1
        button.layer.shadowRadius = 12
        button.layer.masksToBounds = false
        return button
    }()
    
    private var centerWhiteView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 12
        return view
    }()
    
    private var addButton: UIButton = {
        let button = UIButton()
        button.setImage("+".image, for: .normal)
        button.layer.cornerRadius = 5
        button.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.25).cgColor
        button.layer.shadowOffset = CGSize(width: 3.0, height: 6.0)
        button.layer.shadowOpacity = 1
        button.layer.shadowRadius = 12
        button.layer.masksToBounds = false
        return button
    }()
    
    private lazy var tableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 61
        table.backgroundColor = .clear
        table.separatorStyle = .none
        return table
    }()
    
    var blockListDomains: [String] {
        get {
            if let domains = UserDefaults.standard.stringArray(forKey: UserDefaults.Keys.blockedDomains), !domains.isEmpty {
                addButton.snp.remakeConstraints { make in
                    make.centerY.equalTo(centerWhiteView.snp.bottom)
                    make.height.equalTo(56)
                    make.width.equalTo(59)
                    make.centerX.equalToSuperview()
                }
                return domains
            }
            addButton.snp.remakeConstraints { make in
                make.centerY.equalToSuperview()
                make.height.equalTo(56)
                make.width.equalTo(59)
                make.centerX.equalToSuperview()
            }
            return []
        }
        set { UserDefaults.standard.set(newValue, forKey: UserDefaults.Keys.blockedDomains) }
    }
    
    var blockerList: [BlackListModel]? {
        set {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            guard let newValue = newValue else { return }
            guard let data = try? encoder.encode(newValue) else { return }
            guard let url = Constants.app.blockerJsonUrl else { return }
            try? data.write(to: url)
        }
        get {
            guard let url = Constants.app.blockerJsonUrl else { return nil }
            guard let data = try? Data(contentsOf: url) else { return nil }
            return try? JSONDecoder().decode([BlackListModel].self, from: data)
        }
    }
    
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
  
    }
    
    private func setup (){
        configureLayout()
        setupButtons()
        configureTable()
    }
    
    private func configureLayout() {
        view.backgroundColor = "F6F6F6".hexColor
        view.addSubview(scrollView)
        
        scrollView.addSubviews(topImageView, exceptionsLabel, tapAddLabel, centerWhiteView, blacklistView)
        
        centerWhiteView.addSubviews(tableView, addButton)
        
        scrollView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.width.equalTo(UIScreen.main.bounds.width)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
        }
        
        topImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(64.resized())
            make.width.equalTo(276)
            make.height.equalTo(111)
            make.centerX.equalToSuperview()
        }
        
        exceptionsLabel.snp.makeConstraints { make in
            make.top.equalTo(topImageView.snp.bottom).offset(34.resized())
            make.width.equalTo((UIScreen.main.bounds.width - 92.resized(.width)))
            make.centerX.equalToSuperview()
            make.height.equalTo(48)
        }
        
        tapAddLabel.snp.makeConstraints { make in
            make.top.equalTo(exceptionsLabel.snp.bottom).offset(3)
            make.width.equalTo((UIScreen.main.bounds.width - 92.resized(.width)))
            make.centerX.equalToSuperview()
            make.height.equalTo(48)
        }
        
        centerWhiteView.snp.makeConstraints { make in
            make.top.equalTo(blacklistView.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width - 90.resized(.width)))
            make.centerX.equalToSuperview()
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-37.resized())
        }
        
        blacklistView.snp.makeConstraints { make in
            make.top.equalTo(tapAddLabel.snp.bottom).offset(29.resized())
            make.width.equalTo(151)
            make.centerX.equalToSuperview()
            make.height.equalTo(61)
        }
        
        tableView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.bottom.equalToSuperview()
            make.leading.equalToSuperview().offset(22)
            make.trailing.equalToSuperview().offset(-22)
        }
        
        addButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.height.equalTo(56)
            make.width.equalTo(59)
            make.centerX.equalToSuperview()
        }
        
        view.layoutIfNeeded()
        
        blacklistView.addGradient(.leftRight, ["36D5B8".hexColor, "45BED1".hexColor], 5)
      
    }
 
    private func setupButtons(){
        addButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.showInputDialog(title: NSLocalizedString("Add exception", comment: ""), subtitle: NSLocalizedString("Enter URL address you want to \nexclude from browsing safari", comment: ""), inputPlaceholder: "http://example.org", actionHandler: { [weak self] url in
                guard let self = self, let url = url else { return }
                if url != "" {
                    if IAPManager.shared().isPurchased {
                        if self.blockListDomains.count == 0 {
                            self.appendBlockItem(urlString: url)
                        } else {
                            self.appendBlockItem(urlString: url)
                        }
                        Constants.ud.exceptionLinksCount = self.blockListDomains.count
                    } else {
                        if self.blockListDomains.count < 5 {
                            if self.blockListDomains.count == 0 {
                                self.appendBlockItem(urlString: url)
                            } else {
                                self.appendBlockItem(urlString: url)
                            }
                            Constants.ud.exceptionLinksCount = self.blockListDomains.count
                        } else {
                            Constants.ud.currentDismis = 2
                            IAPManager.shared().presentSingleSubscriptionVC()
                            IAPManager.shared().purchaseCompletion = { [weak self] _ in
                                IAPManager.shared().dismissSubscriptionVC(animated: true, completion: nil)
                                self?.appendBlockItem(urlString: url)
                                Constants.ud.exceptionLinksCount = self?.blockListDomains.count
                            }                           
                        }
                    }
                }
             
            })
        }.disposed(by: disposeBag)
    }
    
    private func configureTable() {
        tableView.register(BlackListCell.self, forCellReuseIdentifier: BlackListCell.nibIdentifier)
        tableView.rx.setDelegate(self).disposed(by: disposeBag)
        tableView.rx.setDataSource(self).disposed(by: disposeBag)
        tableView.contentInset.top = 30
    }
}

//MARK: - Content blocker
extension ExceptionsViewController {
    private func appendBlockItem(urlString: String) {
        let text = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        self.addBlockItem(text: text.replacingOccurrences(of: "http://", with: "").replacingOccurrences(of: "https://", with: "").replacingOccurrences(of: "www.", with: ""))
        self.blockListDomains.append(text)
        self.tableView.reloadData()
    }
    
    private func removeBlockItem(index: Int) {
        let valueToRemove = blockListDomains[index].replacingOccurrences(of: "http://", with: "").replacingOccurrences(of: "https://", with: "").replacingOccurrences(of: "www.", with: "")
        if let indexToRemove = blockerList?.firstIndex(where: {  $0.trigger.urlFilter.contains(valueToRemove) }), let indexDomainToRemove = blockListDomains.firstIndex(where: { $0.contains(valueToRemove) }) {
            blockListDomains.remove(at: indexDomainToRemove)//removeAll(where: { $0.contains(valueToRemove) })
            blockerList?.remove(at: indexToRemove)
            Constants.ud.exceptionLinksCount = self.blockListDomains.count
        }
        tableView.reloadData()
        reloadContentBlocker()
    }
    
    private func blockItem(websiteString: String) -> BlackListModel {
        let website = String(format: "https?://(www.)?%@*", websiteString)
        let blockItem = BlackListModel(trigger: Trigger(urlFilter: website), action: Action(type: "block"))
        return blockItem
    }
    
    private func addBlockItem(text: String) {
        let item = blockItem(websiteString: text)
        blockerList?.append(item)
        reloadContentBlocker()
    }
    
    private func reloadContentBlocker(completion: (() -> (Void))? = nil) {
        DispatchQueue.main.async {
            SFContentBlockerManager.reloadContentBlocker(withIdentifier: Constants.app.contentBlockerExtensionName) { (error) in
                if error == nil {
                    print("Rules activated.")
                } else {
                    print("ERROR activating rules")
                    print(error)
                }
                completion?()
            }
        }
    }
}

//MARK: - UITableViewDelegate
extension ExceptionsViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
}

//MARK: - UITableViewDataSource
extension ExceptionsViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return blockListDomains.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: BlackListCell.nibIdentifier, for: indexPath) as! BlackListCell
        cell.customDomain = blockListDomains[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            removeBlockItem(index: indexPath.row)
            if !blockListDomains.isEmpty {
                addButton.snp.remakeConstraints { make in
                    make.centerY.equalTo(centerWhiteView.snp.bottom)
                    make.height.equalTo(56)
                    make.width.equalTo(59)
                    make.centerX.equalToSuperview()
                }
            } else {
                addButton.snp.remakeConstraints { make in
                    make.centerY.equalToSuperview()
                    make.height.equalTo(56)
                    make.width.equalTo(59)
                    make.centerX.equalToSuperview()
                }
            }
        }
    }
}
