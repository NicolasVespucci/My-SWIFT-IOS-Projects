import UIKit
import RxSwift
import IHProgressHUD
import SwiftyStoreKit


class FirstSubscriptionsViewController: UIViewController {
    
    var identifiers = Constants.analytics.threeMonth
    
    private var topImageView: UIImageView = {
        let imageView = UIImageView(image: "three".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private var topBackButton: UIButton = {
        let button = UIButton()
        button.setImage("backTutorial".image, for: .normal)
        return button
    }()
    
    private var restoreButton: UIButton = {
        let button = UIButton()
        button.setImage("restore2".image?.withRenderingMode(.alwaysOriginal), for: .normal)
        return button
    }()
    
    private var emptyView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()
    
    
    private lazy var shildImage: UIImageView = {
        let imageView = UIImageView(image: "data".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private lazy var adImage: UIImageView = {
        let imageView = UIImageView(image: "adsfree".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private lazy var listImage: UIImageView = {
        let imageView = UIImageView(image: "whiteList".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private lazy var shildLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.text = NSLocalizedString("Data usage protected", comment: "")
        label.textColor = "404147".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .left
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var adLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.text = NSLocalizedString("Ads free browsing", comment: "")
        label.textColor = "404147".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .left
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var listLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.text = NSLocalizedString("Whitelist websites", comment: "")
        label.textColor = "404147".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .left
        label.numberOfLines = 1
        return label
    }()
    
    private var buyButton: UIButton = {
        let button = UIButton()
        button.setTitle(NSLocalizedString("SUBSCRIBE", comment: ""), for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 18, weight: .semibold)
        button.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.25).cgColor
        button.layer.shadowOffset = CGSize(width: 3.0, height: 6.0)
        button.layer.shadowOpacity = 1
        button.layer.shadowRadius = 12
        button.layer.masksToBounds = false
        return button
    }()
    
    private lazy var trialLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .regular)
        label.textColor = "74757A".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .center
        label.numberOfLines = 2
        return label
    }()
  
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup(){
        configureLayout()
        setupButtons()
        configureTrialLabel()
    }
    
    private func configureLayout(){
        view.backgroundColor = .white
        navigationController?.isNavigationBarHidden = true
        view.addSubviews(topImageView, topBackButton, restoreButton, emptyView,buyButton, trialLabel)
        
        emptyView.addSubviews(shildImage, shildLabel, adImage, adLabel, listImage, listLabel)
        
        topImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(120)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview().offset(-10)
        }
        
        topBackButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(53)
            make.leading.equalToSuperview().offset(35)
            make.size.equalTo(24)
        }
        
        restoreButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(53)
            make.trailing.equalToSuperview().offset(-35)
            make.size.equalTo(24)
        }
        
        emptyView.snp.makeConstraints { make in
            make.bottom.equalTo(buyButton.snp.top).offset(-25.resized())
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(115.resized())
        }
        
        shildImage.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview().offset(32)
            make.size.equalTo(24.resized())
        }
        
        shildLabel.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalTo(shildImage.snp.trailing).offset(16)
            make.height.equalTo(24.resized())
        }
        
        adImage.snp.makeConstraints { make in
            make.top.equalTo(shildImage.snp.bottom).offset(16.resized())
            make.leading.equalTo(shildImage.snp.leading)
            make.size.equalTo(24.resized())
        }
        
        adLabel.snp.makeConstraints { make in
            make.top.equalTo(shildLabel.snp.bottom).offset(16.resized())
            make.leading.equalTo(shildImage.snp.trailing).offset(16)
            make.height.equalTo(24.resized())
        }
        
        listImage.snp.makeConstraints { make in
            make.top.equalTo(adImage.snp.bottom).offset(16.resized())
            make.leading.equalTo(adImage.snp.leading)
            make.size.equalTo(24.resized())
        }
        
        listLabel.snp.makeConstraints { make in
            make.top.equalTo(adLabel.snp.bottom).offset(16.resized())
            make.leading.equalTo(shildImage.snp.trailing).offset(16)
            make.height.equalTo(24.resized())
        }
        
        buyButton.snp.makeConstraints { make in
            make.bottom.equalTo(trialLabel.snp.top)
            make.height.equalTo(63)
            make.leading.equalToSuperview().offset(58)
            make.trailing.equalToSuperview().offset(-58)
        }
        
        trialLabel.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-30.resized())
            make.leading.equalToSuperview().offset(60)
            make.trailing.equalToSuperview().offset(-60)
            make.height.equalTo(50)
        }
    
        view.layoutIfNeeded()
        buyButton.addGradient(.leftRight, ["36D5B8".hexColor, "45BED1".hexColor], 14)
    }
    
    private func setupButtons(){
        topBackButton.rx.tap.bind {
            IAPManager.shared().dismissSubscriptionVC()
        }.disposed(by: disposeBag)
        
        restoreButton.rx.tap.bind {
            IAPManager.shared().restore()
        }.disposed(by: disposeBag)

        buyButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            let product = self.identifiers
            IAPManager.shared().purchase(rcPackage: product, quantity: 1, atomically: true)
        }.disposed(by: disposeBag)
    }
    
    private func topBackButtonAction() {
        let controller = HomeTabBarController()
        let navigationController = UINavigationController(rootViewController: controller)
        UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.rootViewController = navigationController
        UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.makeKeyAndVisible()
    }
    
    private func nextButtonAction(){
        IAPManager.shared().presentSubscriptionVC()
        IAPManager.shared().purchaseCompletion = { [weak self] _ in
            IAPManager.shared().dismissSubscriptionVC()
            guard let self = self else { return }
            if Constants.ud.isPurchased {
                self.navigationController?.dismiss(animated: true)
            }
        }
    }

    private func configureTrialLabel() {
        IHProgressHUD.show()
        SwiftyStoreKit.retrieveProductsInfo([Constants.analytics.threeMonth]) { result in
            if(!result.retrievedProducts.isEmpty) {
                let testProduct = Product(product: result.retrievedProducts.first!)
                guard let period = testProduct.period else { return }
                let periodString = period.formattedString // MONTHLY
                let perPeriodString = period.perFormattedString.capitalized // MONTH
                let price = testProduct.localizedPrice
                let introductoryPeriod = testProduct.introductory?.period?.formattedString ?? ""

                if introductoryPeriod == "" {
                    self.trialLabel.text = price + NSLocalizedString(" per ", comment: "") + perPeriodString
                    IHProgressHUD.dismiss()
                } else {
                    self.trialLabel.text = NSLocalizedString("Start your ", comment: "") + "\(introductoryPeriod)" + NSLocalizedString(" free trial, \nthen ", comment: "") + "\(price) / \(periodString)"
                    IHProgressHUD.dismiss()
                }
            }
        }
    }
}
