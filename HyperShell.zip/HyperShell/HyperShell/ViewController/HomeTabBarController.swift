
import UIKit

class HomeTabBarController: UITabBarController, UITabBarControllerDelegate {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        tabBar.clipsToBounds = true
        self.tabBarController?.delegate = self
        delegate = self
        setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.isNavigationBarHidden = true
        
    }
    
    public func setup() {
        tabBar.backgroundColor = .white
        let protectionVC = ProtectionViewController()
        let exceptionsVC = ExceptionsViewController()
        let settingsVC = SettingsViewController()
        tabBarController?.tabBar.isHidden = false
        let mainVCBarItem = UITabBarItem(title: NSLocalizedString("Protection", comment: "") , image: "ProtectionOffS".image?.withRenderingMode(.alwaysOriginal), selectedImage: "ProtectionOn".image?.withRenderingMode(.alwaysOriginal))
        let exceptionsVCBarItem = UITabBarItem(title: NSLocalizedString("Exceptions", comment: ""), image: "ExceptionsOff".image, selectedImage: "ExceptionsOn".image)
        let settingsBarItem = UITabBarItem(title: NSLocalizedString("Settings", comment: ""), image: "SettingsOff".image, selectedImage: "SettingsOn".image)
        
        protectionVC.tabBarItem = mainVCBarItem
        exceptionsVC.tabBarItem = exceptionsVCBarItem
        settingsVC.tabBarItem = settingsBarItem
        
        let child1 = UINavigationController(rootViewController: protectionVC)
        let child2 = UINavigationController(rootViewController: exceptionsVC)
        let child3 = UINavigationController(rootViewController: settingsVC)
        
        child1.setNavigationBarHidden(true, animated: true)
        child2.setNavigationBarHidden(true, animated: true)
        child3.setNavigationBarHidden(true, animated: true)
        child1.isNavigationBarHidden = true
        child2.isNavigationBarHidden = true
        child3.isNavigationBarHidden = true
        
        tabBar.tintColor = "A94DF2".hexColor
        tabBar.unselectedItemTintColor = "404147".hexColor
        tabBar.barTintColor = "FFFFFF".hexColor
        
        addChild(child1)
        addChild(child2)
        addChild(child3)
    }
    
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        let tabBarIndex = tabBarController.selectedIndex
        if tabBarIndex == 0 {
       
        }
    }

}
