import UIKit
import RxSwift
import AppTrackingTransparency

class PresentViewController: UIViewController, UIScrollViewDelegate {
    
    private let firstView = PresentScrollView(topText: NSLocalizedString("Powerfull ad blocker", comment: ""), bottomText: NSLocalizedString("Enjoy superior ad blocking and faster browsing", comment: ""))
    private let secondView = PresentScrollView(topText: NSLocalizedString("Encrease your secure", comment: ""), bottomText: NSLocalizedString("Protect yourself from nasty viruses that hide in malicious ads", comment: ""))
    
    private lazy var centerImageView: UIImageView = {
        let imageView = UIImageView(image: "first".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private var scrollView: UIScrollView = {
        let view = UIScrollView()
        view.isPagingEnabled = true
        view.isScrollEnabled = false
        view.showsHorizontalScrollIndicator = false
        return view
    }()

    private var nextButton: UIButton = {
        let button = UIButton()
        button.setTitle(NSLocalizedString("NEXT", comment: ""), for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 18, weight: .semibold)
        button.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.25).cgColor
        button.layer.shadowOffset = CGSize(width: 3.0, height: 6.0)
        button.layer.shadowOpacity = 1
        button.layer.shadowRadius = 12
        button.layer.masksToBounds = false
        return button
    }()
    
    private var pageControll: UIImageView = {
        let imageView = UIImageView(image: "1".image)
        return imageView
    }()
    
    var xOffSet: CGFloat = 0
    var contentWidth: CGFloat = 0.0
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup (){
        configureLayout()
        setupButtons()
        configureScrollView()
    }
    
    private func configureLayout() {
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = .white
        view.addSubview(centerImageView)
        view.addSubviews(scrollView, nextButton, pageControll)
        
        centerImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        scrollView.snp.makeConstraints { make in
            make.height.equalTo(81.resized())
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalTo(nextButton.snp.top).offset(-95.resized())
        }
        
        nextButton.snp.makeConstraints { make in
            make.bottom.equalTo(pageControll.snp.top).offset(-20)
            make.height.equalTo(63)
            make.leading.equalToSuperview().offset(58)
            make.trailing.equalToSuperview().offset(-58)
        }
        
        pageControll.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-14.resized())
            make.height.equalTo(17)
            make.width.equalTo(157)
            make.centerX.equalToSuperview()
        }
        
        
        view.layoutIfNeeded()
        nextButton.addGradient(.leftRight, ["36D5B8".hexColor, "45BED1".hexColor], 14)
    }
    
    private func setupButtons() {
        nextButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.continueStartButtonAction()
        }.disposed(by: disposeBag)
    }
    
    private func continueStartButtonAction(){
        if self.xOffSet < UIScreen.main.bounds.width {
            requestPermission()
            DispatchQueue.main.async {
                self.xOffSet += UIScreen.main.bounds.width
                self.scrollView.contentOffset.x = self.xOffSet
                self.nextButton.setTitle(NSLocalizedString("START", comment: ""), for: .normal)
                self.pageControll.image = "2".image
                self.centerImageView.image = "second".image
            }
        } else {
           
            nextButtonActions()
            showCurrentController = true
            UserDefaults.standard.set(showCurrentController, forKey: "showCurrentController")
            self.xOffSet = UIScreen.main.bounds.width
        }
    }
    
    private func configureScrollView() {
        scrollView.delegate = self
        let viewsForScroll = [firstView, secondView]
        for (index, view) in viewsForScroll.enumerated() {
            scrollView.addSubview(view)
            view.snp.makeConstraints { make in
                make.top.equalToSuperview()
                make.height.equalTo(81.resized())
                make.leading.equalToSuperview().offset(CGFloat(index) * UIScreen.main.bounds.width)
                make.width.equalToSuperview()
            }
            self.view.layoutIfNeeded()
            self.scrollView.layoutIfNeeded()
            contentWidth += self.view.frame.width
        }
        scrollView.contentSize = CGSize(width: contentWidth, height: scrollView.frame.height)
    }
    
    private func nextButtonActions(){
        let controller = HomeTabBarController()
        let navigationController = UINavigationController(rootViewController: controller)
        UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.rootViewController = navigationController
        UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.makeKeyAndVisible()
        // self.xOffSet = UIScreen.main.bounds.width
    }
    
    func requestPermission() {
        if #available(iOS 14, *) {
            ATTrackingManager.requestTrackingAuthorization { status in
                switch status {
                case .authorized:
                    // Tracking authorization dialog was shown
                    // and we are authorized
                    print("Authorized")
                    // Now that we are authorized we can get the IDFA
                case .denied:
                    // Tracking authorization dialog was
                    // shown and permission is denied
                    print("Denied")
                case .notDetermined:
                    // Tracking authorization dialog has not been shown
                    print("Not Determined")
                case .restricted:
                    print("Restricted")
                @unknown default:
                    print("Unknown")
                }
            }
        }
    }
}
