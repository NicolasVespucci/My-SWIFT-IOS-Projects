import UIKit
import SnapKit
import RxSwift
import IHProgressHUD
import SafariServices
import SwiftyAttributes


class ProtectionViewController: UIViewController {
    
    var isProtected = true
    var isActivated = false
    
    
    
    private var topImageView: UIImageView = {
        let imageView = UIImageView(image: "protectionFull".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private var protectionLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 32, weight: .heavy)
        label.textColor = "404147".hexColor
        label.text = NSLocalizedString("Protection is OFF", comment: "")
        label.textAlignment = .center
        label.minimumScaleFactor = 0.5
        label.adjustsFontSizeToFitWidth = true
        return label
    }()
    
    //MARK: - Turn Off On Button
    private var buttonImageView: UIImageView = {
        let imageView = UIImageView(image: "TurnOff".image)
        imageView.contentMode = .scaleAspectFit
        imageView.isUserInteractionEnabled = true
        return imageView
    }()

    private var turnOffOnButton: UIButton = {
        let button = UIButton()
        button.layer.shadowColor = UIColor(red: 0.22, green: 0.83, blue: 0.73, alpha: 0.86).cgColor
        button.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
        button.layer.shadowOpacity = 1
        button.layer.shadowRadius = 12
        button.layer.masksToBounds = false
        return button
    }()
    
    private var adsBlockedLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 12, weight: .bold)
        label.textColor = "3C3C3C".hexColor
        label.text = NSLocalizedString("ADS BLOCKED", comment: "")
        label.textAlignment = .center
        return label
    }()
    
    private var numberAdsBlockedLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 36, weight: .bold)
        label.textColor = "404147".hexColor
        label.text = ""
        label.textAlignment = .center
        return label
    }()
    
    private var exceptionsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 12, weight: .bold)
        label.textColor = "3C3C3C".hexColor
        label.text = NSLocalizedString("EXCEPTIONS", comment: "")
        label.textAlignment = .center
        return label
    }()
    
    private var numberExceptionsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 36, weight: .bold)
        label.textColor = "404147".hexColor
        label.text = "0"
        label.textAlignment = .center
        return label
    }()
    
    private var getPremiumButton: UIButton = {
        let button = UIButton()
        button.setTitle(NSLocalizedString("GET PREMIUM", comment: ""), for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 18, weight: .semibold)
        button.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.25).cgColor
        button.layer.shadowOffset = CGSize(width: 3.0, height: 6.0)
        button.layer.shadowOpacity = 1
        button.layer.shadowRadius = 12
        button.layer.masksToBounds = false
        return button
    }()
    
    private var turnOffOnView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()
    
    var currentPosition = false

    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        numberAdsBlockedLabel.text = "\(Constants.ud.adsBlockedCount ?? 0)"
        numberExceptionsLabel.text = "\(Constants.ud.exceptionLinksCount ?? 0)"
    }

    private func setup() {
        configureLayout()
        setupButtons()
        configureBindBlockAction()
        configureAdblockAction()
    }
    
    override public func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        premiumPayWallOne()
        currentAdBlockerSatus()
        numberAdsBlockedLabel.text = "\(Constants.ud.adsBlockedCount ?? 0)"
        numberExceptionsLabel.text = "\(Constants.ud.exceptionLinksCount ?? 0)"
        
        numberAdsBlockedLabel.snp.updateConstraints { make in
            make.width.equalTo(numberAdsBlockedLabel.text!.width(constrainedBy: 100, with: .systemFont(ofSize: 36, weight: .bold)) + 25)
        }
        
        if IAPManager.shared().isPurchased {
            checkSubscriptions()
        }
      
    }
    
    private func premiumPayWallOne(){
        if !IAPManager.shared().isPurchased {
            IAPManager.shared().presentSingleSubscriptionVC(animated: true)
            IAPManager.shared().purchaseCompletion = { _ in
                IAPManager.shared().dismissSubscriptionVC()
            }
            IAPManager.shared().restoreCompletion = { subscription in
                IAPManager.shared().dismissSubscriptionVC()
                if Constants.ud.isPurchased {
                    AlertManager.shared().showPurchasesWereRestored()
                }
            }
        }
    }
    
    private func configureLayout() {
        view.backgroundColor = "F6F6F6".hexColor
        view.addSubviews(topImageView, turnOffOnView, protectionLabel, buttonImageView, adsBlockedLabel, numberAdsBlockedLabel, exceptionsLabel, numberExceptionsLabel, getPremiumButton)
        
        buttonImageView.addSubviews(turnOffOnButton)
        
        topImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        turnOffOnView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        protectionLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(151.resized())
            make.leading.equalToSuperview().offset(30)
            make.trailing.equalToSuperview().offset(-30)
            make.height.equalTo(48)
        }
        
        buttonImageView.snp.makeConstraints { make in
            make.top.equalTo(protectionLabel.snp.bottom).offset(3)
            make.width.equalTo(375)
            make.centerX.equalToSuperview()
            make.height.equalTo(107)
        }
        
        turnOffOnButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(29)
            make.trailing.equalToSuperview().offset(-285)
            make.size.equalTo(61)
        }
        
        adsBlockedLabel.snp.makeConstraints { make in
            make.top.equalTo(turnOffOnButton.snp.bottom).offset(75.resized())
            make.leading.equalToSuperview().offset(30)
            make.trailing.equalToSuperview().offset(-30)
            make.height.equalTo(24)
        }
        
        numberAdsBlockedLabel.snp.makeConstraints { make in
            make.top.equalTo(adsBlockedLabel.snp.bottom).offset(7.resized())
            make.width.equalTo(numberAdsBlockedLabel.text!.width(constrainedBy: 100, with: .systemFont(ofSize: 36, weight: .bold)) + 25)
            make.width.equalTo(UIScreen.main.bounds.width)
            make.centerX.equalToSuperview()
            make.height.equalTo(30)
        }
        
        exceptionsLabel.snp.makeConstraints { make in
            make.top.equalTo(numberAdsBlockedLabel.snp.bottom).offset(28.resized())
            make.leading.equalToSuperview().offset(30)
            make.trailing.equalToSuperview().offset(-30)
            make.height.equalTo(24)
        }
        
        numberExceptionsLabel.snp.makeConstraints { make in
            make.top.equalTo(exceptionsLabel.snp.bottom).offset(24.resized())
            make.width.equalTo(UIScreen.main.bounds.width)
            make.centerX.equalToSuperview()
            make.height.equalTo(30)
        }
        
        getPremiumButton.snp.makeConstraints { make in
            make.top.equalTo(numberExceptionsLabel.snp.bottom).offset(52.resized())
            make.width.equalTo((UIScreen.main.bounds.width - 116.resized(.width)))
            make.centerX.equalToSuperview()
            make.height.equalTo(63)
            
        }
    
        view.layoutIfNeeded()
        
        turnOffOnButton.addGradient(.leftRight, ["5200FF".hexColor, "3FC7C7".hexColor], 30.5)
        getPremiumButton.addGradient(.leftRight, ["36D5B8".hexColor, "45BED1".hexColor], 14)
    }
    
    private func turnOnFreeSwitch(){
        
        if Constants.ud.blockAdsSwitchValue == false {
            Constants.ud.blockAdsSwitchValue = true
            Constants.ud.adsBlockedCount? += 5679
        }
         
        if Constants.ud.blockSocialSwitchValue == false {
            Constants.ud.blockSocialSwitchValue = true
            Constants.ud.adsBlockedCount? += 7213
        }
    
        self.numberAdsBlockedLabel.text = "\(Constants.ud.adsBlockedCount ?? 0)"
        
            self.numberAdsBlockedLabel.snp.remakeConstraints{ make in
                make.top.equalTo(self.adsBlockedLabel.snp.bottom).offset(7.resized())
                make.width.equalTo(UIScreen.main.bounds.width)
                make.centerX.equalToSuperview()
                make.height.equalTo(30)
            }
    }
    
    private func setupButtons() {
        turnOffOnButtonAction()
        
        getPremiumButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.getPremiumButtonAction()
        }.disposed(by: disposeBag)
    }
    
    private func turnOffOnButtonAction(){
        let swipeGesture = createSwipeGestureRecognizer(for: .right)
        let swipeGesture2 = createSwipeGestureRecognizer(for: .left)
        turnOffOnButton.addGestureRecognizer(swipeGesture)
        turnOffOnButton.addGestureRecognizer(swipeGesture2)
    }

    private func createSwipeGestureRecognizer(for direction: UISwipeGestureRecognizer.Direction) -> UISwipeGestureRecognizer {
        let swipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(didSwipe(_:)))
        swipeGestureRecognizer.direction = direction
        return swipeGestureRecognizer
    }
    
    @objc private func didSwipe(_ sender: UISwipeGestureRecognizer) {
        var frame = turnOffOnButton.frame
        switch sender.direction {
        case .left:
            switch self.buttonImageView.image {
            case "TurnOff".image:
                print("Off")
//                self.isActivated = true
//                self.setActiveLayout()
            case "TurnDisable".image:
                self.presentTutorialViewController()
            case "TurnOn".image:
                if currentPosition == true {
                    frame.origin.x -= 256.0
                    frame.origin.x = max(0.0, frame.origin.x)
                    self.currentPosition = false
                    self.isActivated = false
                    self.setUnactiveLayout()
                }
            default:break
            }
            
        case .right:
            switch self.buttonImageView.image {
            case "TurnOff".image:
                if currentPosition == false {
                    frame.origin.x += 256.0
                    if frame.maxX > view.bounds.maxX {
                        frame.origin.x = view.bounds.width - frame.width
                    }
                    self.currentPosition = true
                    self.isActivated = true
                    self.setActiveLayout()
                    turnOnFreeSwitch()
                    Constants.ud.turnOnAddBlock = true
                }
            case "TurnDisable".image:
                self.presentTutorialViewController()
                Constants.ud.currentAdBlockerValue = 2
            case "TurnOn".image:
                print("On")
//                self.isActivated = false
//                self.setUnactiveLayout()
            default:break
            }
        default:
            break
        }
        UIView.animate(withDuration: 1.0) {
            self.turnOffOnButton.frame = frame
        }
    }
    
    private func getPremiumButtonAction(){
        if IAPManager.shared().isPurchased {
            print("Subscriptions succesful")
        } else {
            IAPManager.shared().presentSingleSubscriptionVC()
            IAPManager.shared().purchaseCompletion = { [weak self] _ in
                IAPManager.shared().dismissSubscriptionVC()
                guard let self = self else { return }
                self.checkSubscriptions()
            }
            IAPManager.shared().restoreCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                    AlertManager.shared().showPurchasesWereRestored()
                    self.checkSubscriptions()
                }
            }
        }
    }
    
    public func checkSubscriptions(){
        self.getPremiumButton.isHidden = true
    }
    
    func presentTutorialViewController() {
        var vc: UIViewController!
        vc = TutorialViewController()
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }
    
    func currentAdBlockerSatus() {
        switch Constants.ud.currentAdBlockerValue {
        case 0:
            UIView.animate(withDuration: 0.7) { [weak self] in
                guard let self = self else { return }
                self.turnOffOnButton.snp.remakeConstraints { make in
                    make.centerY.equalToSuperview()
                    make.leading.equalToSuperview().offset(29)
                    make.trailing.equalToSuperview().offset(-285)
                    make.size.equalTo(61)
                }
                self.currentPosition = false
                self.isActivated = false
                self.setUnactiveLayout()
            }
        case 1:
            UIView.animate(withDuration: 0.7) { [weak self] in
                guard let self = self else { return }
                self.turnOffOnButton.snp.remakeConstraints { make in
                    make.centerY.equalToSuperview()
                    make.leading.equalToSuperview().offset(285)
                    make.trailing.equalToSuperview().offset(-29)
                    make.size.equalTo(61)
                }
                self.currentPosition = true
                self.isActivated = true
                self.setActiveLayout()
                self.turnOnFreeSwitch()
                Constants.ud.turnOnAddBlock = true
                
            }
        case 2:
            UIView.animate(withDuration: 0.7) { [weak self] in
                guard let self = self else { return }
                self.turnOffOnButton.snp.remakeConstraints { make in
                    make.centerY.equalToSuperview()
                    make.leading.equalToSuperview().offset(29)
                    make.trailing.equalToSuperview().offset(-285)
                    make.size.equalTo(61)
                }
            }
        default:
            break
        }
    }
}

//MARK: - Safari Services
extension ProtectionViewController {
    func configureAdblockAction() {
        IHProgressHUD.show()
        SFContentBlockerManager.getStateOfContentBlocker(withIdentifier: Constants.app.contentBlockerExtensionName) { [weak self] (state, error) in
            if let state = state {
                if state.isEnabled {
                    SFContentBlockerManager.reloadContentBlocker(withIdentifier: Constants.app.contentBlockerExtensionName) { [weak self] (error) in
                        guard let self = self else { return }
                        if error == nil {
                            print("Rules activated.")
                            self.isProtected = true
                            self.isActivated ? self.setActiveLayout() : self.setUnactiveLayout()

                        } else {
                            print("ERROR activating rules")
                            print(error)
                            self.isProtected = false
                            self.setDisabledLayout()
                        }
                    }
                } else {
                    self?.isProtected = false
                    self?.setDisabledLayout()
                }
            } else if let error = error {
                print(error)
                self?.isProtected = false
                self?.setDisabledLayout()
            }
        }
    }

    func configureBindBlockAction() {
        UIApplication.shared.rx.applicationDidBecomeActive.bind { [weak self] _ in
            self?.configureAdblockAction()
        }.disposed(by: disposeBag)
    }

    func setDisabledLayout() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.buttonImageView.image = "TurnDisable".image
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.alignment = .center
            let attributedTitle = (NSLocalizedString("Protection is ", comment: "").withAttributes([.textColor("404147".hexColor),
                .font(.systemFont(ofSize: 32, weight: .heavy))]) + NSLocalizedString("Disabled", comment: "").withAttributes([.textColor("#F11E01".hexColor),
                .font(.systemFont(ofSize: 32, weight: .heavy))])).withAttribute(.paragraphStyle(paragraphStyle))
            self.protectionLabel.attributedText = attributedTitle
                       self.view.layoutIfNeeded()
                       self.topImageView.image = "protectionFull".image
                       self.turnOffOnButton.addGradient(.leftRight, ["5200FF".hexColor, "3FC7C7".hexColor], 30.5)
                       self.getPremiumButton.addGradient(.leftRight, ["36D5B8".hexColor, "45BED1".hexColor], 14)
                    self.getPremiumButton.setTitleColor(.white, for: .normal)
                       self.turnOffOnButton.layer.shadowColor = UIColor(red: 0.22, green: 0.83, blue: 0.73, alpha: 0.86).cgColor
                       self.turnOffOnButton.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
                       self.turnOffOnButton.layer.shadowOpacity = 1
                       self.turnOffOnButton.layer.shadowRadius = 12
                       self.turnOffOnButton.layer.masksToBounds = false
                    self.adsBlockedLabel.textColor = "3C3C3C".hexColor
                       self.exceptionsLabel.textColor = "3C3C3C".hexColor
                    self.numberExceptionsLabel.textColor = "42C2CC".hexColor
                       self.numberAdsBlockedLabel.textColor = "42C2CC".hexColor
                    self.turnOffOnView.backgroundColor = .clear
            Constants.ud.currentAdBlockerValue = 2
            IHProgressHUD.dismiss()
        }
    }

    func setUnactiveLayout() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.buttonImageView.image = "TurnOff".image
            self.protectionLabel.text = NSLocalizedString("Protection is OFF", comment: "")
            UIView.animate(withDuration: 1.0) {
                DispatchQueue.main.async {
                    self.buttonImageView.image = "TurnOff".image
                       self.view.layoutIfNeeded()
                       self.topImageView.image = "protectionFull".image
                       self.turnOffOnButton.addGradient(.leftRight, ["5200FF".hexColor, "3FC7C7".hexColor], 30.5)
                       self.getPremiumButton.addGradient(.leftRight, ["36D5B8".hexColor, "45BED1".hexColor], 14)
                    self.getPremiumButton.setTitleColor(.white, for: .normal)
                       self.turnOffOnButton.layer.shadowColor = UIColor(red: 0.22, green: 0.83, blue: 0.73, alpha: 0.86).cgColor
                       self.turnOffOnButton.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
                       self.turnOffOnButton.layer.shadowOpacity = 1
                       self.turnOffOnButton.layer.shadowRadius = 12
                       self.turnOffOnButton.layer.masksToBounds = false
                    self.adsBlockedLabel.textColor = "3C3C3C".hexColor
                       self.exceptionsLabel.textColor = "3C3C3C".hexColor
                    self.numberExceptionsLabel.textColor = "42C2CC".hexColor
                       self.numberAdsBlockedLabel.textColor = "42C2CC".hexColor
                    self.turnOffOnView.backgroundColor = .clear
                    self.protectionLabel.textColor = "404147".hexColor
                    Constants.ud.currentAdBlockerValue = 0
                }
            }
            IHProgressHUD.dismiss()
        }
    }

    func setActiveLayout() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            self.buttonImageView.image = "TurnOn".image
            self.protectionLabel.text = NSLocalizedString("Protection is ON", comment: "")
            UIView.animate(withDuration: 1.0) {
                DispatchQueue.main.async {
                    self.buttonImageView.image = "TurnOn".image
                    self.view.layoutIfNeeded()
                    self.topImageView.image = "anotherFullView".image
                    self.turnOffOnButton.addGradient(.leftRight, ["FFFFFF".hexColor, "EAEAEA".hexColor], 30.5)
                    self.getPremiumButton.addGradient(.leftRight, [.white, .white], 14)
                    self.getPremiumButton.setTitleColor("A94DF2".hexColor, for: .normal)

                    self.turnOffOnButton.layer.shadowColor = UIColor(red: 1.0, green: 1.0, blue: 1.0, alpha: 0.35).cgColor
                    self.turnOffOnButton.layer.shadowOffset = CGSize(width: 1.0, height: 1.0)
                    self.turnOffOnButton.layer.shadowOpacity = 1
                    self.turnOffOnButton.layer.shadowRadius = 12
                    self.turnOffOnButton.layer.masksToBounds = false
                  
                    self.adsBlockedLabel.textColor = .white
                    self.exceptionsLabel.textColor = .white
                    self.numberExceptionsLabel.textColor = .white
                    self.numberAdsBlockedLabel.textColor = .white
                    self.turnOffOnView.backgroundColor = "A94DF2".hexColor.withAlphaComponent(0.9)
                    self.protectionLabel.textColor = .white
                    Constants.ud.currentAdBlockerValue = 1
                }
            }
            IHProgressHUD.dismiss()
        }
    }
}


