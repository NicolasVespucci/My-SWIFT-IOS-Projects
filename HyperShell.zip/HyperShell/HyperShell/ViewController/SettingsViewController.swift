import UIKit
import RxSwift
import MessageUI
import SnapKit

class SettingsViewController: UIViewController {
    
    public var settingModels = [SettingModel(image: "ads", title: NSLocalizedString("Block Ads", comment: ""), value: Constants.ud.blockAdsSwitchValue),
                                SettingModel(image: "social", title: NSLocalizedString("Block Social buttons", comment: ""), value: Constants.ud.blockSocialSwitchValue),
                                SettingModel(image: "tracking", title: NSLocalizedString("Block Tracking", comment: ""), value: Constants.ud.blockTrackingSwitchValue),
                                SettingModel(image: "scripts", title: NSLocalizedString("Block Scripts", comment: ""), value: Constants.ud.blockScriptsSwitchValue),
                                SettingModel(image: "url", title: NSLocalizedString("Block URLs", comment: ""), value: Constants.ud.blockURLSSwitchValue),
                                SettingModel(image: "privacy", title: NSLocalizedString("Privacy Policy", comment: ""), value: nil),
                                SettingModel(image: "terms", title: NSLocalizedString("Terms of Use", comment: ""), value: nil),
                                SettingModel(image: "contact", title: NSLocalizedString("Contact support", comment: ""), value: nil),
                                SettingModel(image: "restore", title: NSLocalizedString("Restore purchases", comment: ""), value: nil)
    ]
    
    private lazy var scrollView: UIScrollView = {
        let view = UIScrollView()
        view.isPagingEnabled = true
        view.isScrollEnabled = true
        view.showsVerticalScrollIndicator = false
        view.backgroundColor = "F7F8FC".hexColor
        view.frame = self.view.bounds
        view.contentSize = CGSize(width: self.view.frame.width, height: 954)
        view.autoresizingMask = .flexibleTopMargin
        view.bounces = true
        return view
    }()
    
    private var topImageView: UIImageView = {
        let imageView = UIImageView(image: "squaresSettings".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private var settingsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 32, weight: .heavy)
        label.textColor = "404147".hexColor
        label.text = NSLocalizedString("Settings", comment: "")
        label.textAlignment = .left
        return label
    }()
    
    private lazy var emptyClearView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()
    
    private lazy var tableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 67
        table.backgroundColor = .clear
        table.separatorStyle = .none
        table.isScrollEnabled = false
        return table
    }()
    
    private var getPremiumButton: UIButton = {
        let button = UIButton()
        button.setTitle(NSLocalizedString("GET PREMIUM", comment: ""), for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 18, weight: .semibold)
        button.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.25).cgColor
        button.layer.shadowOffset = CGSize(width: 3.0, height: 6.0)
        button.layer.shadowOpacity = 1
        button.layer.shadowRadius = 12
        button.layer.masksToBounds = false
        return button
    }()
    
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        checkPay()

        if Constants.ud.turnOnAddBlock == true {
            self.settingModels[0].value = Constants.ud.blockAdsSwitchValue
            self.settingModels[1].value = Constants.ud.blockSocialSwitchValue
            self.tableView.reloadData()
        }
        
    }
    
    private func setup (){
        configureLayout()
        configureTableView()
        setupButtons()
        
       
    }
    
    private func configureLayout() {
        self.navigationController?.isNavigationBarHidden = true
        view.backgroundColor = "F6F6F6".hexColor
        view.addSubview(scrollView)
        
        scrollView.addSubviews(topImageView, settingsLabel, emptyClearView, getPremiumButton)
        emptyClearView.addSubview(tableView)
     
        scrollView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.width.equalTo(UIScreen.main.bounds.width)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
        }
        
        topImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.width.equalTo(276)
            make.height.equalTo(135)
            make.centerX.equalToSuperview()
        }
        
        settingsLabel.snp.makeConstraints { make in
            make.top.equalTo(topImageView.snp.bottom).offset(34.resized())
            make.width.equalTo((UIScreen.main.bounds.width - 92.resized(.width)))
            make.centerX.equalToSuperview()
            make.height.equalTo(48)
        }
        
        getPremiumButton.snp.makeConstraints { make in
            make.top.equalTo(settingsLabel.snp.bottom).offset(28.resized())
            make.width.equalTo((UIScreen.main.bounds.width - 116.resized(.width)))
            make.centerX.equalToSuperview()
            make.height.equalTo(63)
        }
        
        emptyClearView.snp.makeConstraints { make in
            make.top.equalTo(getPremiumButton.snp.bottom).offset(18)
            make.height.equalTo(600)
            make.width.equalTo((UIScreen.main.bounds.width - 32.resized(.width)))
            make.centerX.equalToSuperview()
        }
        
        tableView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
     
        
        view.layoutIfNeeded()
        
        getPremiumButton.addGradient(.leftRight, ["36D5B8".hexColor, "45BED1".hexColor], 14)
    }
    
    private func configureTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(SettingsCell.self, forCellReuseIdentifier: SettingsCell.nibIdentifier)
    }
    
    private func setupButtons() {
        getPremiumButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.premiumButtonImageAction()
        }.disposed(by: disposeBag)
    }
    
    private func premiumButtonImageAction(){
        IAPManager.shared().presentSubscriptionVC()
        IAPManager.shared().purchaseCompletion = { [weak self] _ in
            IAPManager.shared().dismissSubscriptionVC()
            guard let self = self else { return }
            self.checkPay()
        }
        IAPManager.shared().restoreCompletion = { subscription in
            if Constants.ud.isPurchased {
                IAPManager.shared().dismissSubscriptionVC()
                AlertManager.shared().showPurchasesWereRestored()
                self.checkPay()
            }
        }
    }
    
    func checkPay() {
        if IAPManager.shared().isPurchased {
            getPremiumButton.isHidden = true
            scrollView.contentSize = CGSize(width: self.view.frame.width, height: 854)
        } else {
            print("No subscription ------------->")
        }
    }
    
    func pushPoliciesVC(_ policiesType: Policies) {
        let termsVC = TermsAndPrivacy()
        termsVC.policiesType = policiesType
        termsVC.modalPresentationStyle = .pageSheet
        self.present(termsVC, animated: true, completion: nil)
    }
    
    private func contact() {
        if MFMailComposeViewController.canSendMail() {
            let toRecipients = ["support@hypershell-app.com"]
            let subject = "Feedback"
            let mail = configuredMailComposeViewController(recipients: toRecipients, subject: subject, body: "", isHtml: true, images: nil)
            presentMailComposeViewController(mailComposeViewController: mail)
        } else {
            print("You don't have email in Mail iOS App")
        }
    }
    
    private func restore() {
        if Constants.ud.isPurchased {
            AlertManager.shared().showNoPurchasesToRestore()
        } else {
            IAPManager.shared().restore()
            IAPManager.shared().restoreCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                    AlertManager.shared().showPurchasesWereRestored()
                }
            }
        }
    }
    
    private func presentFirstSubscriptions(){
        IAPManager.shared().presentSingleSubscriptionVC()
        IAPManager.shared().restoreCompletion = { subscription in
            if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                    AlertManager.shared().showPurchasesWereRestored()
                self.checkPay()
            }
        }
        
        IAPManager.shared().purchaseCompletion = { subscription in
            if Constants.ud.isPurchased {
                    AlertManager.shared().showPurchaseComplite()
                    IAPManager.shared().dismissSubscriptionVC()
                self.checkPay()
            }
        }
    }
}

extension SettingsViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
        func adsActiveNonActiveValue (){
            Constants.ud.blockAdsSwitchValue = !Constants.ud.blockAdsSwitchValue
            self.settingModels[indexPath.row].value = Constants.ud.blockAdsSwitchValue
            if Constants.ud.blockAdsSwitchValue {
                Constants.ud.adsBlockedCount? += 5679
            } else {
                Constants.ud.adsBlockedCount? -= 5679
            }

        }
        
        func socialActiveNonActiveValue() {
            Constants.ud.blockSocialSwitchValue = !Constants.ud.blockSocialSwitchValue
            settingModels[indexPath.row].value = Constants.ud.blockSocialSwitchValue
            
            if Constants.ud.blockSocialSwitchValue {
                Constants.ud.adsBlockedCount? += 7213
            } else {
                Constants.ud.adsBlockedCount? -= 7213
            }
            

        }
        
        func scriptActiveNonActiveValue() {
            if !IAPManager.shared().isPurchased {
                presentFirstSubscriptions()
            } else {
                IAPManager.shared().dismissSubscriptionVC()
                Constants.ud.blockScriptsSwitchValue = !Constants.ud.blockScriptsSwitchValue
                settingModels[indexPath.row].value = Constants.ud.blockScriptsSwitchValue

                if Constants.ud.blockScriptsSwitchValue {
                    Constants.ud.adsBlockedCount? += 4521
                } else {
                    Constants.ud.adsBlockedCount? -= 4521
                }
            }
        }
        
        func trackingActiveNonActiveValue() {
            if !IAPManager.shared().isPurchased {
                presentFirstSubscriptions()
            } else {
                IAPManager.shared().dismissSubscriptionVC()
                Constants.ud.blockTrackingSwitchValue = !Constants.ud.blockTrackingSwitchValue
                settingModels[indexPath.row].value = Constants.ud.blockTrackingSwitchValue

                if Constants.ud.blockTrackingSwitchValue {
                    Constants.ud.adsBlockedCount? += 12567
                } else {
                    Constants.ud.adsBlockedCount? -= 12567
                }
            }
        }
        
        func URLsActiveNonActiveValue() {
            if !IAPManager.shared().isPurchased {
                presentFirstSubscriptions()
            } else {
                IAPManager.shared().dismissSubscriptionVC()
                Constants.ud.blockURLSSwitchValue = !Constants.ud.blockURLSSwitchValue
                settingModels[indexPath.row].value = Constants.ud.blockURLSSwitchValue
                if Constants.ud.blockURLSSwitchValue {
                    Constants.ud.adsBlockedCount? += 39621
                } else {
                    Constants.ud.adsBlockedCount? -= 39621
                }
            }
        }
        
        DispatchQueue.main.async {
            switch self.settingModels[indexPath.row].title {
            case NSLocalizedString("Block Ads", comment: ""):
                adsActiveNonActiveValue()
            case NSLocalizedString("Block Social buttons", comment: ""):
                socialActiveNonActiveValue()
            case NSLocalizedString("Block Tracking", comment: ""):
                scriptActiveNonActiveValue()
            case NSLocalizedString("Block Scripts", comment: ""):
                trackingActiveNonActiveValue()
            case NSLocalizedString("Block URLs", comment: ""):
                URLsActiveNonActiveValue()
            case NSLocalizedString("Privacy Policy", comment: ""):
                self.pushPoliciesVC(.privacy)
            case NSLocalizedString("Terms of Use", comment: ""):
                self.pushPoliciesVC(.terms)
            case NSLocalizedString("Contact support", comment: ""):
                self.contact()
            case NSLocalizedString("Restore purchases", comment: ""):
                self.restore()
            default: print("Unknown")
            }
            self.tableView.reloadData()
        }
    }
}

extension SettingsViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return settingModels.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let oneCell = tableView.dequeueReusableCell(withIdentifier: SettingsCell.nibIdentifier, for:  indexPath) as! SettingsCell
        let settingModel = settingModels[indexPath.row]
        oneCell.settingModel = settingModel
        if settingModel.value != nil {
            oneCell.configureLayoutWithSwitch()
        } else {
            oneCell.configureLayoutWithoutSwitch()
        }
        return oneCell
    }
}
