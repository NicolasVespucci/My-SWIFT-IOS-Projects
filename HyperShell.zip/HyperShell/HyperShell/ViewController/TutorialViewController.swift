import UIKit
import RxSwift
import SwiftyAttributes

class TutorialViewController: UIViewController {
    
    private var topImageView: UIImageView = {
        let imageView = UIImageView(image: "TutorialFull".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private var topBackButton: UIButton = {
        let button = UIButton()
        button.setImage("backTutorial".image, for: .normal)
        return button
    }()
    
    private var HowToActivateLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 28, weight: .semibold)
        label.textColor = "404147".hexColor
        label.text = NSLocalizedString("How to activate \nAdd blocker", comment: "")
        label.textAlignment = .left
        label.numberOfLines = 2
        return label
    }()
    
    private var vercticalLineImageView: UIImageView = {
        let imageView = UIImageView(image: "line".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private lazy var firstLabel: UILabel = {
        let label = UILabel()
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        let attributedTitle = (NSLocalizedString("Open", comment: "").withAttributes([.textColor("404147".hexColor), .font(.systemFont(ofSize: 16, weight: .semibold))]) + NSLocalizedString(" Settings", comment: "").withAttributes([.textColor("A94DF2".hexColor), .font(.systemFont(ofSize: 16, weight: .semibold))]) + NSLocalizedString(",\n locate", comment: "").withAttributes([.textColor("404147".hexColor), .font(.systemFont(ofSize: 16, weight: .semibold))]) + NSLocalizedString(" Safari", comment: "").withAttributes([.textColor("A94DF2".hexColor), .font(.systemFont(ofSize: 16, weight: .semibold))])
        ).withAttribute(.paragraphStyle(paragraphStyle))
        label.attributedText = attributedTitle
        label.minimumScaleFactor = 0.5
        label.numberOfLines = 2
        return label
    }()
    
    private lazy var secondLabel: UILabel = {
        let label = UILabel()
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        let attributedTitle = (NSLocalizedString("Open", comment: "").withAttributes([.textColor("404147".hexColor), .font(.systemFont(ofSize: 16, weight: .semibold))]) + NSLocalizedString(" Content Blockers", comment: "").withAttributes([.textColor("A94DF2".hexColor), .font(.systemFont(ofSize: 16, weight: .semibold))])
        ).withAttribute(.paragraphStyle(paragraphStyle))
        label.attributedText = attributedTitle
        label.minimumScaleFactor = 0.5
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var thirdLabel: UILabel = {
        let label = UILabel()
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        let attributedTitle = (NSLocalizedString("Switch On ", comment: "").withAttributes([.textColor("404147".hexColor), .font(.systemFont(ofSize: 16, weight: .semibold))]) + NSLocalizedString("HyperShell", comment: "").withAttributes([.textColor("A94DF2".hexColor), .font(.systemFont(ofSize: 16, weight: .semibold))])
        ).withAttribute(.paragraphStyle(paragraphStyle))
        label.attributedText = attributedTitle
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.numberOfLines = 1
        return label
    }()
    
    private var openSettingsButton: UIButton = {
        let button = UIButton()
        button.setTitle(NSLocalizedString("OPEN SETTINGS", comment: ""), for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 18, weight: .semibold)
        button.titleLabel?.adjustsFontSizeToFitWidth = true
        button.titleLabel?.minimumScaleFactor = 0.5
        button.layer.shadowColor = UIColor(red: 0.0, green: 0.0, blue: 0.0, alpha: 0.25).cgColor
        button.layer.shadowOffset = CGSize(width: 3.0, height: 6.0)
        button.layer.shadowOpacity = 1
        button.layer.shadowRadius = 12
        button.layer.masksToBounds = false
        return button
    }()
    
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup() {
        configureLayout()
        setupButtons()
    }
    
    private func configureLayout() {
        view.addSubviews(topImageView, topBackButton, HowToActivateLabel, vercticalLineImageView, firstLabel, secondLabel, thirdLabel, openSettingsButton)
        
        topImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        topBackButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(45.resized())
            make.leading.equalToSuperview().offset(37)
            make.size.equalTo(24)
        }
        
        HowToActivateLabel.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(28)
            make.height.equalTo(70)
            make.bottom.equalTo(firstLabel.snp.top).offset(-27.resized())
        }
        
        vercticalLineImageView.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(28)
            make.height.equalTo(157)
            make.width.equalTo(17)
            make.bottom.equalTo(openSettingsButton.snp.top).offset(-50.resized())
        }
        
        firstLabel.snp.makeConstraints { make in
            make.leading.equalTo(vercticalLineImageView.snp.trailing).offset(42)
            make.height.equalTo(44)
            make.bottom.equalTo(secondLabel.snp.top).offset(-25)
        }
        
        secondLabel.snp.makeConstraints { make in
            make.leading.equalTo(vercticalLineImageView.snp.trailing).offset(42)
            make.height.equalTo(24)
            make.bottom.equalTo(thirdLabel.snp.top).offset(-47)
        }
        
        thirdLabel.snp.makeConstraints { make in
            make.leading.equalTo(vercticalLineImageView.snp.trailing).offset(42)
            make.height.equalTo(24)
            make.bottom.equalTo(openSettingsButton.snp.top).offset(-50.resized())
        }
        
        openSettingsButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-45.resized())
            make.leading.equalToSuperview().offset(52)
            make.trailing.equalToSuperview().offset(-64)
            make.height.equalTo(63)
        }
        
        view.layoutIfNeeded()
        
        openSettingsButton.addGradient(.leftRight, ["36D5B8".hexColor, "45BED1".hexColor], 14)
    }
    
    private func setupButtons() {
        topBackButton.rx.tap.bind { [weak self] in
            self?.dismiss(animated: true)
        }.disposed(by: disposeBag)
        
        openSettingsButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.openSettings()
        }.disposed(by: disposeBag)
    }
    
    func openSettings() {
        if let URL = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(URL)
        }
    }
}
