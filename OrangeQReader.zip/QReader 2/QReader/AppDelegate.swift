//
//  AppDelegate.swift
//  QReader
//
//  Created by iMac 27 on 30.03.2022.
//

import UIKit
import SwiftyStoreKit

var showCurrentController = false
@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        SwiftyStoreKit.completeTransactions(atomically: true) { purchases in
            for purchase in purchases {
                switch purchase.transaction.transactionState {
                case .purchased, .restored:
                    if purchase.needsFinishTransaction {
                        // Deliver content from server, then:
                        SwiftyStoreKit.finishTransaction(purchase.transaction)
                    }
                    Constants.ud.isPurchased = true
                case .failed, .purchasing, .deferred:
                    Constants.ud.isPurchased = false
                    break // do nothing
                @unknown default: break
                }
            }
        }
        setRootVC()
        return true
    }
    
    private func setRootVC() {
        window = UIWindow()
        window?.makeKeyAndVisible()
        let mainVC = StartViewController()
        let navController = UINavigationController()
        navController.pushViewController(mainVC, animated: false)
        window?.rootViewController = navController
    }
}

