//
//  Constants.swift
//  QReader
//
//  Created by iMac 21 on 04/04/2022.
//

import Foundation
import UIKit
import ApphudSDK


var UD = UserDefaults.standard

public struct Constants {
  
  static var app = AppConstants()
  static var analytics = AnalyticsConstants()
  static var ud = UDConstants()
  
  struct AnalyticsConstants {
      let week = "qr.week.er"
      let threeMonth = "qr.month.er"
      let year = "qr.annual.er"
      
          //com.qr.read.er
  }
  
  struct AppConstants {
    let appid = "1622371716"
  }
  
  struct UDConstants {
    
    
    var didAcceptPrivacy: Bool {
      get { return UD.bool(forKey: UserDefaults.Keys.didAcceptPrivacy) }
      set { UD.set(newValue, forKey: UserDefaults.Keys.didAcceptPrivacy) }
    }
    
      var isPurchased : Bool {
          get { return UD.bool(forKey: UserDefaults.Keys.isPurchased) }
          set { UD.set(newValue, forKey: UserDefaults.Keys.isPurchased) }
      }
    

      var batchScanValue: Bool {
          get { return UD.bool(forKey: "blockAdsSwitchValue") }
          set { UD.set(newValue, forKey: "blockAdsSwitchValue") }
      }
      
      var vibrateValue: Bool {
          get { return UD.bool(forKey: "blockSocialSwitchValue") }
          set { UD.set(newValue, forKey: "blockSocialSwitchValue") }
      }
      
      var historyValue: Bool {
          get { return UD.bool(forKey: "blockScriptsSwitchValue") }
          set { UD.set(newValue, forKey: "blockScriptsSwitchValue") }
      }
      
      var dublicateScansValue: Bool {
          get { return UD.bool(forKey: "blockTrackingSwitchValue") }
          set { UD.set(newValue, forKey: "blockTrackingSwitchValue") }
      }
      
      var currentDismis: Int? {
          set { UD.set(newValue, forKey: "currentDismis") }
          get { return UD.integer(forKey: "currentDismis") }
      }
      
  }
  
  static var country: String = {
    let locale: NSLocale = NSLocale(localeIdentifier: "en_US")
    if let countryCode = locale.object(forKey: NSLocale.Key.countryCode) as? String,
      let country = locale.displayName(forKey: NSLocale.Key.countryCode, value: countryCode) {
      print(country)
      return country
    }
    return "unsigned"
  }()
}
