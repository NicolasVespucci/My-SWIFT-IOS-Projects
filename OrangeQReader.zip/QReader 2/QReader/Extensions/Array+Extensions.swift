//
//  Array+Extensions.swift
//  PurchasesTutorial
//
//  Created by Marcel on 4/2/19.
//  Copyright © 2019 Marcel. All rights reserved.
//

import Foundation

extension Array {
  subscript(safe index: Index) -> Element? {
    let isValidIndex = index >= 0 && index < count
    return isValidIndex ? self[index] : nil
  }
}

extension Array{
  public mutating func appends(_ elements: Element...) {
    elements.forEach { self.append($0) }
  }
}
