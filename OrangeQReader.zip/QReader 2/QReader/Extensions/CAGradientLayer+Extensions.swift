
import UIKit
import Foundation



public enum GradientDirection {
  case topToBottom
  case bottomToTop
  case leftToRight
  case rightToLeft
  case topLeftToBottomRight
  case topRightToBottomLeft
  case bottomLeftToTopRight
  case bottomRightToTopLeft
  case half
  case babyBee
}

extension UIView{
  public func setMainViewGradient(){
    let gradient = GradientLayer(direction: GradientDirection.leftToRight, colors: [#colorLiteral(red: 0.3411764706, green: 0.6392156863, blue: 0.9725490196, alpha: 1),#colorLiteral(red: 0.2117647059, green: 0.3843137255, blue: 0.9843137255, alpha: 1)], cornerRadius: 0)
    let viewX = self.frame.origin.x
    let viewY = self.frame.origin.y
    let viewH = self.frame.height
    let viewW = self.frame.width
    self.backgroundColor = UIColor.fromGradient(gradient, frame: CGRect(x:viewX, y: viewY, width: viewW, height: viewH))
  }
}


public extension UIColor {
  convenience init(hex: String) {
    var stringHex = hex
    if stringHex.contains("#") { stringHex.removeAll(where: {$0 == "#"}) }
    guard let hex = Int(stringHex, radix: 16) else {
      self.init(red: 0, green: 0, blue: 0, alpha: 1)
      return
    }
    
    let red = ((CGFloat)((hex & 0xFF0000) >> 16)) / 255.0
    let green = ((CGFloat)((hex & 0x00FF00) >> 8)) / 255.0
    let blue = ((CGFloat)((hex & 0x0000FF) >> 0)) / 255.0
    self.init(displayP3Red: red, green: green, blue: blue, alpha: 1.0)
  }
  
  static func hex(_ hex: String, alpha: CGFloat = 1.0) -> UIColor {
    guard let hex = Int(hex, radix: 16) else { return UIColor.clear }
    return UIColor(red: ((CGFloat)((hex & 0xFF0000) >> 16)) / 255.0,
                   green: ((CGFloat)((hex & 0x00FF00) >> 8)) / 255.0,
                   blue: ((CGFloat)((hex & 0x0000FF) >> 0)) / 255.0,
                   alpha: alpha)
  }
  
  
  static func fromGradient(_ gradient: GradientLayer, frame: CGRect, cornerRadius: CGFloat = 0) -> UIColor? {
    guard let image = UIImage.fromGradient(gradient, frame: frame, cornerRadius: cornerRadius) else { return nil }
    let color = UIColor(patternImage: image)
    return color
  }
  
  static func fromGradientWithDirection(_ direction: GradientDirection, frame: CGRect, colors: [UIColor], cornerRadius: CGFloat = 0) -> UIColor? {
    let gradient = GradientLayer(direction: direction, colors: colors, cornerRadius: cornerRadius)
    return UIColor.fromGradient(gradient, frame: frame)
  }
}

open class GradientLayer: CAGradientLayer {
  
  private var direction: GradientDirection = .topLeftToBottomRight
  
  public init(direction: GradientDirection, colors: [UIColor], cornerRadius: CGFloat = 0) {
    super.init()
    self.direction = direction
    self.needsDisplayOnBoundsChange = true
    self.colors = colors.map { $0.cgColor as Any }
    let (startPoint, endPoint) = GradientKitHelper.getStartEndPointOf(direction)
    self.startPoint = startPoint
    self.endPoint = endPoint
    self.cornerRadius = cornerRadius
  }
  
  public override init(layer: Any) {
    super.init(layer: layer)
  }
  
  required public init(coder aDecoder: NSCoder) {
    super.init()
  }
  
  public final func clone() -> GradientLayer {
    if let colors = self.colors {
      return GradientLayer(direction: self.direction, colors: colors.map { UIColor.init(cgColor: $0 as! CGColor) }, cornerRadius: self.cornerRadius)
    }
    return GradientLayer(direction: self.direction, colors: [], cornerRadius: self.cornerRadius)
  }
}

open class GradientKitHelper {
  static func getStartEndPointOf(_ gradientDirection: GradientDirection) -> (startPoint: CGPoint, endPoint: CGPoint) {
    switch gradientDirection {
    case .topToBottom:
      return (CGPoint(x: 0.5, y: 0.0), CGPoint(x: 0.5, y: 1.0))
    case .bottomToTop:
      return (CGPoint(x: 0.5, y: 1.0), CGPoint(x: 0.5, y: 0.0))
    case .leftToRight:
      return (CGPoint(x: 0.0, y: 0.5), CGPoint(x: 1.0, y: 0.5))
    case .rightToLeft:
      return (CGPoint(x: 1.0, y: 0.5), CGPoint(x: 0.0, y: 0.5))
    case .topLeftToBottomRight:
      return (CGPoint.zero, CGPoint(x: 1.0, y: 1.0))
    case .topRightToBottomLeft:
      return (CGPoint(x: 0.1, y: 0.0), CGPoint(x: 0.0, y: 1.0))
    case .bottomLeftToTopRight:
      return (CGPoint(x: 0.0, y: 1.0), CGPoint(x: 1.0, y: 0.0))
    case .bottomRightToTopLeft:
      return (CGPoint(x: 1.0, y: 1.0), CGPoint(x: 0.0, y: 0.0))
    case .half:
      return (CGPoint(x: 0.0, y: 0.8), CGPoint(x: 0.0, y: 0.8))
    case .babyBee:
      return (CGPoint(x: 0.0, y: 0.9), CGPoint(x: 0.0, y: 0.9))
    }
    
  }
}
extension UIImage{
  public static func fromGradient(_ gradient: GradientLayer, frame: CGRect, cornerRadius: CGFloat = 0) -> UIImage? {
    UIGraphicsBeginImageContextWithOptions(frame.size, false, UIScreen.main.scale)
    guard let ctx = UIGraphicsGetCurrentContext() else { return nil }
    let cloneGradient = gradient.clone()
    cloneGradient.frame = frame
    cloneGradient.cornerRadius = cornerRadius
    cloneGradient.render(in: ctx)
    guard let image = UIGraphicsGetImageFromCurrentImageContext() else { return nil }
    UIGraphicsEndImageContext()
    return image
  }
  
  public static func fromGradientWithDirection(_ direction: GradientDirection, frame: CGRect, colors: [UIColor], cornerRadius: CGFloat = 0) -> UIImage? {
    let gradient = GradientLayer(direction: direction, colors: colors, cornerRadius: cornerRadius)
    return UIImage.fromGradient(gradient, frame: frame)
  }
}
