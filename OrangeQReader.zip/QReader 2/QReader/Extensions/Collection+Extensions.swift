//
//  Collection+Extensions.swift
//  PurchasesTutorial
//
//  Created by Marcel on 4/2/19.
//  Copyright © 2019 Marcel. All rights reserved.
//

import Foundation

extension Collection {
  subscript(safe index: Index) -> Element? {
    return indices.contains(index) ? self[index] : nil
  }
}
