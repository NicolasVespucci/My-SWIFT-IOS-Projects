//
//  Date+Extensions.swift
//  Snell
//
//  Created by Marcel on 1/9/19.
//  Copyright © 2019 Marcel . All rights reserved.
//

import Foundation

extension Date {
  func toString(dateFormat format: String? = "yyyy-MM-dd HH:mm:ssZ") -> String {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = format
    return dateFormatter.string(from: self)
  }
}
