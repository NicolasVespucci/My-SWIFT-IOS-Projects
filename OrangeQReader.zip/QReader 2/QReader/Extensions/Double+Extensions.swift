//
//  Double+Extensions.swift
//  Snell
//
//  Created by Marcel Spinu on 11/29/18.
//  Copyright © 2018 Marcel . All rights reserved.
//

import Foundation
import UIKit

extension Double {
    
    func rounded(toPlaces places: Int, rule: FloatingPointRoundingRule? = .down) -> Double {
        let divisor = pow(10.0, Double(places))
        return (self * divisor).rounded(rule!) / divisor
    }
    
    var stringValue: String {
        return String(format: "%.02f", self)
    }
    
    var cgFloat: CGFloat {
        return CGFloat(self)
    }
}
