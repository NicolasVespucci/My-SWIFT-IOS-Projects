import UIKit
import Foundation

protocol NibIdentifiable: class {
  static var nib: UINib { get }
  static var nibIdentifier: String { get }
}

extension NibIdentifiable {
  static var nibIdentifier: String {
    return "\(self)"
  }
  
  static var nib: UINib {
    return UINib(nibName: nibIdentifier, bundle: nil)
  }
}

extension UIView: NibIdentifiable {}
extension UIViewController: NibIdentifiable {}

extension NibIdentifiable where Self: UIViewController {
  static func instantiateFromNib() -> Self {
    return Self(nibName: nibIdentifier, bundle: nil)
  }
}

extension NibIdentifiable where Self: UIView {
  static func instantiateFromNib() -> Self {
    guard let view = UINib(nibName: nibIdentifier, bundle: nil)
      .instantiate(withOwner: nil, options: nil).first as? Self
      else {
        fatalError("Couldn't find nib file for \(String(describing: Self.self))")
    }
    return view
  }
}

extension UICollectionView {
  func register<CellClass: UICollectionViewCell>(cellClass: CellClass.Type) {
    self.register(cellClass, forCellWithReuseIdentifier: cellClass.nibIdentifier)
  }
  
  func register<Cell: UICollectionViewCell>(cellType: Cell.Type) {
    self.register(cellType.nib, forCellWithReuseIdentifier: cellType.nibIdentifier)
  }
  
  func register<HeaderClass: UICollectionReusableView>(headerClass: HeaderClass.Type, kind: String) {
    self.register(headerClass, forSupplementaryViewOfKind: kind, withReuseIdentifier: headerClass.nibIdentifier)
  }
  
  func register<Header: UICollectionReusableView>(headerType: Header.Type, kind: String){
    self.register(headerType.nib, forSupplementaryViewOfKind: kind, withReuseIdentifier: headerType.nibIdentifier)
  }
  
  func dequeueReusableView<Header: UICollectionReusableView>(type: Header.Type,
                                                             kind: String,
                                                             indexPath: IndexPath) -> Header{
    return self.dequeueReusableSupplementaryView(ofKind: kind,
                                                 withReuseIdentifier: type.nibIdentifier, for: indexPath) as! Header
  }
  
  
  func dequeueReusableView<HeaderClass: UICollectionReusableView>(headerClass: HeaderClass.Type, kind: String, indexPath: IndexPath) -> HeaderClass {
    return self.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: headerClass.nibIdentifier, for: indexPath) as! HeaderClass
  }
  
  func cellForItem<Cell: UICollectionViewCell>(_ cellClass: Cell.Type , _ indexPath: IndexPath) -> Cell {
    return self.cellForItem(at: indexPath) as! Cell
  }
  
  
  func dequeueReusableCell<Cell: UICollectionViewCell>(type: Cell.Type,
                                                       indexPath: IndexPath) -> Cell {
    return self.dequeueReusableCell(withReuseIdentifier: Cell.nibIdentifier, for: indexPath) as! Cell
  }
  
  func dequeueReusableCell<CellClass: UICollectionViewCell>(classType: CellClass.Type, indexPath: IndexPath) -> CellClass {
    return self.dequeueReusableCell(withReuseIdentifier: classType.nibIdentifier, for: indexPath) as! CellClass
  }
  
}

extension UITableView {
  func register<Cell: UITableViewCell>(cellType: Cell.Type) {
    register(cellType.nib, forCellReuseIdentifier: cellType.nibIdentifier)
  }
  
  func register<CellClass: UITableViewCell>(cellClass: CellClass.Type) {
    register(cellClass, forCellReuseIdentifier: cellClass.nibIdentifier)
  }
  
  func dequeueReusableCell<CellClass: UITableViewCell>(cellClass: CellClass.Type, indexPath: IndexPath) -> CellClass {
    return dequeueReusableCell(withIdentifier: cellClass.nibIdentifier , for: indexPath) as! CellClass
  }
  
  func dequeueReusableCell<Cell: UITableViewCell>(type: Cell.Type,
                                                  indexPath: IndexPath) -> Cell {
    return dequeueReusableCell(withIdentifier: Cell.nibIdentifier, for: indexPath) as! Cell
  }
  
  func dequeueTableHeaderFooter<Header: UITableViewHeaderFooterView>(type: Header.Type) -> Header {
    return dequeueReusableHeaderFooterView(withIdentifier: Header.nibIdentifier) as! Header
  }
}
