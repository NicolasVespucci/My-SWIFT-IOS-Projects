//
//  TimeInterval + Extensions.swift
//  Smart Cleaner
//
//  Created by Baluta Eugen on 1/22/20.
//

import Foundation

extension TimeInterval {
  var formatted: String {
    let dateFormatter = DateFormatter()
    dateFormatter.dateFormat = "MMM, yyyy"
    let date = Date(timeIntervalSince1970: self)
    let string = dateFormatter.string(from: date)
    return string
  }
}
