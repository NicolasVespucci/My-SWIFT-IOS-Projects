//
//  UIApplication+Extensions.swift
//  BaseProject
//
//  Created by Marcel  on 7/16/18.
//  Copyright © 2018 Marcel . All rights reserved.
//

import Foundation
import UIKit

extension UIApplication {
  
  static var presentedViewController: UIViewController? {
    var presentViewController = UIApplication.shared.keyWindow?.rootViewController
    while let pVC = presentViewController?.presentedViewController {
      presentViewController = pVC
    }
    return presentViewController
  }
  
  static var applicationVersion: String {
    return Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String
  }
  
  static var applicationBuild: String {
    return Bundle.main.object(forInfoDictionaryKey: kCFBundleVersionKey as String) as! String
  }
  
  static var versionBuild: String {
    return "v\(self.applicationVersion)(\(self.applicationBuild))"
  }
}
