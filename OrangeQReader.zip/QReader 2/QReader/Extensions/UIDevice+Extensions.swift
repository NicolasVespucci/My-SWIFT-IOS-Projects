//
//  UIDevice+Extensions.swift
//  PurchasesTutorial
//
//  Created by Marcel on 2/7/19.
//  Copyright © 2019 Marcel. All rights reserved.
//

import Foundation
import UIKit
import NotificationCenter

extension UIDevice {
  
  enum ScreenType: String {
    case iPhone4_4S = "iPhone 4 or iPhone 4S"
    case iPhones_5_5s_5c_SE = "iPhone 5, iPhone 5s, iPhone 5c or iPhone SE"
    case iPhones_6_6s_7_8 = "iPhone 6, iPhone 6S, iPhone 7 or iPhone 8"
    case iPhones_6Plus_6sPlus_7Plus_8Plus = "iPhone 6 Plus, iPhone 6S Plus, iPhone 7 Plus or iPhone 8 Plus"
    case iPhoneXR = "iPhone XR"
    case iPhoneX_XS = "iPhone X,iPhoneXS"
    case iPhoneXSMax = "iPhoneXS Max"
    case unknown
  }
  
  var screenType: ScreenType {
    switch UIScreen.main.nativeBounds.height {
    case 960:           return .iPhone4_4S
    case 1136:          return .iPhones_5_5s_5c_SE
    case 1334:          return .iPhones_6_6s_7_8
    case 1792:          return .iPhoneXR
    case 1920, 2208:    return .iPhones_6Plus_6sPlus_7Plus_8Plus
    case 2436:          return .iPhoneX_XS
    case 2688:          return .iPhoneXSMax
    default:            return .unknown
    }
  }
  
  var countryCode: String? {
    return Locale.current.regionCode
  }
  
  var countryName: String? {
    return Locale.current.localizedString(forRegionCode: countryCode ?? "Unknown")
  }
  
  // MARK: DEVICE MODEL
  static let modelName: String = {
    var systemInfo = utsname()
    uname(&systemInfo)
    let machineMirror = Mirror(reflecting: systemInfo.machine)
    let identifier = machineMirror.children.reduce("") { identifier, element in
      guard let value = element.value as? Int8, value != 0 else { return identifier }
      return identifier + String(UnicodeScalar(UInt8(value)))
    }
    
    func mapToDevice(identifier: String) -> String { // swiftlint:disable:this cyclomatic_complexity
      #if os(iOS)
      switch identifier {
      case "iPod5,1":                                 return "iPod Touch 5"
      case "iPod7,1":                                 return "iPod Touch 6"
      case "iPhone3,1", "iPhone3,2", "iPhone3,3":     return "iPhone 4"
      case "iPhone4,1":                               return "iPhone 4s"
      case "iPhone5,1", "iPhone5,2":                  return "iPhone 5"
      case "iPhone5,3", "iPhone5,4":                  return "iPhone 5c"
      case "iPhone6,1", "iPhone6,2":                  return "iPhone 5s"
      case "iPhone7,2":                               return "iPhone 6"
      case "iPhone7,1":                               return "iPhone 6 Plus"
      case "iPhone8,1":                               return "iPhone 6s"
      case "iPhone8,2":                               return "iPhone 6s Plus"
      case "iPhone9,1", "iPhone9,3":                  return "iPhone 7"
      case "iPhone9,2", "iPhone9,4":                  return "iPhone 7 Plus"
      case "iPhone8,4":                               return "iPhone SE"
      case "iPhone10,1", "iPhone10,4":                return "iPhone 8"
      case "iPhone10,2", "iPhone10,5":                return "iPhone 8 Plus"
      case "iPhone10,3", "iPhone10,6":                return "iPhone X"
      case "iPhone11,2":                              return "iPhone XS"
      case "iPhone11,4", "iPhone11,6":                return "iPhone XS Max"
      case "iPhone11,8":                              return "iPhone XR"
      case "iPhone12,1":                              return "iPhone 11"
      case "iPhone12,3":                              return "iPhone 11 Pro"
      case "iPhone12,5":                              return "iPhone 11 Pro Max"
      case "iPad2,1", "iPad2,2", "iPad2,3", "iPad2,4":return "iPad 2"
      case "iPad3,1", "iPad3,2", "iPad3,3":           return "iPad 3"
      case "iPad3,4", "iPad3,5", "iPad3,6":           return "iPad 4"
      case "iPad4,1", "iPad4,2", "iPad4,3":           return "iPad Air"
      case "iPad5,3", "iPad5,4":                      return "iPad Air 2"
      case "iPad6,11", "iPad6,12":                    return "iPad 5"
      case "iPad7,5", "iPad7,6":                      return "iPad 6"
      case "iPad11,4", "iPad11,5":                    return "iPad Air (3rd generation)"
      case "iPad2,5", "iPad2,6", "iPad2,7":           return "iPad Mini"
      case "iPad4,4", "iPad4,5", "iPad4,6":           return "iPad Mini 2"
      case "iPad4,7", "iPad4,8", "iPad4,9":           return "iPad Mini 3"
      case "iPad5,1", "iPad5,2":                      return "iPad Mini 4"
      case "iPad11,1", "iPad11,2":                    return "iPad Mini 5"
      case "iPad6,3", "iPad6,4":                      return "iPad Pro (9.7-inch)"
      case "iPad6,7", "iPad6,8":                      return "iPad Pro (12.9-inch)"
      case "iPad7,1", "iPad7,2":                      return "iPad Pro (12.9-inch) (2nd generation)"
      case "iPad7,3", "iPad7,4":                      return "iPad Pro (10.5-inch)"
      case "iPad8,1", "iPad8,2", "iPad8,3", "iPad8,4":return "iPad Pro (11-inch)"
      case "iPad8,5", "iPad8,6", "iPad8,7", "iPad8,8":return "iPad Pro (12.9-inch) (3rd generation)"
      case "AppleTV5,3":                              return "Apple TV"
      case "AppleTV6,2":                              return "Apple TV 4K"
      case "AudioAccessory1,1":                       return "HomePod"
      case "i386", "x86_64":                          return "Simulator \(mapToDevice(identifier: ProcessInfo().environment["SIMULATOR_MODEL_IDENTIFIER"] ?? "iOS"))"
      default:                                        return identifier
      }
      #elseif os(tvOS)
      switch identifier {
      case "AppleTV5,3": return "Apple TV 4"
      case "AppleTV6,2": return "Apple TV 4K"
      case "i386", "x86_64": return "Simulator \(mapToDevice(identifier: ProcessInfo().environment["SIMULATOR_MODEL_IDENTIFIER"] ?? "tvOS"))"
      default: return identifier
      }
      #endif
    }
    
    return mapToDevice(identifier: identifier)
  }()
}

extension UIDevice {
  
  public var cpuName: String {
    return Array(CPUinfo().keys)[0]
  }
  
  public var cpuSpeed: String {
    return Array(CPUinfo().values)[0]
  }
  
  private func CPUinfo() -> Dictionary<String, String> {
    
    #if (arch(i386) || arch(x86_64)) && os(iOS)
    let identifier = ProcessInfo().environment["SIMULATOR_MODEL_IDENTIFIER"]!
    #else
    
    var systemInfo = utsname()
    uname(&systemInfo)
    let machineMirror = Mirror(reflecting: systemInfo.machine)
    let identifier = machineMirror.children.reduce("") { identifier, element in
      guard let value = element.value as? Int8 , value != 0 else { return identifier }
      return identifier + String(UnicodeScalar(UInt8(value)))
    }
    #endif
    
    switch identifier {
    case "iPod5,1":                                 return ["A5":"800 MHz"] // underclocked
    case "iPod7,1":                                 return ["A8":"1.4 GHz"]
    case "iPhone3,1", "iPhone3,2", "iPhone3,3":     return ["A4":"800 MHz"] // underclocked
    case "iPhone4,1":                               return ["A5":"800 MHz"] // underclocked
    case "iPhone5,1", "iPhone5,2":                  return ["A6":"1.3 GHz"]
    case "iPhone5,3", "iPhone5,4":                  return ["A6":"1.3 GHz"]
    case "iPhone6,1", "iPhone6,2":                  return ["A7":"1.3 GHz"]
    case "iPhone7,2":                               return ["A8":"1.4 GHz"]
    case "iPhone7,1":                               return ["A8":"1.4 GHz"]
    case "iPhone8,1":                               return ["A9":"1.85 GHz"]
    case "iPhone8,2":                               return ["A9":"1.85 GHz"]
    case "iPhone9,1", "iPhone9,3":                  return ["A10 Fusion":"2.34 GHz"]
    case "iPhone9,2", "iPhone9,4":                  return ["A10 Fusion":"2.34 GHz"]
    case "iPhone8,4":                               return ["A9":"1.85 GHz"]
    case "iPhone10,1", "iPhone10,4":                return ["A11 Bionic": "2.39 GHz"]
    case "iPhone10,2", "iPhone10,5":                return ["A11 Bionic": "2.39 GHz"]
    case "iPhone10,3", "iPhone10,6":                return ["A11 Bionic": "2.39 GHz"]
    case "iPhone11,2":                              return ["A12 Bionic": "2.5 GHz"]
    case "iPhone11,4", "iPhone11,6":                return ["A12 Bionic": "2.5 GHz"]
    case "iPhone11,8":                              return ["A12 Bionic" : "2.5 Ghz"]
    case "iPhone12,1":                              return ["A13 Bionic" : "2.65 GHz "]
    case "iPhone12,3":                              return ["A13 Bionic" : "2.65 GHz "]
    case "iPhone12,5":                              return ["A13 Bionic" : "2.65 GHz "]
    case "iPad2,1", "iPad2,2", "iPad2,3", "iPad2,4":return ["A5":"1.0 GHz"]
    case "iPad3,1", "iPad3,2", "iPad3,3":           return ["A5X":"1.0 GHz"]
    case "iPad3,4", "iPad3,5", "iPad3,6":           return ["A6X":"1.4 GHz"]
    case "iPad4,1", "iPad4,2", "iPad4,3":           return ["A7":"1.4 GHz"]
    case "iPad5,3", "iPad5,4":                      return ["A8X":"1.5 GHz"]
    case "iPad6,11", "iPad6,12":                    return ["A9":"1.85 GHz"]
    case "iPad2,5", "iPad2,6", "iPad2,7":           return ["A5":"1.0 GHz"]
    case "iPad4,4", "iPad4,5", "iPad4,6":           return ["A7":"1.3 GHz"]
    case "iPad4,7", "iPad4,8", "iPad4,9":           return ["A7":"1.3 GHz"]
    case "iPad5,1", "iPad5,2":                      return ["A8":"1.5 GHz"]
    case "iPad6,3", "iPad6,4":                      return ["A9X":"2.16 GHz"] // underclocked
    case "iPad6,7", "iPad6,8":                      return ["A9X":"2.24 GHz"]
    case "iPad7,1", "iPad7,2":                      return ["A10X Fusion":"2.34 GHz"]
    case "iPad7,3", "iPad7,4":                      return ["A10X Fusion":"2.34 GHz"]
    case "AppleTV5,3":                              return ["A8":"1.4 GHz"]
    case "AppleTV6,2":                              return ["A10X Fusion":"2.34 GHz"]
    case "AudioAccessory1,1":                       return ["A8":"1.4 GHz"] // clock speed is a guess
    default:                                        return ["N/A":"N/A"]
    }
  }
}



extension UIDevice {
  func MBFormatter(_ bytes: Int64) -> String {
    let formatter = ByteCountFormatter()
    formatter.allowedUnits = ByteCountFormatter.Units.useMB
    formatter.countStyle = ByteCountFormatter.CountStyle.decimal
    formatter.includesUnit = false
    return formatter.string(fromByteCount: bytes) as String
  }
  
  var percentUsed: Int {
    let usedGB = usedDiskSpaceInGB.replacingOccurrences(of: " GB", with: "")
    let total = totalDiskSpaceInGB.replacingOccurrences(of: " GB", with: "")
    if let usedD = usedGB.double(), let totalD = total.double() {
      return Int((usedD/totalD) * 100)
    }
    return .zero
  }
  
  var usedPercent: String {
    let usedGB = usedDiskSpaceInGB.replacingOccurrences(of: " GB", with: "")
    let total = totalDiskSpaceInGB.replacingOccurrences(of: " GB", with: "")
    if let usedD = usedGB.double(), let totalD = total.double() {
      return "\(Int((usedD/totalD) * 100)) %"
    }
    return ""
  }
  
	
	var freeDiskSpace: String {
		return "\(100 - percentUsed) %"
	}
	
	
	
  var usedDiskSpaceInt: Int {
    if let usedGB = usedDiskSpaceInGB.replacingOccurrences(of: " GB", with: "").double() {
      let used = Int(usedGB)
      return used
    }
    return 0
  }
  
  var totalDiskSpaceInt: Int {
    if let total = totalDiskSpaceInGB.replacingOccurrences(of: " GB", with: "").double() {
      let used = Int(total)
      return used
    }
    return 0
  }
  
	var freeDiskSpaceInt: Int {
		if let total = freeDiskSpaceInGB.replacingOccurrences(of: " GB", with: "").double() {
			let used = Int(total)
			return used
		}
		return 0
	}
	
  
  //MARK: Get String Value
  var totalDiskSpaceInGB:String {
    return ByteCountFormatter.string(fromByteCount: totalDiskSpaceInBytes, countStyle: ByteCountFormatter.CountStyle.memory)
  }
  
  var freeDiskSpaceInGB:String {
    return ByteCountFormatter.string(fromByteCount: freeDiskSpaceInBytes, countStyle: ByteCountFormatter.CountStyle.decimal)
  }
  
  var usedDiskSpaceInGB:String {
    return ByteCountFormatter.string(fromByteCount: usedDiskSpaceInBytes, countStyle: ByteCountFormatter.CountStyle.decimal)
  }
  
  var totalDiskSpaceInMB:String {
    return MBFormatter(totalDiskSpaceInBytes)
  }
  
  var freeDiskSpaceInMB:String {
    return MBFormatter(freeDiskSpaceInBytes)
  }
  
  var usedDiskSpaceInMB:String {
    return MBFormatter(usedDiskSpaceInBytes)
  }
  
  //MARK: Get raw value
  var totalDiskSpaceInBytes:Int64 {
    guard let systemAttributes = try? FileManager.default.attributesOfFileSystem(forPath: NSHomeDirectory() as String),
      let space = (systemAttributes[FileAttributeKey.systemSize] as? NSNumber)?.int64Value else { return 0 }
    return space
  }
  
	var freeDiskSpaceInBytes:Int64 {
		if let space = try? URL(fileURLWithPath: NSHomeDirectory() as String).resourceValues(forKeys: [URLResourceKey.volumeAvailableCapacityForImportantUsageKey]).volumeAvailableCapacityForImportantUsage {
			return space
		} else {
			return 0
		}
	}
	
  var usedDiskSpaceInBytes:Int64 {
    return totalDiskSpaceInBytes - freeDiskSpaceInBytes
  }
  
	
	
  var iPhone: Bool {
    return UIDevice().userInterfaceIdiom == .phone
  }
}

extension Int {
	var string: String {
		return "\(self)"
	}
}
