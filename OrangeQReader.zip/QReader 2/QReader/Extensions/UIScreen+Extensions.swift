//
//  UIScreen+Extensions.swift
//  PurchasesTutorial
//
//  Created by Marcel on 2/7/19.
//  Copyright © 2019 Marcel. All rights reserved.
//

import Foundation
import UIKit

extension UIScreen {
  
  static var height: CGFloat {
    return UIScreen.main.bounds.height
  }
  
  static var width: CGFloat {
    return UIScreen.main.bounds.width
  }
  
  static var iPhones_5_5s_5c_SE: CGSize {
    return CGSize(width: 320, height: 568)
  }
  
  static var iPhones_6_6s_7_8: CGSize {
    return CGSize(width: 375, height: 667)
  }
  
  static var iPhones_6Plus_6sPlus_7Plus_8Plus: CGSize {
    return CGSize(width: 414, height: 736)
  }
  
  static var iPhoneX_XS: CGSize {
    return CGSize(width: 375, height: 812)
  }
  
  static var iPhoneXSMax_XR: CGSize {
    return CGSize(width: 414, height: 896)
  }
  
  static var isiPhone6_7_8: Bool {
    return UIScreen.height == 667
  }
  
  static var isiPhone6_7_8Plus: Bool {
    return UIScreen.height == 736
  }
  
  static var isiPhone5_5S: Bool {
    return UIScreen.height == 568
  }
  
  static var isiPhoneXSMax: Bool {
    return UIScreen.height == 896
  }
  
  static var isiPhoneX_XS: Bool {
    return UIScreen.height == 812
  }

}

extension UIView {
  func addSubviews(_ views: UIView...) {
      views.forEach { self.addSubview($0) }
  }
}
