//
//  UIStoryboard+Extensions.swift
//  PurchasesTutorial
//
//  Created by Marcel Spinu on 6/17/19.
//  Copyright © 2019 Marcel. All rights reserved.
//

import Foundation
import UIKit

extension UIStoryboard {
  func vc(_ identifier: String) -> UIViewController {
    return instantiateViewController(withIdentifier: identifier)
  }
  
  func nc(_ identifier: String) -> UINavigationController? {
    return instantiateViewController(withIdentifier: identifier) as? UINavigationController
  }
  func instantiate<Controller: UIViewController>(_ type: Controller.Type) -> Controller{
    guard let controller = self.instantiateViewController(withIdentifier: type.nibIdentifier) as? Controller else { fatalError("Controller with couldnt be instantiated: wrong storyboard id.") }
    return controller
  }
}
