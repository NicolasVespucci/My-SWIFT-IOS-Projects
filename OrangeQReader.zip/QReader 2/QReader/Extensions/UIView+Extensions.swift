
import Foundation
import UIKit

extension UIView {
  
  func pulsateAnimation() {
    let pulseAnimation = CABasicAnimation(keyPath: "transform.scale")
    pulseAnimation.duration = 0.5
    pulseAnimation.fromValue = 1
    pulseAnimation.toValue = 1.11
    pulseAnimation.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
    pulseAnimation.autoreverses = true
    pulseAnimation.repeatCount = .greatestFiniteMagnitude
    layer.add(pulseAnimation, forKey: nil)
  }
  
  func addGradient(_ direction: CAGradientLayer.GradientPoint,_ colors: [UIColor], _ cornerRadius: CGFloat? = nil, _ customFrame: CGRect? = nil/*isAnimate: Bool, fromColors: [UIColor]? = nil, toColors: [UIColor]? = nil*/) {
    layer.sublayers?.first(where: { $0 is CAGradientLayer })?.removeFromSuperlayer()
    let gradientLayer = CAGradientLayer(frame: customFrame ?? bounds, gradient: direction, colors: colors)
    gradientLayer.cornerRadius = cornerRadius ?? 0
    
//    if isAnimate {
//      let animation = CABasicAnimation(keyPath: "colors")
//      animation.fromValue = fromColors
//      animation.toValue = toColors
//      animation.fillMode = .forwards
//      animation.timingFunction = CAMediaTimingFunction(name: .linear)
//      animation.duration = 3
//      animation.isRemovedOnCompletion = true
//      gradientLayer.add(animation, forKey: "colors")
//    }
    layer.insertSublayer(gradientLayer, at: 0)
    
    layoutIfNeeded()
  }
  
  func dropShadow(color: UIColor, opacity: Float = 0.5, offSet: CGSize, radius: CGFloat = 1, scale: Bool = true) {
    layer.masksToBounds = false
    layer.shadowColor = color.cgColor
    layer.shadowOpacity = opacity
    layer.shadowOffset = offSet
    layer.shadowRadius = radius
    
    layer.shadowPath = UIBezierPath(rect: self.bounds).cgPath
    layer.shouldRasterize = true
    layer.rasterizationScale = scale ? UIScreen.main.scale : 1
  }
  
    func addBorder(width: CGFloat, color: String, withAlphaComponent: CGFloat? = nil) {
    layer.borderWidth = width
    layer.borderColor = color.hexColor.withAlphaComponent(withAlphaComponent ?? 1.0).cgColor
    
  }
  
  func removeBorders() {
    layer.borderColor = nil
    layer.borderWidth = 0
  }
  
  func removeGradient() {
    layer.sublayers?.removeAll(where: { $0 is CAGradientLayer })
  }
  
  func shake() {
    DispatchQueue.main.async { [weak self] in
      let animation = CAKeyframeAnimation(keyPath: "transform.translation.y")
      animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
      animation.duration = 2
      animation.repeatCount = 3
      animation.values = [-5.0, 0.0, -5.0, 0.0, -5.0, 0.0, -5.0, 0.0 ]
      self?.layer.add(animation, forKey: "shake")
    }
  }
  
  //  func gradientColor(gradientLayer :CAGradientLayer) -> UIColor? {
  //  //We are creating UIImage to get gradient color.
  //        UIGraphicsBeginImageContext(gradientLayer.bounds.size)
  //        gradientLayer.render(in: UIGraphicsGetImageFromCurrentImageContext()!)
  //        let image = UIGraphicsGetImageFromCurrentImageContext()
  //        UIGraphicsEndImageContext()
  //        return UIColor(patternImage: image!)
  //  }
  //  func getGradientLayer(colors: UIColor...) -> CAGradientLayer{
  //      let gradient = CAGradientLayer()
  //      gradient.frame = bounds
  //      gradient.colors = [UIColor.red.cgColor, UIColor.blue.cgColor]
  //      gradient.startPoint = CGPoint(x: 0.0, y: 0.5)
  //      gradient.endPoint = CGPoint(x: 1.0, y: 0.5)
  //      return gradient
  //  }
  
  func animateGradientChange(newColors: [UIColor]) {
    
    if let gradientLayer = layer.sublayers?.first(where: { $0 is CAGradientLayer}) as? CAGradientLayer {
      let oldColors = gradientLayer.colors
          
      // Define the new colors for the gradient.
          
      // Set the new colors of the gradient.
      gradientLayer.colors = newColors
          
      // Initialize new animation for changing the colors of the gradient.
      let animation: CABasicAnimation = CABasicAnimation(keyPath: "colors")
          
      // Set current color value.
      animation.fromValue = oldColors
          
      // Set new color value.
      animation.toValue = newColors
         
      // Set duration of animation.
      animation.duration = 0.3
          
      // Set animation to remove once its completed.
      animation.isRemovedOnCompletion = true
          
      // Set receiver to remain visible in its final state when the animation is completed.
      animation.fillMode = .forwards
          
      // Set linear pacing, which causes an animation to occur evenly over its duration.
      animation.timingFunction = CAMediaTimingFunction(name: .linear)
          
      // Set delegate of animation.
//      animation.delegate = self
          
      // Add the animation.
      gradientLayer.add(animation, forKey: "animateGradientColorChange")
    }
    
  }
    
    func rotate() {
            let rotation : CABasicAnimation = CABasicAnimation(keyPath: "transform.rotation.z")
            rotation.toValue = NSNumber(value: Double.pi * 2)
        rotation.duration = 2.5
            rotation.isCumulative = true
            rotation.repeatCount = 0
            self.layer.add(rotation, forKey: "rotationAnimation")
        }
    
    func NoRotate() {
            let rotation : CABasicAnimation = CABasicAnimation(keyPath: "transform.rotation.z")
            rotation.toValue = NSNumber(value: Double.pi * 2)
            rotation.duration = 1
            rotation.isCumulative = false
            rotation.repeatCount = Float.greatestFiniteMagnitude
            self.layer.add(rotation, forKey: "rotationAnimation")
        }
}

