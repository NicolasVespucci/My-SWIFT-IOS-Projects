//
//  UIViewController+Extensions.swift
//  PurchasesTutorial
//
//  Created by Marcel on 4/2/19.
//  Copyright © 2019 Marcel. All rights reserved.
//

import Foundation
import UIKit
import SwiftMessages
import MessageUI

extension UIViewController {
  // MARK: Swizzle
//  @objc dynamic func _swizzled_viewDidAppear(_ animated: Bool) {
//    let pathLentgh = 3
//    if Constants.ud.purchasePath == nil { Constants.ud.purchasePath = "" }
//    let exceptionalClasses: [AnyClass?] = [
//      NSClassFromString("UINavigationController"),
//      NSClassFromString("UIAlertController"),
//      NSClassFromString("UIInputWindowController"),
//      NSClassFromString("UICompatibilityInputViewController"),
//      NSClassFromString("UISystemKeyboardDockController"),
//      NSClassFromString("UIApplicationRotationFollowingControllerNoTouches"),
//      NSClassFromString("MFMailComposeInternalViewController"),
//      NSClassFromString("MFMailComposeRemoteViewController"),
//      NSClassFromString("MFMailComposeViewController")
//      ].compactMap { $0 }
//    if self is WindowViewController { return }
//    if exceptionalClasses.contains(where: { $0 == self.classForCoder }) { return }
//    Constants.ud.purchasePath! += "->\(type(of: self))"
//    let screens = Constants.ud.purchasePath!.components(separatedBy: "->").suffix(pathLentgh)
//    
//    if screens.count == pathLentgh {
//      Constants.ud.purchasePath = ""
//      screens.forEach {
//        let arrow = Constants.ud.purchasePath!.isEmpty ? "" : "->"
//        Constants.ud.purchasePath!.append(arrow + $0)
//      }
//    }
//    
//    print("Path : \(String(describing: Constants.ud.purchasePath))")
//    _swizzled_viewDidAppear(animated)
//		
//		navigationItem.backBarButtonItem = UIBarButtonItem(title: " ", style: .plain, target: nil, action: nil)
//  }
}

//MARK:- Message composer
extension UIViewController: MFMessageComposeViewControllerDelegate {
	func canSendText() -> Bool {
		return MFMessageComposeViewController.canSendText()
	}
	
	func configureMessageController(_ recipient: String?) -> MFMessageComposeViewController {
		let messagesController = MFMessageComposeViewController()
		messagesController.messageComposeDelegate = self
		messagesController.recipients = [recipient ?? ""]
		messagesController.body = ""
		DispatchQueue.main.async {
			UIBarButtonItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.blue], for: .normal)
		}
		
		return messagesController
	}
	func pesentMessagesComposer(_ messagesController: MFMessageComposeViewController) {
		if canSendText() {
      present(messagesController, animated: true)
		} else {
			let alert = UIAlertController(title: "Sorry your phone is not supported to send messages.", message: nil, preferredStyle: .alert)
			let action = UIAlertAction(title: "OK", style: .default)
			alert.addAction(action)
			present(alert, animated: true)
		}
  }
	
	
	public func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
		DispatchQueue.main.async {
			UIBarButtonItem.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.clear], for: .normal)
		}
    switch (result) {
    case .cancelled:
      controller.dismiss(animated: true, completion: nil)
    case .sent:
      controller.dismiss(animated: true, completion: nil)
    case .failed:
      controller.dismiss(animated: true, completion: nil)
		default:
      controller.dismiss(animated: true, completion: nil)
    }
	}
}


// MARK: MAILCOMPOSER
extension UIViewController: MFMailComposeViewControllerDelegate {
  // MARK: MAIL COMPOSER
  func configuredMailComposeViewController(recipients : [String]?, subject :
    String, body : String, isHtml : Bool = false,
            images : [UIImage]?) -> MFMailComposeViewController {
    //UINavigationBar.appearance().isTranslucent = false
    //UINavigationBar.appearance().barTintColor = .black
    
    let customBody = "<br><br><br><p>Version - \(UIApplication.applicationVersion)<br> Build - \(UIApplication.applicationBuild)<br> Device - \(UIDevice.modelName)<br> iOS version - \(UIDevice.current.systemVersion)</p>"
    let mailComposerVC = MFMailComposeViewController()
    mailComposerVC.mailComposeDelegate = self
    mailComposerVC.setToRecipients(recipients)
    mailComposerVC.setSubject(subject)
    mailComposerVC.setMessageBody(customBody, isHTML: isHtml)
    
    for image in images ?? [] {
      if let imageData = image.jpegData(compressionQuality: 1.0) {
        mailComposerVC.addAttachmentData(imageData,
                                         mimeType: "image/jpg",
                                         fileName: "Image")
      }
    }
    return mailComposerVC
  }
  
  func presentMailComposeViewController(mailComposeViewController :
    MFMailComposeViewController) {
    if MFMailComposeViewController.canSendMail() {
      //mailComposeViewController.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor : UIColor.white]
      //mailComposeViewController.navigationBar.tintColor = .white
      present(mailComposeViewController, animated: true, completion:{ () in
        //UIApplication.shared.statusBarStyle = UIStatusBarStyle.lightContent
      })
    }
  }
  
  public func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
    switch (result) {
		case .cancelled, .saved, .sent, .failed:
      dismiss(animated: true, completion: nil)
    default:
      dismiss(animated: true, completion: nil)
    }
  }
  
  var version: String {
    let bundleVersionKey = "CFBundleShortVersionString"
    guard let version = Bundle.main.object(forInfoDictionaryKey: bundleVersionKey) else { return "" }
    return "Version \(version)"
  }
  
  var buildVersion: String {
    let buildVersionKey = "CFBundleVersion"
    guard let build = Bundle.main.object(forInfoDictionaryKey: buildVersionKey) else { return "" }
    return "Build \(build)"
  }
}


