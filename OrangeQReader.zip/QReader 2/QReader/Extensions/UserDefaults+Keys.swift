//
//  UserDefaults+Keys.swift
//  SmartPromo
//
//  Created by Marcel  on 1/31/18.
//  Copyright © 2018 Marcel . All rights reserved.
//

import Foundation

extension UserDefaults {
  enum Keys {
    static let isPurchased = "isPurchased"
    static let didLaunchingApp = "didLaunchingApp"
    static let trackingId = "trackingId"
    static let fbCampagneId = "fbCampagneId"
    static let campagneId = "campagneId"
    static let purchasePath = "purchasePath"
    static let purchasePathNotification = "purchasePathNotification"
    static let sessionFromTime = "sessionFromTime"
    static let dynamicProductsKey = "dynamicProductsKey"
    static let paramPref = "paramPref"
    static let sourceApp = "sourceApp"
    static let wasAF_SUB1 = "wasAF_SUB1"
    static let wasLaunchedBefore = "wasLaunchedBefore"
    static let wasFBDeeplink = "wasFBDeeplink"
    static let didAcceptPrivacy = "didAcceptPrivacy"
  }
  
  enum TestsKeys {
    static let notes_data = "notes_data"
    static let passwords_data = "passwords_data"
    static let albums_data = "albums_data"
    static let contacts_data = "contacts_data"
  }
  
}
