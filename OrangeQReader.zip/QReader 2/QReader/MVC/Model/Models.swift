//
//  Models.swift
//  QReader
//
//  Created by iMac 21 on 31/03/2022.
//

import Foundation

struct BookModel : Codable {
    var link : String?
    var title : String?
}

struct HistoryModel : Codable {
    var name : String?
    var code : String?
    var id : String?
}

struct MyCodeModel : Codable {
    var name : String?
    var code : String?
    var date: Date?
    var id: String?
}
