//
//  AfterScanController.swift
//  QReader
//
//  Created by iMac 21 on 31/03/2022.
//

import Foundation
import UIKit
import SnapKit
import RxSwift
import RxCocoa


class AfterScanController : UIViewController, UITextViewDelegate {
    
    var disposeBag = DisposeBag()
    public var testImage : UIImage = UIImage()
    public var qrtext = "";
    
    private var chipsImageView: UIImageView = {
        let imageView = UIImageView(image: "chips".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    var qrCodeView : UIImageView = {
       var imageview = UIImageView()
        imageview.contentMode = .scaleAspectFit
        return imageview
    }()
    
    var controllerLabel : UILabel = {
       var label = UILabel()
        label.text = "QR Code"
        label.font = .systemFont(ofSize: 28, weight: .semibold)
        label.textColor = "#404147".hexColor
        label.textAlignment = .center
        return label
    }()
    
    var shareButton : UIButton = {
       var button = UIButton()
        button.setTitle("Share QR Code", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .medium)
       return button
    }()
    
    var qrCodeTextView : UITextView = {
       var textView = UITextView()
        textView.backgroundColor = .white
        textView.addBorder(width: 2, color: "000000")
        textView.layer.cornerRadius = 20
        textView.clipsToBounds = true
        textView.isEditable = false
        textView.textColor = "#404147".hexColor
        textView.textContainerInset = UIEdgeInsets(top: 0, left: 30, bottom: 0, right: 0)
        textView.font = .systemFont(ofSize: 16, weight: .regular)
        return textView
    }()
    
    var qrCodeName : UITextView = {
       var textView = UITextView()
        textView.backgroundColor = .white
        textView.addBorder(width: 2, color: "000000")
        textView.layer.cornerRadius = 20
        textView.clipsToBounds = true
        textView.isEditable = true
        textView.textColor = "#404147".hexColor
        textView.textContainerInset = UIEdgeInsets(top: 0, left: 30, bottom: 0, right: 0)
        textView.font = .systemFont(ofSize: 16, weight: .regular)
        return textView
    }()
    
    var textLabel : UILabel = {
       var label = UILabel()
        label.text = "Link"
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.textColor = UIColor(red: 0.00, green: 0.00, blue: 0.00, alpha: 0.33)
        label.textAlignment = .center
        return label
    }()
    
    var nameQRLabel : UILabel = {
       var label = UILabel()
        label.text = "Name"
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.textColor = UIColor(red: 0.00, green: 0.00, blue: 0.00, alpha: 0.33)
        label.textAlignment = .center
        return label
    }()
    
    var doneButton : UIButton = {
       var button = UIButton()
        button.setTitle("Done", for: .normal)
        button.setTitleColor("#404147".hexColor, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .medium)
       return button
    }()
    
    
    var addToBookmarks : UIButton = {
       var button = UIButton()
        button.setImage("addStar".image, for: .normal)
        button.contentMode = .scaleAspectFit
       return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = "#F7F8FC".hexColor
        
        qrCodeView.image = testImage
        qrCodeTextView.text = qrtext
        qrCodeName.text = qrtext
        view.addSubview(controllerLabel)
        controllerLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(45.resized())
            make.centerX.equalToSuperview()
            make.width.equalTo(120)
            make.height.equalTo(32.resized())
        }
        
        view.addSubview(chipsImageView)
        chipsImageView.addSubview(qrCodeView)
        chipsImageView.snp.makeConstraints { make in
            make.top.equalTo(controllerLabel.snp.bottom).offset(75.resized())
            make.centerX.equalToSuperview()
            make.size.equalTo(245)
        }
        
        qrCodeView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview()
            make.size.equalTo(160.resized())
        }
        
        view.addSubview(shareButton)
        shareButton.snp.makeConstraints { make in
            make.trailing.equalToSuperview().offset(-40)
            make.leading.equalToSuperview().offset(40)
            make.height.equalTo(50)
            make.bottom.equalToSuperview().offset(-70.resized())
        }

        view.addSubview(qrCodeTextView)
        
        qrCodeTextView.snp.makeConstraints { make in
            make.trailing.equalToSuperview().offset(-40.resized(.width))
            make.leading.equalToSuperview().offset(40.resized(.width))
            make.height.equalTo(58.resized())
            make.top.equalTo(chipsImageView.snp.bottom).offset(33.resized())
        }
        
        view.addSubview(qrCodeName)
        qrCodeName.snp.makeConstraints { make in
            make.trailing.equalToSuperview().offset(-40.resized(.width))
            make.leading.equalToSuperview().offset(40.resized(.width))
            make.height.equalTo(58.resized())
            make.top.equalTo(qrCodeTextView.snp.bottom).offset(15.resized())
        }
        
        view.addSubview(textLabel)
        textLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(qrCodeTextView.snp.top).offset(-25.resized())
        }
        
        
        view.addSubview(nameQRLabel)
        nameQRLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(qrCodeName.snp.bottom).offset(25.resized())
        }
        
        view.addSubview(doneButton)
        doneButton.snp.makeConstraints { make in
            make.trailing.equalToSuperview().offset(-20)
            make.top.equalToSuperview().offset(45.resized())
            make.height.equalTo(39)
        }
        view.addSubview(addToBookmarks)
        
        addToBookmarks.snp.makeConstraints { make in
            make.top.equalTo(nameQRLabel.snp.bottom).offset(12)
            make.centerX.equalToSuperview()
            make.width.equalTo(200)
            make.height.equalTo(60.resized())
        }
        setupButtons()
        qrCodeName.delegate = self
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        qrCodeTextView.addGestureRecognizer(gestRect)
        
        view.layoutIfNeeded()
        
        shareButton.addGradient(.topBottom, ["FFB648".hexColor, "F29337".hexColor], 20)
    }
    
    @objc func keyboardWillShow(notification: Notification) {
        
        let keyboardHeight = (notification.userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.height;
        UIView.animate(withDuration: 0.5, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
            self.qrCodeView.snp.updateConstraints { make in
                make.size.equalTo(0)
            }
            self.view.layoutIfNeeded()
               },completion: {_ in
                   
               })
           
        }
    
    @objc func keyboardWillHide(notification: Notification) {
       

        UIView.animate(withDuration: 0.5, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
            self.qrCodeView.snp.updateConstraints { make in
                make.size.equalTo(160.resized())
            }
            self.view.layoutIfNeeded()
               },completion: {_ in
                   
               })
        }
    
   func doneButtonAction() {
       if let data = UserDefaults.standard.data(forKey: "History") {
           do {
               // Create JSON Decoder
               let decoder = JSONDecoder()
               // Decode Note
               var history = try decoder.decode([HistoryModel].self, from: data)
               var flag = 0
               let uuid = UUID().uuidString
              // history.filter( [)
               
               if Constants.ud.dublicateScansValue == false {
                   if history.filter({($0.name == qrCodeName.text)}).count == 0 {
                       history.append(HistoryModel(name: qrCodeName.text, code: qrCodeTextView.text, id: uuid))
                   } else {
                       print("QQQQQQ")
                   }
               } else {
                   history.append(HistoryModel(name: qrCodeName.text, code: qrCodeTextView.text, id: uuid))
               }
               
               do {
                                 let encoder = JSONEncoder()
                                 let data = try encoder.encode(history)
                                 UserDefaults.standard.set(data, forKey: "History")
              
                             } catch {
                                 print("Unable to Encode Array of Notes (\(error))")
                             }
           } catch {
               print("Unable to Decode Notes (\(error))")
           }
       } else {
           let uuid = UUID().uuidString
           var tempArr = [HistoryModel(name: qrCodeName.text, code: qrCodeTextView.text, id: uuid)]
           do {
                             let encoder = JSONEncoder()
                             let data = try encoder.encode(tempArr)
                             UserDefaults.standard.set(data, forKey: "History")
          
                         } catch {
                             print("Unable to Encode Array of Notes (\(error))")
                         }
        }
    }
    
    func bookmarksButtonAction() {
        
        if let data = UserDefaults.standard.data(forKey: "Bookmarks") {
            do {
                // Create JSON Decoder
                let decoder = JSONDecoder()

                // Decode Note
                var history = try decoder.decode([HistoryModel].self, from: data)
                var flag = 0
                let uuid = UUID().uuidString
                history.append(HistoryModel(name: qrCodeName.text, code: qrCodeTextView.text, id: uuid))
             
                
                do {
                                  let encoder = JSONEncoder()
                                  let data = try encoder.encode(history)
                                  UserDefaults.standard.set(data, forKey: "Bookmarks")
               
                              } catch {
                                  print("Unable to Encode Array of Notes (\(error))")
                              }
              
            } catch {
                print("Unable to Decode Notes (\(error))")
            }
        } else {
            let uuid = UUID().uuidString
            var tempArr = [HistoryModel(name: qrCodeName.text, code: qrCodeTextView.text, id: uuid)]
            do {
                              let encoder = JSONEncoder()
                              let data = try encoder.encode(tempArr)
                              UserDefaults.standard.set(data, forKey: "Bookmarks")
           
                          } catch {
                              print("Unable to Encode Array of Notes (\(error))")
                          }
         }
     }
    
    lazy var gestRect:
        UITapGestureRecognizer = {
            let gestureRecognizer = UITapGestureRecognizer()
            gestureRecognizer
                .addTarget(self, action: #selector(handleOneTap))

            return gestureRecognizer
    }()
    
    @objc func handleOneTap(sender: UITapGestureRecognizer) {
        if(qrCodeTextView.text.isURL()){
            guard let url = URL(string: qrCodeTextView.text!) else { return }
            UIApplication.shared.open(url)
        } else {
            let pasteboard = UIPasteboard.general
            pasteboard.string = qrCodeTextView.text
            
            qrCodeTextView.text = "Coppied to clipboard";
            qrCodeTextView.textColor = "21D40B".hexColor
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                self.qrCodeTextView.text = self.qrtext
                self.qrCodeTextView.textColor = "#404147".hexColor
            }
        }
    }
    
    func setupButtons(){
        doneButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            if Constants.ud.historyValue == true {
                self.doneButtonAction()
            }
            self.dismiss(animated: true, completion: nil)
        }.disposed(by: disposeBag)
        
        addToBookmarks.rx.tap.bind {
            self.bookmarksButtonAction()
            self.addToBookmarks.isHidden = true
        }.disposed(by: disposeBag)
        
        shareButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.shareButtonActions()
        }.disposed(by: disposeBag)
    }
    
    override func viewDidLayoutSubviews() {
        qrCodeTextView.centerVertically()
        qrCodeName.centerVertically()
    }
    
    private func shareButtonActions() {
        if self.qrCodeView.image == self.testImage {
            let image = self.testImage
            let imageToShare = [ image ]
            let activityViewController = UIActivityViewController(activityItems: imageToShare, applicationActivities: nil)
            activityViewController.popoverPresentationController?.sourceView = self.view
            activityViewController.excludedActivityTypes = [ UIActivity.ActivityType.airDrop, UIActivity.ActivityType.postToFacebook ]
            self.present(activityViewController, animated: true, completion: nil)
        }
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        if text == "\n" {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
}


extension UITextView {
    func centerVertically() {
        let fittingSize = CGSize(width: bounds.width, height: CGFloat.greatestFiniteMagnitude)
        let size = sizeThatFits(fittingSize)
        let topOffset = (bounds.size.height - size.height * zoomScale) / 2
        let positiveTopOffset = max(1, topOffset)
        contentOffset.y = -positiveTopOffset
    }
}
