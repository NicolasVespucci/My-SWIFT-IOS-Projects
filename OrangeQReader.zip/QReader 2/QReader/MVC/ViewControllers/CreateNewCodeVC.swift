//
//  CreateNewCodeVC.swift
//  QReader
//
//  Created by iMac 21 on 31/03/2022.
//

import Foundation
import UIKit
import SnapKit
import RxSwift
import RxCocoa


class CreateNewCodeVC : UIViewController, UITextViewDelegate {
    
    var disposeBag = DisposeBag()
    var qrCodeView : UIImageView = {
       var imageview = UIImageView()
        imageview.contentMode = .scaleAspectFit
        return imageview
    }()
    
    var controllerLabel : UILabel = {
       var label = UILabel()
        label.text = "QR Code"
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.textColor = "#404147".hexColor
        label.textAlignment = .center
        return label
    }()
    
    var addCodeButton : UIButton = {
       var button = UIButton()
        button.setTitle(NSLocalizedString("ADD QRCODE", comment: ""), for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .medium)
        button.layer.cornerRadius = 31
       return button
    }()
    
    var shareLabel : UILabel = {
       var label = UILabel()
        label.text = "ADD QRCODE"
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.textColor = "#FFFFFF".hexColor
        label.textAlignment = .center
        return label
    }()
    
    var qrCodeTextView : UITextView = {
       var textView = UITextView()
        textView.backgroundColor = .white
        textView.addBorder(width: 2, color: "000000")
        textView.layer.cornerRadius = 20
        textView.clipsToBounds = true
        textView.isEditable = true
        textView.textColor = "#404147".hexColor
        textView.textContainerInset = UIEdgeInsets(top: 0, left: 30, bottom: 0, right: 0)
        textView.font = .systemFont(ofSize: 16, weight: .regular)
        return textView
    }()
    
    var qrCodeName : UITextView = {
       var textView = UITextView()
        textView.backgroundColor = .white
        textView.addBorder(width: 2, color: "000000")
        textView.layer.cornerRadius = 20
        textView.clipsToBounds = true
        textView.isEditable = true
        textView.textColor = "#404147".hexColor
        textView.textContainerInset = UIEdgeInsets(top: 0, left: 30, bottom: 0, right: 0)
        textView.font = .systemFont(ofSize: 16, weight: .regular)
        return textView
    }()
    
    var textLabel : UILabel = {
       var label = UILabel()
        label.text = "Link"
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.textColor = UIColor(red: 0.00, green: 0.00, blue: 0.00, alpha: 0.33)
        label.textAlignment = .center
        return label
    }()
    
    var nameQRLabel : UILabel = {
       var label = UILabel()
        label.text = "Name"
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.textColor = UIColor(red: 0.00, green: 0.00, blue: 0.00, alpha: 0.33)
        label.textAlignment = .center
        return label
    }()
    
    
    
    var closeButton: UIButton = {
        var button = UIButton()
         button.setImage("closeButton".image, for: .normal)
         button.contentMode = .scaleAspectFill
        return button
     }()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = "#F7F8FC".hexColor
        view.addSubview(controllerLabel)
        controllerLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(45.resized())
            make.centerX.equalToSuperview()
            make.width.equalTo(120)
            make.height.equalTo(32.resized())
        }
        
        view.addSubview(qrCodeView)
        qrCodeView.snp.makeConstraints { make in
            make.top.equalTo(controllerLabel.snp.bottom).offset(75.resized())
            make.centerX.equalToSuperview()
            make.size.equalTo(160.resized())
        }
        
        view.addSubview(addCodeButton)
        addCodeButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-100.resized())
            make.leading.equalToSuperview().offset(40)
            make.trailing.equalToSuperview().offset(-40)
            make.height.equalTo(50)
        }
        
        view.addSubview(qrCodeTextView)
        
        qrCodeTextView.snp.makeConstraints { make in
            make.trailing.equalToSuperview().offset(-40.resized(.width))
            make.leading.equalToSuperview().offset(40.resized(.width))
            make.height.equalTo(58.resized())
            make.top.equalTo(qrCodeView.snp.bottom).offset(67.resized())
        }
        
        
        view.addSubview(qrCodeName)
        qrCodeName.snp.makeConstraints { make in
            make.trailing.equalToSuperview().offset(-40.resized(.width))
            make.leading.equalToSuperview().offset(40.resized(.width))
            make.height.equalTo(58.resized())
            make.top.equalTo(qrCodeTextView.snp.bottom).offset(15.resized())
        }
        
        view.addSubview(textLabel)
        textLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(qrCodeTextView.snp.top).offset(-25.resized())
        }
        
        view.addSubview(nameQRLabel)
        nameQRLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(qrCodeName.snp.bottom).offset(25.resized())
        }
        
        view.addSubview(closeButton)
        
        closeButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(45.resized())
            make.leading.equalToSuperview().offset(20.resized(.width))
            make.size.equalTo(24)
        }
        
        qrCodeName.delegate = self
        qrCodeTextView.delegate = self
        setupButtons()
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        
        view.layoutIfNeeded()
        addCodeButton.addGradient(.topBottom, ["FFB648".hexColor, "F29337".hexColor], 20)
    }
    
    @objc func keyboardWillShow(notification: Notification) {
        
        let keyboardHeight = (notification.userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.height;
        UIView.animate(withDuration: 0.3, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
            self.qrCodeView.snp.updateConstraints { make in
                make.size.equalTo(0)
            }
            self.view.layoutIfNeeded()
               },completion: {_ in
                   
               })
           
        }
    
    @objc func keyboardWillHide(notification: Notification) {
       

        UIView.animate(withDuration: 0.3, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
            self.qrCodeView.snp.updateConstraints { make in
                make.size.equalTo(160.resized())
            }
            self.view.layoutIfNeeded()
               },completion: {_ in
                   
               })

    
        }
    
   func addCodeButtonAction() {
       if !((qrCodeName.text.trimmingCharacters(in: .whitespacesAndNewlines) == "") && (qrCodeTextView.text.trimmingCharacters(in: .whitespacesAndNewlines) == "")) {
           if let data = UserDefaults.standard.data(forKey: "MyCodes") {
               do {
                   // Create JSON Decoder
                   let decoder = JSONDecoder()

                   // Decode Note
                   var mycodes = try decoder.decode([MyCodeModel].self, from: data)
                   let uuid = UUID().uuidString
                   
                  
                   
                   mycodes.append(MyCodeModel(name: qrCodeName.text, code: qrCodeTextView.text, id: uuid))


                   do {
                                     let encoder = JSONEncoder()
                                     let data = try encoder.encode(mycodes)
                                     UserDefaults.standard.set(data, forKey: "MyCodes")

                                 } catch {
                                     print("Unable to Encode Array of Notes (\(error))")
                                 }

               } catch {
                   print("Unable to Decode Notes (\(error))")
               }
           } else {
               let uuid = UUID().uuidString
               var tempArr = [MyCodeModel(name: qrCodeName.text, code: qrCodeTextView.text, id: uuid)]
               do {
                                 let encoder = JSONEncoder()
                                 let data = try encoder.encode(tempArr)
                                 UserDefaults.standard.set(data, forKey: "MyCodes")

                             } catch {
                                 print("Unable to Encode Array of Notes (\(error))")
                             }
       }
           self.dismiss(animated: true, completion: nil)
       } else {
           AlertManager.shared().notText()
       }

      
    }
    
    func setupButtons(){
        addCodeButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.addCodeButtonAction()
            
        }.disposed(by: disposeBag)
        
        closeButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.dismiss(animated: true, completion: nil)
        }.disposed(by: disposeBag)
    }
    
    override func viewDidLayoutSubviews() {
        qrCodeTextView.centerVertically()
        qrCodeName.centerVertically()
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        if text == "\n" {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
}

