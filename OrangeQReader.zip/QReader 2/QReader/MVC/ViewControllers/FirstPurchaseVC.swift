//
//  FirstPurchaseVC.swift
//  QReader
//
//  Created by iMac 21 on 04/04/2022.
//

import UIKit
import RxCocoa
import RxSwift
import SnapKit
import NetworkExtension
import Network
import SwiftyAttributes
import Reachability
import StoreKit
import SwiftyStoreKit

class FirstPurchaseVC: UIViewController {
    
    private var topImage: UIImageView = {
        let imageView = UIImageView()
        imageView.image = "ic_welcome_3".image
        
        return imageView
    }()
    
    
    var productsDescription: NSAttributedString {
        let terms = NSLocalizedString("Terms", comment: "") + " " + NSLocalizedString("of", comment: "") + " " + NSLocalizedString("Use", comment: "")
        let privacy = NSLocalizedString("Privacy", comment: "") + " " + NSLocalizedString("Policy", comment: "")
        let and = " and "
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        
        let textAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12)),
            .textColor("#7B7C80".hexColor),
            .paragraphStyle(paragraphStyle)
        ]
        
        let andAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12)),
            .textColor("#B8BABF".hexColor),
            .paragraphStyle(paragraphStyle)
        ]
        
        let attributedDescription =
        terms.withAttributes(textAttributes)
        + and.withAttributes(andAttributes)
        + privacy.withAttributes(textAttributes)
        return attributedDescription
    }
    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.layoutIfNeeded()
        textView.isEditable = false
        textView.isSelectable = false
        textView.isScrollEnabled = true
        textView.backgroundColor = .clear
        textView.showsVerticalScrollIndicator = true
        textView.attributedText = productsDescription
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapResponse(recognizer:)))
        textView.addGestureRecognizer(tap)
        return textView
    }()
    
    private var upgdateLabel: UILabel = {
        let label = UILabel()
        label.text = "Enjoy full version app \n without ads"
        label.textColor = "#74757A".hexColor
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.numberOfLines = 2
        label.textAlignment = .center
        return label
    }()
    
    private lazy var payCollectionView: UICollectionView = {
        let collection = UICollectionView(frame: .zero, collectionViewLayout: .init())
        collection.backgroundColor = .clear
        collection.showsHorizontalScrollIndicator = false
        collection.showsVerticalScrollIndicator = false
        collection.isScrollEnabled = true
        return collection
    }()
    
    
    
    
    private var upgradeButton: UIButton = {
        let button = UIButton()
        button.setImage("upgrade".image, for: .normal)
        button.contentMode = .scaleAspectFit
        return button
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("back".image, for: .normal)
        button.contentMode = .scaleAspectFit
        return button
    }()
    
    private var resetButton: UIButton = {
        let button = UIButton()
        button.setTitle("Reset", for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.backgroundColor = .red
        button.layer.cornerRadius = 20
        return button
    }()
    
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
       setup()
        self.navigationController?.navigationBar.isHidden = true
    }

    private func setup(){
        configureLayout()
        setupButton()
        configureCollection()
    }
    
    
    private func configureCollection() {
      
    }
    
    private func configureLayout() {
        view.backgroundColor = "#F7F8FC".hexColor
        view.addSubview(topImage)
        
        topImage.snp.makeConstraints { make in
            make.trailing.equalToSuperview()
            make.leading.equalToSuperview()
            make.top.equalToSuperview()
            make.height.equalTo(382.resized())
        }
        
        view.addSubview(upgradeButton)
        
        upgradeButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-50.resized())
            make.width.equalTo(296)
            make.height.equalTo(90)
            make.centerX.equalToSuperview()
        }
        
        view.addSubview(textView)
        
        textView.snp.makeConstraints { make in
            make.top.equalTo(upgradeButton.snp.bottom).offset(0)
            make.width.equalTo(UIScreen.main.bounds.width)
            make.height.equalTo(30.resized())
            make.centerX.equalToSuperview()
        }
        
        view.addSubview(upgdateLabel)
        
        upgdateLabel.snp.makeConstraints { make in
            make.bottom.equalTo(upgradeButton.snp.top).offset(10.resized())
            make.centerX.equalToSuperview()
            make.height.equalTo(60.resized())
            make.width.equalTo(180)
        }
        
        view.addSubview(backButton)
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(52)
            make.leading.equalToSuperview().offset(20)
            make.size.equalTo(20)
        }
    }

    private func setupButton() {
        upgradeButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
         //   self.generateYourQRcodeButtonActions()
        }.disposed(by: disposeBag)
        
        backButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            print("kek")
            self.dismiss(animated: true)
        }.disposed(by: disposeBag)
        
    }
    
   

}


extension FirstPurchaseVC {
    @objc func tapResponse(recognizer: UITapGestureRecognizer) {
        let location: CGPoint = recognizer.location(in: textView)
        let position: CGPoint = CGPoint(x: location.x, y: location.y)
        let tapPosition: UITextPosition? = textView.closestPosition(to: position)
        if tapPosition != nil {
            let textRange: UITextRange? = textView.tokenizer.rangeEnclosingPosition(tapPosition!, with: UITextGranularity.word, inDirection: UITextDirection(rawValue: 1))
            if textRange != nil
            {
                let tappedWord: String? = textView.text(in: textRange!)
                guard let word = tappedWord else { return }
                wordAction(word)
            }
        }
    }
    
    private func wordAction(_ word: String) {
        switch word {
        case NSLocalizedString("Terms", comment: ""), NSLocalizedString("of", comment: ""), NSLocalizedString("Use", comment: ""): pushPoliciesVC(.terms)
            
        case NSLocalizedString("Privacy", comment: ""), NSLocalizedString("Policy", comment: ""): pushPoliciesVC(.privacy)
        default: break
        }
    }
    
    func pushPoliciesVC(_ policiesType: Policies) {
        let termsVC = PoliciesVC()
        termsVC.policiesType = policiesType
        navigationController?.pushViewController(termsVC, animated: true)
    }
}
