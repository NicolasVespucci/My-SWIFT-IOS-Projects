import UIKit
import RxSwift
import SwiftyStoreKit
import SwiftyAttributes
import IHProgressHUD

class FirstSubscriptionsViewController: UIViewController {

    var identifiers = Constants.analytics.threeMonth

    private var topImageView: UIImageView = {
        let imageView = UIImageView(image: "pay2Top".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()

    private var topBackButton: UIButton = {
        let button = UIButton()
        button.setImage("topBack".image, for: .normal)
        return button
    }()
    
    private var restoreButton: UIButton = {
        let button = UIButton()
        button.setImage("restoreMain".image, for: .normal)
        return button
    }()

    private var emptyView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()

    public var pricePeriodLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.numberOfLines = 0
        return label
    }()

    private var buyButton: UIButton = {
        let button = UIButton()
        button.setTitle(NSLocalizedString("BUY", comment: ""), for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .medium)
        button.layer.cornerRadius = 31
        return button
    }()

    var productsDescription: NSAttributedString {
        let terms = NSLocalizedString("Terms", comment: "") + " " + NSLocalizedString("of", comment: "") + " " + NSLocalizedString("Use", comment: "")
        let privacy = NSLocalizedString("Privacy", comment: "") + NSLocalizedString(" ", comment: "") + NSLocalizedString("Policy", comment: "")
        let and = " & "

        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center

        let textAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12, weight: .medium)),
            .textColor("414860".hexColor.withAlphaComponent(0.7)),
            .paragraphStyle(paragraphStyle)
        ]

        let andAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12, weight: .medium)),
            .textColor("414860".hexColor.withAlphaComponent(0.4)),
            .paragraphStyle(paragraphStyle)
        ]

        let attributedDescription =
        terms.withAttributes(textAttributes)
        + and.withAttributes(andAttributes)
        + privacy.withAttributes(textAttributes)
        return attributedDescription
    }

    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.layoutIfNeeded()
        textView.isEditable = false
        textView.isSelectable = false
        textView.isScrollEnabled = false
        textView.backgroundColor = .clear
        textView.showsVerticalScrollIndicator = true
        textView.attributedText = productsDescription
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapResponse(recognizer:)))
        textView.addGestureRecognizer(tap)
        return textView
    }()

    var window: UIWindow?
    
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
    }
    
    private func setup(){
        configureLayout()
        setupButtons()
        configureTrialLabel()
    }

    private func configureLayout(){
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = "F7F8FC".hexColor
        view.addSubviews(topImageView, topBackButton, restoreButton, emptyView, buyButton, textView)
        emptyView.addSubviews(pricePeriodLabel)

        topImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(30)
            make.centerX.equalToSuperview()
            make.size.equalTo(320)
        }

        topBackButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(52.resized())
            make.leading.equalToSuperview().offset(17)
            make.size.equalTo(35)
        }
        
        restoreButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(50.resized())
            make.trailing.equalToSuperview().offset(-21)
            make.size.equalTo(22)
        }

        emptyView.snp.makeConstraints { make in
            make.top.equalTo(topImageView.snp.bottom).offset(10)
            make.bottom.equalTo(buyButton.snp.top).offset(-10)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
        }

        pricePeriodLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.height.equalTo(96)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
        }

        buyButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-65.resized())
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(50)
        }

        textView.snp.makeConstraints { make in
            make.top.equalTo(buyButton.snp.bottom).offset(14.resized())
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(30)
        }

        view.layoutIfNeeded()
        buyButton.addGradient(.topBottom, ["FFB648".hexColor, "F29337".hexColor], 20)
    }

    private func setupButtons(){
        topBackButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            if Constants.ud.currentDismis == 1 {
                self.topBackButtonAction()
            } else {
                IAPManager.shared().dismissSubscriptionVC()
            }
        }.disposed(by: disposeBag)
        
        restoreButton.rx.tap.bind {
            IAPManager.shared().restore()
        }.disposed(by: disposeBag)

        buyButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            let product = self.identifiers
            IAPManager.shared().purchase(rcPackage: product, quantity: 1, atomically: true)
        }.disposed(by: disposeBag)
    }

    private func topBackButtonAction() {
        window = UIWindow()
        window?.makeKeyAndVisible()
        let mainVC = SettingsVC()
        let navController = UINavigationController()
        navController.pushViewController(mainVC, animated: false)
        window?.rootViewController = navController
    }

    private func configureTrialLabel() {
        IHProgressHUD.show()
        SwiftyStoreKit.retrieveProductsInfo([Constants.analytics.threeMonth]) { result in
            if(!result.retrievedProducts.isEmpty) {
                let testProduct = Product(product: result.retrievedProducts.first!)
                guard let period = testProduct.period else { return }
                let periodString = period.formattedString // MONTHLY
                let perPeriodString = period.perFormattedString // MONTH
                let price = testProduct.localizedPrice
                let introductoryPeriod = testProduct.introductory?.period?.formattedString ?? ""

                if introductoryPeriod == "" {
                    self.pricePeriodLabel.text = price + NSLocalizedString(" per ", comment: "") + perPeriodString

                    IHProgressHUD.dismiss()
                } else {
                    let paragraphStyle = NSMutableParagraphStyle()
                    paragraphStyle.alignment = .center
                    let attributedTitle = (NSLocalizedString("Enjoy your ", comment: "")
                                            .withAttributes([.textColor("404147".hexColor),
                                            .font(.systemFont(ofSize: 20, weight: .medium))])
                                           + introductoryPeriod
                                            .withAttributes([.textColor("404147".hexColor),
                                            .font(.systemFont(ofSize: 20, weight: .medium))])
                                           + NSLocalizedString("\n free trial,\nthen ", comment: "")
                                            .withAttributes([.textColor("404147".hexColor),
                                            .font(.systemFont(ofSize: 20, weight: .medium))])
                                           +  price
                                            .withAttributes([.textColor("5075FF".hexColor),
                                            .font(.systemFont(ofSize: 20, weight: .medium))])
                                           + NSLocalizedString(" per \n", comment: "")
                                            .withAttributes([.textColor("5075FF".hexColor),
                                            .font(.systemFont(ofSize: 20, weight: .medium))])
                                           + perPeriodString
                                            .withAttributes([.textColor("5075FF".hexColor),
                                            .font(.systemFont(ofSize: 20, weight: .semibold))])).withAttribute(.paragraphStyle(paragraphStyle))
                    self.pricePeriodLabel.attributedText = attributedTitle
                    IHProgressHUD.dismiss()
                }
            }
        }
    }
    
    deinit {
        IHProgressHUD.dismiss()
    }
    
   
}

//MARK: - Text View
extension FirstSubscriptionsViewController {
    @objc func tapResponse(recognizer: UITapGestureRecognizer) {
        let location: CGPoint = recognizer.location(in: textView)
        let position: CGPoint = CGPoint(x: location.x, y: location.y)
        let tapPosition: UITextPosition? = textView.closestPosition(to: position)
        if tapPosition != nil {
            let textRange: UITextRange? = textView.tokenizer.rangeEnclosingPosition(tapPosition!, with: UITextGranularity.word, inDirection: UITextDirection(rawValue: 1))
            if textRange != nil
            {
                let tappedWord: String? = textView.text(in: textRange!)
                guard let word = tappedWord else { return }
                wordAction(word)
            }
        }
    }

    private func wordAction(_ word: String) {
        switch word {
        case NSLocalizedString("Terms", comment: ""), NSLocalizedString("of", comment: ""), NSLocalizedString("Use", comment: ""): pushPoliciesVC(.terms)

        case NSLocalizedString("Privacy", comment: ""),NSLocalizedString(" ", comment: ""), NSLocalizedString("Policy", comment: ""): pushPoliciesVC(.privacy)
        default: break
        }
    }

    func pushPoliciesVC(_ policiesType: Policies) {
        let termsVC = PoliciesVC()
        termsVC.policiesType = policiesType
        navigationController?.pushViewController(termsVC, animated: true)
    }
}
