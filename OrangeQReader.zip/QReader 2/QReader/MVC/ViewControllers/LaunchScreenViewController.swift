import UIKit
import RxSwift
import SnapKit

class LaunchScreenViewController: UIViewController {
    
    private var fullimageView: UIImageView = {
        let imageView = UIImageView(image: "launchIcon".image)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }

    let disposeBag = DisposeBag()
    private func setup() {
        configureLayout()
        setHome()
    }
    
    private func configureLayout() {
        view.backgroundColor = .white
        view.addSubview(fullimageView)
        fullimageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.width.equalTo(212)
            make.height.equalTo(212)
            make.centerX.equalToSuperview()
        }
    }
    
    private func setHome() {
        
        if UserDefaults.standard.value(forKey: "showCurrentController") != nil {
            showCurrentController = UserDefaults.standard.value(forKey: "showCurrentController") as! Bool
        }
        
        let controller = showCurrentController ? QRScannerController() : PresentViewController()
        
        let navigationController = UINavigationController(rootViewController: controller)
        UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.rootViewController = navigationController
        UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.makeKeyAndVisible()
    }
}

