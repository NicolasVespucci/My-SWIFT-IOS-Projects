//
//  MyCodesVC.swift
//  QReader
//
//  Created by iMac 21 on 31/03/2022.
//

import Foundation
import UIKit
import RxSwift
import SnapKit
import RxCocoa
import RxSwift

class MyCodesVC: UIViewController {
    
    
  
    let disposeBag = DisposeBag()
    
    var myCodesArr: [MyCodeModel]?
  
    var tableView : UITableView = {
        let table = UITableView()
        table.rowHeight = 60
        table.backgroundColor = "#F7F8FC".hexColor
        table.showsVerticalScrollIndicator = false
        table.separatorStyle = .none
        return table
    }()
    
    var controllerLabel : UILabel = {
       var label = UILabel()
        label.text = "My Codes"
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.textColor = "404147".hexColor
        label.textAlignment = .center
        return label
    }()
    
    private lazy var mainButton: UIButton = {
        let button = UIButton()
        button.setImage("add+".image, for: .normal)
        button.contentMode = .scaleAspectFit
       return button
    }()
    
    var noCodesLabel : UILabel = {
       var label = UILabel()
        label.text = "No codes Found"
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.textColor = "#C8C8C8".hexColor
        label.textAlignment = .center
        return label
    }()
    
    
    var bottombar : BottomNavBar!
    

    
    func setupConstraints(){
        view.addSubview(bottombar)
        bottombar.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-25)
            make.centerX.equalToSuperview()
            make.width.equalTo(UIScreen.main.bounds.width - 124)
            make.height.equalTo(63)
        }

        view.addSubview(controllerLabel)
        controllerLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(45.resized())
            make.centerX.equalToSuperview()
            make.width.equalTo(160)
            make.height.equalTo(32)
        }
        view.addSubview(mainButton)
        
        mainButton.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(controllerLabel.snp.bottom).offset(15.resized())
            make.size.equalTo(46.resized())
        }
        
        view.addSubview(tableView)
        tableView.snp.makeConstraints { make in
            make.top.equalTo(mainButton.snp.bottom).offset(60.resized())
            make.bottom.equalTo(bottombar.snp.top)
            make.leading.equalToSuperview().offset(33)
            make.trailing.equalToSuperview().offset(-33)
        }
        
        view.addSubview(noCodesLabel)
        noCodesLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
            make.height.equalTo(32.resized())
            make.width.equalTo(270.resized(.width))
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = "#F7F8FC".hexColor
        bottombar = BottomNavBar(nav: self.navigationController!)
        self.navigationController?.navigationBar.isHidden = true
        
        if let data = UserDefaults.standard.data(forKey: "MyCodes") {
            do {
                // Create JSON Decoder
                let decoder = JSONDecoder()

                // Decode Note
                let historyTempArr = try decoder.decode([MyCodeModel].self, from: data)

                myCodesArr = historyTempArr

                tableView.reloadData()

                tableView.isHidden = false
                noCodesLabel.isHidden = true
            } catch {
                print("Unable to Decode Notes (\(error))")
            }
        } else {
            noCodesLabel.isHidden = false
            tableView.isHidden = true
        }
        setupConstraints()
       setupTableViews()
        setupButtons()
    }
    
    func setupTableViews(){
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(MyCodeCell.self, forCellReuseIdentifier: MyCodeCell.nibIdentifier)
    }
    
    func setupButtons(){
        mainButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            if self.myCodesArr?.count ?? 0 > 0 {
                if !IAPManager.shared().isPurchased {
                    Constants.ud.currentDismis = 2
                    IAPManager.shared().presentSingleSubscriptionVC()
                    IAPManager.shared().purchaseCompletion = { _ in
                        IAPManager.shared().dismissSubscriptionVC()
                        AlertManager.shared().showPurchaseComplite()
                    }
                    IAPManager.shared().restoreCompletion = { subscription in
                        IAPManager.shared().dismissSubscriptionVC()
                        if Constants.ud.isPurchased {
                            AlertManager.shared().showPurchasesWereRestored()
                        }
                    }
                } else {
                    let vc = CreateNewCodeVC()
                    vc.modalPresentationStyle = .fullScreen
                    self.present(vc, animated: true, completion: nil)
                }
            } else {
                let vc = CreateNewCodeVC()
                vc.modalPresentationStyle = .fullScreen
                self.present(vc, animated: true, completion: nil)
            }
        }.disposed(by: disposeBag)

//        bookmarksButton.rx.tap.bind { [weak self] in
//            guard let self = self else { return }
//
//        }.disposed(by: disposeBag)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if let data = UserDefaults.standard.data(forKey: "MyCodes") {
            do {
                // Create JSON Decoder
                let decoder = JSONDecoder()

                // Decode Note
                let historyTempArr = try decoder.decode([MyCodeModel].self, from: data)

                myCodesArr = historyTempArr

                tableView.reloadData()

                tableView.isHidden = false
                noCodesLabel.isHidden = true
            } catch {
                print("Unable to Decode Notes (\(error))")
            }
        } else {
            noCodesLabel.isHidden = false
            tableView.isHidden = true
        }
    }
}


extension MyCodesVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = PresentCodeVC()
        vc.qrtext = myCodesArr?[indexPath.row].code! ?? "";
        vc.qrname = myCodesArr?[indexPath.row].name! ?? "";
        vc.qrid = myCodesArr?[indexPath.row].id! ?? "";
        vc.modalPresentationStyle = .fullScreen
        
        self.present(vc, animated: true, completion: nil)
        
    }
    
}

extension MyCodesVC: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myCodesArr?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: MyCodeCell.nibIdentifier, for: indexPath) as! MyCodeCell
            cell.mycode = myCodesArr?[indexPath.row]
            cell.configureDefaultLayout()
            return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            self.myCodesArr?.remove(at: indexPath.row)
            self.tableView.deleteRows(at: [indexPath], with: .automatic)
            do {
                              let encoder = JSONEncoder()
                let data = try encoder.encode(self.myCodesArr)
                              UserDefaults.standard.set(data, forKey: "MyCodes")
                          } catch {
                              print("Unable to Encode Array of Notes (\(error))")
                          }
        }
    }
}


class MyCodeCell: UITableViewCell {
    
    private lazy var fullView: UIView = {
        let view = UIView()
        view.backgroundColor = "#F7F8FC".hexColor
     
       return view
    }()
    
    public lazy var myCodeName : UILabel = {
        let label = UILabel()
        label.textColor = "#404147".hexColor
        label.textAlignment = .left
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 1
        label.font = .systemFont(ofSize: 16, weight: .medium)
        return label
    }()
    
    
    private lazy var myCodeImage : UIImageView = {
       let imageView = UIImageView()
        
        imageView.image = "codeImage".image
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    public lazy var myCodeDate : UILabel = {
        let label = UILabel()
        label.textColor = "#B0B0B0".hexColor
        label.textAlignment = .left
        label.text = "today"
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 1
        label.font = .systemFont(ofSize: 12, weight: .regular)
        return label
    }()
    
    public lazy var polygonImage : UIImageView = {
       var imageView = UIImageView()
        imageView.image = "polygon".image
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()

    
    var mycode: MyCodeModel? {
        didSet {
            configureCell()
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
     
    
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func configureDefaultLayout() {
        contentView.addSubview(fullView)
        
        fullView.snp.makeConstraints { make in
            make.bottom.equalToSuperview()
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
        }
        
        fullView.addSubviews(myCodeImage,myCodeImage, myCodeDate)
        
        myCodeImage.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview()
            make.size.equalTo(47)
        }
        
        myCodeName.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(15.resized())
            make.leading.equalTo(myCodeImage.snp.trailing).offset(11)
        }
        
        fullView.addSubview(myCodeDate)
        myCodeDate.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-7.resized())
            make.leading.equalTo(myCodeImage.snp.trailing).offset(11)
        }
        
        fullView.addSubview(polygonImage)
        
        polygonImage.snp.makeConstraints { make in
            make.trailing.equalToSuperview()
            make.centerY.equalToSuperview()
            make.size.equalTo(12)
        }
    
    }
    
    
    
    private func configureCell() {
        guard let mycode = mycode else { return }
        
        
        myCodeName.text = mycode.name
        

    }
    
}
