import UIKit
import RxCocoa
import RxSwift
import SnapKit
import NetworkExtension
import Network
import SwiftyAttributes
import Reachability
import StoreKit
import SwiftyStoreKit

class PayOneVC: UIViewController {
    
    private lazy var topImageView: UIImageView = {
        let imageView = UIImageView(image: "paywall".image)
        imageView.contentMode = .scaleAspectFill
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    private lazy var backButton: UIButton = {
        let button = UIButton()
        button.setImage("close".image, for: .normal)
        return button
    }()
    
    private lazy var restoreButton: UIButton = {
        let button = UIButton()
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .regular)
        button.setTitle(NSLocalizedString("Restore", comment: ""), for: .normal)
        button.setTitleColor("A5A6AD".hexColor, for: .normal)
        return button
    }()
    
    private lazy var centerLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 28, weight: .semibold)
        label.text = NSLocalizedString("ADcrypt Premium", comment: "")
        label.textColor = "404147".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .center
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var shildImage: UIImageView = {
        let imageView = UIImageView(image: "ic_shield".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private lazy var adImage: UIImageView = {
        let imageView = UIImageView(image: "adS".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private lazy var listImage: UIImageView = {
        let imageView = UIImageView(image: "Swhitelist".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private lazy var shildLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.text = NSLocalizedString("Data usage protected", comment: "")
        label.textColor = "404147".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .left
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var adLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.text = NSLocalizedString("Ads free browsing", comment: "")
        label.textColor = "404147".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .left
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var listLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.text = NSLocalizedString("Whitelist websites", comment: "")
        label.textColor = "404147".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .left
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var trialLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.text = ""
        label.textColor = "404147".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .center
        label.numberOfLines = 2
        return label
    }()
    
    private lazy var subscribeButton: UIButton = {
        let button = UIButton()
        button.layer.cornerRadius = 12
        button.setTitle(NSLocalizedString("Subscribe", comment: ""), for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .semibold)
        button.titleLabel?.textColor = .white
        button.backgroundColor = "#4560E5".hexColor
        return button
    }()
    
    var productsDescription: NSAttributedString {
        let terms = NSLocalizedString("Terms", comment: "") + " " + NSLocalizedString("of", comment: "") + " " + NSLocalizedString("Use", comment: "")
        let privacy = NSLocalizedString("Privacy", comment: "") + " " + NSLocalizedString("Policy", comment: "")
        let and = " & "
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        
        let textAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12)),
            .textColor("#7B7C80".hexColor),
            .paragraphStyle(paragraphStyle)
        ]
        
        let andAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12)),
            .textColor("#B8BABF".hexColor),
            .paragraphStyle(paragraphStyle)
        ]
        
        let attributedDescription =
        terms.withAttributes(textAttributes)
        + and.withAttributes(andAttributes)
        + privacy.withAttributes(textAttributes)
        return attributedDescription
    }
    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.layoutIfNeeded()
        textView.isEditable = false
        textView.isSelectable = false
        textView.isScrollEnabled = true
        textView.backgroundColor = .clear
        textView.showsVerticalScrollIndicator = true
        textView.attributedText = productsDescription
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapResponse(recognizer:)))
        textView.addGestureRecognizer(tap)
        return textView
    }()
    
    public lazy var progressView = ProgressView(message: "", theme: .dark, isModal: true)
    
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
            if Constants.ud.isPurchased {
                AlertManager.shared().showPurchasesWereRestored()
                self.navigationController?.dismiss(animated: true)
            }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
//        (((presentingViewController as! UINavigationController).viewControllers[0] as! MainBarController).viewControllers![0] as! UINavigationController).viewControllers[0].viewWillAppear(true)
    }
    
    private func setup() {
        configureLayout()
        setupTrialLabel()
        setupButtons()
    }
    
    private func configureLayout(){
        view.backgroundColor = .white
        view.addSubviews(topImageView, backButton, restoreButton, centerLabel, shildImage, shildLabel, adImage, adLabel, listImage, listLabel, trialLabel, subscribeButton, textView)
        
        topImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(44.resized())
            make.centerX.equalToSuperview()
            make.width.equalTo(315.resized(.width))
            make.height.equalTo(276.resized(.height))
        }
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(50)
            make.leading.equalToSuperview().offset(32)
            make.size.equalTo(32)
        }
        
        restoreButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(24)
        }
        
        centerLabel.snp.makeConstraints { make in
            make.bottom.equalTo(shildLabel.snp.top).offset(-32.resized())
            make.leading.equalToSuperview().offset(102)
            make.trailing.equalToSuperview().offset(-101)
            make.height.equalTo(32.resized())
        }
        
        shildImage.snp.makeConstraints { make in
            make.top.equalTo(centerLabel.snp.bottom).offset(32.resized())
            make.leading.equalToSuperview().offset(32)
            make.size.equalTo(24.resized())
        }
        
        shildLabel.snp.makeConstraints { make in
            make.top.equalTo(centerLabel.snp.bottom).offset(32.resized())
            make.leading.equalTo(shildImage.snp.trailing).offset(16)
            make.height.equalTo(24.resized())
        }
        
        adImage.snp.makeConstraints { make in
            make.top.equalTo(shildImage.snp.bottom).offset(16.resized())
            make.leading.equalTo(shildImage.snp.leading)
            make.size.equalTo(24.resized())
        }
        
        adLabel.snp.makeConstraints { make in
            make.top.equalTo(shildLabel.snp.bottom).offset(16.resized())
            make.leading.equalTo(shildImage.snp.trailing).offset(16)
            make.height.equalTo(24.resized())
        }
        
        listImage.snp.makeConstraints { make in
            make.top.equalTo(adImage.snp.bottom).offset(16.resized())
            make.leading.equalTo(adImage.snp.leading)
            make.size.equalTo(24.resized())
        }
        
        listLabel.snp.makeConstraints { make in
            make.top.equalTo(adLabel.snp.bottom).offset(16.resized())
            make.leading.equalTo(shildImage.snp.trailing).offset(16)
            make.height.equalTo(24.resized())
        }
        
        trialLabel.snp.makeConstraints { make in
            make.top.equalTo(listLabel.snp.bottom).offset(22.resized())
            make.bottom.equalTo(subscribeButton.snp.top).offset(-22.resized())
            make.leading.equalToSuperview().offset(92)
            make.trailing.equalToSuperview().offset(-90)
            make.height.equalTo(48.resized())
        }
        
        subscribeButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-72.resized())
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(56)
        }
        
        textView.snp.makeConstraints { make in
            make.top.equalTo(subscribeButton.snp.bottom).offset(12.resized())
            make.width.equalTo(UIScreen.main.bounds.width)
            make.height.equalTo(40.resized())
        }
        
        view.layoutIfNeeded()
        view.layoutSubviews()
    }
    
    private func setupTrialLabel() {
        self.progressView.show()
        SwiftyStoreKit.retrieveProductsInfo([Constants.analytics.week]) { result in
            if(!result.retrievedProducts.isEmpty) {
                let testProduct = Product(product: result.retrievedProducts.first!)
                guard let period = testProduct.period else { return }
                let periodString = period.formattedString // MONTHLY
                let perPeriodString = period.perFormattedString.capitalized // MONTH
                let price = testProduct.localizedPrice
                let introductoryPeriod = testProduct.introductory?.period?.formattedString ?? "asda"
                self.trialLabel.text = NSLocalizedString("Start your ", comment: "") + "\(introductoryPeriod)" + NSLocalizedString(" free trial, then ", comment: "") + "\(price) / \(periodString)"
                self.progressView.hide()
            } else {
                self.progressView.hide()
                self.setupTrialLabel()
            }
        }
    }
    
    private func setupButtons() {
        subscribeButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.subscribeButtonAction()
        }.disposed(by: disposeBag)
        
        backButton.rx.tap.bind { [weak self] in
            self?.dismiss(animated: true)
        }.disposed(by: disposeBag)
        
        restoreButton.rx.tap.bind {
            IAPManager.shared().restore()
        }.disposed(by: disposeBag)
        
        
    }
    
    private func subscribeButtonAction() {
        IAPManager.shared().presentSubscriptionVC()
        IAPManager.shared().purchaseCompletion = { [weak self] _ in
            IAPManager.shared().dismissSubscriptionVC()
            guard let self = self else { return }
            if Constants.ud.isPurchased {
                self.navigationController?.dismiss(animated: true)
            }
        }
    }
}

//MARK: - Text View
extension PayOneVC {
    @objc func tapResponse(recognizer: UITapGestureRecognizer) {
        let location: CGPoint = recognizer.location(in: textView)
        let position: CGPoint = CGPoint(x: location.x, y: location.y)
        let tapPosition: UITextPosition? = textView.closestPosition(to: position)
        if tapPosition != nil {
            let textRange: UITextRange? = textView.tokenizer.rangeEnclosingPosition(tapPosition!, with: UITextGranularity.word, inDirection: UITextDirection(rawValue: 1))
            if textRange != nil
            {
                let tappedWord: String? = textView.text(in: textRange!)
                guard let word = tappedWord else { return }
                wordAction(word)
            }
        }
    }
    
    private func wordAction(_ word: String) {
        switch word {
        case NSLocalizedString("Terms", comment: ""), NSLocalizedString("of", comment: ""), NSLocalizedString("Use", comment: ""): pushPoliciesVC(.terms)
            
        case NSLocalizedString("Privacy", comment: ""), NSLocalizedString("Policy", comment: ""): pushPoliciesVC(.privacy)
        default: break
        }
    }
    
    func pushPoliciesVC(_ policiesType: Policies) {
        let termsVC = PoliciesVC()
        termsVC.policiesType = policiesType
        navigationController?.pushViewController(termsVC, animated: true)
    }
}

