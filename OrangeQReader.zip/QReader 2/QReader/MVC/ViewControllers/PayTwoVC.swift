import UIKit
import RxCocoa
import RxSwift
import SnapKit
import NetworkExtension
import Network
import SwiftyAttributes
import Reachability
import StoreKit
import SwiftyStoreKit

class PayTwoVC: UIViewController {
    
    var identifiers = [Constants.analytics.week, Constants.analytics.threeMonth, Constants.analytics.year]
    
    private lazy var topImageView: UIImageView = {
        let imageView = UIImageView(image: "paywall2".image)
        imageView.contentMode = .scaleAspectFill
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    private lazy var backButton: UIButton = {
        let button = UIButton()
        button.setImage("close".image, for: .normal)
        return button
    }()
    
    private lazy var restoreButton: UIButton = {
        let button = UIButton()
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .regular)
        button.setTitle(NSLocalizedString("Restore", comment: ""), for: .normal)
        button.setTitleColor("A5A6AD".hexColor, for: .normal)
        return button
    }()
    
    private lazy var centerLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 28, weight: .semibold)
        label.text = NSLocalizedString("Full Access", comment: "")
        label.textColor = "404147".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .center
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var buttonCenterLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 12, weight: .bold)
        label.text = NSLocalizedString("Get your full access", comment: "")
        label.textColor = "74757A".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .center
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var payCollectionView: UICollectionView = {
        let collection = UICollectionView(frame: .zero, collectionViewLayout: .init())
        collection.backgroundColor = .clear
        collection.showsHorizontalScrollIndicator = false
        collection.showsVerticalScrollIndicator = false
        collection.isScrollEnabled = true
        return collection
    }()
    
    private lazy var payLayout: UICollectionViewLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 0
        layout.itemSize = .init(width: 311, height: 64)
        layout.sectionInset = .init(top: 0, left: 0, bottom: 0, right: 0)
        return layout
    }()
    
    private lazy var subscribeButton: UIButton = {
        let button = UIButton()
        button.layer.cornerRadius = 12
        button.setTitle(NSLocalizedString("Subscribe", comment: ""), for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .semibold)
        button.titleLabel?.textColor = .white
        button.backgroundColor = "#4560E5".hexColor
        return button
    }()
    
    var productsDescription: NSAttributedString {
        let terms = NSLocalizedString("Terms", comment: "") + " " + NSLocalizedString("of", comment: "") + " " + NSLocalizedString("Use", comment: "")
        let privacy = NSLocalizedString("Privacy", comment: "") + " " + NSLocalizedString("Policy", comment: "")
        let and = " & "
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        
        let textAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12)),
            .textColor("#7B7C80".hexColor),
            .paragraphStyle(paragraphStyle)
        ]
        
        let andAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12)),
            .textColor("#B8BABF".hexColor),
            .paragraphStyle(paragraphStyle)
        ]
        
        let attributedDescription =
        terms.withAttributes(textAttributes)
        + and.withAttributes(andAttributes)
        + privacy.withAttributes(textAttributes)
        return attributedDescription
    }
    
    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.layoutIfNeeded()
        textView.isEditable = false
        textView.isSelectable = false
        textView.isScrollEnabled = true
        textView.backgroundColor = .clear
        textView.showsVerticalScrollIndicator = true
        textView.attributedText = productsDescription
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapResponse(recognizer:)))
        textView.addGestureRecognizer(tap)
        return textView
    }()
        
    var products = [SKProduct]()
    var selectedIndex = 0
    
    let disposeBag = DisposeBag()
    public lazy var progressView = ProgressView(message: "", theme: .dark, isModal: true)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup() {
        updateProducts()
        configureLayout()
        configureCollection()
        setupButtons()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
       
//        if let navVC = presentingViewController as? UINavigationController {
//            if let mainBarController = navVC.viewControllers[0] as? MainBarController {
//                if let settingsNC = mainBarController.viewControllers?[2] as? UINavigationController {
//                    if let settingsVC = settingsNC.viewControllers.first, settingsVC.className == String(describing: settingsVC.self) {
//                        settingsVC.viewWillAppear(true)
//                    }
//                }
//            }
//        }
    }
    
    private func configureCollection() {
        payCollectionView.setCollectionViewLayout(payLayout, animated: true)
        payCollectionView.dataSource = self
        payCollectionView.delegate = self
        payCollectionView.register(PayCell.self, forCellWithReuseIdentifier: PayCell.nibIdentifier)
    }
    
    private func configureLayout(){
        view.backgroundColor = "F7F8FC".hexColor
        view.addSubviews(topImageView, centerLabel, buttonCenterLabel,payCollectionView, subscribeButton, textView)
        topImageView.addSubviews(backButton, restoreButton)
        
        topImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(44)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(336.resized())
        }
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(6)
            make.leading.equalToSuperview().offset(32)
            make.size.equalTo(32)
        }
        
        restoreButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(10)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(24)
        }
        
        centerLabel.snp.makeConstraints { make in
            make.top.equalTo(topImageView.snp.bottom).offset(24.resized())
            make.leading.equalToSuperview().offset(102)
            make.trailing.equalToSuperview().offset(-101)
            make.height.equalTo(32)
        }
        
        buttonCenterLabel.snp.makeConstraints { make in
            make.top.equalTo(centerLabel.snp.bottom).offset(8.resized())
            make.centerX.equalToSuperview()
            make.width.equalTo(200)
            make.height.equalTo(16)
        }
        
        payCollectionView.snp.makeConstraints { make in
            make.top.equalTo(buttonCenterLabel.snp.bottom).offset(10.resized())
            make.leading.equalToSuperview().offset(32.resized(.width))
            make.trailing.equalToSuperview().offset(-32.resized(.width))
            make.bottom.equalTo(subscribeButton.snp.top).offset(-10)
        }
        
        subscribeButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-73.resized())
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(56)
        }
        
        textView.snp.makeConstraints { make in
            make.top.equalTo(subscribeButton.snp.bottom).offset(12.resized())
            make.centerX.equalToSuperview()
            make.width.equalTo(UIScreen.main.bounds.width)
            make.height.equalTo(40.resized())
        }
        
        view.layoutIfNeeded()
        view.layoutSubviews()
        
        IAPManager.shared().productsReceived.bind { [weak self] received in
            if received {
                self?.payCollectionView.reloadData()
            } else {
                self?.updateProducts()
            }
        }.disposed(by: disposeBag)
        
        IAPManager.shared().productsReceived.bind { [weak self] received in
            if received {
                self?.payCollectionView.reloadData()
            } else {
                self?.updateProducts()
                self?.payCollectionView.reloadData()
            }
        }.disposed(by: disposeBag)
    }
    
    private func setupButtons() {
        backButton.rx.tap.bind { [weak self] in
            self?.dismiss(animated: true)
        }.disposed(by: disposeBag)
        
        subscribeButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            let product = self.identifiers[self.selectedIndex]
            IAPManager.shared().purchase(rcPackage: product, quantity: 1, atomically: true)
        }.disposed(by: disposeBag)
        
        restoreButton.rx.tap.bind {
            IAPManager.shared().restore()
        }.disposed(by: disposeBag)
    }
  
    private func configurePriceLabel(product: SKProduct?) {
        guard let appHudproduct = product else { return }
        let product = Product(product: appHudproduct)
        guard let period = product.period else { return }
        let price = product.localizedPrice
        let perPeriodString = period.perFormattedString.capitalized
        
        if product.introductory?.period != nil {
            subscribeButton.setTitle(NSLocalizedString("Start ", comment: "") + (product.introductory?.period?.formattedString ?? "asda") + NSLocalizedString(" free trial", comment: ""), for: .normal)
        } else {
            subscribeButton.setTitle(NSLocalizedString("Subscribe", comment: ""), for: .normal)
        }
    }
    private func updateProducts() {
        progressView.show()
        SwiftyStoreKit.retrieveProductsInfo([Constants.analytics.week, Constants.analytics.threeMonth, Constants.analytics.year]) { result in
            if(!result.retrievedProducts.isEmpty) {
                self.products = Array(result.retrievedProducts).sorted(by: { Product(product: $0).price < Product(product: $1).price })
                self.payCollectionView.reloadData()
                self.configurePriceLabel(product: self.products[0])
                self.progressView.hide()
            } else {
                self.progressView.hide()
                self.updateProducts()
            }
        }
    }
}
//MARK: - CollectionView
extension PayTwoVC: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedIndex = indexPath.item
        let apphudProduct = self.products[selectedIndex]
        configurePriceLabel(product: apphudProduct)
        payCollectionView.reloadData()
    }
}

extension PayTwoVC: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return products.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PayCell.nibIdentifier, for: indexPath) as! PayCell
        let apphudProduct = products[indexPath.item]
        let product = Product(product: apphudProduct)
        print(product)
        cell.product = product
        if indexPath.item == self.selectedIndex {
            product.type == .renewable(.trial) ? cell.configureTrialSelected() : cell.configureCommonSelected()
        } else {
            product.type == .renewable(.trial) ? cell.configureTrial() : cell.configureCommon()
        }
        return cell
    }
}

//MARK: - Text View
extension PayTwoVC {
    @objc func tapResponse(recognizer: UITapGestureRecognizer) {
        let location: CGPoint = recognizer.location(in: textView)
        let position: CGPoint = CGPoint(x: location.x, y: location.y)
        let tapPosition: UITextPosition? = textView.closestPosition(to: position)
        if tapPosition != nil {
            let textRange: UITextRange? = textView.tokenizer.rangeEnclosingPosition(tapPosition!, with: UITextGranularity.word, inDirection: UITextDirection(rawValue: 1))
            if textRange != nil
            {
                let tappedWord: String? = textView.text(in: textRange!)
                guard let word = tappedWord else { return }
                wordAction(word)
            }
        }
    }
    
    private func wordAction(_ word: String) {
        switch word {
        case NSLocalizedString("Terms", comment: ""), NSLocalizedString("Of", comment: ""), NSLocalizedString("Use", comment: ""): pushPoliciesVC(.terms)
        case NSLocalizedString("Privacy", comment: ""), NSLocalizedString("Policy", comment: ""): pushPoliciesVC(.privacy)
            
        default: break
        }
    }
    
    func pushPoliciesVC(_ policiesType: Policies) {
        let termsVC = PoliciesVC()
        termsVC.policiesType = policiesType
        navigationController?.pushViewController(termsVC, animated: true)
    }
}
