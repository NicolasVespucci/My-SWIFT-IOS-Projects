//
//  PresentCodeVC.swift
//  QReader
//
//  Created by iMac 21 on 31/03/2022.
//
import Foundation
import UIKit
import SnapKit
import RxSwift
import RxCocoa


class PresentCodeVC : UIViewController, UITextViewDelegate {
    
    var disposeBag = DisposeBag()
    public var testImage : UIImage = UIImage()
    public var qrtext = "";
    public var qrname = "";
    public var qrid = "";
    
    private var chipsImageView: UIImageView = {
        let imageView = UIImageView(image: "chips".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    var qrCodeView : UIImageView = {
       var imageview = UIImageView()
        imageview.contentMode = .scaleAspectFill
        return imageview
    }()
    
    var controllerLabel : UILabel = {
       var label = UILabel()
        label.text = "QR Code"
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.textColor = "#404147".hexColor
        label.textAlignment = .center
        return label
    }()
    
    var shareButton : UIButton = {
       var button = UIButton()
        button.setTitle("Share QR Code", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .medium)
       return button
    }()
    
    var qrCodeTextView : UITextView = {
       var textView = UITextView()
        textView.backgroundColor = .white
        textView.addBorder(width: 2, color: "000000")
        textView.layer.cornerRadius = 20
        textView.clipsToBounds = true
        textView.isEditable = false
        textView.textColor = "#404147".hexColor
        textView.textContainerInset = UIEdgeInsets(top: 0, left: 30, bottom: 0, right: 0)
        textView.font = .systemFont(ofSize: 16, weight: .regular)
    
        return textView
    }()
    
    lazy var gestRect:
        UITapGestureRecognizer = {
            let gestureRecognizer = UITapGestureRecognizer()
            gestureRecognizer
                .addTarget(self, action: #selector(handleOneTap))

            return gestureRecognizer
    }()
    
    @objc func handleOneTap(sender: UITapGestureRecognizer) {
        if(qrCodeTextView.text.isURL()){
            guard let url = URL(string: qrCodeTextView.text!) else { return }
            UIApplication.shared.open(url)
        } else {
            let pasteboard = UIPasteboard.general
            pasteboard.string = qrCodeTextView.text
            
            qrCodeTextView.text = "Coppied to clipboard";
            qrCodeTextView.textColor = "21D40B".hexColor
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                self.qrCodeTextView.text = self.qrtext
                self.qrCodeTextView.textColor = "#404147".hexColor
            }
        }
    }
    
    var qrCodeName : UITextView = {
       var textView = UITextView()
        textView.backgroundColor = .white
        textView.addBorder(width: 2, color: "000000")
        textView.layer.cornerRadius = 20
        textView.clipsToBounds = true
        textView.isEditable = true
        textView.textColor = "#404147".hexColor
        textView.textContainerInset = UIEdgeInsets(top: 0, left: 30, bottom: 0, right: 0)
        textView.font = .systemFont(ofSize: 16, weight: .regular)
        return textView
    }()
    
    var textLabel : UILabel = {
       var label = UILabel()
        label.text = "Link"
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.textColor = UIColor(red: 0.00, green: 0.00, blue: 0.00, alpha: 0.33)
        label.textAlignment = .center
        return label
    }()
    
    var nameQRLabel : UILabel = {
       var label = UILabel()
        label.text = "Name"
        label.font = .systemFont(ofSize: 14, weight: .medium)
        label.textColor = UIColor(red: 0.00, green: 0.00, blue: 0.00, alpha: 0.33)
        label.textAlignment = .center
        return label
    }()
    
    var doneButton : UIButton = {
       var button = UIButton()
        button.setTitle("Done", for: .normal)
        button.setTitleColor("#404147".hexColor, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .medium)
       return button
    }()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = "#F7F8FC".hexColor
        qrCodeView.image = generateQRCode(from: qrtext)
        qrCodeTextView.text = qrtext
        qrCodeName.text = qrname
        view.addSubview(controllerLabel)
        controllerLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(45.resized())
            make.centerX.equalToSuperview()
            make.width.equalTo(120)
            make.height.equalTo(32.resized())
        }
        qrCodeTextView.addGestureRecognizer(gestRect)
        view.addSubview(chipsImageView)
        chipsImageView.addSubview(qrCodeView)
        chipsImageView.snp.makeConstraints { make in
            make.top.equalTo(controllerLabel.snp.bottom).offset(75.resized())
            make.centerX.equalToSuperview()
            make.size.equalTo(245)
        }
        qrCodeView.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview()
            make.size.equalTo(160.resized())
        }
        
        view.addSubview(shareButton)
        shareButton.snp.makeConstraints { make in
            make.trailing.equalToSuperview().offset(-40)
            make.leading.equalToSuperview().offset(40)
            make.height.equalTo(50)
            make.bottom.equalToSuperview().offset(-105.resized())
        }
        
        view.addSubview(qrCodeTextView)
        
        qrCodeTextView.snp.makeConstraints { make in
            make.trailing.equalToSuperview().offset(-40.resized(.width))
            make.leading.equalToSuperview().offset(40.resized(.width))
            make.height.equalTo(58.resized())
            make.top.equalTo(chipsImageView.snp.bottom).offset(33.resized())
        }
        
        view.addSubview(qrCodeName)
        qrCodeName.snp.makeConstraints { make in
            make.trailing.equalToSuperview().offset(-40.resized(.width))
            make.leading.equalToSuperview().offset(40.resized(.width))
            make.height.equalTo(58.resized())
            make.top.equalTo(qrCodeTextView.snp.bottom).offset(15.resized())
        }
        
        view.addSubview(textLabel)
        textLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(qrCodeTextView.snp.top).offset(-25.resized())
        }
        
        view.addSubview(nameQRLabel)
        nameQRLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(qrCodeName.snp.bottom).offset(25.resized())
        }
        
        view.addSubview(doneButton)
        doneButton.snp.makeConstraints { make in
            make.trailing.equalToSuperview().offset(-20)
            make.top.equalToSuperview().offset(45.resized())
            make.height.equalTo(39)
           
        }
        setupButtons()
        qrCodeName.delegate = self
        qrCodeTextView.rx.didBeginEditing.bind { [weak self] in
            print(":kek")
        }.disposed(by: disposeBag)
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        
        view.layoutIfNeeded()
        
        shareButton.addGradient(.topBottom, ["FFB648".hexColor, "F29337".hexColor], 20)
        
     
    }
    
    
    private func shareButtonActions() {
            let image = self.qrCodeView.image
            let imageToShare = [ image ]
            let activityViewController = UIActivityViewController(activityItems: imageToShare, applicationActivities: nil)
            activityViewController.popoverPresentationController?.sourceView = self.view
            activityViewController.excludedActivityTypes = [ UIActivity.ActivityType.airDrop, UIActivity.ActivityType.postToFacebook ]
            self.present(activityViewController, animated: true, completion: nil)
    }
    
    
    @objc func keyboardWillShow(notification: Notification) {
        
        let keyboardHeight = (notification.userInfo![UIResponder.keyboardFrameEndUserInfoKey] as! NSValue).cgRectValue.height;
        UIView.animate(withDuration: 0.5, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
            self.qrCodeView.snp.updateConstraints { make in
                make.size.equalTo(0)
            }
            self.view.layoutIfNeeded()
               },completion: {_ in
                   
               })
           
        }
    
    @objc func keyboardWillHide(notification: Notification) {
       

        UIView.animate(withDuration: 0.5, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
            self.qrCodeView.snp.updateConstraints { make in
                make.size.equalTo(160.resized())
            }
            self.view.layoutIfNeeded()
               },completion: {_ in
                   
               })

    
        }
    
    func generateQRCode(from string: String) -> UIImage? {
        let data = string.data(using: String.Encoding.ascii)

        if let filter = CIFilter(name: "CIQRCodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            let transform = CGAffineTransform(scaleX: 3, y: 3)

            if let output = filter.outputImage?.transformed(by: transform) {
                return UIImage(ciImage: output)
            }
        }

        return nil
    }
    
   func doneButtonAction() {
       
       if let data = UserDefaults.standard.data(forKey: "History") {
           do {
               // Create JSON Decoder
               let decoder = JSONDecoder()

               // Decode Note
               let history = try decoder.decode([HistoryModel].self, from: data)
               
               let newArr = history.map { model in
                   model.id == self.qrid ? HistoryModel(name: qrCodeName.text, code: qrCodeTextView.text, id: qrid) : model
               }
               
               
               do {
                                 let encoder = JSONEncoder()
                                 let data = try encoder.encode(newArr)
                                 UserDefaults.standard.set(data, forKey: "History")
              
                             } catch {
                                 print("Unable to Encode Array of Notes (\(error))")
                             }
             
           } catch {
               print("Unable to Decode Notes (\(error))")
           }
       }
       
       if let data = UserDefaults.standard.data(forKey: "Bookmarks") {
           do {
               // Create JSON Decoder
               let decoder = JSONDecoder()

               // Decode Note
               let history = try decoder.decode([HistoryModel].self, from: data)
               
               let newArr = history.map { model in
                   model.id == self.qrid ? HistoryModel(name: qrCodeName.text, code: qrCodeTextView.text, id: qrid) : model
               }
               
               
               do {
                                 let encoder = JSONEncoder()
                                 let data = try encoder.encode(newArr)
                                 UserDefaults.standard.set(data, forKey: "Bookmarks")
              
                             } catch {
                                 print("Unable to Encode Array of Notes (\(error))")
                             }
             
           } catch {
               print("Unable to Decode Notes (\(error))")
           }
       }
       
       if let data = UserDefaults.standard.data(forKey: "MyCodes") {
           do {
               // Create JSON Decoder
               let decoder = JSONDecoder()

               // Decode Note
               let history = try decoder.decode([MyCodeModel].self, from: data)
               
               let newArr = history.map { model in
                   model.id == self.qrid ? MyCodeModel(name: qrCodeName.text, code: qrCodeTextView.text, id: qrid) : model
               }
               
               
               do {
                                 let encoder = JSONEncoder()
                                 let data = try encoder.encode(newArr)
                                 UserDefaults.standard.set(data, forKey: "MyCodes")
              
                             } catch {
                                 print("Unable to Encode Array of Notes (\(error))")
                             }
             
           } catch {
               print("Unable to Decode Notes (\(error))")
           }
       }
       
    }
    
    func setupButtons(){
        doneButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.doneButtonAction()
            self.dismiss(animated: true, completion: nil)
        }.disposed(by: disposeBag)
        
        shareButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.shareButtonActions()
        }.disposed(by: disposeBag)
        
    }
    
    override func viewDidLayoutSubviews() {
        qrCodeTextView.centerVertically()
        qrCodeName.centerVertically()
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        if text == "\n" {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
}



    extension String {
        func isURL() -> Bool {
            if hasPrefix("https://") || hasPrefix("http://") { return true }
            return range(of: "^(https?:\\/\\/)?([\\da-z\\.-]+)\\.([a-z\\.]{2,6})([\\/\\w \\.-]*)*\\/?$", options: .regularExpression) != nil
          }

    }
