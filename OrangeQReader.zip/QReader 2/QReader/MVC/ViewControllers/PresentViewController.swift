import UIKit
import RxSwift
import AppTrackingTransparency
import SwiftUI

class PresentViewController: UIViewController, UIScrollViewDelegate {
    
    private let firstView = PresentScrollView(image: "welcome1".image ?? UIImage(), topText: NSLocalizedString("QR Reader: Qr & Barcode", comment: ""), bottomText: NSLocalizedString("High-speed and precise\nQr & Barcode scanner / generator.", comment: ""))
    private let secondView = PresentScrollView(image: "welcome2".image ?? UIImage(), topText: NSLocalizedString("Scan all types of QR codes", comment: ""), bottomText: NSLocalizedString("- Scan history \n- Fast batch QR scan \n- Create your own QR codes", comment: ""))
    
    
    private var scrollView: UIScrollView = {
        let view = UIScrollView()
        view.isPagingEnabled = true
        view.isScrollEnabled = false
        view.showsHorizontalScrollIndicator = false
        return view
    }()

    private var nextButton: UIButton = {
        let button = UIButton()
        button.setTitle(NSLocalizedString("CONTUNUE", comment: ""), for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .medium)
        return button
    }()
    
    private var pageControll: UIImageView = {
        let imageView = UIImageView(image: "page-1".image)
        return imageView
    }()
    
    private lazy var pageControl: UIPageControl = {
        let pageControl = UIPageControl()
        pageControl.numberOfPages = 2
        pageControl.currentPage = 0
        pageControl.pageIndicatorTintColor = "404147".hexColor.withAlphaComponent(0.4)
        pageControl.currentPageIndicatorTintColor = "404147".hexColor
        pageControl.isUserInteractionEnabled = false
        return pageControl
    }()
    
    var window: UIWindow?
    
    var xOffSet: CGFloat = 0
    var contentWidth: CGFloat = 0.0
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup (){
        configureLayout()
        setupButtons()
        configureScrollView()
    }
    
    private func configureLayout() {
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = "F7F8FC".hexColor
        view.addSubview(scrollView)
        view.addSubviews(nextButton, pageControl)
        
        scrollView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        nextButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-100.resized())
            make.height.equalTo(50)
            make.leading.equalToSuperview().offset(58)
            make.trailing.equalToSuperview().offset(-58)
        }
        
        pageControl.snp.makeConstraints { make in
            make.top.equalTo(nextButton.snp.bottom).offset(44.resized())
            make.height.equalTo(12)
            make.width.equalTo(200)
            make.centerX.equalToSuperview()
        }
        
        view.layoutIfNeeded()
        nextButton.addGradient(.topBottom, ["FFB648".hexColor, "F29337".hexColor], 20)
    }
    
    private func setupButtons() {
        nextButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.continueStartButtonAction()
        }.disposed(by: disposeBag)
    }
    
    private func continueStartButtonAction(){
        if self.xOffSet < UIScreen.main.bounds.width {

            DispatchQueue.main.async {
                self.xOffSet += UIScreen.main.bounds.width
                self.scrollView.contentOffset.x = self.xOffSet
                self.nextButton.setTitle(NSLocalizedString("START", comment: ""), for: .normal)
                self.pageControll.image = "page-2".image
               //self.backButton.isHidden = false
            }
        } else {
            nextButtonActions()
            showCurrentController = true
            UserDefaults.standard.set(showCurrentController, forKey: "showCurrentController")
            self.xOffSet = UIScreen.main.bounds.width
        }
        
    }
    
    private func configureScrollView() {
        scrollView.delegate = self
        let viewsForScroll = [firstView, secondView]
        for (index, view) in viewsForScroll.enumerated() {
            scrollView.addSubview(view)
            view.snp.makeConstraints { make in
                make.top.equalToSuperview()
                make.bottom.equalToSuperview()
                make.leading.equalToSuperview().offset(CGFloat(index) * UIScreen.main.bounds.width)
                make.width.equalToSuperview()
            }
            self.view.layoutIfNeeded()
            self.scrollView.layoutIfNeeded()
            contentWidth += self.view.frame.width
        }
        scrollView.contentSize = CGSize(width: contentWidth, height: scrollView.frame.height)
    }
    
    private func nextButtonActions(){
        window = UIWindow()
        window?.makeKeyAndVisible()
        let mainVC = QRScannerController()
        let navController = UINavigationController()
        navController.pushViewController(mainVC, animated: false)
        window?.rootViewController = navController
    }
    
    func requestPermission() {
        if #available(iOS 14, *) {
            ATTrackingManager.requestTrackingAuthorization { status in
                switch status {
                case .authorized:
                    // Tracking authorization dialog was shown
                    // and we are authorized
                    print("Authorized")
                    // Now that we are authorized we can get the IDFA
                case .denied:
                    // Tracking authorization dialog was
                    // shown and permission is denied
                    print("Denied")
                case .notDetermined:
                    // Tracking authorization dialog has not been shown
                    print("Not Determined")
                case .restricted:
                    print("Restricted")
                @unknown default:
                    print("Unknown")
                }
            }
        }
    }
    
    internal func scrollViewDidScroll(_ scrollView: UIScrollView){
        pageControl.currentPage = Int(scrollView.contentOffset.x / UIScreen.main.bounds.width)
//        if pageControl.currentPage == 1 {
//            continueButton.setTitle(NSLocalizedString("Start", comment: ""), for: .normal)
//        } else if pageControl.currentPage == 0  {
//            continueButton.setTitle(NSLocalizedString("Continue", comment: ""), for: .normal)
//        }
    }
}
