import UIKit
import SnapKit
import RxSwift

class QRCodeViewController: UIViewController {
    
    private var qrCodeImageView: UIImageView = {
        let imageView = UIImageView()
        return imageView
    }()
    
    private var writeTextlabel: UILabel = {
        let label = UILabel()
        label.text = "Write Your Text: "
        label.textColor = .white
        return label
    }()
    
    private var inputYourText: UITextField = {
        let textField = UITextField()
          textField.translatesAutoresizingMaskIntoConstraints = false
          textField.placeholder = "Title *"
          textField.keyboardType = UIKeyboardType.default
          textField.returnKeyType = UIReturnKeyType.done
          textField.autocorrectionType = UITextAutocorrectionType.no
          textField.font = UIFont.systemFont(ofSize: 13)
          textField.borderStyle = UITextField.BorderStyle.roundedRect
          textField.clearButtonMode = UITextField.ViewMode.whileEditing;
          textField.contentVerticalAlignment = UIControl.ContentVerticalAlignment.center
        return textField
    }()
    
    private var generateYourQRcodeButton: UIButton = {
        let button = UIButton()
        button.setTitle("Creat QRcode", for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.backgroundColor = .lightGray
        button.layer.cornerRadius = 20
        return button
    }()
    
    private var resetButton: UIButton = {
        let button = UIButton()
        button.setTitle("Reset", for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.backgroundColor = .red
        button.layer.cornerRadius = 20
        return button
    }()
    
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
       setup()
    }

    private func setup(){
        configureLayout()
        setupButton()
    }
    
    private func configureLayout() {
        view.backgroundColor = .black
        view.addSubviews(qrCodeImageView, writeTextlabel, inputYourText, generateYourQRcodeButton, resetButton)
        
        qrCodeImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(50)
            make.size.equalTo(200)
            make.centerX.equalToSuperview()
        }
        
        writeTextlabel.snp.makeConstraints { make in
            make.bottom.equalTo(generateYourQRcodeButton.snp.top).offset(-50)
            make.leading.equalToSuperview().offset(50)
            make.height.equalTo(30)
        }
        
        inputYourText.snp.makeConstraints { make in
            make.bottom.equalTo(generateYourQRcodeButton.snp.top).offset(-50)
            make.trailing.equalToSuperview().offset(-50)
            make.height.equalTo(30)
            make.width.equalTo(200)
        }
        
        generateYourQRcodeButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-50)
            make.leading.equalToSuperview().offset(30)
            make.width.equalTo(200)
            make.height.equalTo(50)
        }
        
        resetButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-50)
            make.trailing.equalToSuperview().offset(-30)
            make.width.equalTo(110)
            make.height.equalTo(50)
        }
    }

    private func setupButton() {
        generateYourQRcodeButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.generateYourQRcodeButtonActions()
        }.disposed(by: disposeBag)
        
        resetButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.resetButtonActions()
        }.disposed(by: disposeBag)
        
    }
    
    private func generateYourQRcodeButtonActions() {
        let yourText = inputYourText.text
        if let text = yourText {
            let combinedString = "\(text)\n\(Date())"
            qrCodeImageView.image = generateQRCode(from: combinedString)
        }
    }
    
    private func resetButtonActions() {
        qrCodeImageView.image = "".image
    }
    
    func generateQRCode(from string: String) -> UIImage? {
        let data = string.data(using: String.Encoding.ascii)

        if let filter = CIFilter(name: "CIQRCodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            let transform = CGAffineTransform(scaleX: 3, y: 3)

            if let output = filter.outputImage?.transformed(by: transform) {
                return UIImage(ciImage: output)
            }
        }

        return nil
    }

}

