//
//  RecentsViewController.swift
//  QReader
//
//  Created by iMac 21 on 31/03/2022.
//

import Foundation
import UIKit
import RxSwift
import SnapKit
import RxCocoa
import RxSwift


class RecentsViewController: UIViewController {
    
    
    var xOffSet: CGFloat = UIScreen.main.bounds.width
    var contentWidth: CGFloat = 0.0
    let disposeBag = DisposeBag()
    
    var historyArray = [HistoryModel(name: "test", code: "test"), HistoryModel(name: "test", code: "test"), HistoryModel(name: "test", code: "test"), HistoryModel(name: "test", code: "test")];
    
    var bookmarksArray = [HistoryModel(name: "test", code: "test"), HistoryModel(name: "test", code: "test"), HistoryModel(name: "test", code: "test"), HistoryModel(name: "test", code: "test")];
    
    var historyTableView : UITableView = {
        let table = UITableView()
        table.backgroundColor = .clear
        table.rowHeight = 48
        table.showsVerticalScrollIndicator = false
        table.separatorStyle = .none
        table.clipsToBounds = true
        table.layer.cornerRadius = 12
        return table
    }()
    
    var bookmarksTableView : UITableView = {
        let table = UITableView()
        table.backgroundColor = .clear
        table.rowHeight = 48
        table.showsVerticalScrollIndicator = false
        table.separatorStyle = .none
        table.clipsToBounds = true
        table.layer.cornerRadius = 12
        return table
    }()
    
    private lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.backgroundColor = .clear
        scrollView.isScrollEnabled = false
       return scrollView
    }()
    
    var controllerLabel : UILabel = {
       var label = UILabel()
        label.text = "Recents"
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.textColor = "#404147".hexColor
        label.textAlignment = .center
        return label
    }()
    
    private lazy var mainButton: UIButton = {
        let button = UIButton()
        button.layer.cornerRadius = 38
        button.setTitleColor(.white, for: .normal)
       return button
    }()
    
    private lazy var pageImageView: UIImageView = {
        let imageView = UIImageView(image: "ic_welcome_page_1".image)
        imageView.contentMode = .scaleAspectFit
       return imageView
    }()
    
    var bottombar : BottomNavBar!
    
    var headerView : UIView = {
       var view = UIView()
        view.clipsToBounds = true
        view.layer.cornerRadius = 9
     //   view.backgroundColor = .clear
        return view
    }()
    
    var currentPageView : UIView = {
       var view = UIView()
        view.clipsToBounds = true
        view.layer.cornerRadius = 9
     //   view.backgroundColor = .clear
        return view
    }()
    
    var bookmarksButton : UIButton = {
        var button = UIButton()
        button.setTitle("Bookmarks", for: .normal)
        button.setTitleColor("96A6C2".hexColor, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        button.titleLabel?.textAlignment = .center
       return button
    }()
    
    var historyButton : UIButton = {
        var button = UIButton()
        button.setTitle("History", for: .normal)
        button.titleLabel?.textColor = "FFFFFF".hexColor
        button.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        button.titleLabel?.textAlignment = .center
       return button
    }()
    
    var historyView : UIView = {
        var view = UIView()
       
      //  view.backgroundColor = .black
         return view
     }()
    
    var bookmarksView : UIView = {
        var view = UIView()
       
         return view
     }()
    
    var noHistoryLabel : UILabel = {
       var label = UILabel()
        label.text = "No history Found"
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.textColor = "C8C8C8".hexColor
        label.textAlignment = .center
        return label
    }()
    
    var noBookmarksLabel : UILabel = {
       var label = UILabel()
        label.text = "No bookmarks Found"
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.textColor = "C8C8C8".hexColor
        label.textAlignment = .center
        return label
    }()
    
    
    
    func setupConstraints(){
        view.addSubview(bottombar)
        bottombar.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-25)
            make.centerX.equalToSuperview()
            make.width.equalTo(UIScreen.main.bounds.width - 124)
            make.height.equalTo(63)
        }

        view.addSubview(controllerLabel)
        controllerLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(45.resized())
            make.centerX.equalToSuperview()
            make.width.equalTo(120)
            make.height.equalTo(32)
        }
        
        view.addSubview(headerView)
        headerView.snp.makeConstraints { make in
            make.width.equalTo(287.resized(.width))
            make.centerX.equalToSuperview()
            make.height.equalTo(31.resized())
            make.top.equalTo(controllerLabel.snp.bottom).offset(23.resized())
        }
        
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = CGRect(x: 0, y: 0, width: 297.resized(.width), height: 55.resized())
        gradientLayer.colors = ["FFFFFF".hexColor.cgColor, "FFFFFF".hexColor.cgColor]
        gradientLayer.shouldRasterize = true
        gradientLayer.startPoint = CGPoint(x: 0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1, y: 0.5)
        headerView.layer.addSublayer(gradientLayer)
        
        headerView.addSubview(currentPageView)
        
        currentPageView.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(3.resized(.width))
            make.centerY.equalToSuperview()
            make.height.equalTo(24.resized())
            make.width.equalTo(145.resized(.width))
        }
        let gradientLayer1 = CAGradientLayer()
        gradientLayer1.frame = CGRect(x: 0, y: 0, width: 145.resized(.width), height: 43.resized())
        gradientLayer1.colors = ["FFB648".hexColor.cgColor, "F29337".hexColor.cgColor]
        gradientLayer1.shouldRasterize = true
        gradientLayer1.startPoint = CGPoint(x: 0, y: 0.5)
        gradientLayer1.endPoint = CGPoint(x: 1, y: 0.5)
        currentPageView.layer.addSublayer(gradientLayer1)
        headerView.addSubviews(historyButton, bookmarksButton)
        historyButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.height.equalTo(22.resized())
            make.width.equalTo(145.resized(.width))
            make.leading.equalToSuperview().offset(3.resized(.width))
        
        }
        bookmarksButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.height.equalTo(22.resized())
            make.width.equalTo(145.resized(.width))
            make.trailing.equalToSuperview().offset(-3.resized(.width))
        
        }
        view.addSubview(scrollView)
        
        scrollView.snp.makeConstraints { make in
            make.top.equalTo(headerView.snp.bottom).offset(29.resized())
            make.leading.equalToSuperview()
            make.width.equalToSuperview()
            make.bottom.equalTo(bottombar.snp.top)
        }
        
        historyView.snp.makeConstraints { make in
            make.width.equalTo(UIScreen.main.bounds.width - 64)
            make.height.equalTo(545.resized())
        }
        
        historyView.addSubview(historyTableView)
        
        historyTableView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(10)
            make.trailing.equalToSuperview().offset(-32.resized(.width))
            make.leading.equalToSuperview().offset(32.resized(.width))
            make.bottom.equalToSuperview().offset(-30.resized())
        }
        
        historyView.addSubview(noHistoryLabel)
        
        noHistoryLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.height.equalTo(32)
            make.width.equalTo(270)
            make.top.equalToSuperview().offset(150.resized())
        }
        
        bookmarksView.snp.makeConstraints { make in
            make.width.equalTo(UIScreen.main.bounds.width - 64)
            make.height.equalTo(545.resized())
        }
        
        bookmarksView.addSubview(bookmarksTableView)
        
        bookmarksTableView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(10)
            make.trailing.equalToSuperview().offset(-32.resized(.width))
            make.leading.equalToSuperview().offset(32.resized(.width))
            make.bottom.equalToSuperview().offset(-30.resized())
        }
        
        bookmarksView.addSubview(noBookmarksLabel)
        
        noBookmarksLabel.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.height.equalTo(32)
            make.width.equalTo(270)
            make.top.equalToSuperview().offset(150.resized())
        }
        
    }
    
    
//
//    struct MyProvider: PreviewProvider {
//        static var previews: some View {
//            ConteinerView().edgesIgnoringSafeArea(.all)
//        }
//        struct ConteinerView: UIViewControllerRepresentable {
//            func makeUIViewController(context: UIViewControllerRepresentableContext<MyProvider.ConteinerView>) -> some SettingsVC{
//                return SettingsVC()
//            }
//            func updateUIViewController(_ uiViewController: MyProvider.ConteinerView.UIViewControllerType, context: UIViewControllerRepresentableContext<MyProvider.ConteinerView>) {
//            }
//        }
//    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = "#F7F8FC".hexColor
        bottombar = BottomNavBar(nav: self.navigationController!)
        self.navigationController?.navigationBar.isHidden = true
        
        if let data = UserDefaults.standard.data(forKey: "History") {
            do {
                // Create JSON Decoder
                let decoder = JSONDecoder()

                // Decode Note
                let historyTempArr = try decoder.decode([HistoryModel].self, from: data)
                
                historyArray = historyTempArr
                
                historyTableView.reloadData()

                historyTableView.isHidden = false
                noHistoryLabel.isHidden = true
            } catch {
                print("Unable to Decode Notes (\(error))")
            }
        } else {
            noHistoryLabel.isHidden = false
            historyTableView.isHidden = true
        }
        
        if let data1 = UserDefaults.standard.data(forKey: "Bookmarks") {
            do {
                // Create JSON Decoder
                let decoder = JSONDecoder()

                // Decode Note
                let booksTempArr = try decoder.decode([HistoryModel].self, from: data1)
                
                bookmarksArray = booksTempArr
                
                bookmarksTableView.reloadData()
                noBookmarksLabel.isHidden = true
                bookmarksTableView.isHidden = false
                
            } catch {
                print("Unable to Decode Notes (\(error))")
            }
        } else {
            noBookmarksLabel.isHidden = false
            bookmarksTableView.isHidden = true
        }
        
        setupConstraints()
        setupButtons()
        centerScrollView()
        setupTableViews()
    }
    
    func setupTableViews(){
        historyTableView.delegate = self
        historyTableView.dataSource = self
        historyTableView.register(HistoryCell.self, forCellReuseIdentifier: HistoryCell.nibIdentifier)
        
        bookmarksTableView.delegate = self
        bookmarksTableView.dataSource = self
        bookmarksTableView.register(HistoryCell.self, forCellReuseIdentifier: HistoryCell.nibIdentifier)
    }
    
    func setupButtons(){
        historyButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            UIView.animate(withDuration: 0.3, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
                self.currentPageView.snp.updateConstraints { make in
                    make.leading.equalToSuperview().offset(3.resized(.width))
                }
                self.bookmarksButton.setTitleColor("96A6C2".hexColor, for: .normal)
                self.historyButton.setTitleColor("FFFFFF".hexColor, for: .normal)
                self.view.layoutIfNeeded()
                   },completion: {_ in
                      
                   })
            self.scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
        }.disposed(by: disposeBag)
        
        bookmarksButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            UIView.animate(withDuration: 0.3, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
                self.currentPageView.snp.updateConstraints { make in
                    make.leading.equalToSuperview().offset(139.resized(.width))
                }
                self.bookmarksButton.setTitleColor("FFFFFF".hexColor, for: .normal)
                self.historyButton.setTitleColor("96A6C2".hexColor, for: .normal)
                self.view.layoutIfNeeded()
            }, completion: {_ in
               
            })
            self.scrollView.setContentOffset(CGPoint(x: UIScreen.main.bounds.width, y: 0), animated: true)
        }.disposed(by: disposeBag)
    }
    
    private func centerScrollView() {
        scrollView.delegate = self
        let viewsForScroll = [historyView, bookmarksView];

        for (index, view) in viewsForScroll.enumerated() {
            scrollView.addSubview(view)

            view.snp.makeConstraints { make in
                make.top.equalToSuperview()
                make.bottom.equalToSuperview()
                make.leading.equalToSuperview().offset(CGFloat(index) * UIScreen.main.bounds.width)
                make.width.equalToSuperview()
            }

            self.view.layoutIfNeeded()
            self.scrollView.layoutIfNeeded()

            contentWidth += self.view.frame.width
        }

        scrollView.contentSize = CGSize(width: contentWidth, height: scrollView.frame.height)
    }

    override func viewDidAppear(_ animated: Bool) {
        if let data = UserDefaults.standard.data(forKey: "History") {
            do {
                // Create JSON Decoder
                let decoder = JSONDecoder()

                // Decode Note
                let historyTempArr = try decoder.decode([HistoryModel].self, from: data)
                
                historyArray = historyTempArr
                
                historyTableView.reloadData()

                historyTableView.isHidden = false
                noHistoryLabel.isHidden = true
            } catch {
                print("Unable to Decode Notes (\(error))")
            }
        } else {
            noHistoryLabel.isHidden = false
            historyTableView.isHidden = true
        }
        
        if let data1 = UserDefaults.standard.data(forKey: "Bookmarks") {
            do {
                // Create JSON Decoder
                let decoder = JSONDecoder()

                // Decode Note
                let booksTempArr = try decoder.decode([HistoryModel].self, from: data1)
                
                bookmarksArray = booksTempArr
                
                bookmarksTableView.reloadData()
                noBookmarksLabel.isHidden = true
                bookmarksTableView.isHidden = false
                
            } catch {
                print("Unable to Decode Notes (\(error))")
            }
        } else {
            noBookmarksLabel.isHidden = false
            bookmarksTableView.isHidden = true
        }
    }
    
}

extension RecentsViewController: UIScrollViewDelegate {
  func scrollViewDidScroll(_ scrollView: UIScrollView) {
    if scrollView == self.scrollView {
//      topIndicator.transform = CGAffineTransform(translationX: scrollView.contentOffset.x / 375 * 50 - 50, y: 0)
//      bottomIndicator.transform = topIndicator.transform
//      lastContentOffset = scrollView.contentOffset.x
    }
  }
}

extension RecentsViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if(tableView == self.historyTableView){
            let vc = PresentCodeVC()
            vc.qrtext = historyArray[indexPath.row].code!;
            vc.qrname = historyArray[indexPath.row].name!;
            vc.qrid = historyArray[indexPath.row].id!;
            vc.modalPresentationStyle = .fullScreen
            
            self.present(vc, animated: true, completion: nil)
        } else {
            let vc = PresentCodeVC()
            vc.qrtext = bookmarksArray[indexPath.row].code!;
            vc.qrname = bookmarksArray[indexPath.row].name!;
            vc.qrid = bookmarksArray[indexPath.row].id!;
            vc.modalPresentationStyle = .fullScreen
            
            self.present(vc, animated: true, completion: nil)
        }
        
    }
    
}

extension RecentsViewController: UITableViewDataSource {
    

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(tableView == self.historyTableView){
            return historyArray.count
        } else {
            return bookmarksArray.count
        }
      
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if(tableView == self.historyTableView){
            let cell = tableView.dequeueReusableCell(withIdentifier: HistoryCell.nibIdentifier, for: indexPath) as! HistoryCell
           
            cell.historyModel = historyArray[indexPath.row]
            cell.configureDefaultLayout()
           
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: HistoryCell.nibIdentifier, for: indexPath) as! HistoryCell
           
            cell.historyModel = bookmarksArray[indexPath.row]
            cell.configureDefaultLayout()
           
            return cell
        }
      
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            if (tableView == self.historyTableView){
                historyArray.remove(at: indexPath.row)
                historyTableView.deleteRows(at: [indexPath], with: .automatic)
                do {
                    let encoder = JSONEncoder()
                    let data = try encoder.encode(self.historyArray)
                    UserDefaults.standard.set(data, forKey: "History")
                } catch {
                    print("Unable to Encode Array of Notes (\(error))")
                }
            } else {
                bookmarksArray.remove(at: indexPath.row)
                bookmarksTableView.deleteRows(at: [indexPath], with: .automatic)
                do {
                    let encoder = JSONEncoder()
                    let data = try encoder.encode(self.bookmarksArray)
                    UserDefaults.standard.set(data, forKey: "Bookmarks")
                } catch {
                    print("Unable to Encode Array of Notes (\(error))")
                }
            }
        }
    }
}

class HistoryCell: UITableViewCell {


    private lazy var fullView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
     
       return view
    }()
    
    public lazy var histroyName : UILabel = {
        let label = UILabel()
        label.textColor = "#404147".hexColor
        label.textAlignment = .left
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 1
        label.font = .systemFont(ofSize: 14, weight: .medium)
        return label
    }()
    
    
    private lazy var historyImage : UIImageView = {
       let imageView = UIImageView()
        
        imageView.image = "ic_globe".image
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    

    
    var historyModel: HistoryModel? {
        didSet {
            configureCell()
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func configureDefaultLayout() {
        fullView.backgroundColor = .white
        contentView.addSubview(fullView)
        
        fullView.snp.makeConstraints { make in
            make.bottom.equalToSuperview()
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
        }
        
        fullView.addSubview(histroyName)
        fullView.addSubview(historyImage)
        
        historyImage.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(18)
            make.size.equalTo(20)
        }
        
        histroyName.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalTo(historyImage.snp.trailing).offset(10)
            make.trailing.equalToSuperview().offset(-10)
        }
    
        var divider = UIView()
        divider.backgroundColor = "#D7D8DB".hexColor
        fullView.addSubview(divider)
        
        divider.snp.makeConstraints { make in
            make.bottom.equalToSuperview()
            make.height.equalTo(1)
            make.leading.equalTo(historyImage.snp.trailing).offset(10)
            make.trailing.equalToSuperview()
        }
    }
    
    
    
    private func configureCell() {
        guard let historyModel = historyModel else { return }
        
        
        histroyName.text = historyModel.name
        

    }
    
}


extension Date {
    func get(_ components: Calendar.Component..., calendar: Calendar = Calendar.current) -> DateComponents {
        return calendar.dateComponents(Set(components), from: self)
    }

    func get(_ component: Calendar.Component, calendar: Calendar = Calendar.current) -> Int {
        return calendar.component(component, from: self)
    }
}
