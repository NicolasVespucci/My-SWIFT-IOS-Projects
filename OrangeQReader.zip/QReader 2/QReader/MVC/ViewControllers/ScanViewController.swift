//
//  ScanViewController.swift
//  QReader
//
//  Created by iMac 21 on 31/03/2022.
//

import Foundation
import UIKit
import AVFoundation
import SafariServices
import SnapKit
import RxSwift
import RxCocoa
import AudioToolbox


var currentIsScanning = false

final class QRScannerController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    var captureSession = AVCaptureSession()
    
    var videoPreviewLayer: AVCaptureVideoPreviewLayer?
    var qrCodeFrameView: UIView?
    var scanned = false;
    var flashLightOn = false;
    
    var flashlightButton : UIButton = {
        var button = UIButton()
        button.setImage("flashlight".image, for: .normal)
        button.contentMode = .scaleAspectFit
        return button
    }()
    
    var galleryButton : UIButton = {
        var button = UIButton()
        button.setImage("galleryImage".image, for: .normal)
        button.contentMode = .scaleAspectFit
        return button
    }()
    
    var disposeBag = DisposeBag()
    
    var bottombar : BottomNavBar!
    
    private let supportedCodeTypes = [AVMetadataObject.ObjectType.upce,
                                      AVMetadataObject.ObjectType.code39,
                                      AVMetadataObject.ObjectType.code39Mod43,
                                      AVMetadataObject.ObjectType.code93,
                                      AVMetadataObject.ObjectType.code128,
                                      AVMetadataObject.ObjectType.ean8,
                                      AVMetadataObject.ObjectType.ean13,
                                      AVMetadataObject.ObjectType.aztec,
                                      AVMetadataObject.ObjectType.pdf417,
                                      AVMetadataObject.ObjectType.itf14,
                                      AVMetadataObject.ObjectType.dataMatrix,
                                      AVMetadataObject.ObjectType.interleaved2of5,
                                      AVMetadataObject.ObjectType.qr]
    
    func detectQRCode(_ image: UIImage?) -> [CIFeature]? {
        if let image = image, let ciImage = CIImage.init(image: image){
            var options: [String: Any]
            let context = CIContext()
            options = [CIDetectorAccuracy: CIDetectorAccuracyHigh]
            let qrDetector = CIDetector(ofType: CIDetectorTypeQRCode, context: context, options: options)
            if ciImage.properties.keys.contains((kCGImagePropertyOrientation as String)){
                options = [CIDetectorImageOrientation: ciImage.properties[(kCGImagePropertyOrientation as String)] ?? 1]
            } else {
                options = [CIDetectorImageOrientation: 1]
            }
            let features = qrDetector?.features(in: ciImage, options: options)
            return features
            
        }
        return nil
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .black
        bottombar = BottomNavBar(nav: self.navigationController!)
        
        self.navigationController?.navigationBar.isHidden = true
        // Get the back-facing camera for capturing videos
        AVCaptureDevice.requestAccess(for: AVMediaType.video) { response in
            if response {
                guard let captureDevice = AVCaptureDevice.default(for: AVMediaType.video) else {
                    print("Failed to get the camera device")
                    return
                }
                do {
                    // Get an instance of the AVCaptureDeviceInput class using the previous device object.
                    let input = try AVCaptureDeviceInput(device: captureDevice)
                    
                    // Set the input device on the capture session.
                    self.captureSession.addInput(input)
                    
                    // Initialize a AVCaptureMetadataOutput object and set it as the output device to the capture session.
                    let captureMetadataOutput = AVCaptureMetadataOutput()
                    self.captureSession.addOutput(captureMetadataOutput)
                    
                    // Set delegate and use the default dispatch queue to execute the call back
                    captureMetadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
                    captureMetadataOutput.metadataObjectTypes = self.supportedCodeTypes
                    //            captureMetadataOutput.metadataObjectTypes = [AVMetadataObject.ObjectType.qr]
                    
                } catch {
                    // If any error occurs, simply print it out and don't continue any more.
                    print(error)
                    return
                }
            } else {
                
            }
        }
        
        
        setupQRCode()
        
        if !IAPManager.shared().isPurchased {
            Constants.ud.currentDismis = 2
            IAPManager.shared().presentSingleSubscriptionVC()
            IAPManager.shared().purchaseCompletion = { _ in
                IAPManager.shared().dismissSubscriptionVC()
                AlertManager.shared().showPurchaseComplite()
               // self.nextButtonActions()
            }
            IAPManager.shared().restoreCompletion = { subscription in
                IAPManager.shared().dismissSubscriptionVC()
                if Constants.ud.isPurchased {
                    AlertManager.shared().showPurchasesWereRestored()
                    //self.nextButtonActions()
                }
          }
        }
        
        
        
        view.addSubview(flashlightButton)
        flashlightButton.snp.makeConstraints { make in
            make.size.equalTo(53)
            make.leading.equalToSuperview().offset(20.resized(.width))
            make.top.equalToSuperview().offset(50.resized())
        }
        
        view.addSubview(galleryButton)
        galleryButton.snp.makeConstraints { make in
            make.size.equalTo(53)
            make.trailing.equalToSuperview().offset(-20.resized(.width))
            make.top.equalToSuperview().offset(50.resized())
        }
        
        view.addSubview(bottombar)
        
        bottombar.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-25)
            make.centerX.equalToSuperview()
            make.width.equalTo(UIScreen.main.bounds.width - 124)
            make.height.equalTo(63)
        }
        
        setupButtons()
        
    }
    
    func setupQRCode() {
        // Initialize the video preview layer and add it as a sublayer to the viewPreview view's layer.
        videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        videoPreviewLayer?.videoGravity = AVLayerVideoGravity.resizeAspectFill
        videoPreviewLayer?.frame = view.layer.bounds
        view.layer.addSublayer(videoPreviewLayer!)
        
        // Start video capture.
        captureSession.startRunning()
        
        
        // Move the message label and top bar to the front
        
        // Initialize QR Code Frame to highlight the QR code
        qrCodeFrameView = UIView()
        
        if let qrCodeFrameView = qrCodeFrameView {
            qrCodeFrameView.layer.borderColor = "#FFFFFF".hexColor.cgColor
            qrCodeFrameView.layer.borderWidth = 3
            view.addSubview(qrCodeFrameView)
            view.bringSubviewToFront(qrCodeFrameView)
        }
    }
    
    
    
    func setupButtons(){
        flashlightButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.toggleTorch(on: self.flashLightOn)
            self.flashLightOn = !self.flashLightOn
        }.disposed(by: disposeBag)
        
        galleryButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.fromGalerry()
        }.disposed(by: disposeBag)
    }
    
    func fromGalerry() {
        ImagePickerManager().pickImage(self){ image in
            //here is the image
            print(QRToString().string(from: image))
            var str = QRToString().string(from: image)
            
            if(str != ""){
                if(Constants.ud.vibrateValue){
                    AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate))
                }
                var testImage = self.generateQRCode(from: str)
                
                var vc = AfterScanController()
                vc.testImage = testImage!
                vc.qrtext = str
                vc.modalPresentationStyle = .fullScreen
                self.present(vc, animated: true, completion: nil)
                
            }
        }
    }
    
    func toggleTorch(on: Bool) {
        guard let device = AVCaptureDevice.default(for: .video) else { return }
        
        if device.hasTorch {
            do {
                try device.lockForConfiguration()
                
                if on == true {
                    device.torchMode = .on
                } else {
                    device.torchMode = .off
                }
                
                device.unlockForConfiguration()
            } catch {
                print("Torch could not be used")
            }
        } else {
            print("Torch is not available")
        }
    }
    
    // MARK: - Helper methods
    func launchApp(decodedURL: String) {
        
        if presentedViewController != nil {
            return
        }
        
        let alertPrompt = UIAlertController(title: "Open App", message: "You're going to open \(decodedURL)", preferredStyle: .actionSheet)
        let confirmAction = UIAlertAction(title: "Confirm", style: .default, handler: { (action) -> Void in
            
            if let url = URL(string: decodedURL) {
                if UIApplication.shared.canOpenURL(url) {
                    UIApplication.shared.open(url)
                }
            }
        })
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alertPrompt.addAction(confirmAction)
        alertPrompt.addAction(cancelAction)
        
        present(alertPrompt, animated: true, completion: nil)
    }
    private func updatePreviewLayer(layer: AVCaptureConnection, orientation: AVCaptureVideoOrientation) {
        layer.videoOrientation = orientation
        videoPreviewLayer?.frame = view.bounds
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if let connection =  self.videoPreviewLayer?.connection  {
            let currentDevice: UIDevice = UIDevice.current
            let orientation: UIDeviceOrientation = currentDevice.orientation
            let previewLayerConnection : AVCaptureConnection = connection
            
            if previewLayerConnection.isVideoOrientationSupported {
                switch (orientation) {
                case .portrait:
                    updatePreviewLayer(layer: previewLayerConnection, orientation: .portrait)
                    break
                case .landscapeRight:
                    updatePreviewLayer(layer: previewLayerConnection, orientation: .landscapeLeft)
                    break
                case .landscapeLeft:
                    updatePreviewLayer(layer: previewLayerConnection, orientation: .landscapeRight)
                    break
                case .portraitUpsideDown:
                    updatePreviewLayer(layer: previewLayerConnection, orientation: .portraitUpsideDown)
                    break
                default:
                    updatePreviewLayer(layer: previewLayerConnection, orientation: .portrait)
                    break
                }
            }
        }
    }
    
    func generateQRCode(from string: String) -> UIImage? {
        let data = string.data(using: String.Encoding.ascii)
        
        if let filter = CIFilter(name: "CIQRCodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            let transform = CGAffineTransform(scaleX: 3, y: 3)
            
            if let output = filter.outputImage?.transformed(by: transform) {
                return UIImage(ciImage: output)
            }
        }
        
        return nil
    }
    
    //    func imagePickerController(picker: UIImagePickerController!, didFinishPickingImage image: UIImage!, editingInfo: NSDictionary!){
    //
    //        if let features = detectQRCode(image), !features.isEmpty{
    //            for case let row as CIQRCodeFeature in features{
    //                print(row.messageString ?? "nope")
    //            }
    //        }
    //
    //
    //            self.dismiss(animated: true, completion: { () -> Void in
    //
    //            })
    //
    //          //  imageView.image = image
    //        }
    
    override func viewWillAppear(_ animated: Bool) {
        currentIsScanning = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        currentIsScanning = false
    }
}

extension QRScannerController: AVCaptureMetadataOutputObjectsDelegate {
    
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        // Check if the metadataObjects array is not nil and it contains at least one object.
        if metadataObjects.count == 0 {
            qrCodeFrameView?.frame = CGRect.zero
            return
        }
        
        
        // Get the metadata object.
        let metadataObj = metadataObjects[0] as! AVMetadataMachineReadableCodeObject
        
        if supportedCodeTypes.contains(metadataObj.type) {
            // If the found metadata is equal to the QR code metadata (or barcode) then update the status label's text and set the bounds
            let barCodeObject = videoPreviewLayer?.transformedMetadataObject(for: metadataObj)
            qrCodeFrameView?.frame = barCodeObject!.bounds
            
            if metadataObj.stringValue != nil {
                //    launchApp(decodedURL: metadataObj.stringValue!)
                if(!scanned){
                    scanned = true
                    print(metadataObj.stringValue!)
                    if(Constants.ud.vibrateValue){
                        AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate))
                    }
                    var testImage = generateQRCode(from: metadataObj.stringValue!)
                    
                    //MARK: - Batch scan Options
                    
                    var textQRCode = metadataObj.stringValue!
                    if !(textQRCode.trimmingCharacters(in: .whitespacesAndNewlines) == "") {
                        if Constants.ud.batchScanValue == true {
                            if currentIsScanning {
                                if let data = UserDefaults.standard.data(forKey: "History") {
                                    do {
                                        // Create JSON Decoder
                                        let decoder = JSONDecoder()
                                        // Decode Note
                                        var history = try decoder.decode([HistoryModel].self, from: data)
                                        var flag = 0
                                        let uuid = UUID().uuidString
                                        history.append(HistoryModel(name: metadataObj.stringValue!, code: metadataObj.stringValue!, id: uuid))
                                        do {
                                            let encoder = JSONEncoder()
                                            let data = try encoder.encode(history)
                                            UserDefaults.standard.set(data, forKey: "History")
                                            //setupQRCode()
                                            DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                                                self.scanned = false
                                            }
                                            
                                        } catch {
                                            print("Unable to Encode Array of Notes (\(error))")
                                        }
                                        
                                    } catch {
                                        print("Unable to Decode Notes (\(error))")
                                    }
                                } else {
                                    
                                    let uuid = UUID().uuidString
                                    var tempArr = [HistoryModel(name: metadataObj.stringValue!, code: metadataObj.stringValue!, id: uuid)]
                                    do {
                                        let encoder = JSONEncoder()
                                        let data = try encoder.encode(tempArr)
                                        UserDefaults.standard.set(data, forKey: "History")
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                                            self.scanned = false
                                        }
                                        
                                    } catch {
                                        print("Unable to Encode Array of Notes (\(error))")
                                    }
                                }
                            }
                        } else {
                            
                            if currentIsScanning {
                                var vc = AfterScanController()
                                vc.testImage = testImage!
                                vc.qrtext = metadataObj.stringValue!
                                vc.modalPresentationStyle = .fullScreen
                                self.present(vc, animated: true)
                                //                        self.present(vc, animated: true, completion: {
                                //                            self.scanned = false
                                //                        })
                                
                                DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                                    self.scanned = false
                                }
                                //                        DispatchQueue.main.asyncAfter(deadline: .now() + 10) {
                                //                           self.captureSession.startRunning()
                                //                        }
                            }
                        }
                    }
                }
            }
            if metadataObj.descriptor != nil {
            }
        }
    }
    
    
}

class QRToString {
    
    func string(from image: UIImage) -> String {
        
        var qrAsString = ""
        guard let detector = CIDetector(ofType: CIDetectorTypeQRCode,
                                        context: nil,
                                        options: [CIDetectorAccuracy: CIDetectorAccuracyHigh]),
              let ciImage = CIImage(image: image),
              let features = detector.features(in: ciImage) as? [CIQRCodeFeature] else {
                  return qrAsString
              }
        
        for feature in features {
            guard let indeedMessageString = feature.messageString else {
                continue
            }
            qrAsString += indeedMessageString
        }
        
        return qrAsString
    }
}
