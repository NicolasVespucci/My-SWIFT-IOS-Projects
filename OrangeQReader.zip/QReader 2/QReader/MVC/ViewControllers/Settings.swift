//
//  Settings.swift
//  QReader
//
//  Created by iMac 21 on 04/04/2022.
//

import UIKit
import RxCocoa
import RxSwift
import SnapKit
import NetworkExtension
import Network
import MessageUI
import Alamofire
import SwiftUI

class SettingsVC: UIViewController{
    
    public var settingModels = [SettingModel( title: "Batch Scan", value: Constants.ud.batchScanValue),
                                SettingModel( title: "Vibrate", value: Constants.ud.vibrateValue),
                                SettingModel( title: "History", value: Constants.ud.historyValue),
                                SettingModel( title: "Dublicate Scans", value: Constants.ud.dublicateScansValue),
                              ]
    
    
    public var settingModelsTwo = [SettingModelTwo(image: "privacy", title: NSLocalizedString("Privacy Policy", comment: "")),
                                   SettingModelTwo(image: "terms", title: NSLocalizedString("Terms of Use", comment: "")),
                                   SettingModelTwo(image: "contact", title: NSLocalizedString("Contact support", comment: "")),
                                   SettingModelTwo(image: "restore", title: NSLocalizedString("Restore purchases", comment: "")),
                                   SettingModelTwo(image: "share", title: NSLocalizedString("Share app", comment: ""))
    ]
    

    var bottombar : BottomNavBar!
    private lazy var settingsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 32, weight: .semibold)
        label.text = "Settings"
        label.textColor = "#404147".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .left
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var premiumEmptyView: UIView = {
        let view = UIView()
        view.backgroundColor = .black
        view.layer.cornerRadius = 34
        view.addBorder(width: 7, color: "404147", withAlphaComponent: 0.67)
        view.isUserInteractionEnabled = true
        return view
    }()
    
    private var premiumImageView: UIImageView = {
        let imageView = UIImageView(image: "premIcon".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private lazy var premiumLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .bold)
        label.backgroundColor = .clear
        label.textColor = .white
        label.textAlignment = .left
        label.text = NSLocalizedString("Get \nPremium", comment: "")
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.numberOfLines = 0
        return label
    }()
    
    private var premiumButton: UIButton = {
        let button = UIButton()
        return button
    }()
    
    private lazy var testImage: UIView = {
        let view = UIView()
        return view
    }()
    
    private lazy var testImage2: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 12
        return view
    }()
    
    private lazy var scrollView: UIScrollView = {
        let view = UIScrollView()
        view.isPagingEnabled = false
        view.isScrollEnabled = true
        view.showsVerticalScrollIndicator = false
        view.backgroundColor = "#F7F8FC".hexColor
        view.frame = self.view.bounds
        view.contentSize = CGSize(width: self.view.frame.width, height: 1100)
        view.autoresizingMask = .flexibleTopMargin
        view.bounces = true
        return view
    }()
    
    private var lineHorozontal: UIView = {
        let view = UIView()
        view.backgroundColor = "A4A4A4".hexColor.withAlphaComponent(0.35)
        return view
    }()
    
    private lazy var tableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 61
        table.backgroundColor = .clear
        table.separatorStyle = .none
        table.isScrollEnabled = false
        return table
    }()
    
    private lazy var tableViewTwo: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 61
        table.backgroundColor = .clear
        table.separatorStyle = .singleLine
        table.separatorColor = "#D7D8DB".hexColor
        table.separatorInset.left = 48
        table.isScrollEnabled = false
        return table
    }()
    
    let userDefaults = UserDefaults.standard
    var selectedIndex = 0
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
   
    private func setup() {
        bottombar = BottomNavBar(nav: self.navigationController!)
        configureLayout()
        checkPay()
        configureTableView()
        configureTableViewTwo()
        setupButtons()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        checkPay()
        navigationController?.isNavigationBarHidden = true
        navigationController?.navigationBar.isHidden = true
        tabBarController?.tabBar.isHidden = false
    }
    
    private func configureTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(OneSettingsCell.self, forCellReuseIdentifier: OneSettingsCell.nibIdentifier)
    }
    
    private func configureTableViewTwo() {
        tableViewTwo.delegate = self
        tableViewTwo.dataSource = self
        tableViewTwo.register(TwoSettingsCell.self, forCellReuseIdentifier: TwoSettingsCell.nibIdentifier)
    }
    
    private func configureLayout(){
        self.navigationController?.isNavigationBarHidden = true
        view.backgroundColor = "#F7F8FC".hexColor
        view.addSubview(scrollView)
        scrollView.addSubviews(settingsLabel, premiumEmptyView, testImage, testImage2)
        premiumEmptyView.addSubviews(premiumLabel, premiumImageView, premiumButton)
        testImage.addSubview(tableView)
        testImage2.addSubview(tableViewTwo)
        
        scrollView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.width.equalTo(UIScreen.main.bounds.width)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-10)
        }
        
        view.addSubview(bottombar)
        
        bottombar.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-25)
            make.centerX.equalToSuperview()
            make.width.equalTo(UIScreen.main.bounds.width - 124)
            make.height.equalTo(63)
        }
        
        settingsLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(45.resized())
            make.centerX.equalToSuperview()
            make.height.equalTo(32)
        }
        
        premiumEmptyView.snp.makeConstraints { make in
            make.top.equalTo(settingsLabel.snp.bottom).offset(30.resized())
            make.centerX.equalToSuperview()
            make.height.equalTo(175)
            make.width.equalTo(315)
        }
        
        premiumLabel.snp.makeConstraints { make in
            make.leading.equalToSuperview().offset(28)
            make.centerY.equalToSuperview()
            make.height.equalTo(64)
        }
        
        premiumImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.width.equalTo(194.88)
            make.height.equalTo(199)
            make.trailing.equalToSuperview().offset(9)
        }
        
        premiumButton.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        testImage.snp.makeConstraints { make in
            make.top.equalTo(premiumEmptyView.snp.bottom).offset(50.resized())
            make.centerX.equalToSuperview()
            make.height.equalTo(244)
            make.width.equalTo(UIScreen.main.bounds.width - 64)
        }
        
        testImage2.snp.makeConstraints { make in
            make.top.equalTo(testImage.snp.bottom).offset(38)
            make.centerX.equalToSuperview()
            make.height.equalTo(340)
            make.width.equalTo(UIScreen.main.bounds.width - 64)
        }
        
        tableView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        tableViewTwo.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(16)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview().offset(-16)
        }
        
        view.layoutIfNeeded()
        
        premiumEmptyView.layer.masksToBounds = false
        premiumEmptyView.layer.shadowColor = UIColor(red: 0.95, green: 0.58, blue: 0.22, alpha: 0.44).cgColor
        premiumEmptyView.layer.shadowOffset = CGSize(width: 0.0, height: 0.0)
        premiumEmptyView.layer.shadowOpacity = 1
        premiumEmptyView.layer.shadowRadius = 24
        premiumEmptyView.layer.masksToBounds = false

    }
    
    private func setupButtons() {
        premiumButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.premiumButtonImageAction()
        }.disposed(by: disposeBag)
    }
    
    private func premiumButtonImageAction(){
        IAPManager.shared().presentSubscriptionVC()
        IAPManager.shared().purchaseCompletion = { [weak self] _ in
            IAPManager.shared().dismissSubscriptionVC()
            guard let self = self else { return }
            self.checkPay()
        }
        IAPManager.shared().restoreCompletion = { subscription in
            if Constants.ud.isPurchased {
                IAPManager.shared().dismissSubscriptionVC()
                AlertManager.shared().showPurchasesWereRestored()
                self.checkPay()
            }
        }
    }
    
    func checkPay() {
        if IAPManager.shared().isPurchased {
            premiumEmptyView.isHidden = true

            testImage.snp.remakeConstraints { make in
                make.top.equalTo(settingsLabel.snp.bottom).offset(24.resized())
                make.centerX.equalToSuperview()
                make.height.equalTo(244)
                make.width.equalTo(UIScreen.main.bounds.width - 64)
            }
            scrollView.contentSize = CGSize(width: self.view.frame.width, height: 804)
        } else {
            print("No subscription ------------->")
        }
    }
    
    func pushPoliciesVC(_ policiesType: Policies) {
        let termsVC = PoliciesVC()
        termsVC.policiesType = policiesType
        navigationController?.pushViewController(termsVC, animated: true)
    }
    
    private func contact() {
        if MFMailComposeViewController.canSendMail() {
            let toRecipients = ["support@qrcodes-reader.com"]
            let subject = "Feedback"
            let mail = configuredMailComposeViewController(recipients: toRecipients, subject: subject, body: "", isHtml: true, images: nil)
            presentMailComposeViewController(mailComposeViewController: mail)
        } else {
            print("You don't have email in Mail iOS App")
        }
    }
    
    private func restore() {
        IAPManager.shared().restore()
        IAPManager.shared().restoreCompletion = { subscription in
            if Constants.ud.isPurchased {
                IAPManager.shared().dismissSubscriptionVC()
                AlertManager.shared().showPurchasesWereRestored()
                self.checkPay()
            }
        }
    }
}

extension SettingsVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == self.tableView {
            switch settingModels[indexPath.row].title {
            case NSLocalizedString("Batch Scan", comment: ""):
                if !IAPManager.shared().isPurchased {
                    Constants.ud.currentDismis = 2
                    IAPManager.shared().presentSingleSubscriptionVC()
                    IAPManager.shared().purchaseCompletion = { _ in
                        IAPManager.shared().dismissSubscriptionVC()
                        AlertManager.shared().showPurchaseComplite()
                    }
                    IAPManager.shared().restoreCompletion = { subscription in
                        IAPManager.shared().dismissSubscriptionVC()
                        if Constants.ud.isPurchased {
                            AlertManager.shared().showPurchasesWereRestored()
                        }
                    }
                } else {
                    Constants.ud.batchScanValue = !Constants.ud.batchScanValue
                    settingModels[indexPath.row].value = Constants.ud.batchScanValue
                }
            case NSLocalizedString("Vibrate", comment: ""):
                Constants.ud.vibrateValue = !Constants.ud.vibrateValue
                settingModels[indexPath.row].value = Constants.ud.vibrateValue

            case NSLocalizedString("History", comment: ""):
                if !IAPManager.shared().isPurchased {
                    Constants.ud.currentDismis = 2
                    IAPManager.shared().presentSingleSubscriptionVC()
                    IAPManager.shared().purchaseCompletion = { _ in
                        IAPManager.shared().dismissSubscriptionVC()
                        AlertManager.shared().showPurchaseComplite()
                    }
                    IAPManager.shared().restoreCompletion = { subscription in
                        IAPManager.shared().dismissSubscriptionVC()
                        if Constants.ud.isPurchased {
                            AlertManager.shared().showPurchasesWereRestored()
                        }
                    }
                } else {
                    Constants.ud.historyValue = !Constants.ud.historyValue
                    settingModels[indexPath.row].value = Constants.ud.historyValue
                }
            case NSLocalizedString("Dublicate Scans", comment: ""):
                    Constants.ud.dublicateScansValue = !Constants.ud.dublicateScansValue
                    settingModels[indexPath.row].value = Constants.ud.dublicateScansValue    
            default: print("Unknown")
            }
            self.tableView.reloadData()
        } else {
            switch settingModelsTwo[indexPath.row].title {
            case NSLocalizedString("Privacy Policy", comment: ""):
               pushPoliciesVC(.privacy)
            case NSLocalizedString("Terms of Use", comment: ""):
               pushPoliciesVC(.terms)
            case NSLocalizedString("Contact support", comment: ""):
                contact()
            case NSLocalizedString("Restore purchases", comment: ""):
                restore()
            case NSLocalizedString("Share app", comment: ""):
                share()
            default: print("Unknown")
            }
        }
    }
}
    
extension SettingsVC: UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.tableView {
            return settingModels.count
        } else {
            return settingModelsTwo.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView == self.tableView {
            let oneCell = tableView.dequeueReusableCell(withIdentifier: OneSettingsCell.nibIdentifier, for:  indexPath) as! OneSettingsCell
            let settingModel = settingModels[indexPath.row]
            oneCell.settingModel = settingModel
            return oneCell
        } else {
            let twoCell = tableViewTwo.dequeueReusableCell(withIdentifier: TwoSettingsCell.nibIdentifier, for:  indexPath) as! TwoSettingsCell
            let settingModelTwo = settingModelsTwo[indexPath.row]
            twoCell.settingModelTwo = settingModelTwo
            return twoCell
        }
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
    
    func share() {
        UIGraphicsBeginImageContext(view.frame.size)
        view.layer.render(in: UIGraphicsGetCurrentContext()!)
        
        let textToShare = "Check out my app"
    
        if let myWebsite = URL(string: "http://itunes.apple.com/app/\(Constants.app.appid)") {//Enter link to your app here
            let objectsToShare = [textToShare, myWebsite] as [Any]
            let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            activityVC.excludedActivityTypes = [UIActivity.ActivityType.airDrop, UIActivity.ActivityType.addToReadingList]
            activityVC.popoverPresentationController?.sourceView = self.view
            self.present(activityVC, animated: true, completion: nil)
        }
    }
}

struct SettingModel{
    var title: String?
    var value: Bool?
}

struct SettingModelTwo {
    var image: String?
    var title: String?
}
