import UIKit
import RxSwift
import SwiftUI

class StartViewController: UIViewController {
    
    private var centerImageView: UIImageView = {
        let imageView = UIImageView(image: "mainIcon".image)
        imageView.contentMode = .scaleAspectFit
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = 20
        return imageView
    }()
    
    private var сurtainImageView: UIImageView = {
        let imageView = UIImageView(image: "Curtain".image)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    private var nameAppLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .medium)
        label.textColor = "404147".hexColor
        label.textAlignment = .center
        label.text = "Qr scanner"
        return label
    }()
    
    var startHome = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup(){
        configureLayout()
    }
    
    private func configureLayout(){
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = .white
        view.addSubview(centerImageView)
        
        centerImageView.addSubviews(сurtainImageView)
        
        centerImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.width.equalTo(212)
            make.height.equalTo(212)
            make.centerX.equalToSuperview()
        }
        
        сurtainImageView.snp.makeConstraints { make in
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(106)
            make.bottom.equalToSuperview()
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.00) {
            self.startAnimanions()
        }
    }

    private func startAnimanions() {
        UIView.animate(withDuration: 1.5) {
            self.сurtainImageView.snp.updateConstraints{ make in
                make.bottom.equalToSuperview().offset(106)
            }
            self.view.layoutIfNeeded()
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.9) {
            self.stopAnimations()
        }
    }
    
    private func stopAnimations(){
        UIView.animate(withDuration: 1.5) {
        self.сurtainImageView.snp.updateConstraints{ make in
            make.bottom.equalToSuperview()
        }
        self.view.layoutIfNeeded()
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.9) {
            UIView.animate(withDuration: 1.5) {
                self.сurtainImageView.snp.updateConstraints{ make in
                    make.bottom.equalToSuperview().offset(106)
                }
                self.view.layoutIfNeeded()

            }

        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.9) {
            let vc = LaunchScreenViewController()
            self.navigationController?.pushViewController(vc, animated: true)
        }

    }

}
