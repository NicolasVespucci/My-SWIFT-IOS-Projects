import UIKit
import RxSwift
import SwiftyStoreKit
import StoreKit
import SwiftyAttributes
import IHProgressHUD

class SubscriptionsViewController: UIViewController {
    
    var identifiers = [Constants.analytics.week, Constants.analytics.threeMonth, Constants.analytics.year]

    private var topImageView: UIImageView = {
        let imageView = UIImageView(image: "pay2Top".image)
        imageView.contentMode = .scaleAspectFill
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    private var topBackButton: UIButton = {
        let button = UIButton()
        button.setImage("topBack".image, for: .normal)
        return button
    }()
    
    private var restoreButton: UIButton = {
        let button = UIButton()
        button.setImage("restoreMain".image, for: .normal)
        return button
    }()
    
    private lazy var payCollectionView: UICollectionView = {
        let collection = UICollectionView(frame: .zero, collectionViewLayout: .init())
        collection.backgroundColor = .clear
        collection.showsHorizontalScrollIndicator = false
        collection.showsVerticalScrollIndicator = false
        collection.isScrollEnabled = true
        collection.clipsToBounds = false
        collection.isScrollEnabled = false
        return collection
    }()
    
    private lazy var payLayout: UICollectionViewLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 0
        layout.itemSize = .init(width: (UIScreen.main.bounds.width - 64), height: 64)
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 8
        layout.sectionInset = .init(top: 0, left: 0, bottom: 0, right: 0)
        return layout
    }()
    
    private var enjoyLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.textColor = "74757A".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.text = "Enjoy full version \n app without ads"
        label.numberOfLines = 2
        return label
    }()
    
    
    private var buyButton: UIButton = {
        let button = UIButton()
        button.setTitle(NSLocalizedString("BUY", comment: ""), for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .medium)
        return button
    }()
    
    var productsDescription: NSAttributedString {
        let terms = NSLocalizedString("Terms", comment: "") + " " + NSLocalizedString("of", comment: "") + " " + NSLocalizedString("Use", comment: "")
        let privacy = NSLocalizedString("Privacy", comment: "") + NSLocalizedString(" ", comment: "") + NSLocalizedString("Policy", comment: "")
        let and = " & "
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        
        let textAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12, weight: .medium)),
            .textColor("414860".hexColor.withAlphaComponent(0.7)),
            .paragraphStyle(paragraphStyle)
        ]
        
        let andAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12, weight: .medium)),
            .textColor("414860".hexColor.withAlphaComponent(0.4)),
            .paragraphStyle(paragraphStyle)
        ]
        
        let attributedDescription =
        terms.withAttributes(textAttributes)
        + and.withAttributes(andAttributes)
        + privacy.withAttributes(textAttributes)
        return attributedDescription
    }
    
    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.layoutIfNeeded()
        textView.isEditable = false
        textView.isSelectable = false
        textView.isScrollEnabled = false
        textView.backgroundColor = .clear
        textView.showsVerticalScrollIndicator = true
        textView.attributedText = productsDescription
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapResponse(recognizer:)))
        textView.addGestureRecognizer(tap)
        return textView
    }()
    
    let disposeBag = DisposeBag()
    var products = [SKProduct]()
        
    var selectedIndex = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
    }

    private func setup() {
        configureUpdateProducts()
        configureLayout()
        setupShoppingCollection()
        setupButtons()
    }
    
    private func configureLayout() {
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = "F7F8FC".hexColor
        view.addSubviews(topImageView, topBackButton, restoreButton, payCollectionView, enjoyLabel, buyButton, textView)
        
        topImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(30)
            make.centerX.equalToSuperview()
            make.size.equalTo(320)
        }
        
        topBackButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(52.resized())
            make.leading.equalToSuperview().offset(17)
            make.size.equalTo(35)
        }
        
        restoreButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(50.resized())
            make.trailing.equalToSuperview().offset(-21)
            make.size.equalTo(22)
        }
        
        payCollectionView.snp.makeConstraints { make in
            make.top.equalTo(topImageView.snp.bottom).offset(30)
            make.height.equalTo(210)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
        }
        
        enjoyLabel.snp.makeConstraints { make in
            make.bottom.equalTo(buyButton.snp.top).offset(-10.resized())
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(40)
        }
        
        buyButton.snp.makeConstraints { make in
            make.bottom.equalTo(textView.snp.top).offset(-10.resized())
            make.leading.equalToSuperview().offset(58)
            make.trailing.equalToSuperview().offset(-58)
            make.height.equalTo(50)
        }
        
        textView.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-15.resized())
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(30)
        }
       
        view.layoutIfNeeded()
        buyButton.addGradient(.topBottom, ["FFB648".hexColor, "F29337".hexColor], 20)
        
        view.layoutSubviews()
        
        IAPManager.shared().productsReceived.bind { [weak self] received in
            if received {
                self?.payCollectionView.reloadData()
            } else {
                self?.configureUpdateProducts()
            }
        }.disposed(by: disposeBag)
        
        IAPManager.shared().productsReceived.bind { [weak self] received in
            if received {
                self?.payCollectionView.reloadData()
            } else {
                self?.configureUpdateProducts()
                self?.payCollectionView.reloadData()
            }
        }.disposed(by: disposeBag)
    }
    
    private func setupShoppingCollection() {
        payCollectionView.setCollectionViewLayout(payLayout, animated: true)
        payCollectionView.dataSource = self
        payCollectionView.delegate = self
        payCollectionView.register(SecondShoppingCell.self, forCellWithReuseIdentifier: SecondShoppingCell.nibIdentifier)
    }
    
    private func setupButtons() {
        topBackButton.rx.tap.bind { [weak self] in
            self?.dismiss(animated: true)
        }.disposed(by: disposeBag)
    
        restoreButton.rx.tap.bind {
            IAPManager.shared().restore()
            IAPManager.shared().restoreCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                    AlertManager.shared().showPurchasesWereRestored()
                }
            }
        }.disposed(by: disposeBag)
        
        buyButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            let product = self.identifiers[self.selectedIndex]
            IAPManager.shared().purchase(rcPackage: product, quantity: 1, atomically: true)
        }.disposed(by: disposeBag)
    }

    private func configureUpdateProducts() {
        IHProgressHUD.show()
        SwiftyStoreKit.retrieveProductsInfo([Constants.analytics.week, Constants.analytics.threeMonth, Constants.analytics.year]) { result in
            if(!result.retrievedProducts.isEmpty) {
                self.products = Array(result.retrievedProducts).sorted(by: { Product(product: $0).price < Product(product: $1).price })
                self.payCollectionView.reloadData()
                IHProgressHUD.dismiss()
            } else {
                IHProgressHUD.dismiss()
                self.configureUpdateProducts()
            }
        }
    }
    
    deinit {
        IHProgressHUD.dismiss()
    }
}

//MARK: - CollectionView
extension SubscriptionsViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedIndex = indexPath.item
        let apphudProduct = self.products[selectedIndex]
        //configurePriceLabel(product: apphudProduct)
        payCollectionView.reloadData()
        if IAPManager.shared().isPurchased {
            IAPManager.shared().dismissSubscriptionVC()
        }
    }
}

extension SubscriptionsViewController: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return products.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SecondShoppingCell.nibIdentifier, for: indexPath) as! SecondShoppingCell
        let apphudProduct = products[indexPath.item]
        let product = Product(product: apphudProduct)
        print(product)
        cell.product = product
        if indexPath.item == self.selectedIndex {
            product.type == .renewable(.trial) ? cell.configureTrialSelected() : cell.configureCommonSelected()
        } else {
            product.type == .renewable(.trial) ? cell.configureTrial() : cell.configureCommon()
        }
        return cell
    }
}

//MARK: - Text View
extension SubscriptionsViewController {
    @objc func tapResponse(recognizer: UITapGestureRecognizer) {
        let location: CGPoint = recognizer.location(in: textView)
        let position: CGPoint = CGPoint(x: location.x, y: location.y)
        let tapPosition: UITextPosition? = textView.closestPosition(to: position)
        if tapPosition != nil {
            let textRange: UITextRange? = textView.tokenizer.rangeEnclosingPosition(tapPosition!, with: UITextGranularity.word, inDirection: UITextDirection(rawValue: 1))
            if textRange != nil
            {
                let tappedWord: String? = textView.text(in: textRange!)
                guard let word = tappedWord else { return }
                wordAction(word)
            }
        }
    }
    
    private func wordAction(_ word: String) {
        switch word {
        case NSLocalizedString("Terms", comment: ""), NSLocalizedString("of", comment: ""), NSLocalizedString("Use", comment: ""): pushPoliciesVC(.terms)
            
        case NSLocalizedString("Privacy", comment: ""),NSLocalizedString("and", comment: ""), NSLocalizedString("Policy", comment: ""): pushPoliciesVC(.privacy)
        default: break
        }
    }
    
    func pushPoliciesVC(_ policiesType: Policies) {
        let termsVC = PoliciesVC()
        termsVC.policiesType = policiesType
        navigationController?.pushViewController(termsVC, animated: true)
    }
}
