//
//  ViewController.swift
//  QReader
//
//  Created by iMac 27 on 30.03.2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}

