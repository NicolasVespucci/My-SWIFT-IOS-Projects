//
//  WelcomeVC.swift
//  QReader
//
//  Created by iMac 27 on 30.03.2022.
//

import UIKit
import SnapKit
import RxSwift
import RxCocoa

class WelcomeVC: UIViewController, UIScrollViewDelegate {
    
    
    var xOffSet: CGFloat = UIScreen.main.bounds.width
    var contentWidth: CGFloat = 0.0
    let disposeBag = DisposeBag()
    
    private lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.backgroundColor = .clear
        scrollView.isScrollEnabled = false
       return scrollView
    }()
    
    private lazy var mainButton: UIButton = {
        let button = UIButton()
        button.setImage("startButton".image, for: .normal)
     
       return button
    }()
    
    private lazy var pageImageView: UIImageView = {
        let imageView = UIImageView(image: "ic_welcome_page_1".image)
        imageView.contentMode = .scaleAspectFit
       return imageView
    }()
    
    private lazy var firstWelcomeView = WelcomeStartView(model: ("ic_welcome_1", "APP NAME", "Some nice description hereSome nice description hereSome nice description hereSome nice description here"))
    private lazy var secondWelcomeView = WelcomeStartView(model: ("ic_welcome_2", "Start scanning", "Some nice description hereSome nice description hereSome nice description hereSome nice description here"))
    
    private lazy var thirdWelcomeView = WelcomeStartView(model: ("ic_welcome_3", "Start scanning", "Some nice description hereSome nice description hereSome nice description hereSome nice description here"))

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isHidden = true
        setup()
    }
    
    private func setup() {
        configureLayout()
        
        mainButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.scrollView.setContentOffset(CGPoint(x: UIScreen.main.bounds.width, y: 0), animated: true)
        }.disposed(by: disposeBag)
        
      
    }
    
    private func configureLayout() {
        view.backgroundColor = .white
        
        view.addSubviews(scrollView, mainButton, pageImageView)
        
        scrollView.snp.makeConstraints {
            $0.top.equalToSuperview()
            $0.leading.equalToSuperview()
            $0.width.equalToSuperview()
            $0.height.equalTo(542.resized())
        }
        
        mainButton.snp.makeConstraints {
            $0.top.equalTo(scrollView.snp.bottom).offset(35.resized())
            $0.width.equalTo(296.resized(.width))
            $0.centerX.equalToSuperview()
            $0.height.equalTo(90)
        }
        
        pageImageView.snp.makeConstraints {
            $0.bottom.equalToSuperview().inset(42.resized())
            $0.centerX.equalToSuperview()
            $0.width.equalTo(89)
            $0.height.equalTo(9)
        }
        centerScrollView()
        self.scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: false)
    }
    
        private func centerScrollView() {
            scrollView.delegate = self
            let viewsForScroll = [firstWelcomeView, secondWelcomeView, thirdWelcomeView];
    
            for (index, view) in viewsForScroll.enumerated() {
                scrollView.addSubview(view)
    
                view.snp.makeConstraints { make in
                    make.top.equalToSuperview()
                    make.bottom.equalToSuperview()
                    make.leading.equalToSuperview().offset(CGFloat(index) * UIScreen.main.bounds.width)
                    make.width.equalToSuperview()
                }
    
                self.view.layoutIfNeeded()
                self.scrollView.layoutIfNeeded()
    
                contentWidth += self.view.frame.width
            }
    
            scrollView.contentSize = CGSize(width: contentWidth, height: scrollView.frame.height)
        }
    
    internal func scrollViewDidScroll(_ scrollView: UIScrollView){
//           pageControl.currentPage = Int(scrollView.contentOffset.x / UIScreen.main.bounds.width)
//           if pageControl.currentPage == 3 {
//               pageControl.isHidden = true
//               mainButton.isHidden = false
//           } else if pageControl.currentPage == 1  {
//               pageControl.isHidden = false
//               mainButton.isHidden = true
//           }
       }
    
}
