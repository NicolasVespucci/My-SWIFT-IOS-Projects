//
//  BottomNavBar.swift
//  QReader
//
//  Created by iMac 21 on 31/03/2022.
//

import Foundation
import UIKit
import SnapKit
import RxSwift
import RxCocoa
import MessageUI

class BottomNavBar: UIView {
    
 
    let disposeBag = DisposeBag()
    
    var navigationController = UINavigationController()
    
    var scannerButton : UIButton = {
        let button = UIButton()
         
        button.setImage("scanner".image, for: .normal)
        button.contentMode = .scaleAspectFit
         return button
     }()
    
    var plusButton : UIButton = {
        let button = UIButton()
         
        button.setImage("plus".image, for: .normal)
        button.contentMode = .scaleAspectFit
         return button
     }()
    
    var recentButton : UIButton = {
        let button = UIButton()
         
        button.setImage("recent".image, for: .normal)
        button.contentMode = .scaleAspectFit
         return button
     }()
    
    var settingsButton : UIButton = {
        let button = UIButton()
         
        button.setImage("settings".image, for: .normal)
        button.contentMode = .scaleAspectFit
         return button
     }()
    
    
    
    required init(nav: UINavigationController) {
   //     self.customParam = customParamArg
        super.init(frame: .zero)
        self.navigationController = nav
        
        var currentController = self.navigationController.topViewController?.className
        
        switch currentController {
        case "QRScannerController" :
            scannerButton.setImage("scannerHigh".image, for: .normal)
        case "RecentsViewController" :
            recentButton.setImage("recentHigh".image, for: .normal)
        case "MyCodesVC" :
            plusButton.setImage("plusHigh".image, for: .normal)
        case "SettingsVC" :
            settingsButton.setImage("settingHigh".image, for: .normal)
        default :
            print("def")
        }
        
        setupView()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

    func setupView() {
        setupConstraints()
        
        recentButton.rx.tap.bind { [weak self] in
            Constants.ud.currentDismis = 2
            if !IAPManager.shared().isPurchased {
                IAPManager.shared().presentSingleSubscriptionVC()
                IAPManager.shared().purchaseCompletion = { _ in
                    IAPManager.shared().dismissSubscriptionVC()
                    AlertManager.shared().showPurchaseComplite()
                    if(self?.navigationController.topViewController?.className != "RecentsViewController"){
                        self?.navigationController.pushViewController(RecentsViewController(), animated: true)
                    }
                }
                IAPManager.shared().restoreCompletion = { subscription in
                    IAPManager.shared().dismissSubscriptionVC()
                    if Constants.ud.isPurchased {
                        AlertManager.shared().showPurchasesWereRestored()
                        if(self?.navigationController.topViewController?.className != "RecentsViewController"){
                            self?.navigationController.pushViewController(RecentsViewController(), animated: true)
                        }
                    }
                }
            } else {
                if(self?.navigationController.topViewController?.className != "RecentsViewController"){
                    self?.navigationController.pushViewController(RecentsViewController(), animated: true)
                }
            }
            
         
          
        }.disposed(by: disposeBag)
        
        scannerButton.rx.tap.bind { [weak self] in
            if(self?.navigationController.topViewController?.className != "QRScannerController"){
                self?.navigationController.pushViewController(QRScannerController(), animated: true)
            }
          
        }.disposed(by: disposeBag)
        
        plusButton.rx.tap.bind { [weak self] in
            if(self?.navigationController.topViewController?.className != "MyCodesVC"){
                self?.navigationController.pushViewController(MyCodesVC(), animated: true)
            }
          
        }.disposed(by: disposeBag)
        
        settingsButton.rx.tap.bind { [weak self] in
            
            if(self?.navigationController.topViewController?.className != "SettingsVC"){
                self?.navigationController.pushViewController(SettingsVC(), animated: true)
            }
          
        }.disposed(by: disposeBag)
        
    }
    
    func setupConstraints() {
      
        self.backgroundColor = .white
        self.layer.cornerRadius = 20
        
        self.addSubviews(scannerButton, plusButton, settingsButton, recentButton)
        
        scannerButton.snp.makeConstraints { make in
            make.size.equalTo(35.resized())
            make.leading.equalToSuperview().offset(17.resized(.width))
            make.centerY.equalToSuperview()
        }
        
        plusButton.snp.makeConstraints { make in
            make.size.equalTo(35.resized())
            make.leading.equalToSuperview().offset(77.5.resized(.width))
            make.centerY.equalToSuperview()
        }
        
        recentButton.snp.makeConstraints { make in
            make.size.equalTo(35.resized())
            make.trailing.equalToSuperview().offset(-77.5.resized(.width))
            make.centerY.equalToSuperview()
        }
        
        settingsButton.snp.makeConstraints { make in
            make.size.equalTo(35.resized())
            make.trailing.equalToSuperview().offset(-17.resized(.width))
            make.centerY.equalToSuperview()
        }
    }
}



extension UIViewController {
    var className: String {
                    NSStringFromClass(self.classForCoder).components(separatedBy: ".").last!
                }
}
