import UIKit
import StoreKit

class SecondShoppingCell: UICollectionViewCell {

    private lazy var cellView: UIView = {
        let cell = UIView()
        cell.layer.cornerRadius = 21
        cell.clipsToBounds = false
        cell.backgroundColor = "F9A440".hexColor
        return cell
    }()
    
    private lazy var periodAndPriceLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .semibold)
        label.textColor = "404147".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .left
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private lazy var trialLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 13, weight: .semibold)
        label.textColor = "74757A".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .left
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private lazy var checkMarkImage: UIImageView = {
        let imageView = UIImageView(image: "check".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    var product: Product?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
   
    public func configureTrial() {
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubviews(periodAndPriceLabel, trialLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
                
        periodAndPriceLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(16)
            make.height.equalTo(24)
        }
        
        trialLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-50)
            make.height.equalTo(16)
        }
       
        cellView.backgroundColor = "FFFFFF".hexColor
        cellView.addBorder(width: 2, color: "000000")
        periodAndPriceLabel.textColor = "404147".hexColor
        trialLabel.textColor = "404147".hexColor
        trialLabel.text = (product.introductory?.period?.formattedString ?? "asda") + NSLocalizedString(" free trial", comment: "")
        periodAndPriceLabel.text = periodString + " • " + price
        checkMarkImage.isHidden = true
        layoutSubviews()
    }
    
    public func configureCommon() {
        
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubview(periodAndPriceLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        periodAndPriceLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(16)
            make.height.equalTo(24)
        }
    
        cellView.backgroundColor = "FFFFFF".hexColor
        cellView.addBorder(width: 2, color: "000000")
        periodAndPriceLabel.textColor = "404147".hexColor
        
        periodAndPriceLabel.text = periodString + " • " + price
        checkMarkImage.isHidden = true
        layoutIfNeeded()
        layoutSubviews()
    }
    
    public func configureTrialSelected() {
        
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubviews(trialLabel, periodAndPriceLabel, checkMarkImage)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
                
        periodAndPriceLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(16)
            make.height.equalTo(24)
        }
        
        trialLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-50)
            make.height.equalTo(16)
        }
        
        checkMarkImage.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-16)
            make.width.equalTo(9)
            make.height.equalTo(6)
        }
        
        cellView.addGradient(.topLeftBottomRight, ["FFB648".hexColor, "F9A440".hexColor], 21)
        periodAndPriceLabel.textColor = "404147".hexColor
        trialLabel.textColor = "FFFFFF".hexColor
        trialLabel.text = (product.introductory?.period?.formattedString ?? "asda") + NSLocalizedString(" free trial", comment: "")
        periodAndPriceLabel.text = periodString + " • " + price
        checkMarkImage.isHidden = false
        layoutIfNeeded()
        layoutSubviews()
    }
    
    public func configureCommonSelected() {
        
        cellView.subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        subviews.forEach({
            $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
            $0.removeBorders()
            $0.removeFromSuperview()
        })
        
        clipsToBounds = true
        guard let product = product else { return }
        guard let period = product.period else { return }
        let periodString = period.formattedString // MONTHLY
        let perPeriodString = period.perFormattedString.capitalized // MONTH
        let price = product.localizedPrice
        let introductoryPeriod = product.introductory?.period?.formattedString ?? "asda"
        
        addSubview(cellView)
        cellView.addSubviews(periodAndPriceLabel, checkMarkImage)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        periodAndPriceLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(16)
            make.height.equalTo(24)
        }
        
        checkMarkImage.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-16)
            make.width.equalTo(9)
            make.height.equalTo(6)
        }
        
        cellView.addGradient(.topLeftBottomRight, ["FFB648".hexColor, "F9A440".hexColor], 21)
        periodAndPriceLabel.textColor = "404147".hexColor
        periodAndPriceLabel.text = periodString + " • " + price
        checkMarkImage.isHidden = false
        
        layoutIfNeeded()
        layoutSubviews()
    }
}

