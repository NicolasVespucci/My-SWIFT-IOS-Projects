//
//  SettingsCells.swift
//  QReader
//
//  Created by iMac 21 on 04/04/2022.
//

import Foundation
import UIKit
import SnapKit

class OneSettingsCell: UITableViewCell {
    
    var settingModel: SettingModel? {
        didSet { configurePayModel() }
    }
    
    private lazy var mainView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.clipsToBounds = true
        view.layer.cornerRadius = 14
        return view
    }()
    
    private lazy var settingsImageView: UIImageView = {
        let imageView = UIImageView(image: "".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private lazy var nameCellLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16)
        label.textColor = "404147".hexColor
        label.minimumScaleFactor = 0.5
        label.textAlignment = .left
        return label
    }()
    
    public lazy var switchButton: UISwitch = {
        let button = UISwitch()
        button.tintColor = .white
        button.onTintColor = "F29538".hexColor
        return button
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        selectionStyle = .none
        configureLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureLayout() {
        addSubview(mainView)
        mainView.addSubviews(settingsImageView, nameCellLabel, switchButton)
        
        mainView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(53)
        }
        
        nameCellLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(13)
            make.trailing.equalTo(switchButton.snp.leading).offset(-10)
            make.height.equalTo(22)
        }
        
        switchButton.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-16)
            make.height.equalTo(31)
            make.width.equalTo(51)
        }
    }

    private func configurePayModel() {
        guard let settingModel = settingModel else { return }
 //       settingsImageView.image = settingModel.image?.image
        nameCellLabel.text = settingModel.title
        switchButton.isOn = settingModel.value ?? false
    }
}



class TwoSettingsCell: UITableViewCell {
    
    var settingModelTwo: SettingModelTwo? {
        didSet { configurePayModelTwo() }
    }
    
    private lazy var mainView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()
    
    private lazy var settingsImageView: UIImageView = {
        let imageView = UIImageView(image: "".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private lazy var nameCellLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16)
        label.adjustsFontSizeToFitWidth = true
        label.textColor = "404147".hexColor
        return label
    }()
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        selectionStyle = .none
        configureLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureLayout() {
        addSubview(mainView)
        mainView.addSubviews(settingsImageView, nameCellLabel)
        
        mainView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        settingsImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(16)
            make.size.equalTo(24)
        }
        
        nameCellLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalTo(settingsImageView.snp.trailing).offset(8)
            make.height.equalTo(24)
            make.width.equalTo(200)
        }
    }
    
    private func configurePayModelTwo() {
        guard let settingModelTwo = settingModelTwo else { return }
        settingsImageView.image = settingModelTwo.image?.image
        nameCellLabel.text = settingModelTwo.title
    }
}
