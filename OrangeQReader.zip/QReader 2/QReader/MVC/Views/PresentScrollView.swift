import UIKit

class PresentScrollView: UIView {

    var image: UIImage?
    var topText: String?
    var bottomText: String?
    
    private lazy var centerImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()

    private lazy var firstLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 28, weight: .semibold)
        label.textColor = "404147".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .left
        return label
    }()
    
    private lazy var secondLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.textColor = "74757A".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textAlignment = .left
        label.numberOfLines = 0
        return label
    }()

    init(image: UIImage, topText: String, bottomText: String) {
        super.init(frame: .zero)
        self.image = image
        self.topText = topText
        self.bottomText = bottomText
        isUserInteractionEnabled = true
        launch()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func launch() {
        configureLayout()
        configureViewContent()
    }
    
    private func configureLayout() {
        addSubviews(centerImageView)
        centerImageView.addSubviews(firstLabel, secondLabel)
        
        centerImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(29)
            make.centerX.equalToSuperview()
            make.size.equalTo(333)
        }
    
        firstLabel.snp.makeConstraints { make in
            make.top.equalTo(centerImageView.snp.bottom)
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(32)
        }
        
        secondLabel.snp.makeConstraints { make in
            make.top.equalTo(firstLabel.snp.bottom).offset(14)
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(72)
        }
    }
    
    private func configureViewContent() {
        centerImageView.image = image
        firstLabel.text = topText
        secondLabel.text = bottomText
    }

}

