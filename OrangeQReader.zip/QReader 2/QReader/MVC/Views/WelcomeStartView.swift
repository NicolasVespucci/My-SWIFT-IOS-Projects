//
//  WelcomeStartView.swift
//  QReader
//
//  Created by iMac 27 on 30.03.2022.
//

import UIKit
import SnapKit
import RxSwift
import RxCocoa

class WelcomeStartView: UIView {

    private lazy var mainImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
       return imageView
    }()
    
    private lazy var topLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 28, weight: .semibold)
        label.adjustsFontSizeToFitWidth = true
        label.textColor = "404147".hexColor
       return label
    }()
    
    private lazy var bottomLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 28, weight: .semibold)
        label.minimumScaleFactor = 0.5
        label.textColor = "74757A".hexColor
        label.numberOfLines = 3
       return label
    }()
    
    init(model: (image: String, topText: String, bottomText: String)) {
        super.init(frame: .zero)
        configureLayout()
        setViewData(image: model.image, topText: model.topText, bottomText: model.bottomText)
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        configureLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureLayout() {
        addSubviews(mainImageView, topLabel, bottomLabel)
        
        mainImageView.snp.makeConstraints {
            $0.top.equalToSuperview()
            $0.leading.equalToSuperview()
            $0.trailing.equalToSuperview()
            $0.height.equalTo(362.resized())
        }
        
        topLabel.snp.makeConstraints {
            $0.top.equalTo(mainImageView.snp.bottom)
            $0.leading.equalToSuperview().offset(32)
            $0.height.equalTo(26)
        }
        
        bottomLabel.snp.makeConstraints {
            $0.top.equalTo(topLabel.snp.bottom).offset(14)
            $0.leading.equalToSuperview().offset(32)
            $0.height.equalTo(72.resized())
            $0.width.equalTo(311.resized(.width))
        }
    }
    
    private func setViewData(image: String, topText: String, bottomText: String) {
        mainImageView.image = image.image
        topLabel.text = topText
        bottomLabel.text = bottomText
    }
}
