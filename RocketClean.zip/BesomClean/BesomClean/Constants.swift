import Foundation
import UIKit
import Contacts

var UD = UserDefaults.standard

public struct Constants {
    
    static var app = AppConstants()
    static var analytics = AnalyticsConstants()
    static var ud = UDConstants()
    
    struct AnalyticsConstants {
//        let week = "week.plan.bes"
//        let threeMonth = "month.plan.bes"
//        let year = "annual.plan.bes"
        
//        name - RocketClean
//        bundle - com.clean.applic
        
//        week -  rclean.week
//        month - rclean.month
//        annual - rclean.annual
        
        let week = "rclean.week"
        let threeMonth = "rclean.month"
        let year = "rclean.annual"
    }
    
    struct AppConstants {
     
        let appid = "1625910340"
    }
    
    struct UDConstants {
        
        var adsBlockedCount: Int? {
            set { UD.set(newValue, forKey: "adsBlockedCount") }
            get { return UD.integer(forKey: "adsBlockedCount") }
        }
        
        var adsSwitchActive: [String] {
            set { UD.set(newValue, forKey: "adsSwitchActive") }
            get { return UD.stringArray(forKey: "adsSwitchActive") ?? [] }
        }
        
//        var dataContacts: [Data] {
//            set { UD.set(newValue, forKey: "dataContacts") }
//            get { return UD.object(forKey: "dataContacts") as! [Data] }
//        }
        var dataContacts: [Any] {
            set { UD.set(newValue, forKey: "dataContacts") }
            get { return UD.array(forKey: "dataContacts") ?? [] }
        }
        
        var datebackUpContacts: [String] {
            set { UD.set(newValue, forKey: "datebackUpContacts") }
            get { return UD.stringArray(forKey: "datebackUpContacts") ?? [] }
        }

        
//        var countAllBackUpContacts: [String] {
//            set { UD.set(newValue, forKey: "backUpContacts") }
//            get { return UD.stringArray(forKey: "backUpContacts") ?? [] }
//        }
        
        var backUpContacts: [String] {
            set { UD.set(newValue, forKey: "backUpContacts") }
            get { return UD.stringArray(forKey: "backUpContacts") ?? [] }
        }
        
        var didAcceptPrivacy: Bool {
            get { return UD.bool(forKey: UserDefaults.Keys.didAcceptPrivacy) }
            set { UD.set(newValue, forKey: UserDefaults.Keys.didAcceptPrivacy) }
        }
        
        var isPurchased : Bool {
            get { return UD.bool(forKey: UserDefaults.Keys.isPurchased) }
            set { UD.set(newValue, forKey: UserDefaults.Keys.isPurchased) }
        }
        
        var didAddObserver: Bool {
            get { return UD.bool(forKey: "observer") }
            set { UD.set(newValue, forKey: "observer") }
        }
        
        var blockAdsSwitchValue: Bool {
            get { return UD.bool(forKey: "blockAdsSwitchValue") }
            set { UD.set(newValue, forKey: "blockAdsSwitchValue") }
        }
        
        var blockSocialSwitchValue: Bool {
            get { return UD.bool(forKey: "blockSocialSwitchValue") }
            set { UD.set(newValue, forKey: "blockSocialSwitchValue") }
        }
        
        var blockScriptsSwitchValue: Bool {
            get { return UD.bool(forKey: "blockScriptsSwitchValue") }
            set { UD.set(newValue, forKey: "blockScriptsSwitchValue") }
        }
        
        var blockTrackingSwitchValue: Bool {
            get { return UD.bool(forKey: "blockTrackingSwitchValue") }
            set { UD.set(newValue, forKey: "blockTrackingSwitchValue") }
        }
        
        var blockURLSSwitchValue: Bool {
            get { return UD.bool(forKey: "blockURLSSwitchValue") }
            set { UD.set(newValue, forKey: "blockURLSSwitchValue") }
        }
        
        var currentAdBlockerValue: Int? {
            set { UD.set(newValue, forKey: "currentAdBlockerValue") }
            get { return UD.integer(forKey: "currentAdBlockerValue") }
        }
        
        //
        var currentDismis: Bool {
            get { return UD.bool(forKey: "currentDismis") }
            set { UD.set(newValue, forKey: "currentDismis") }
        }
        
        var currentDismissing: Int? {
            set { UD.set(newValue, forKey: "currentDismissing") }
            get { return UD.integer(forKey: "currentDismissing") }
        }
        
        var currentRestoreDismissing: Int? {
            set { UD.set(newValue, forKey: "currentDismissing") }
            get { return UD.integer(forKey: "currentDismissing") }
        }

        
        
    }
    
    static var country: String = {
        let locale: NSLocale = NSLocale(localeIdentifier: "en_US")
        if let countryCode = locale.object(forKey: NSLocale.Key.countryCode) as? String,
           let country = locale.displayName(forKey: NSLocale.Key.countryCode, value: countryCode) {
            print(country)
            return country
        }
        return "unsigned"
    }()
}
