

import Foundation

extension Date {
  var string: String {
    let formatter = DateFormatter()
    formatter.dateFormat = "dd.MM.yyyy"
    return formatter.string(from: self)
  }
  
  func string(with format: String) -> String {
    let formatter = DateFormatter()
    formatter.dateFormat = format
    return formatter.string(from: self)
  }
  
  func years(sinceDate: Date) -> Int? {
    return Calendar.current.dateComponents([.year], from: sinceDate, to: self).year
  }
  
  func months(sinceDate: Date) -> Int? {
    return Calendar.current.dateComponents([.month], from: sinceDate, to: self).month
  }
  
  func days(sinceDate: Date) -> Int? {
    return Calendar.current.dateComponents([.day], from: sinceDate, to: self).day
  }
  
  func hours(sinceDate: Date) -> Int? {
    return Calendar.current.dateComponents([.hour], from: sinceDate, to: self).hour
  }
  
  func minutes(sinceDate: Date) -> Int? {
    return Calendar.current.dateComponents([.minute], from: sinceDate, to: self).minute
  }
  
  func seconds(sinceDate: Date) -> Int? {
    return Calendar.current.dateComponents([.second], from: sinceDate, to: self).second
  }
  
  func dayNumberOfWeek() -> Int? {
    return Calendar.current.dateComponents([.weekday], from: self).weekday
  }
  
  func convertNextDate(days: Int) -> Date {
      let dateFormatter = DateFormatter()
      let tomorrow = Calendar.current.date(byAdding: .day, value: days, to: self)
      return tomorrow ?? Date()
  }
}
