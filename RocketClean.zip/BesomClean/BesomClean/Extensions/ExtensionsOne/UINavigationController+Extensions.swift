



import Foundation
import UIKit

extension UINavigationController {
  
  open override func viewDidLoad() {
    super.viewDidLoad()
    interactivePopGestureRecognizer?.delegate = nil
    makeClearBar(color: .white)
  }
  
  public func makeClearBar(color: UIColor) {
    if #available(iOS 13.0, *) {
      let navBarAppearance = UINavigationBarAppearance()
      navBarAppearance.configureWithOpaqueBackground()
      navBarAppearance.shadowImage = nil
      navBarAppearance.shadowColor = nil
      navBarAppearance.backgroundColor = color
      navBarAppearance.backgroundImage = UIImage()
      navBarAppearance.titleTextAttributes = [.foregroundColor: UIColor.black, .font: UIFont.systemFont(ofSize: 17, weight: .semibold)]
        navBarAppearance.largeTitleTextAttributes = [.foregroundColor: UIColor.black, .font: UIFont.systemFont(ofSize: 34, weight: .semibold)]
      navigationBar.standardAppearance = navBarAppearance
      navigationBar.prefersLargeTitles = true
      navigationItem.largeTitleDisplayMode = .automatic
    } else {
      navigationBar.titleTextAttributes = [.foregroundColor: UIColor.black, .font: UIFont.systemFont(ofSize: 17, weight: .semibold)]
      navigationBar.largeTitleTextAttributes = [.foregroundColor: UIColor.black, .font: UIFont.systemFont(ofSize: 34, weight: .semibold)]
      navigationBar.shadowImage = UIImage()
      navigationBar.setBackgroundImage(UIImage(), for: .default)
      navigationBar.backgroundColor = color
      navigationBar.prefersLargeTitles = true
      navigationItem.largeTitleDisplayMode = .automatic
    }
  }
}
