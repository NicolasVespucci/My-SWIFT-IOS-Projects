import Foundation

struct AdvantagesModel {
    var image: String?
    var title: String?
}
