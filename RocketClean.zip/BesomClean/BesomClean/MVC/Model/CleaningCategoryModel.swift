import Foundation
import UIKit
import Photos
struct CleaningCategoryModel {
    var image: String?
    var nameSections: String?
    var sectionsImageArray: [PHAsset]?
    var volumeStorage: String?
}
