
import UIKit


extension UIDevice {
  func MBFormatter(_ bytes: Int64) -> String {
    let formatter = ByteCountFormatter()
    formatter.allowedUnits = ByteCountFormatter.Units.useMB
    formatter.countStyle = ByteCountFormatter.CountStyle.decimal
    formatter.includesUnit = false
    return formatter.string(fromByteCount: bytes) as String
  }

  var usedPercent: String {
    let usedGB = usedDiskSpaceInGB.trimmingCharacters(in: CharacterSet(charactersIn: "0123456789.").inverted)
    let total = totalDiskSpaceInGB.trimmingCharacters(in: CharacterSet(charactersIn: "0123456789.").inverted)
    if let usedD = usedGB.double(), let totalD = total.double() {
      return "\(Int((usedD/totalD) * 100))"
    }
    return ""
  }

  var usedDiskSpaceInt: Float {
    if  let usedGB = usedDiskSpaceInGB.trimmingCharacters(in: CharacterSet(charactersIn: "0123456789.").inverted).double() {
      let used = Float(usedGB)
      return used
    }
    return 0
  }

  var totalDiskSpaceInt: Int {
    if let total = totalDiskSpaceInGB.trimmingCharacters(in: CharacterSet(charactersIn: "0123456789.").inverted).double() {
      let used = Int(total)
      return used
    }
    return 0
  }


  //MARK: Get String Value
  var totalDiskSpaceInGB:String {
    return ByteCountFormatter.string(fromByteCount: totalDiskSpaceInBytes, countStyle: ByteCountFormatter.CountStyle.memory)
  }

  var freeDiskSpaceInGB:String {
    return ByteCountFormatter.string(fromByteCount: freeDiskSpaceInBytes, countStyle: ByteCountFormatter.CountStyle.decimal)
  }

  var usedDiskSpaceInGB:String {
    return ByteCountFormatter.string(fromByteCount: usedDiskSpaceInBytes, countStyle: ByteCountFormatter.CountStyle.decimal)
  }

  var totalDiskSpaceInMB:String {
    return MBFormatter(totalDiskSpaceInBytes)
  }

  var freeDiskSpaceInMB:String {
    return MBFormatter(freeDiskSpaceInBytes)
  }

  var usedDiskSpaceInMB:String {
    return MBFormatter(usedDiskSpaceInBytes)
  }

  //MARK: Get raw value
  var totalDiskSpaceInBytes:Int64 {
    guard let systemAttributes = try? FileManager.default.attributesOfFileSystem(forPath: NSHomeDirectory() as String),
      let space = (systemAttributes[FileAttributeKey.systemSize] as? NSNumber)?.int64Value else { return 0 }
    return space
  }

  var freeDiskSpaceInBytes:Int64 {
    if #available(iOS 11.0, *) {
      if let space = try? URL(fileURLWithPath: NSHomeDirectory() as String).resourceValues(forKeys: [URLResourceKey.volumeAvailableCapacityForImportantUsageKey]).volumeAvailableCapacityForImportantUsage {
        return space
      } else {
        return 0
      }
    } else {
      if let systemAttributes = try? FileManager.default.attributesOfFileSystem(forPath: NSHomeDirectory() as String),
        let freeSpace = (systemAttributes[FileAttributeKey.systemFreeSize] as? NSNumber)?.int64Value {
        return freeSpace
      } else {
        return 0
      }
    }
  }

  var usedDiskSpaceInBytes:Int64 {
    return totalDiskSpaceInBytes - freeDiskSpaceInBytes
  }

  var iPhone: Bool {
    return UIDevice().userInterfaceIdiom == .phone
  }

//  enum ScreenType: String {
//    case iPhone4
//    case iPhone5
//    case iPhone6
//    case iPhone6Plus
//    case Unknown
//  }
//  var screenType: ScreenType {
//    guard iPhone else { return .Unknown}
//    switch UIScreen.main.nativeBounds.height {
//    case 960:
//      return .iPhone4
//    case 1136:
//      return .iPhone5
//    case 1334:
//      return .iPhone6
//    case 1920: //fallthrough
//      return .iPhone6Plus
//    case 2208:
//      return .iPhone6Plus
//    default:
//      return .Unknown
//    }
//  }
//
//  var isiPhone6_7_8: Bool{
//    return UIDevice.current.screenType == .iPhone6
//  }
//
//  var isiPhone6_7_8Plus: Bool{
//    return UIDevice.current.screenType == .iPhone6Plus
//  }
}


extension String {
//  func hexStringToUIColor() -> UIColor {
//    var cString:String = self.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
//
//    if (cString.hasPrefix("#")) {
//      cString.remove(at: cString.startIndex)
//    }
//
//    if ((cString.count) != 6) {
//      return UIColor.gray
//    }
//
//    var rgbValue:UInt64 = 0
//    Scanner(string: cString).scanHexInt64(&rgbValue)
//
//    return UIColor(
//      red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
//      green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
//      blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
//      alpha: CGFloat(1.0)
//    )
//  }

  func print(_ comment: String = "") {
    Swift.print(self, comment)
  }

  var int: Int? {
    return Int(self)
  }

  func toInt() -> Int {
    let s = replacingOccurrences(of: ".", with: "").replacingOccurrences(of: ",", with: ".")
    guard let formattedDouble = NumberFormatter().number(from: s)?.doubleValue.rounded() else { return 0 }
    return Int(formattedDouble)
  }
}
