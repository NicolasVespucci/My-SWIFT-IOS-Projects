import UIKit

class AdvantagesShoppingCell: UITableViewCell {
    
    var AdvantagesShoppingCellModel: AdvantagesModel? {
        didSet { configureAdvantagesModel() }
    }
    
    private lazy var cellView: UIView = {
        let view = UIView()
        view.layer.masksToBounds = true
        return view
    }()
    
    private lazy var settingsImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private lazy var cellLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.textColor = "2F2E33".hexColor
        label.textAlignment = .left
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        selectionStyle = .none
        configureLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureLayout() {
        addSubview(cellView)
        cellView.addSubviews(settingsImageView, cellLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(40)
        }
        
        settingsImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview()
            make.size.equalTo(24.resized())
        }
        
        cellLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalTo(settingsImageView.snp.trailing).offset(12)
            make.trailing.equalToSuperview()
            make.height.equalTo(24)
        }
    }
    
    private func configureAdvantagesModel() {
        guard let advantagesShoppingCellModel = AdvantagesShoppingCellModel else { return }
        cellLabel.text = advantagesShoppingCellModel.title
        settingsImageView.image = advantagesShoppingCellModel.image?.image
    }
}
