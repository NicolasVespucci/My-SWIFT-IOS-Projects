import UIKit

class ContactCleaningCategoryCell: UICollectionViewCell {
    
    var cleaningCategoryModel: CleaningCategoryModel? {
        didSet { configureOptionsModel() }
    }
    
    private var optionImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private var duplicatesLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 17, weight: .medium)
        label.textColor = "5745A3".hexColor
        label.textAlignment = .left
        return label
    }()
    
    private var countContactsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 13, weight: .regular)
        label.textColor = "#707070".hexColor.withAlphaComponent(0.4)
        label.text = "Contacts"
        label.textAlignment = .left
        return label
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
    }
        
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupLayout() {
        backgroundColor = .white
        layer.cornerRadius = 16
        addSubviews(optionImageView, duplicatesLabel, countContactsLabel)
        
        optionImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(16)
            make.size.equalTo(72)
            make.centerX.equalToSuperview()
        }
        
        duplicatesLabel.snp.makeConstraints { make in
            make.top.equalTo(optionImageView.snp.bottom).offset(16)
            make.leading.equalToSuperview().offset(16)
            make.height.equalTo(24)
        }
        
        countContactsLabel.snp.makeConstraints { make in
            make.top.equalTo(duplicatesLabel.snp.bottom).offset(8)
            make.leading.equalToSuperview().offset(16)
            make.height.equalTo(16)
        }
    }
    
    private func configureOptionsModel() {
        guard let cleaningCategoryModel = cleaningCategoryModel else { return }
        duplicatesLabel.text = cleaningCategoryModel.nameSections
        optionImageView.image = cleaningCategoryModel.image?.image
        setupLayout()
    }
    
    
}


