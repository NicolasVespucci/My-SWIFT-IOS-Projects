import UIKit
import SwiftyAttributes
import RxSwift

class OptionsCell: UICollectionViewCell {
    
    var optionsCellModel: OptionsModel? {
        didSet { configureOptionsModel() }
    }
    
    var completion2: (()->())? = nil
    
    private lazy var cellView: UIView = {
        let view = UIView()
        view.layer.masksToBounds = true
        view.backgroundColor = "2E8DFF".hexColor.withAlphaComponent(0.7)
        view.layer.cornerRadius = 12
        let blurEffect = UIBlurEffect(style: UIBlurEffect.Style.systemUltraThinMaterialLight)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = view.bounds
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        blurEffectView.layer.cornerRadius = 12
        view.layer.cornerRadius = 12
        view.addSubview(blurEffectView)
        return view
    }()
    
    private lazy var optionsImageView: UIImageView = {
        let imageView = UIImageView(image: "".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private lazy var optionsNameLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16, weight: .regular)
        label.adjustsFontSizeToFitWidth = true
        label.textColor = .white
        label.textAlignment = .left
        label.numberOfLines = 0
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private lazy var descriptionNameLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 12, weight: .regular)
        label.adjustsFontSizeToFitWidth = true
        label.textColor = .white.withAlphaComponent(0.65)
        label.textAlignment = .left
        label.numberOfLines = 0
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    let disposeBag = DisposeBag()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureLayout() {
        addSubview(cellView)
        cellView.addSubviews(optionsImageView, optionsNameLabel, descriptionNameLabel)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        optionsImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(16)
            make.leading.equalToSuperview().offset(16)
            make.size.equalTo(48)
        }
        
        optionsNameLabel.snp.makeConstraints { make in
            make.top.equalTo(optionsImageView.snp.bottom).offset(16)
            make.leading.equalToSuperview().offset(16)
            make.trailing.equalToSuperview().offset(-10)
            make.height.equalTo(24)
        }
        
        descriptionNameLabel.snp.makeConstraints { make in
            make.top.equalTo(optionsNameLabel.snp.bottom).offset(16)
            make.leading.equalToSuperview().offset(16)
            make.trailing.equalToSuperview().offset(-10)
            make.height.equalTo(40)
        }
        
//        optionsButton.snp.makeConstraints { make in
//            make.top.equalTo(descriptionNameLabel.snp.bottom).offset(8)
//            make.leading.equalToSuperview().offset(16)
//
//            make.height.equalTo(32)
//            make.width.equalTo(optionsButton.currentTitle!.width(constrainedBy: 100, with: .systemFont(ofSize: 12, weight: .medium)) + 16)
//        }
        
        layoutIfNeeded()
    }
    
    private func configureOptionsModel() {
        guard let optionsCellModel = optionsCellModel else { return }
        optionsImageView.image = optionsCellModel.image?.image
        optionsNameLabel.text = optionsCellModel.nameOptions
        descriptionNameLabel.text = optionsCellModel.descriptionOptions
        configureLayout()
    }
}

