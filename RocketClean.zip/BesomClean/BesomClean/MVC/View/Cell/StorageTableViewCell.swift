import RxSwift
import RxCocoa
import Photos
import UIKit
import SnapKit
import IHProgressHUD

class StorageTableViewCell: UICollectionViewCell {
    
    // MARK: - Duplicates Photo Section
    
    var cleaningCategoryModel: CleaningCategoryModel? {
        didSet { configureOptionsModel() }
    }
    
    private var optionImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private var duplicatesLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 17, weight: .medium)
        label.textColor = "5745A3".hexColor
        label.textAlignment = .left
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var countDuplicateLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 13, weight: .regular)
        label.textColor = "#707070".hexColor.withAlphaComponent(0.4)
        label.text = ""
        label.textAlignment = .left
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
        
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
        
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureLayout() {
        backgroundColor = .white
        layer.cornerRadius = 16
        contentView.addSubviews(optionImageView, duplicatesLabel, countDuplicateLabel)
        
        optionImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(16)
            make.size.equalTo(72)
            make.centerX.equalToSuperview()
        }
        
        duplicatesLabel.snp.makeConstraints { make in
            make.top.equalTo(optionImageView.snp.bottom).offset(16)
            make.leading.equalToSuperview().offset(16)
            make.trailing.equalToSuperview().offset(-10)
            make.height.equalTo(24)
        }
        
        countDuplicateLabel.snp.makeConstraints { make in
            make.top.equalTo(duplicatesLabel.snp.bottom).offset(8)
            make.leading.equalToSuperview().offset(16)
            make.trailing.equalToSuperview().offset(-10)
            make.height.equalTo(16)
        }
    }
    
    //MARK: - setup Photo and Video
    
    deinit {
        print(self, #function)
    }
    
    var currentAccets = [PHAsset]()
    
    private func configureOptionsModel() {
        guard let cleaningCategoryModel = cleaningCategoryModel else { return }
        duplicatesLabel.text = cleaningCategoryModel.nameSections
        optionImageView.image = cleaningCategoryModel.image?.image
        countDuplicateLabel.text = "\(Int(cleaningCategoryModel.sectionsImageArray?.count ?? -1)) " + "Photos".localized
    
        configureLayout()
    }
}
