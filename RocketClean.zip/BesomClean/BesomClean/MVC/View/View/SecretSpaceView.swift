import UIKit

class SecretSpaceView: UIView {

    private var secretSpaceLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15, weight: .medium)
        label.text = NSLocalizedString("Secret space", comment: "")
        label.textColor = "5745A3".hexColor
        label.textAlignment = .left
        return label
    }()
    
    private var accessButton: UIButton = {
        let button = UIButton()
        button.setTitleColor("5745A3".hexColor, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 13, weight: .medium)
        button.titleLabel?.textAlignment = .center
        button.layer.cornerRadius = 8
        button.backgroundColor = "EAE6F7".hexColor
        button.setTitle(NSLocalizedString("Access", comment: ""), for: .normal)
        return button
    }()
    
    private var lockImageView: UIImageView = {
        let imageView = UIImageView(image: "lock".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    

    init() {
        super.init(frame: .zero)
        isUserInteractionEnabled = true
        setupLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupLayout(){
        backgroundColor = .white
        layer.cornerRadius = 16
        addSubviews(secretSpaceLabel, accessButton, lockImageView)
        
        secretSpaceLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(16)
            make.leading.equalToSuperview().offset(16)
            make.height.equalTo(20)
        }
        
        accessButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-16)
            make.leading.equalToSuperview().offset(16)
            make.height.equalTo(32)
        }
        
        lockImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-16)
            make.size.equalTo(84)
        }
    }

}
