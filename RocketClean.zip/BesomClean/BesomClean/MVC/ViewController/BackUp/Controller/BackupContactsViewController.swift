import UIKit
import Contacts
import RxSwift
import CoreData
import SwiftyContacts

class BackupContactsViewController: UIViewController {
    
    //MARK: User Interface Elements
    
    private var backupContactsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 17, weight: .semibold)
        label.text = "Backup contacts".localized
        label.textColor = "2F2E33".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("leftBack".image, for: .normal)
        return button
    }()
    
    private var noBackupsMadeYetImageView: UIImageView = {
        let imageView = UIImageView(image: "backUp".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private var noBackupsMadeYetLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 13, weight: .regular)
        label.text = "No Backups made yet".localized
        label.textColor = "8B68DF".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var backUpTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 64
        table.backgroundColor = .clear
        table.isScrollEnabled = true
        table.separatorStyle = .none
        return table
    }()
    
    private var backupContactsButton: UIButton = {
        let button = UIButton()
        button.setTitle("Backup contacts".localized, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 17, weight: .medium)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = "8B68DF".hexColor
        button.layer.cornerRadius = 16
        return button
    }()
    
    //MARK: Var and Let
    
    var backUpCountContact = [BackUpModel]()
    
    var fullContacts = [CNContact]()
    
    var dataCurrentContacts: Data?
    
    var currentDate: String?
    
    let disposeBag = DisposeBag()
    
    
    //MARK: CoreData Array
    
    var coreDataFullBackUpContacts: [Task] = []
    
    
//    private func getContext() -> NSManagedObjectContext {
//        let appDelegate = UIApplication.shared.delegate as! AppDelegate
//        return appDelegate.persistentContainer.viewContext
//    }
    
//    override func viewWillAppear(_ animated: Bool) {
//        super.viewWillAppear(animated)
//
//    }
    
//    private func saveBackUpContacts(backUpData: Data){
//        let context = getContext()
//        guard let entity = NSEntityDescription.entity(forEntityName: "Task", in: context) else { return }
//
//        let taskObject = Task(entity: entity, insertInto: context)
//        taskObject.backup = backUpData
//
//        do {
//            try context.save()
//        } catch let error as NSError {
//            print(error.localizedDescription)
//        }
//    }
    
    //MARK: viewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    //MARK: Setup
    
    private func setup(){
        fetchContact()
        setupLayout()
        configureTableView()
        setupButtons()
    }
    
    //MARK: Setup Layout
    
    private func setupLayout(){
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = "F2EFFA".hexColor
        view.addSubviews(backupContactsLabel,  backButton,noBackupsMadeYetImageView, noBackupsMadeYetLabel, backUpTableView, backupContactsButton)
        
        backupContactsLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.height.equalTo(24)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
        }
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.leading.equalToSuperview().offset(24)
            make.size.equalTo(24)
        }
        
        noBackupsMadeYetImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
            make.size.equalTo(98)
        }
        
        noBackupsMadeYetLabel.snp.makeConstraints { make in
            make.top.equalTo(noBackupsMadeYetImageView.snp.bottom).offset(16)
            make.height.equalTo(16)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
        }
        
        backUpTableView.snp.makeConstraints { make in
            make.top.equalTo(backupContactsLabel.snp.bottom).offset(24)
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.bottom.equalTo(backupContactsButton.snp.top).offset(-10)
        }
        
        backupContactsButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-54)
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(48)
        }
    }
    
    //MARK: Configure TableView
    
    private func configureTableView() {
        backUpTableView.delegate = self
        backUpTableView.dataSource = self
        backUpTableView.register(BackUpCell.self, forCellReuseIdentifier: BackUpCell.nibIdentifier)
    }
    
    //MARK: Setup Buttons
    
    private func setupButtons() {
        backButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.navigationController?.popViewController(animated: true)
        }.disposed(by: disposeBag)
        
        backupContactsButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.backUpButtonAction()
        }.disposed(by: disposeBag)
    }
    
    //MARK: Button Action
    
    private func backUpButtonAction() {
        Constants.ud.dataContacts.append(dataCurrentContacts!)
        currentDate = Date().shortDate
        Constants.ud.datebackUpContacts.append(currentDate!)
        if Constants.ud.dataContacts != nil {
            let currentBackUpContacts = Constants.ud.dataContacts.last
            let transformationIntoContacts = NSKeyedUnarchiver.unarchiveObject(with: currentBackUpContacts as! Data) as? [CNContact]
            backUpCountContact.append(BackUpModel(countContacts: "\(transformationIntoContacts!.count)", currentDate: currentDate))
        }
        backUpTableView.reloadData()
    }
    
    //MARK: Fetch Contacts
    
    private func fetchContact(){
        let store = CNContactStore()
        store.requestAccess(for: .contacts) { acces, error in
            if let error = error {
                print("Error------>", error)
                return
            }
            
            if acces {
                print("Acces granted")
                let key = [CNContactGivenNameKey, CNContactFamilyNameKey, CNContactPhoneNumbersKey]
                let request = CNContactFetchRequest(keysToFetch: key as [CNKeyDescriptor])
                
                do {
                    try store.enumerateContacts(with: request, usingBlock: { (contact, stopEnumerating) in
                        
                        let fullName = contact.givenName + " " +  contact.familyName
                        let number = contact.phoneNumbers.first?.value.stringValue ?? ""
                        self.fullContacts.append(contact)
                    })
                } catch let error {
                    print("Error enumerated contacts:", error)
                }
            } else {
                print("Acces denied...")
            }
        }
        
        let dataBlob = NSKeyedArchiver.archivedData(withRootObject: fullContacts)
        dataCurrentContacts = dataBlob
        
        countBackUpContact()
    }
    
    
    //MARK: Count In BackUp Contacts
    private func countBackUpContact() {
        if Constants.ud.dataContacts != nil {
            noBackupsMadeYetLabel.isHidden = true
            noBackupsMadeYetImageView.isHidden = true
            var dataContactsU = Constants.ud.dataContacts
            var datebackUpContactsU = Constants.ud.datebackUpContacts
            
            for (count, date) in zip(dataContactsU, datebackUpContactsU) {
                // Transformation Data Into Contacts
                let transformationIntoContacts = NSKeyedUnarchiver.unarchiveObject(with: count as! Data) as? [CNContact]
                
                backUpCountContact.append(BackUpModel(countContacts: "\(transformationIntoContacts!.count)", currentDate: date))
            }

        } else {
            noBackupsMadeYetLabel.isHidden = false
            noBackupsMadeYetImageView.isHidden = false
        }
        backUpTableView.reloadData()
    }
}

//MARK: UITableViewDelegate, UITableViewDataSource

extension BackupContactsViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = PhoneBackUpViewController()
        let data = Constants.ud.dataContacts[indexPath.item]
        vc.dataContact = data as! Data
        navigationController?.pushViewController(vc, animated: true)
    }
}

extension BackupContactsViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Constants.ud.dataContacts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = backUpTableView.dequeueReusableCell(withIdentifier: BackUpCell.nibIdentifier, for: indexPath) as! BackUpCell
        let backUpModel = backUpCountContact[indexPath.row]
        cell.backUpModel = backUpModel
        return cell
    }
}


