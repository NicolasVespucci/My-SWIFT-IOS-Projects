import Foundation


struct BackUpModel {
    var countContacts: String?
    var currentDate: String?
}
