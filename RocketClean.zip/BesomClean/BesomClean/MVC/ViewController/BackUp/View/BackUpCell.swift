import UIKit
import SwiftUI

class BackUpCell: UITableViewCell {
    
    var backUpModel: BackUpModel? {
        didSet { configureBackUpModel() }
    }
    
    private var cellView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 16
        return view
    }()
    
    private var connectivityImageView: UIImageView = {
        let imageView = UIImageView(image: "Connectivity".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private var dateLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15, weight: .regular)
        label.text = ""
        label.textColor = "2F2E33".hexColor
        label.textAlignment = .left
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var countContactsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15, weight: .regular)
        label.text = "726"
        label.textColor = "2F2E33".hexColor
        label.textAlignment = .right
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var chevronRightImageView: UIImageView = {
        let imageView = UIImageView(image: "ChevronRight".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    var fullBackUpContacts: Data?
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        selectionStyle = .none
        setupLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupLayout(){
        addSubview(cellView)
        cellView.addSubviews(connectivityImageView, dateLabel, countContactsLabel, chevronRightImageView)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(48)
        }
        
        connectivityImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.size.equalTo(24)
            make.leading.equalToSuperview().offset(12)
        }
        
        dateLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.height.equalTo(24)
            make.leading.equalTo(connectivityImageView.snp.trailing).offset(12)
        }
        
        countContactsLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.height.equalTo(24)
            make.trailing.equalTo(chevronRightImageView.snp.leading).offset(-4)
        }
        
        chevronRightImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.size.equalTo(24)
            make.trailing.equalToSuperview().offset(-12)
        }
    }
    
    private func configureBackUpModel() {
        guard let backUpModel = backUpModel else { return }
        countContactsLabel.text = backUpModel.countContacts
        dateLabel.text = backUpModel.currentDate
    }
}
