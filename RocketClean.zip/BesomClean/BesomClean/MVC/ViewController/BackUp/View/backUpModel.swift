import Foundation


struct BackUpModel {
    var date: String?
    var countContacts: String?
}
