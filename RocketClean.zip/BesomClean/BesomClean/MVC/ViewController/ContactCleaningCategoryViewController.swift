import UIKit

class ContactCleaningCategoryViewController: UIViewController {
    
    public var sectionsName = [CleaningCategoryModel(image: "name",nameSections: "Names", sectionsImageArray: nil, volumeStorage: ""),
                               CleaningCategoryModel(image: "phoneNumber", nameSections: "Phone Number", sectionsImageArray: nil, volumeStorage: ""),
                               CleaningCategoryModel(image: "emails",nameSections: "Email", sectionsImageArray: nil, volumeStorage: ""),
                               CleaningCategoryModel(image: "alls",nameSections: "All Contacts", sectionsImageArray: nil, volumeStorage: "")]
    
    private var contactLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 17, weight: .semibold)
        label.text = "Contact"
        label.textColor = "2F2E33".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("leftBack".image, for: .normal)
        return button
    }()
    
    private var backupContactsView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 16
        return view
    }()
    
    private var backupContactsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15, weight: .medium)
        label.text = "Backup contacts"
        label.textColor = "5745A3".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var backupLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 13, weight: .medium)
        label.text = "Backup"
        label.textColor = "5745A3".hexColor
        label.backgroundColor = "EAE6F7".hexColor
        label.clipsToBounds = true
        label.layer.cornerRadius = 8
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var walletMemoryImageView: UIImageView = {
        let imageView = UIImageView(image: "walletMemory".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private var contactCleaningCategoryCollectionView: UICollectionView = {
        let collection = UICollectionView(frame: .zero, collectionViewLayout: .init())
        collection.backgroundColor = .clear
        collection.showsHorizontalScrollIndicator = false
        collection.showsVerticalScrollIndicator = false
        collection.isScrollEnabled = true
        collection.clipsToBounds = false
        return collection
    }()
    
    private var contactCleaningCategoryLayout: UICollectionViewLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = .init(width: 155.5, height: 176)
        layout.minimumInteritemSpacing = 16
        layout.minimumLineSpacing = 16
        layout.sectionInset = .init(top: 0, left: 0, bottom: 0, right: 0)
        return layout
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup(){
        setupLayout()
        setupCollection()
    }
    
    private func setupLayout(){
        view.backgroundColor = "F2EFFA".hexColor
        view.addSubviews(contactLabel, backButton, backupContactsView, contactCleaningCategoryCollectionView)
        
        backupContactsView.addSubviews(backupContactsLabel, backupLabel, walletMemoryImageView)
        
        contactLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.height.equalTo(24)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
        }
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.leading.equalToSuperview().offset(24)
            make.size.equalTo(24)
        }
        
        backupContactsView.snp.makeConstraints { make in
            make.top.equalTo(contactLabel.snp.bottom).offset(24)
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(96)
        }
        
        backupContactsLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(16)
            make.leading.equalToSuperview().offset(16)
            make.height.equalTo(20)
        }
        
        backupLabel.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-16)
            make.leading.equalToSuperview().offset(16)
            make.height.equalTo(32)
        }
        
        
        walletMemoryImageView.snp.makeConstraints { make in
            make.size.equalTo(84)
            make.centerY.equalToSuperview()
            make.trailing.equalToSuperview().offset(-16)
        }
        
        contactCleaningCategoryCollectionView.snp.makeConstraints { make in
            make.top.equalTo(backupContactsView.snp.bottom).offset(16)
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.bottom.equalToSuperview()
        }
    }
    
    private func setupCollection() {
        contactCleaningCategoryCollectionView.setCollectionViewLayout(contactCleaningCategoryLayout, animated: true)
        contactCleaningCategoryCollectionView.dataSource = self
        contactCleaningCategoryCollectionView.delegate = self
        contactCleaningCategoryCollectionView.register(ContactCleaningCategoryCell.self, forCellWithReuseIdentifier: ContactCleaningCategoryCell.nibIdentifier)
    }
    
}

//MARK: - CollectionView
extension ContactCleaningCategoryViewController: UICollectionViewDelegate {
    
}

extension ContactCleaningCategoryViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return sectionsName.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ContactCleaningCategoryCell.nibIdentifier, for: indexPath) as! ContactCleaningCategoryCell
        let sectionsName = sectionsName[indexPath.item]
        cell.cleaningCategoryModel = sectionsName
        return cell
    }
    
    
}

