import UIKit
import SnapKit
import RxSwift
import SwiftyAttributes
import IHProgressHUD

class FastCleanerViewController: UIViewController {
    
    private var fullScreenImageView: UIImageView = {
        let imageView = UIImageView(image: "FullScreenImageView".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("leftBack".image, for: .normal)
        return button
    }()
    
    private var circleProgressImageView: UIImageView = {
        let imageView = UIImageView(image: "fCircle".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()

    private var rotateCircleProgressImageView: UIImageView = {
        let imageView = UIImageView(image: "fRotate".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private var lookingLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 13, weight: .semibold)
        label.text = "Looking for similar photos...".localized
        label.textAlignment = .center
        label.textColor = "8B68DF".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var procentLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 25, weight: .medium)
        label.text = ""
        label.textAlignment = .center
        label.textColor = "5745A3".hexColor
        return label
    }()
    
    public var cleaningCategories = CleanerCategories.similar
    private var currentSize = 0.0
    
    
    
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        IHProgressHUD.dismiss()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    private func setup(){
        configureLayout()
        setupButtons()
        setupAllDuplicateSimilarsPhoto()
    }
    
    private func configureLayout() {
        view.backgroundColor = "F2EFFA".hexColor
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
        view.addSubviews(backButton, circleProgressImageView, lookingLabel, procentLabel)
        
        circleProgressImageView.addSubviews(rotateCircleProgressImageView, procentLabel)
                
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.leading.equalToSuperview().offset(24)
            make.size.equalTo(24)
        }
        
        circleProgressImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
            make.size.equalTo(130)
        }
        
        lookingLabel.snp.makeConstraints { make in
            make.bottom.equalTo(circleProgressImageView.snp.top).offset(-24)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(20)
        }
        
        rotateCircleProgressImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        procentLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(72)
        }
    }
    
    private func setupButtons() {
        backButton.rx.tap.bind { [weak self] in
            self?.navigationController?.popViewController(animated: true)
        }.disposed(by: disposeBag)
    }
    
    func setupAllDuplicateSimilarsPhoto(){
        rotateCircleProgressImageView.rotate()
        fetchByOption()
        
        LibraryMediaManager.shared
            .countedSize
            .do(onNext: { [weak self] _, _ in
            })
                .compactMap { size, s in
                    return (("\(String(format: "%.2f", size)) GB"), size, s)
                }
                .subscribe(onNext: { [weak self] stringSize , size, stop in
                    guard let self = self else { return }
                    self.animateProgress()
                    if size == -1.0 {
                        IHProgressHUD.dismiss()
                        self.procentLabel.isHidden = true
                        self.lookingLabel.text = "No duplicates have been found".localized
                        self.rotateCircleProgressImageView.NoRotate()
                        return
                    } else {
                       
                    }
                    if stop {
                        
                    }
                })
                .disposed(by: disposeBag)
    }
    
    private func fetchByOption() {
        LibraryMediaManager.shared.fetchPhotos(with: PhotoOptions.similar.fetchPredicate) {
            LibraryMediaManager.shared.appendToExistingAssets()
            LibraryMediaManager.shared.mapAssets(predicate: NSPredicate(format: "burstIdentifier == nil")) { _ in
                LibraryMediaManager.shared.requestForSize()
                LibraryMediaManager.shared.getSize(assets: LibraryMediaManager.shared.allSimilarAssets)
            }
        }
    }
    
    func animateProgress() {
        
        DispatchQueue.main.async {
            
        
        UIView.animate(withDuration: 2, animations: { [weak self] in
            guard let self = self else { return }
            self.currentSize += 0.04
            self.procentLabel.text = "\(Int(self.currentSize))%"
            
        }) { [weak self] _ in
            guard let self = self else { return }
            if self.currentSize <= 100 {
               
                self.animateProgress()
            } else {
                if self.lookingLabel.text == "No duplicates have been found".localized {
                    self.rotateCircleProgressImageView.NoRotate()
                    self.circleProgressImageView.isHidden = true
                    self.rotateCircleProgressImageView.isHidden = true
                } else {
                    self.circleProgressImageView.isHidden = false
                    self.rotateCircleProgressImageView.isHidden = false
                    self.rotateCircleProgressImageView.NoRotate()
                    if IAPManager.shared().isPurchased {
                        let assetsVC = AssetsScreen(rootOption: self.cleaningCategories)
                        assetsVC.isCleaner = true
                        LibraryMediaManager.shared.itemsToDelete.value.forEach { element in
                            assetsVC.selectedIndexes.append(element.indexPath)
                        }
                        self.navigationController?.pushViewController(assetsVC, animated: true)
                    } else {
                        Constants.ud.currentDismissing = 3
                        let vc = FirstSubscriptionsViewController()
                        self.navigationController?.pushViewController(vc, animated: true)
                        IAPManager.shared().purchaseCompletion = { _ in
                            let assetsVC = AssetsScreen(rootOption: self.cleaningCategories)
                            assetsVC.isCleaner = true
                            LibraryMediaManager.shared.itemsToDelete.value.forEach { element in
                                assetsVC.selectedIndexes.append(element.indexPath)
                            }
                            self.navigationController?.pushViewController(assetsVC, animated: true)
                            
                        }
                        IAPManager.shared().restoreCompletion = { subscription in
                            let assetsVC = AssetsScreen(rootOption: self.cleaningCategories)
                            assetsVC.isCleaner = true
                            LibraryMediaManager.shared.itemsToDelete.value.forEach { element in
                                assetsVC.selectedIndexes.append(element.indexPath)
                            }
                            self.navigationController?.pushViewController(assetsVC, animated: true)
                            
                            if Constants.ud.isPurchased {
                                AlertManager.shared().showPurchasesWereRestored()
                            }
                        }
                    }
                }
            }
        }
        
        }
    }
    
    deinit {
        print(self, #function)
        LibraryMediaManager.shared.allSimilarAssets.removeAll()
        LibraryMediaManager.shared.fetchedAssets.removeAll()
        LibraryMediaManager.shared.itemsToDelete.accept([])
    }
}
