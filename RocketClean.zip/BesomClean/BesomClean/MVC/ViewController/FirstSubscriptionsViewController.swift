import UIKit
import RxSwift
import SwiftyStoreKit
import SnapKit
import NetworkExtension
import Network
import SwiftyAttributes
import Reachability
import StoreKit
import IHProgressHUD
import SwiftUI

class FirstSubscriptionsViewController: UIViewController {
    
    var identifiers = Constants.analytics.threeMonth

    public var advantagesModel = [AdvantagesModel(image: "1",title: "Clean up your gallery".localized),
                                  AdvantagesModel(image: "2" ,title: "Get rid of useless contact copies".localized),
                                  AdvantagesModel(image: "3",title: "Boost your phone".localized)
    ]
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("topBack".image, for: .normal)
        button.isUserInteractionEnabled = true
        return button
    }()
    
    private var restoreButton: UIButton = {
        let button = UIButton()
        button.setTitle("Restore".localized, for: .normal)
        button.setTitleColor("2F2E33".hexColor.withAlphaComponent(0.6), for: .normal)
        button.titleLabel?.textAlignment = .left
        button.isUserInteractionEnabled = true
        button.titleLabel?.adjustsFontSizeToFitWidth = true
        button.titleLabel?.minimumScaleFactor = 0.5
        return button
    }()
    
    private var topExampeImageView: UIImageView = {
        let imageView = UIImageView(image: "topPayOne".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private var topImproveLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.text = "Take the best of Your device".localized
        label.numberOfLines = 2
        label.textColor = "8B68DF".hexColor
        return label
    }()
    
    private lazy var AdvantagesShoppingTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 56
        table.backgroundColor = .clear
        table.isScrollEnabled = false
        table.separatorStyle = .none
        return table
    }()
    
    public var pricePeriodLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.numberOfLines = 0
        label.textColor = "2F2E33".hexColor
        return label
    }()
    
    private var emptyView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()
    
    private lazy var subscribeButton: UIButton = {
        let button = UIButton()
        button.layer.cornerRadius = 16
        button.setTitle("Subscribe".localized, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 17, weight: .medium)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = "8B68DF".hexColor
        return button
    }()
    
    var productsDescription: NSAttributedString {
        let terms = "Terms".localized + " " + "of".localized + " " + "Use".localized
        let privacy = "Privacy".localized + " " + "and".localized
        + " " + "Policy".localized
        let and = " & "
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .center
        
        let textAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12, weight: .medium)),
            .textColor("2F2E33".hexColor.withAlphaComponent(0.6)),
            .paragraphStyle(paragraphStyle)
        ]
        
        let andAttributes: [Attribute] = [
            .font(Font.systemFont(ofSize: 12, weight: .medium)),
            .textColor("2F2E33".hexColor.withAlphaComponent(0.6)),
            .paragraphStyle(paragraphStyle)
        ]
        
        let attributedDescription =
        terms.withAttributes(textAttributes)
        + and.withAttributes(andAttributes)
        + privacy.withAttributes(textAttributes)
        return attributedDescription
    }
    
    private lazy var textView: UITextView = {
        let textView = UITextView()
        textView.layoutIfNeeded()
        textView.isEditable = false
        textView.isSelectable = false
        textView.isScrollEnabled = true
        textView.backgroundColor = .clear
        textView.showsVerticalScrollIndicator = true
        textView.attributedText = productsDescription
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapResponse(recognizer:)))
        textView.addGestureRecognizer(tap)
        return textView
    }()
    
    let disposeBag = DisposeBag()
    
    var hoomContoller = true
    var products = [SKProduct]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup() {
        configureLayout()
        configureButtons()
        setupTableView()
        configureTrialLabel()
    }
    
    private func configureLayout() {
        view.backgroundColor = "F2EFFA".hexColor
        navigationController?.isNavigationBarHidden = true
        view.addSubviews(backButton, restoreButton,topExampeImageView, topImproveLabel, AdvantagesShoppingTableView, emptyView, textView,subscribeButton)
        
        emptyView.addSubview(pricePeriodLabel)
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.leading.equalToSuperview().offset(24)
            make.size.equalTo(48)
        }
        
        restoreButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.trailing.equalToSuperview().offset(-24)
            make.leading.equalTo(topExampeImageView.snp.trailing).offset(5)
            make.height.equalTo(48)
        }
        
        topExampeImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54.resized())
            make.centerX.equalToSuperview()
            make.size.equalTo(128)
        }
        
        topImproveLabel.snp.makeConstraints { make in
            make.top.equalTo(topExampeImageView.snp.bottom).offset(24)
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(64)
        }
        
        AdvantagesShoppingTableView.snp.makeConstraints { make in
            make.top.equalTo(topImproveLabel.snp.bottom).offset(32.resized())
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(160)
        }
        
        emptyView.snp.makeConstraints { make in
            make.top.equalTo(AdvantagesShoppingTableView.snp.bottom).offset(10)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalTo(textView.snp.top).offset(-10)
        }
        
        pricePeriodLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(68)
        }
        
        textView.snp.makeConstraints { make in
            make.bottom.equalTo(subscribeButton.snp.top).offset(-32.resized())
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(25)
        }
        
        subscribeButton.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-52.resized())
            make.leading.equalToSuperview().offset(32)
            make.trailing.equalToSuperview().offset(-32)
            make.height.equalTo(48)
        }
      
        view.layoutIfNeeded()
    }
    
    private func configureButtons() {
        subscribeButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            let product = self.identifiers
            IAPManager.shared().purchase(rcPackage: product, quantity: 1, atomically: true)
        }.disposed(by: disposeBag)

        backButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            
            switch Constants.ud.currentDismissing {
            case 1:
                self.skipButtonActions()
            case 2:
                self.dismiss(animated: true)
            case 3:
                self.navigationController?.popToRootViewController(animated: true)
            default:
                break
            }
            
        }.disposed(by: disposeBag)
        
        restoreButton.rx.tap.bind {
            DispatchQueue.main.async {
                IAPManager.shared().restore()
                if Constants.ud.currentRestoreDismissing == 1 {
                    IAPManager.shared().restoreCompletion = { [weak self] _ in
                        self?.skipButtonActions()
                    }
                }

            }
        }.disposed(by: disposeBag)
    }

    private func setupTableView() {
        AdvantagesShoppingTableView.delegate = self
        AdvantagesShoppingTableView.dataSource = self
        AdvantagesShoppingTableView.register(AdvantagesShoppingCell.self, forCellReuseIdentifier: AdvantagesShoppingCell.nibIdentifier)
    }
    
    private func configureTrialLabel() {
        IHProgressHUD.show()
        SwiftyStoreKit.retrieveProductsInfo([Constants.analytics.threeMonth]) { result in
            if(!result.retrievedProducts.isEmpty) {
                let testProduct = Product(product: result.retrievedProducts.first!)
                guard let period = testProduct.period else { return }
                let periodString = period.formattedString // MONTHLY
                let perPeriodString = period.perFormattedString.capitalized // MONTH
                let price = testProduct.localizedPrice
                let introductoryPeriod = testProduct.introductory?.period?.formattedString ?? ""

                if introductoryPeriod == "" {
                    self.pricePeriodLabel.text = price + NSLocalizedString(" per ", comment: "") + perPeriodString
                    IHProgressHUD.dismiss()
                } else {
                    let paragraphStyle = NSMutableParagraphStyle()
                    paragraphStyle.alignment = .center
                    let attributedTitle = ("Enjoy your ".localized
                                            .withAttributes([.textColor("2F2E33".hexColor),
                                            .font(.systemFont(ofSize: 14, weight: .regular))])
                                           + introductoryPeriod
                                            .withAttributes([.textColor("2F2E33".hexColor),
                                            .font(.systemFont(ofSize: 14, weight: .regular))])
                                           + " free trial,\nthen ".localized
                                            .withAttributes([.textColor("2F2E33".hexColor),
                                            .font(.systemFont(ofSize: 14, weight: .regular))])
                                           +  price
                                            .withAttributes([.textColor("2F2E33".hexColor),
                                            .font(.systemFont(ofSize: 14, weight: .semibold))])
                                           + " per ".localized
                                            .withAttributes([.textColor("2F2E33".hexColor),
                                            .font(.systemFont(ofSize: 14, weight: .semibold))])
                                           + perPeriodString
                                            .withAttributes([.textColor("2F2E33".hexColor),
                                            .font(.systemFont(ofSize: 14, weight: .semibold))])).withAttribute(.paragraphStyle(paragraphStyle))
                    self.pricePeriodLabel.attributedText = attributedTitle
                    IHProgressHUD.dismiss()
                }
            }
        }
    }
    
    private func skipButtonActions(){
        let options = CleaningOptions.allCases
        let vc = HomeViewController(options)
        let nc = UINavigationController(rootViewController: vc)
        guard let window = UIApplication.shared.windows.first else { return }
        window.rootViewController = nc
    }
    
   
}

//MARK: - Top TableView
extension FirstSubscriptionsViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}
extension FirstSubscriptionsViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return advantagesModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = AdvantagesShoppingTableView.dequeueReusableCell(withIdentifier: AdvantagesShoppingCell.nibIdentifier, for:  indexPath) as! AdvantagesShoppingCell
        let settingModelTwo = advantagesModel[indexPath.row]
        cell.AdvantagesShoppingCellModel = settingModelTwo
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }

}

//MARK: - Text View
extension FirstSubscriptionsViewController {
    @objc func tapResponse(recognizer: UITapGestureRecognizer) {
        let location: CGPoint = recognizer.location(in: textView)
        let position: CGPoint = CGPoint(x: location.x, y: location.y)
        let tapPosition: UITextPosition? = textView.closestPosition(to: position)
        if tapPosition != nil {
            let textRange: UITextRange? = textView.tokenizer.rangeEnclosingPosition(tapPosition!, with: UITextGranularity.word, inDirection: UITextDirection(rawValue: 1))
            if textRange != nil
            {
                let tappedWord: String? = textView.text(in: textRange!)
                guard let word = tappedWord else { return }
                wordAction(word)
            }
        }
    }
    
    private func wordAction(_ word: String) {
        switch word {
        case "Terms".localized, "of".localized, "Use".localized: pushPoliciesVC(.terms)
        case "Privacy".localized, "and".localized, "Policy".localized: pushPoliciesVC(.privacy)
        default: break
        }
    }
    
    func pushPoliciesVC(_ policiesType: Policies) {
        let termsVC = TermsAndPrivacy()
        termsVC.policiesType = policiesType
        navigationController?.pushViewController(termsVC, animated: true)
    }
}

