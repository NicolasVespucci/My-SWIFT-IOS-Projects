import UIKit
import SnapKit
import RxSwift
import SwiftyAttributes
import MBCircularProgressBar
import Photos
import RxCocoa
import IHProgressHUD
import Contacts

class HomeViewController: UIViewController {
    
    public var options = [OptionsModel(image: "gallary", nameOptions: "Gallery cleaner".localized, descriptionOptions: "Cleaning gallery\nfrom duplicates".localized), OptionsModel(image: "contact", nameOptions: "Contacts".localized, descriptionOptions: "Merging similar\ncontact numbers".localized)]
    
    private var menuButton: UIButton = {
        let button = UIButton()
        button.setImage("menuButton".image, for: .normal)
        button.isUserInteractionEnabled = true
        return button
    }()
    
    private var topWelcomeLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 20, weight: .semibold)
        label.text = "Welcome to RocketClean".localized
        label.textColor = "5745A3".hexColor
        label.textAlignment = .left
        label.minimumScaleFactor = 0.5
        label.adjustsFontSizeToFitWidth = true
        return label
    }()
    
    private var severalItemsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 17, weight: .regular)
        label.text = "Several items can\nbe optimized".localized
        label.textColor = "5745A3".hexColor
        label.textAlignment = .left
        label.numberOfLines = 0
        return label
    }()
    
    //  MARK: - Percentage Of Memory Already Filled And Amount Of Memory
    
    typealias Capacity = (used: String, total: String)
    
    private var deviceCapacity: Capacity {
        return ("\(UIDevice.current.usedDiskSpaceInt)",
                "\(UIDevice.current.totalDiskSpaceInt)")
    }
    
    private var cicrleMainImageView: UIImageView = {
        let imageView = UIImageView(image: "cicrleMain".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()

    private var storageLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 10, weight: .medium)
        label.text = "Storage".localized
        label.textColor = "8B68DF".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    //- memory as a percentage
    private var capacityPercent: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.attributedText = UIDevice.current.usedPercent.withAttribute(.font(.systemFont(ofSize: 17, weight: .regular))) + "%".withAttribute(.font(.systemFont(ofSize: 17, weight: .regular)))
        label.textColor = "5745A3".hexColor
        return label
    }()
    
    //- filled places out of everything
    private lazy var spaceLabel: UILabel = {
        let label = UILabel()
        label.textColor = "9A999D".hexColor
        label.textAlignment = .center
        let total = deviceCapacity.total
        let used = deviceCapacity.used
        label.text = "\(used) GB of \(total) GB"
        label.font = .systemFont(ofSize: 12, weight: .semibold)
        return label
    }()
    
    private var premiumView = PremiumView()
    
    // FAST CLEANER Button
    private var fastCleanerButton: UIButton = {
        let button = UIButton()
        return button
    }()
    
    private lazy var homeCollectionView: UICollectionView = {
        let collection = UICollectionView(frame: .zero, collectionViewLayout: .init())
        collection.backgroundColor = .clear
        collection.showsHorizontalScrollIndicator = false
        collection.showsVerticalScrollIndicator = false
        collection.isScrollEnabled = true
        collection.clipsToBounds = false
        return collection
    }()
    
    private lazy var homeLayout: UICollectionViewLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 0
        layout.itemSize = .init(width: 155.5, height: 168)
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 16
        layout.sectionInset = .init(top: 0, left: 0, bottom: 0, right: 0)
        return layout
    }()
    
    private lazy var fullView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.isHidden = true
        return view
    }()
    
    private var getFullAccessButton: UIButton = {
        let button = UIButton()
        return button
    }()
        
    private var currentOption: CleaningOptions?
    public var allOptions = [CleaningOptions]()
    
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        
        if !IAPManager.shared().isPurchased {
            Constants.ud.currentDismissing = 2
            Constants.ud.currentRestoreDismissing = 2
            
            IAPManager.shared().presentSingleSubscriptionVC(animated: true)
            IAPManager.shared().purchaseCompletion = { _ in
                IAPManager.shared().dismissSubscriptionVC()
                self.getFullAccessButton.isHidden = true
            }
            IAPManager.shared().restoreCompletion = { subscription in
                IAPManager.shared().dismissSubscriptionVC()
                if Constants.ud.isPurchased {
                    AlertManager.shared().showPurchasesWereRestored()
                    self.getFullAccessButton.isHidden = true
                }
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        fullView.isHidden = true
        if IAPManager.shared().isPurchased {
            getFullAccessButton.isHidden = true
        }
    }
    
    private func setup() {
        configureLayout()
        configureButtons()
        configureCollection()
    }
    
    convenience init(_ options: [CleaningOptions]) {
        self.init()
        allOptions = options
    }
    
    deinit {
        print(self, #function)
    }
    
    private func configureLayout() {
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = "F2EFFA".hexColor
        view.addSubviews(menuButton, topWelcomeLabel, severalItemsLabel, cicrleMainImageView, premiumView, homeCollectionView, fullView, getFullAccessButton)
        
        cicrleMainImageView.addSubviews(capacityPercent, storageLabel)
        
        self.premiumView.tryForFreeButton.setTitle("Fast Cleaner".localized, for: .normal)
        premiumView.addSubviews(fastCleanerButton)
        
        menuButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.leading.equalToSuperview().offset(24)
            make.size.equalTo(24)
        }
        
        topWelcomeLabel.snp.makeConstraints { make in
            make.top.equalTo(menuButton.snp.bottom).offset(24)
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalTo(cicrleMainImageView.snp.leading).offset(-5)
            make.height.equalTo(24)
        }
        
        severalItemsLabel.snp.makeConstraints { make in
            make.top.equalTo(topWelcomeLabel.snp.bottom).offset(8)
            make.leading.equalToSuperview().offset(24)
            make.height.equalTo(48)
        }
        
        cicrleMainImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(101)
            make.trailing.equalToSuperview().offset(-24)
            make.size.equalTo(80)
        }
        
        capacityPercent.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(20)
            make.height.equalTo(20)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
        }
        
        storageLabel.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-20)
            make.height.equalTo(16)
            make.leading.equalToSuperview().offset(10)
            make.trailing.equalToSuperview().offset(-10)
        }
        
        premiumView.snp.makeConstraints { make in
            make.top.equalTo(severalItemsLabel.snp.bottom).offset(32)
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(144)
        }
        
        fastCleanerButton.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        homeCollectionView.snp.makeConstraints { make in
            make.top.equalTo(fastCleanerButton.snp.bottom).offset(38.resized())
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(170)
        }
        
        fullView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    
        view.layoutIfNeeded()
    }
    
    private func configureButtons() {
        DispatchQueue.main.async {
            self.menuButton.rx.tap.bind { [weak self] in
                guard let self = self else { return }
                self.menuViewControllerActions()
            }.disposed(by: self.disposeBag)
            
            self.fastCleanerButton.rx.tap.bind { [weak self] in
                IHProgressHUD.show()
                guard let self = self else { return }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    self.fastCleanerButtonActions()
                }
                
            }.disposed(by: self.disposeBag)
            
            self.getFullAccessButton.rx.tap.bind { [weak self] in
                guard let self = self else { return }
                self.premiunButtonAction()
            }.disposed(by: self.disposeBag)
            
        }
    }
    
    private func menuViewControllerActions() {
        var termsVC = MenuViewController()
        navigationController?.pushViewController(termsVC, animated: true)
    }
    
    private func configureCollection() {
        homeCollectionView.setCollectionViewLayout(homeLayout, animated: true)
        homeCollectionView.dataSource = self
        homeCollectionView.delegate = self
        homeCollectionView.register(OptionsCell.self, forCellWithReuseIdentifier: OptionsCell.nibIdentifier)
    }
    
    private func premiunButtonAction() {
        Constants.ud.currentDismissing = 2
        Constants.ud.currentRestoreDismissing = 2
        IAPManager.shared().presentSingleSubscriptionVC(animated: true)
        
        IAPManager.shared().purchaseCompletion = { _ in
            IAPManager.shared().dismissSubscriptionVC()
            //self.premiumView.tryForFreeButton.setTitle("Scan", for: .normal)
        }
        IAPManager.shared().restoreCompletion = { subscription in
            IAPManager.shared().dismissSubscriptionVC()
            if Constants.ud.isPurchased {
                AlertManager.shared().showPurchasesWereRestored()
               // self.premiumView.tryForFreeButton.setTitle("Scan", for: .normal)
            }
        }
    }
    
    // FAST CLEANER action
    private func fastCleanerButtonActions(){
        DispatchQueue.main.async {
            LibraryMediaManager.shared.askPermission(PhotoOptions.similar.fetchPredicate) { [weak self] in
                Constants.ud.currentDismissing = 3
                Constants.ud.currentRestoreDismissing = 2
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                    let vc = FastCleanerViewController()
                    self?.navigationController?.pushViewController(vc, animated: false)
                }
            }
        }
    }
}

extension HomeViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let option = CleaningOptions.contacts
        switch self.options[indexPath.row].nameOptions {
        case "Gallery cleaner".localized:
            IHProgressHUD.show()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                LibraryMediaManager.shared.askPermission(PhotoOptions.similar.fetchPredicate) { [weak self] in
                    DispatchQueue.main.async {
                        guard let self = self else { return }
                        let vc = StorageViewController()
                        self.navigationController?.pushViewController(vc, animated: true)
                        self.fullView.isHidden = false
                        LibraryMediaManager.shared.allSimilarAssets.removeAll()
                    }
                }
            }
            
        case "Contacts".localized:
            IHProgressHUD.show()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                let vc = ContactScreen()
                self.navigationController?.pushViewController(vc, animated: true)
                self.fullView.isHidden = false
            }
            
        default: print("Unknown")
        }
    }
}

extension HomeViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return options.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: OptionsCell.nibIdentifier, for: indexPath) as! OptionsCell
        let option = options[indexPath.row]
        cell.optionsCellModel = option
        return cell
    }
}
