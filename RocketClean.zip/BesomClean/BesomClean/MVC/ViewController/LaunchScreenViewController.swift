import UIKit
import SnapKit

class LaunchScreenViewController: UIViewController {
    
    private var fullScreenImageView: UIImageView = {
        let imageView = UIImageView(image: "FullScreenImageView".image)
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup() {
        configureLayout()
        setHomeViewController()
    }
    
    private func configureLayout() {
        view.addSubviews(fullScreenImageView)
        
        fullScreenImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    }
    private func homeViewControllerAction(){
        let vg = UISearchBar()
        let options = CleaningOptions.allCases
        let vc = HomeViewController(options)
        let nc = UINavigationController(rootViewController: vc)
        guard let window = UIApplication.shared.windows.first else { return }
        window.rootViewController = nc
    }
    
    private func setHomeViewController() {
        
        if UserDefaults.standard.value(forKey: "isShownBefore") != nil {
            isShownBefore = UserDefaults.standard.value(forKey: "isShownBefore") as! Bool
        }
        if isShownBefore {
            homeViewControllerAction()
        } else {
            let controller = PresentViewController()
            let navigationController = UINavigationController(rootViewController: controller)
            UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.rootViewController = navigationController
            UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.makeKeyAndVisible()
        }
    }
}
