import UIKit
import RxCocoa
import RxSwift
import SnapKit
import NetworkExtension
import Network
import MessageUI

class MenuViewController: UIViewController {
    
    public var menuModel = [MenuModel(image: "privacy", title: "Privacy Policy".localized),
                            MenuModel(image: "terms", title: "Terms of Use".localized),
                            MenuModel(image: "restore", title: "Restore purchases".localized),
                            MenuModel(image: "contactM", title: "Contact us".localized),
                            MenuModel(image: "share", title: "Share App".localized)
    ]
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("leftBack".image, for: .normal)
        return button
    }()
    
    private var topMenuLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .heavy)
        label.text = "Settings".localized
        label.textColor = "2F2E33".hexColor
        label.textAlignment = .center
        return label
    }()
    
    private lazy var tableView: UITableView = {
        let table = UITableView()
        table.backgroundColor = .clear
        table.rowHeight = 72
        table.showsVerticalScrollIndicator = false
        table.separatorStyle = .none
        table.isScrollEnabled = false
        return table
    }()
    
    private var emptyPremiumView = PremiumView()
    

    private var premiumButton: UIButton = {
        let button = UIButton()
        return button
    }()
    
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        if IAPManager.shared().isPurchased {
            emptyPremiumView.isHidden = true
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        if IAPManager.shared().isPurchased {
            emptyPremiumView.isHidden = true
            
        }
    }
    
    private func setup() {
        configureLayout()
        setupButtons()
        configureTableView()
    }
    
    private func configureLayout() {
       // navigationController?.isNavigationBarHidden = true
        view.backgroundColor = "F2EFFA".hexColor
        view.addSubviews(backButton, topMenuLabel, tableView, emptyPremiumView)
        
        self.emptyPremiumView.tryForFreeButton.setTitle("Get Premium".localized, for: .normal)
        
        emptyPremiumView.addSubviews(premiumButton)
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.leading.equalToSuperview().offset(24)
            make.size.equalTo(24)
        }
        
        topMenuLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.leading.equalToSuperview().offset(30)
            make.trailing.equalToSuperview().offset(-30)
            make.height.equalTo(24)
        }
        
        tableView.snp.makeConstraints { make in
            make.top.equalTo(topMenuLabel.snp.bottom).offset(46.resized())
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(360)
        }
        
        emptyPremiumView.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-35.resized())
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(144)
        }
        
        premiumButton.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    
        view.layoutIfNeeded()
    }
    
    private func setupButtons() {
        backButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.navigationController?.popViewController(animated: true)
        }.disposed(by: disposeBag)
        
        premiumButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.premiunButtonAction()
        }.disposed(by: disposeBag)
    }
    
    private func premiunButtonAction() {
        IAPManager.shared().presentSubscriptionVC()
        IAPManager.shared().purchaseCompletion = { [weak self] _ in
            IAPManager.shared().dismissSubscriptionVC()
        }
        IAPManager.shared().restoreCompletion = { subscription in
            IAPManager.shared().dismissSubscriptionVC()
            if Constants.ud.isPurchased {
                AlertManager.shared().showPurchasesWereRestored()
            }
        }
    }
    
    private func configureTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(MenuCell.self, forCellReuseIdentifier: MenuCell.nibIdentifier)
    }
    
//    func pushPoliciesVC(_ policiesType: Policies2) {
//        let termsVC = TermsAndPrivacy2()
//        termsVC.policiesType = policiesType
//        navigationController?.pushViewController(termsVC, animated: true)
//    }
    
    func pushPoliciesVC(_ policiesType: Policies) {
        let termsVC = TermsAndPrivacy()
        termsVC.policiesType = policiesType
        navigationController?.pushViewController(termsVC, animated: true)
    }
    
    
    
    
    private func contact() {
        if MFMailComposeViewController.canSendMail() {
            let toRecipients = ["support@rocketclean-app.com"]
            let subject = "Feedback"
            let mail = configuredMailComposeViewController(recipients: toRecipients, subject: subject, body: "", isHtml: true, images: nil)
            presentMailComposeViewController(mailComposeViewController: mail)
        } else {
            print("You don't have email in Mail iOS App")
        }
    }
    
    func share() {
        UIGraphicsBeginImageContext(view.frame.size)
        view.layer.render(in: UIGraphicsGetCurrentContext()!)
        
        let textToShare = "Check out my app"

        if let myWebsite = URL(string: "http://itunes.apple.com/app/\(Constants.app.appid)") {//Enter link to your app here
            let objectsToShare = [textToShare, myWebsite] as [Any]
            let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            activityVC.excludedActivityTypes = [UIActivity.ActivityType.airDrop, UIActivity.ActivityType.addToReadingList]
            activityVC.popoverPresentationController?.sourceView = self.view
            self.present(activityVC, animated: true, completion: nil)
        }
    }
    
    private func restore() {
        if Constants.ud.isPurchased {
            AlertManager.shared().showNoPurchasesToRestore()
        } else {
            IAPManager.shared().restore()
            IAPManager.shared().restoreCompletion = { subscription in
                if Constants.ud.isPurchased {
                    IAPManager.shared().dismissSubscriptionVC()
                    AlertManager.shared().showPurchasesWereRestored()
                }
            }
        }
    }
}

extension MenuViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch menuModel[indexPath.row].title {
        case "Privacy Policy".localized:
            pushPoliciesVC(.privacy)
        case "Terms of Use".localized:
            pushPoliciesVC(.terms)
        case "Contact us".localized:
            contact()
        case "Restore purchases".localized:
            restore()
        case "Share App".localized:
            share()
        default: print("Unknown")
        }
    }
}

extension MenuViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuModel.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: MenuCell.nibIdentifier, for:  indexPath) as! MenuCell
        let menuModelTwo = menuModel[indexPath.row]
        cell.menuModel = menuModelTwo
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
}

