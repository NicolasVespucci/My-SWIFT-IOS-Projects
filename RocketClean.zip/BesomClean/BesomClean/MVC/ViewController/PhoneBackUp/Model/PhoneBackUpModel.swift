import Foundation


struct PhoneBackUpModel {
    var name: String?
    var number: String?
    var checkSelected: Bool?
}
