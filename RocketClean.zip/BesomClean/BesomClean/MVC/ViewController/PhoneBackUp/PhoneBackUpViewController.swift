import UIKit
import RxSwift
import Contacts
import ContactsUI
import SwiftyContacts

class PhoneBackUpViewController: UIViewController {
    
    //MARK: User Interface Elements

    private var backupContactsLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 17, weight: .semibold)
        label.text = "BackUp Phones".localized
        label.textColor = "2F2E33".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("leftBack".image, for: .normal)
        return button
    }()
    
    private var addToContactsButton: UIButton = {
        let button = UIButton()
        button.setTitle("Add".localized, for: .normal)
        button.setTitleColor("8B68DF".hexColor, for: .normal)
        button.backgroundColor = .clear
        return button
    }()
    
    
    private var phoneBackUpTableView: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 56
        table.backgroundColor = .clear
        table.isScrollEnabled = true
        table.separatorStyle = .none
        
        return table
    }()
    
    //MARK: Var and Let

    let disposeBag = DisposeBag()
    public var dataContact: Data?
    public var currentPhoneBackUp = [PhoneBackUpModel]()
    
    var currentContact = [CNContact]()
    var currentCell = 0
    
    let valueForSelectedCell = false
    var selectedCellValue = [Bool]()
    
    //MARK: viewDidLoad
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    //MARK: Setup
    
    private func setup(){
        contactSetup()
        layoutSetup()
        setupTable()
        setupButtons()
    }
    
    //MARK: Setup Layout
    
    private func layoutSetup(){
        view.backgroundColor = "F2EFFA".hexColor
        view.addSubviews(backupContactsLabel, backButton, addToContactsButton, phoneBackUpTableView)
        
        backupContactsLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54.resized())
            make.height.equalTo(24)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
        }
        
        backButton.snp.makeConstraints { make in
            make.top.equalTo(backupContactsLabel.snp.bottom).offset(5)
            make.leading.equalToSuperview().offset(24)
            make.size.equalTo(24)
        }
        
        addToContactsButton.snp.makeConstraints { make in
            make.top.equalTo(backupContactsLabel.snp.bottom).offset(5)
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(24)
        }
        
        phoneBackUpTableView.snp.makeConstraints { make in
            make.top.equalTo(backButton.snp.bottom).offset(10)
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.bottom.equalToSuperview()
        }
    }
    
    //MARK: Configure TableView
    
    private func setupTable(){
        phoneBackUpTableView.delegate = self
        phoneBackUpTableView.dataSource = self
        phoneBackUpTableView.register(PhoneBackUpCell.self, forCellReuseIdentifier: PhoneBackUpCell.nibIdentifier)
    }
    
    //MARK: Setup Buttons
    
    private func setupButtons(){
        backButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.navigationController?.popViewController(animated: true)
        }.disposed(by: disposeBag)
        
        addToContactsButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.addNewContacts()
        }.disposed(by: disposeBag)
        
    }
    
    private func configureSelectedCell() {
        // Filling our array with selected cell
        selectedCellValue = []
        for contact in currentPhoneBackUp {
            selectedCellValue.append(contact.checkSelected ?? false)
        }
    }

    
    //MARK: Configure Selected BackUp Contacts
    
    private func contactSetup(){
        
        let transformationIntoContacts = NSKeyedUnarchiver.unarchiveObject(with: dataContact!) as? [CNContact]
        
        var contacts = [CNContact]()
    
        contacts = transformationIntoContacts ?? [CNContact]()
        currentContact = transformationIntoContacts ?? [CNContact]()
        
        //MARK: Mutable Contact
       // var mutableContact: [CNMutableContact] = []
        
        for contact in contacts {
            
            let fullName = contact.givenName + " " + contact.familyName
            let number = contact.phoneNumbers.first?.value.stringValue ?? ""

            self.currentPhoneBackUp.append(PhoneBackUpModel(name: "\(fullName)", number: "\(number)", checkSelected: false))
            //MARK: Convert Contact in Mutable Contact and add 
           // mutableContact.append(contact.mutableCopy() as! CNMutableContact)
        }
        
        print("reloade Data------------------->>>>>>>")
        phoneBackUpTableView.reloadData()
    }
    
    
    //MARK: Add New Contacts in Contacts Store
    private func addNewContacts(){
        if currentPhoneBackUp[currentCell].checkSelected == true {
            var countDuplicateContact = 0
            var errorValue = false
            var mutableContact: [CNMutableContact] = []
            
            // Conversion CNContacts in CNMutbleContacts and add in CNContacts Array
            for contact in currentContact {
                mutableContact.append(contact.mutableCopy() as! CNMutableContact)
            }

            selectedCellValue.enumerated().forEach({ (index, selected) in
                if selected == true {
                    // Adding a contact to contacts in iphone
                    var contactForRecovery = mutableContact[index]
                    addContact(Contact: contactForRecovery) { (result) in
                        switch result{
                            case .Success(response: let bool):
                                if bool{
                                    print("Contact Sucessfully Added")
                                    self.currentPhoneBackUp[self.currentCell].checkSelected = false
                                    AlertManager.shared().savedContact()
                                }
                                break
                            case .Error(error: let error):
                                print(error.localizedDescription)
                            countDuplicateContact += 1
                            errorValue = true
                                break
                        }
                    }
                }
            })
            
            if errorValue == true {
                AlertManager.shared().notSavedContact(count: countDuplicateContact)
            }
            
            currentPhoneBackUp = [PhoneBackUpModel]()
            contactSetup()
            phoneBackUpTableView.reloadData()
        }
    }
}


//MARK: UITableViewDelegate, UITableViewDataSource

extension PhoneBackUpViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if currentPhoneBackUp[indexPath.row].checkSelected == true {
            currentCell = indexPath.row
            currentPhoneBackUp[indexPath.row].checkSelected = false
            configureSelectedCell()
            phoneBackUpTableView.reloadData()
        } else {
            currentCell = indexPath.row
            currentPhoneBackUp[indexPath.row].checkSelected = true
            configureSelectedCell()
            phoneBackUpTableView.reloadData()
        }
    }
}

extension PhoneBackUpViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return currentPhoneBackUp.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = phoneBackUpTableView.dequeueReusableCell(withIdentifier: PhoneBackUpCell.nibIdentifier, for: indexPath) as! PhoneBackUpCell
        let phoneBackUpModel = currentPhoneBackUp[indexPath.row]
        cell.phoneBackUpModel = phoneBackUpModel
        return cell
    }
}
