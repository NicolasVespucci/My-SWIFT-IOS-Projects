import UIKit
import BEMCheckBox

class PhoneBackUpCell: UITableViewCell {
    
    var phoneBackUpModel: PhoneBackUpModel? {
        didSet { configurephoneBackUpModel() }
    }
    
    private var cellView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 16
        return view
    }()
    
    private var nameLabel: UILabel = {
          let label = UILabel()
          label.font = .systemFont(ofSize: 15, weight: .regular)
          label.text = "Nov 15, 2021 23:05"
          label.textColor = "2F2E33".hexColor
          label.textAlignment = .left
//          label.adjustsFontSizeToFitWidth = true
//          label.minimumScaleFactor = 0.5
          return label
      }()
    
    private var numberLabel: UILabel = {
          let label = UILabel()
          label.font = .systemFont(ofSize: 15, weight: .regular)
          label.text = "726"
          label.textColor = "2F2E33".hexColor
          label.textAlignment = .left
//          label.adjustsFontSizeToFitWidth = true
//          label.minimumScaleFactor = 0.5
          return label
      }()
    
    public var checkContact: BEMCheckBox! = {
        let box = BEMCheckBox()
        box.boxType = .circle
        box.onAnimationType = .fill
        box.offAnimationType = .fill
        box.onFillColor = "8B68DF".hexColor
        box.onTintColor = "8B68DF".hexColor
        box.onCheckColor = .white
        box.isUserInteractionEnabled = true
        return box
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        selectionStyle = .none
        setupLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupLayout(){
        addSubview(cellView)
        cellView.addSubviews(nameLabel, numberLabel, checkContact)
        
        cellView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(48)
        }
    
        nameLabel.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.height.equalTo(24)
            make.leading.equalToSuperview().offset(15)
            make.trailing.equalTo(checkContact.snp.leading).offset(-5)
        }
        
        numberLabel.snp.makeConstraints { make in
            make.bottom.equalToSuperview()
            make.height.equalTo(24)
            make.leading.equalToSuperview().offset(15)
            make.trailing.equalTo(checkContact.snp.leading).offset(-5)
        }
        
        checkContact.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.size.equalTo(24)
            make.trailing.equalToSuperview().offset(-16)
        }
        
    }
    
    private func configurephoneBackUpModel() {
        guard let phoneBackUpModel = phoneBackUpModel else { return }
        nameLabel.text = phoneBackUpModel.name
        numberLabel.text = phoneBackUpModel.number
        checkContact.setOn(phoneBackUpModel.checkSelected ?? false, animated: false)
    }
}
