import UIKit

class SecretSpaceViewController: UIViewController {
    
    private var secretSpaceLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 17, weight: .semibold)
        label.text = "Secret space"
        label.textColor = "2F2E33".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("leftBack".image, for: .normal)
        return button
    }()
    
    private var settingsButton: UIButton = {
        let button = UIButton()
        button.setImage("settingSecret".image, for: .normal)
        return button
    }()
    
    private var emptyMediaImageView: UIImageView = {
        let imageView = UIImageView(image: "emptyMedia".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private var noMediaYetLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 13, weight: .regular)
        label.text = "No Backups made yet"
        label.textColor = "8B68DF".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var addMediaButton: UIButton = {
        let button = UIButton()
        button.layer.cornerRadius = 16
        button.setTitle("Add Media", for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 17, weight: .medium)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = "8B68DF".hexColor
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    private func setup(){
        view.addSubviews(secretSpaceLabel, backButton, settingsButton, emptyMediaImageView, noMediaYetLabel, addMediaButton)
        
        secretSpaceLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.height.equalTo(24)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
        }
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.leading.equalToSuperview().offset(24)
            make.size.equalTo(24)
        }
        
        settingsButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54)
            make.trailing.equalToSuperview().offset(-24)
            make.size.equalTo(24)
        }
        
        emptyMediaImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
            make.size.equalTo(98)
        }
        
        noMediaYetLabel.snp.makeConstraints { make in
            make.top.equalTo(emptyMediaImageView.snp.bottom).offset(16)
            make.height.equalTo(64)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
        }
//
//        addMediaButton.snp.makeConstraints { make in
//
//        }
        
    }
    
    private func setupLayout(){
        
    }
    
    
    
}
