import RxSwift
import RxCocoa
import Photos
import UIKit
import SnapKit
import IHProgressHUD

//MARK: - CONTROLLER

class StorageViewController: UIViewController {
    
    private var libraryManager: LibraryMediaManager! {
        return LibraryMediaManager.shared
    }
    
    //MARK: - Volume Sections Photo in Storage View Controller
    //Similar Photo
    var memoryDuplicatesVolume = 0.0
    var memoryDuplicatesVolumeString = ""
    //Screenshot
    public var memoryScreenshotVolume = 0.0
    public var memoryScreenshotVolumeString = ""
    //Live Photo
    public var memoryLivePhotoVolume = 0.0
    public var memoryLivePhotoVolumeString = ""
    //Burst Phoro
    public var memoryBurstPhoroVolume = 0.0
    public var memoryBurstPhoroVolumeString = ""
    
    public var sectionsName = [CleaningCategoryModel(image: "Similar",nameSections: "Similar files".localized, sectionsImageArray: LibraryMediaManager.shared.allSimilarAssets, volumeStorage: ""),
                               CleaningCategoryModel(image: "Screenshots", nameSections: "Screenshots".localized, sectionsImageArray: LibraryMediaManager.shared.allScreenshotAssets, volumeStorage: ""),
                               CleaningCategoryModel(image: "Live",nameSections: "Live Photo".localized, sectionsImageArray:
                                                        LibraryMediaManager.shared.allPhotoLiveAssets, volumeStorage: ""),
                               CleaningCategoryModel(image: "Burst",nameSections: "Burst Photo".localized, sectionsImageArray:
                                                        LibraryMediaManager.shared.allBurstPhotoAssets, volumeStorage: ""),
                               CleaningCategoryModel(image: "videoG",nameSections: "Video".localized, sectionsImageArray:
                                                        LibraryMediaManager.shared.allVideoAssets, volumeStorage: "")]
    
    let disposeBag = DisposeBag()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("leftBack".image, for: .normal)
        return button
    }()
    
    private var topStorageLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 17, weight: .semibold)
        label.text = "Gallery cleaner".localized
        label.textColor = "2F2E33".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var scanningLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 24, weight: .heavy)
        label.text = "Scanning...".localized
        label.textColor = "8B68DF".hexColor
        label.textAlignment = .center
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var noDublicateLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 30, weight: .heavy)
        label.text = "Everything is clean, \n no duplicates found on your phone".localized
        label.textColor = "8B68DF".hexColor
        label.textAlignment = .center
        label.numberOfLines = 0
        label.isHidden = true
        return label
    }()
    
    private lazy var galleryCleanerCollectionView: UICollectionView = {
        let collection = UICollectionView(frame: .zero, collectionViewLayout: .init())
        collection.backgroundColor = .clear
        collection.showsHorizontalScrollIndicator = false
        collection.showsVerticalScrollIndicator = false
        collection.isScrollEnabled = true
        collection.clipsToBounds = false
        return collection
    }()
    
    private lazy var galleryCleanerLayout: UICollectionViewLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 0
        layout.itemSize = .init(width: 155.5, height: 176)
        layout.minimumInteritemSpacing = 16
        layout.minimumLineSpacing = 16
        layout.sectionInset = .init(top: 0, left: 0, bottom: 0, right: 0)
        return layout
    }()
    
//    
    //MARK: - Table View
    
    private lazy var storageTableView: UITableView = {
        let table = UITableView()
        table.backgroundColor = .clear
        table.rowHeight = 172
        table.showsVerticalScrollIndicator = false
        table.separatorStyle = .none
        table.isScrollEnabled = true
        return table
    }()
    
    private var cleanerOptionAssetsOne: [[LibraryMediaManager.SimilarObject]] = [[]]
    //MARK: - LibraryMediaManager
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureLayout()
        //setupSimilarPhoto()
    }
    
    private func configureLayout() {
        view.backgroundColor = "F2EFFA".hexColor
        view.addSubviews(backButton, topStorageLabel, galleryCleanerCollectionView, scanningLabel, noDublicateLabel)
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54.resized())
            make.leading.equalToSuperview().offset(24)
            make.size.equalTo(24)
        }
        
        topStorageLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(54.resized())
            make.leading.equalToSuperview().offset(75)
            make.trailing.equalToSuperview().offset(-75)
            make.height.equalTo(24)
        }
        
        galleryCleanerCollectionView.snp.makeConstraints { make in
            make.top.equalTo(topStorageLabel.snp.bottom).offset(14)
            make.leading.equalToSuperview().offset(24)
            make.trailing.equalToSuperview().offset(-24)
            make.bottom.equalToSuperview()
        }
        
        scanningLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview().offset(25)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(50)
        }
        
        noDublicateLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(200)
        }
        
        backButton.rx.tap.bind { [weak self] in
            self?.navigationController?.popViewController(animated: true)
        }.disposed(by: disposeBag)
    }
    
    //MARK: - Setup Table View
    
    
    private func configureCollection() {
        galleryCleanerCollectionView.setCollectionViewLayout(galleryCleanerLayout, animated: true)
        galleryCleanerCollectionView.dataSource = self
        galleryCleanerCollectionView.delegate = self
        galleryCleanerCollectionView.register(StorageTableViewCell.self, forCellWithReuseIdentifier: StorageTableViewCell.nibIdentifier)
    }
    
    func setupSimilarPhoto() {
        IHProgressHUD.show()
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            // Duplicates Photo
            self.libraryManager.askPermission(PhotoOptions.similar.fetchPredicate) { [weak self] in
                DispatchQueue.main.async { [weak self] in
                    guard let self = self else { return }
                    self.sectionsName[0].sectionsImageArray = self.libraryManager.allSimilarAssets
                    IHProgressHUD.dismiss()
                    self.sectionsName[0].volumeStorage = self.libraryManager.getSize(assets: self.libraryManager.allSimilarAssets)
                }
            }
            //2  Screenshots Photo
            self.libraryManager.askPermission(PhotoOptions.screens.fetchPredicate) { [weak self] in
                DispatchQueue.main.async { [weak self] in
                    guard let self = self else { return }
                    self.sectionsName[1].sectionsImageArray = self.libraryManager.allScreenshotAssets
                    IHProgressHUD.dismiss()
                    self.sectionsName[1].volumeStorage = self.libraryManager.getSize(assets: self.libraryManager.allScreenshotAssets)
                }
            }
            //3 Live Photo
            self.libraryManager.askPermission(PhotoOptions.live.fetchPredicate) { [weak self] in
                DispatchQueue.main.async { [weak self] in
                    guard let self = self else { return }
                    self.sectionsName[2].sectionsImageArray = self.libraryManager.allPhotoLiveAssets
                    IHProgressHUD.dismiss()
                    self.sectionsName[2].volumeStorage = self.libraryManager.getSize(assets: self.libraryManager.allPhotoLiveAssets)
                }
            }
            //4 Burst photo
            self.libraryManager.askPermission(PhotoOptions.burst.fetchPredicate) { [weak self] in
                DispatchQueue.main.async { [weak self] in
                    guard let self = self else { return }
                    self.sectionsName[3].sectionsImageArray = self.libraryManager.allBurstPhotoAssets
                    IHProgressHUD.dismiss()
                    self.sectionsName[3].volumeStorage = self.libraryManager.getSize(assets: self.libraryManager.allBurstPhotoAssets)
                }
            }
            self.libraryManager.fetchVideos { [weak self] in
                DispatchQueue.main.async {
                    guard let self = self else { return }
                    self.sectionsName[4].sectionsImageArray = self.libraryManager.allVideoAssets
                    IHProgressHUD.dismiss()
                    self.sectionsName[4].volumeStorage = self.libraryManager.getSize(assets: self.libraryManager.allVideoAssets)
                    //self.configureTableView()
                   // self.configureCollection()
                    self.scanningLabel.isHidden = true
                    
            
                    IHProgressHUD.dismiss()
                    
                    var currentCountInLibraryPhotoVideo = [self.libraryManager.allSimilarAssets.count, self.libraryManager.allScreenshotAssets.count, self.libraryManager.allPhotoLiveAssets.count, self.libraryManager.allBurstPhotoAssets.count, self.libraryManager.allVideoAssets.count]
                    
                   if currentCountInLibraryPhotoVideo.filter({$0 == 0}).count == 5 {
                       self.noDublicateLabel.isHidden = false
                       self.storageTableView.isHidden = true
                   } else {
                       self.noDublicateLabel.isHidden = true
                       // self.configureTableView()
                       self.configureCollection()
                       self.storageTableView.reloadData()
                    }
                }
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.scanningLabel.isHidden = false
        setupSimilarPhoto()
    }
    
    func getMemoryString(volume: Double) -> String {
        if volume / 1024.0 < 1.0 {
            return String(format: "%.2f Mb", volume)
        } else {
            return String(format: "%.2f Gb", volume/1024.0)
        }
    }
    
    deinit {
        print(self, #function)
        libraryManager.itemsToDelete.accept([])
        libraryManager.fetchResult = nil
        libraryManager.allSimilarAssets.removeAll()
        libraryManager.allScreenshotAssets.removeAll()
        libraryManager.allPhotoLiveAssets.removeAll()
        libraryManager.allBurstPhotoAssets.removeAll()
        libraryManager.allVideoAssets.removeAll()
        libraryManager.similars.removeAll()
    }
    
    
    private func presentPayWall(){
        IAPManager.shared().presentSingleSubscriptionVC(animated: true)
        
        IAPManager.shared().purchaseCompletion = { _ in
            IAPManager.shared().dismissSubscriptionVC()
        }
        IAPManager.shared().restoreCompletion = { subscription in
            IAPManager.shared().dismissSubscriptionVC()
            if Constants.ud.isPurchased {
                AlertManager.shared().showPurchasesWereRestored()
            }
        }
    }
}

extension StorageViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        
        switch sectionsName[indexPath.row].nameSections {
        case "Similar files".localized:
            IHProgressHUD.show()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                let selectedOption = PhotoOptions.similar
                let vc = AssetsScreen(selectedOption)
                self.navigationController?.pushViewController(vc, animated: false)
            }
        case "Screenshots".localized:
                if IAPManager.shared().isPurchased {
                    IHProgressHUD.show()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        let selectedOption = PhotoOptions.screens
                        let vc = AssetsScreen(selectedOption)
                        self.navigationController?.pushViewController(vc, animated: false)
                    }
                } else {
                    Constants.ud.currentDismissing = 2
                    Constants.ud.currentRestoreDismissing = 2
                    presentPayWall()
                }
        case "Live Photo".localized:
                if IAPManager.shared().isPurchased {
                    IHProgressHUD.show()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        let selectedOption = PhotoOptions.live
                        let vc = AssetsScreen(selectedOption)
                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                } else {
                    Constants.ud.currentDismissing = 2
                    Constants.ud.currentRestoreDismissing = 2
                    presentPayWall()
                }
        case "Burst Photo".localized:
            if IAPManager.shared().isPurchased {
                IHProgressHUD.show()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    let selectedOption = PhotoOptions.burst
                    let vc = AssetsScreen(selectedOption)
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            } else {
                Constants.ud.currentDismissing = 2
                Constants.ud.currentRestoreDismissing = 2
                presentPayWall()
            }
            
        case "Video".localized:
            if IAPManager.shared().isPurchased {
                IHProgressHUD.show()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    let vc = AssetsScreen(nil)
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            } else {
                Constants.ud.currentDismissing = 2
                Constants.ud.currentRestoreDismissing = 2
                presentPayWall()
            }
        default:
            break
        }
    }
}

extension StorageViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return sectionsName.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: StorageTableViewCell.nibIdentifier, for: indexPath) as! StorageTableViewCell
        let sectionsName = sectionsName[indexPath.row]
        cell.cleaningCategoryModel = sectionsName
        return cell
    }
}

