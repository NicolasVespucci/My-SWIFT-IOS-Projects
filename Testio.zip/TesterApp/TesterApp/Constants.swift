import Foundation
import UIKit

var UD = UserDefaults.standard

public struct Constants {
    
    static var app = AppConstants()
    static var ud = UDConstants()
    
    struct AppConstants {
        let appid = "1626428471"
    }

    struct UDConstants {
    
        //MARK: For Testing App
        
        var digitizer: Int? {
            set { UD.set(newValue, forKey: "digitizer") }
            get { return UD.integer(forKey: "digitizer") }
        }

        var multiToch: Int? {
            set { UD.set(newValue, forKey: "multiToch") }
            get { return UD.integer(forKey: "multiToch") }
        }
        
        var threeDTouch: Int? {
            set { UD.set(newValue, forKey: "threeDTouch") }
            get { return UD.integer(forKey: "threeDTouch") }
        }
        
        var faceIDTouchID: Int? {
            set { UD.set(newValue, forKey: "faceIDTouchID") }
            get { return UD.integer(forKey: "faceIDTouchID") }
        }
        
        var LCD: Int? {
            set { UD.set(newValue, forKey: "LCD") }
            get { return UD.integer(forKey: "LCD") }
        }
        
        var proximitySensor: Int? {
            set { UD.set(newValue, forKey: "proximitySensor") }
            get { return UD.integer(forKey: "proximitySensor") }
        }
        
        var vibration: Int? {
            set { UD.set(newValue, forKey: "vibration") }
            get { return UD.integer(forKey: "vibration") }
        }
        
        var flash: Int? {
            set { UD.set(newValue, forKey: "flash") }
            get { return UD.integer(forKey: "flash") }
        }
        
        var GPS: Int? {
            set { UD.set(newValue, forKey: "GPS") }
            get { return UD.integer(forKey: "GPS") }
        }
        
        var bottonMicrophone : Int? {
            set { UD.set(newValue, forKey: "bottonMicrophone") }
            get { return UD.integer(forKey: "bottonMicrophone") }
        }
        
        var frontMicrophone: Int? {
            set { UD.set(newValue, forKey: "frontMicrophone") }
            get { return UD.integer(forKey: "frontMicrophone") }
        }
        
        var rearMicrophone: Int? {
            set { UD.set(newValue, forKey: "rearMicrophone") }
            get { return UD.integer(forKey: "rearMicrophone") }
        }
        
        var speakerTop: Int? {
            set { UD.set(newValue, forKey: "speakerTop") }
            get { return UD.integer(forKey: "speakerTop") }
        }
        
        var speakerBotton: Int? {
            set { UD.set(newValue, forKey: "speakerBotton") }
            get { return UD.integer(forKey: "speakerBotton") }
        }
        
        var powerButtom: Int? {
            set { UD.set(newValue, forKey: "powerButtom") }
            get { return UD.integer(forKey: "powerButtom") }
        }
        
        
        var thisIsTheBottonMic: Bool {
            get { return UD.bool(forKey: "thisIsTheBottonMic") }
            set { UD.set(newValue, forKey: "thisIsTheBottonMic") }
        }
        
        var thisIsTheFrontMic: Bool {
            get { return UD.bool(forKey: "thisIsTheFrontMic") }
            set { UD.set(newValue, forKey: "thisIsTheFrontMic") }
        }
        
        var thisIsTheRaerMic: Bool {
            get { return UD.bool(forKey: "thisIsTheRaerMic") }
            set { UD.set(newValue, forKey: "thisIsTheRaerMic") }
        }
        
        var micWorking: Bool {
            get { return UD.bool(forKey: "micWorking") }
            set { UD.set(newValue, forKey: "micWorking") }
        }
        
        var accessMic: Bool {
            get { return UD.bool(forKey: "micWorking") }
            set { UD.set(newValue, forKey: "micWorking") }
        }
    }
}

