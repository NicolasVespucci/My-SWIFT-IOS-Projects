import UIKit
import Foundation

extension CALayer {
  
  func addBorder(edge: UIRectEdge, color: UIColor, thickness: CGFloat) {
    
    let border = CALayer()
    
    switch edge {
    case UIRectEdge.top:
      border.frame = CGRect(x: 0, y: 0, width: frame.width, height: thickness)
      
    case UIRectEdge.bottom:
      border.frame = CGRect(x:0, y: frame.height - thickness, width: frame.width, height:thickness)
      
    case UIRectEdge.left:
      border.frame = CGRect(x:0, y:0, width: thickness, height: frame.height)
      
    case UIRectEdge.right:
      border.frame = CGRect(x: frame.width - thickness, y: 0, width: thickness, height: frame.height)
      
    default: do {}
    }
    
    border.backgroundColor = color.cgColor
    
    addSublayer(border)
  }
}

extension CAGradientLayer {
  
  typealias GradientType = (x: CGPoint, y: CGPoint)
  
  enum GradientPoint {
    case leftRight
    case rightLeft
    case topBottom
    case bottomTop
    case topLeftBottomRight
    case bottomRightTopLeft
    case topRightBottomLeft
    case bottomLeftTopRight
    
    func draw() -> GradientType {
      switch self {
      case .leftRight:
        return (x: CGPoint(x: 0, y: 0.5), y: CGPoint(x: 1, y: 0.5))
      case .rightLeft:
        return (x: CGPoint(x: 1, y: 0.5), y: CGPoint(x: 0, y: 0.5))
      case .topBottom:
        return (x: CGPoint(x: 0.5, y: 0), y: CGPoint(x: 0.5, y: 1))
      case .bottomTop:
        return (x: CGPoint(x: 0.5, y: 1), y: CGPoint(x: 0.5, y: 0))
      case .topLeftBottomRight:
        return (x: CGPoint(x: 0, y: 0), y: CGPoint(x: 1, y: 1))
      case .bottomRightTopLeft:
        return (x: CGPoint(x: 1, y: 1), y: CGPoint(x: 0, y: 0))
      case .topRightBottomLeft:
        return (x: CGPoint(x: 1, y: 0), y: CGPoint(x: 0, y: 1))
      case .bottomLeftTopRight:
        return (x: CGPoint(x: 0, y: 1), y: CGPoint(x: 1, y: 0))
      }
    }
  }
  
  convenience init(frame: CGRect? = CGRect.zero, gradient: GradientPoint, colors: [UIColor]) {
    self.init()
    self.colors = colors.map({$0.cgColor})
    self.frame = frame!
    startPoint = gradient.draw().x
    endPoint = gradient.draw().y
  }
  
  func toImage() -> UIImage {
    UIGraphicsBeginImageContext(self.bounds.size)
    self.render(in: UIGraphicsGetCurrentContext()!)
    let image = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    return image ?? UIImage()
  }
}
