

public struct KeyedConfig {

    public static var `default` = KeyedConfig()

    public var keyOptions: KeyOptions

    public init(keyOptions: KeyOptions = KeyOptions(delimiter: .character("."), flat: .emptyOrWhitespace)) {
        self.keyOptions = keyOptions
    }

//    public struct Encoding {
//
//    }
//
//    public struct Decoding {
//        
//    }
}


