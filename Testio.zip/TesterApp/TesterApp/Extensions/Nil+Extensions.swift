//
//  Optional+Extensions.swift
//  MXScrollTutorial
//
//  Created by Marcel Spinu on 6/27/19.
//  Copyright © 2019 Marcel Spinu. All rights reserved.
//

import Foundation
import UIKit

protocol StringType {
  var isEmpty: Bool { get }
}

extension String : StringType { }

extension Optional where Wrapped: StringType {
  var isNilOrEmpty: Bool {
    return self?.isEmpty ?? true
  }
}

extension Optional where Wrapped == String {
  var describing: String {
    return String(describing: self)
  }
}

extension Optional where Wrapped == Double {
  var describing: String {
    return String(describing: self)
  }
}

extension Optional where Wrapped == Int {
  var describing: String {
    return String(describing: self)
  }
}

extension Optional where Wrapped == CGFloat {
  var describing: String {
    return String(describing: self)
  }
}

extension Optional {
  var isNil: Bool {
    return self == nil
  }
  
  var isNotNil: Bool {
    return self != nil
  }
  
  func ifLet(_ action: (Wrapped)-> Void) {
    if self != nil {
      action(self.unsafelyUnwrapped)
    }
    else { return }
  }
  
  func ifNil (_ action: ()-> Void) {
    if self == nil { action() }
    else { return }
  }
  
  func ifElse(_ notNil: ()-> Void, _ isNil: ()-> Void) {
    if self != nil { notNil() }
    else { isNil() }
  }
  
  func or<T>(_ opt: T) -> T {
    if self == nil { return opt }
    else { return self as! T }
  }
  
  mutating func orChange<T>(_ opt: T) {
    if self == nil { self = opt as? Wrapped }
  }
}
