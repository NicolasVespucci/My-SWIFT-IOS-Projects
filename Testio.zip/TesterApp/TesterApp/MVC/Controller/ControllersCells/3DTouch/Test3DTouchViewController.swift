import UIKit
import RxSwift

class Test3DTouchViewController: UIViewController {
    
     let redView = UIView()
     lazy var tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(tapHandler))
     lazy var forceTouchGestureRecognizer = ForceTouchGestureRecognizer(target: self, action: #selector(forceTouchHandler))

    private var centerLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 25, weight: .regular)
        label.textColor = .black
        label.textAlignment = .center
        label.text = "Push harder"
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()

    private var tutorialImageView: UIImageView = {
        let imageView = UIImageView(image: "3dTouchTest".image)
        return imageView
    }()
    
    private var tutorialBackButton: UIButton = {
        let button = UIButton()
        button.setImage("backButton".image, for: .normal)
        return button
    }()
    
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    
//    override func viewWillAppear(_ animated: Bool) {
//        super.viewWillAppear(animated)
//        //MARK: Power Button detectet
//        NotificationCenter.default.addObserver(
//            forName: UIApplication.userDidTakeScreenshotNotification,
//            object: nil,
//            queue: .main) { notification in
//                AlertManager.shared().powerButton()
//        }
//    }
    
    
//    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
//        super.touchesMoved(touches, with: event)
//
//        if let touch = touches.first {
//            if view.traitCollection.forceTouchCapability == .available {
//                if touch.force == touch.maximumPossibleForce {
//                    // user pressed hard – do something!
//                    print("touch.force--->",touch.force)
//                    print("touch.maximum--->",touch.maximumPossibleForce)
//                }
//                print("2touch.force--->",touch.force)
//                print("2touch.maximum--->",touch.maximumPossibleForce)
//            }
//        }
//    }
    
    private func setup() {
        setupLayout()
        setupButtons()
       // dismisingTutorial()
    }
    
    private func setupLayout() {
        view.addSubviews(redView, tutorialImageView, tutorialBackButton)
        redView.addSubview(centerLabel)
        view.backgroundColor = .white
        redView.addGestureRecognizer(forceTouchGestureRecognizer)
        
        redView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        tutorialImageView.snp.makeConstraints { make in
            make.width.equalTo(129)
            make.height.equalTo(183)
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
        }
        
        tutorialBackButton.snp.makeConstraints { make in
            make.size.equalTo(84)
            make.bottom.equalToSuperview().offset(-54)
            make.centerX.equalToSuperview()
        }
        
        
        centerLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(150)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(30)
        }
    }
    
    private func setupButtons() {
        tutorialBackButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.dismiss(animated: true)
        }.disposed(by: disposeBag)
    }
    
    private func dismisingTutorial(){
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.tutorialImageView.isHidden = true
        }
    }
    
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)

        if traitCollection.forceTouchCapability == UIForceTouchCapability.available {
            redView.addGestureRecognizer(forceTouchGestureRecognizer)
        } else  {
            // When force touch is not available, remove force touch gesture recognizer.
            // Also implement a fallback if necessary (e.g. a long press gesture recognizer)
            redView.removeGestureRecognizer(forceTouchGestureRecognizer)
        }
    }

    @objc func tapHandler(_ sender: UITapGestureRecognizer) {
        print("Tap triggered")
    }

    @objc func forceTouchHandler(_ sender: ForceTouchGestureRecognizer) {
        UINotificationFeedbackGenerator().notificationOccurred(.success)
        print("Force touch triggered")
        AlertManager.shared().forceTouch()
        Constants.ud.threeDTouch = 2
    }

}
