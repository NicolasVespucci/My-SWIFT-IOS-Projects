import UIKit
import RxSwift

class DigitizerView: UIView {
    var completion1: (()->())?
    var completion2: (()->())?
    
    var simpl1 = SimpleView()
    var simpl2 = SimpleView()
    var simpl3 = SimpleView()
    var simpl4 = SimpleView()
    var simpl5 = SimpleView()
    var simpl6 = SimpleView()
    var simpl7 = SimpleView()
    var simpl8 = SimpleView()
    var simpl9 = SimpleView()
    var simpl10 = SimpleView()
    var simpl11 = SimpleView()
    var simpl12 = SimpleView()
    var simpl13 = SimpleView()
    var simpl14 = SimpleView()
    var simpl15 = SimpleView()
    var simpl16 = SimpleView()
    var simpl17 = SimpleView()
    var simpl18 = SimpleView()
    var simpl19 = SimpleView()
    var simpl20 = SimpleView()
    var simpl21 = SimpleView()
    var simpl22 = SimpleView()
    var simpl23 = SimpleView()
    var simpl24 = SimpleView()
    var simpl25 = SimpleView()
    var simpl26 = SimpleView()
    var simpl27 = SimpleView()
    var simpl28 = SimpleView()
    var simpl29 = SimpleView()
    var simpl30 = SimpleView()
    var simpl31 = SimpleView()
    var simpl32 = SimpleView()
    var simpl33 = SimpleView()
    var simpl34 = SimpleView()
    var simpl35 = SimpleView()
    var simpl36 = SimpleView()
    
    private var centerLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 25, weight: .regular)
        label.textColor = .black
        label.textAlignment = .center
        label.text = "Drag to fill whole display"
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.numberOfLines = 0
        return label
    }()
    
    private var tutorialImageView: UIImageView = {
        let imageView = UIImageView(image: "DigitizerT".image)
        return imageView
    }()
    
    private var tutorialBackButton: UIButton = {
        let button = UIButton()
        button.setImage("backButton".image, for: .normal)
        return button
    }()
    
    let disposeBag = DisposeBag()

    var touchViews = [UITouch: DigitizerView]()
     
       override init(frame: CGRect) {
          super.init(frame: frame)
          isMultipleTouchEnabled = true
           backgroundColor = .clear
           setupLayout()
           setupButtons()
       }
     
       required init?(coder aDecoder: NSCoder) {
          super.init(coder: aDecoder)
          isMultipleTouchEnabled = true
       }
     
       override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
           
           centerLabel.isHidden = true
           tutorialImageView.isHidden = true
           tutorialBackButton.isHidden = true
           
          for touch in touches {
             createViewForTouch(touch: touch)
          }
       }

    var floodedSquares = [Int]()

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        
          for touch in touches {
             let view = viewForTouch(touch: touch)
             // Move the view to the new location.
             let newLocation = touch.location(in: self)
             view?.center = newLocation
            
              func currentPositions(location: SimpleView) -> Bool {
                  let hitViewX = Int((touch.location(in: location)).x)
                  let hitViewY = Int((touch.location(in: location)).y)
                  let range = 0..<80
                  var itIsCurrentPosition = range.contains(hitViewX) && range.contains(hitViewY)
                  if itIsCurrentPosition {
                      location.backgroundColor = "5D9EFD".hexColor
                  }
                  return itIsCurrentPosition
              }
              
              func сollectArrayForCheckIfAllSquareFilledIn(simpl: SimpleView, number: Int) {
                  if currentPositions(location: simpl) { if (floodedSquares.filter({ $0 == number})).count == 0 {  floodedSquares.append(number) } }
              }
              
             // MARK: Сonfiguration of square puzzles
              
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl1, number: 1)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl2, number: 2)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl3, number: 3)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl4, number: 4)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl5, number: 5)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl6, number: 6)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl7, number: 7)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl8, number: 8)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl9, number: 9)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl10, number: 10)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl11, number: 11)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl12, number: 12)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl13, number: 13)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl14, number: 14)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl15, number: 15)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl16, number: 16)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl17, number: 17)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl18, number: 18)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl19, number: 19)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl20, number: 20)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl21, number: 21)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl22, number: 22)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl23, number: 23)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl24, number: 24)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl25, number: 25)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl26, number: 26)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl27, number: 27)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl28, number: 28)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl29, number: 29)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl30, number: 30)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl31, number: 31)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl32, number: 32)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl33, number: 33)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl34, number: 34)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl35, number: 35)
              сollectArrayForCheckIfAllSquareFilledIn(simpl: simpl36, number: 36)
        
          }
        
        if floodedSquares.count == 36 {
            completion2?()
        }
    
       }
     
       override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
           DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
               guard let self = self else { return }
               self.centerLabel.isHidden = false
               self.centerLabel.text = "The screen is not full yet, continue"
               self.tutorialImageView.isHidden = false
               self.tutorialBackButton.isHidden = false
           }
   
          for touch in touches {
             removeViewForTouch(touch: touch)
      
          }
       }
     
       override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
          for touch in touches {
             removeViewForTouch(touch: touch)
          }
       }
    
    private func setupButtons() {
        tutorialBackButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.completion1?()
        }.disposed(by: disposeBag)
    }
    
    
    func createViewForTouch( touch : UITouch ) {
//       let newView = DigitizerView()
//        newView.backgroundColor = .black
//       newView.bounds = CGRect(x: 0, y: 0, width: 1, height: 1)
//       newView.center = touch.location(in: self)
//
//       // Add the view and animate it to a new size.
//       addSubview(newView)
////       UIView.animate(withDuration: 0.2) {
////          newView.bounds.size = CGSize(width: 100, height: 100)
////       }
//
//       // Save the views internally
//       touchViews[touch] = newView
    }
     
    func viewForTouch (touch : UITouch) -> DigitizerView? {
       return touchViews[touch]
    }
     
    func removeViewForTouch (touch : UITouch ) {
        if touchViews.count == 5 {
            AlertManager.shared().multiTouch()
        }
       if let view = touchViews[touch] {
          view.removeFromSuperview()
          touchViews.removeValue(forKey: touch)
           
       }
    }
   
    
     // Update the corner radius when the bounds change.
//     override var bounds: CGRect {
//        get { return super.bounds }
//        set(newBounds) {
//           super.bounds = newBounds
//           layer.cornerRadius = newBounds.size.width / 2.0
//        }
//     }
    
    private func setupLayout(){
        addSubviews(simpl1, simpl2, simpl3, simpl4, simpl5, simpl6, simpl7, simpl8, simpl9, simpl10, simpl11, simpl12, simpl13, simpl14, simpl15, simpl16, simpl17, simpl18, simpl19, simpl20, simpl21, simpl22, simpl23, simpl24, simpl25, simpl26, simpl27, simpl28, simpl29, simpl30, simpl31, simpl32, simpl33, simpl34, simpl35, simpl36, centerLabel, tutorialImageView, tutorialBackButton)
        
        simpl1.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalToSuperview()
        }
        
        simpl2.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl1.snp.trailing)
        }
        
        simpl3.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl2.snp.trailing)
        }
        
        simpl4.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl3.snp.trailing)
        }
        
        simpl5.snp.makeConstraints { make in
            make.top.equalTo(simpl1.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalToSuperview()
        }
        
        simpl6.snp.makeConstraints { make in
            make.top.equalTo(simpl1.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl5.snp.trailing)
        }
        
        simpl7.snp.makeConstraints { make in
            make.top.equalTo(simpl1.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl6.snp.trailing)
        }
        
        simpl8.snp.makeConstraints { make in
            make.top.equalTo(simpl1.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl7.snp.trailing)
        }
    
        simpl9.snp.makeConstraints { make in
            make.top.equalTo(simpl5.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalToSuperview()
        }

        simpl10.snp.makeConstraints { make in
            make.top.equalTo(simpl5.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl9.snp.trailing)
        }

        simpl11.snp.makeConstraints { make in
            make.top.equalTo(simpl5.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl10.snp.trailing)
        }

        simpl12.snp.makeConstraints { make in
            make.top.equalTo(simpl5.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl11.snp.trailing)
        }

        simpl13.snp.makeConstraints { make in
            make.top.equalTo(simpl9.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalToSuperview()
        }
        
        simpl14.snp.makeConstraints { make in
            make.top.equalTo(simpl9.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl13.snp.trailing)
        }

        simpl15.snp.makeConstraints { make in
            make.top.equalTo(simpl9.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl14.snp.trailing)
        }

        simpl16.snp.makeConstraints { make in
            make.top.equalTo(simpl9.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl15.snp.trailing)
        }

        simpl17.snp.makeConstraints { make in
            make.top.equalTo(simpl13.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalToSuperview()
        }

        simpl18.snp.makeConstraints { make in
            make.top.equalTo(simpl13.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl17.snp.trailing)
        }

        simpl19.snp.makeConstraints { make in
            make.top.equalTo(simpl13.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl18.snp.trailing)
        }

        simpl20.snp.makeConstraints { make in
            make.top.equalTo(simpl13.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl19.snp.trailing)
        }

        simpl21.snp.makeConstraints { make in
            make.top.equalTo(simpl17.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalToSuperview()
        }

        simpl22.snp.makeConstraints { make in
            make.top.equalTo(simpl17.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl21.snp.trailing)
        }

        simpl23.snp.makeConstraints { make in
            make.top.equalTo(simpl17.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl22.snp.trailing)
        }

        simpl24.snp.makeConstraints { make in
            make.top.equalTo(simpl17.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl23.snp.trailing)
        }

        simpl25.snp.makeConstraints { make in
            make.top.equalTo(simpl21.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalToSuperview()
        }

        simpl26.snp.makeConstraints { make in
            make.top.equalTo(simpl21.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl25.snp.trailing)
        }

        simpl27.snp.makeConstraints { make in
            make.top.equalTo(simpl21.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl26.snp.trailing)
        }

        simpl28.snp.makeConstraints { make in
            make.top.equalTo(simpl21.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl27.snp.trailing)
        }

        simpl29.snp.makeConstraints { make in
            make.top.equalTo(simpl25.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalToSuperview()
        }

        simpl30.snp.makeConstraints { make in
            make.top.equalTo(simpl25.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl29.snp.trailing)
        }

        simpl31.snp.makeConstraints { make in
            make.top.equalTo(simpl25.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl30.snp.trailing)
        }

        simpl32.snp.makeConstraints { make in
            make.top.equalTo(simpl25.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl31.snp.trailing)
        }

        simpl33.snp.makeConstraints { make in
            make.top.equalTo(simpl29.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalToSuperview()
        }

        simpl34.snp.makeConstraints { make in
            make.top.equalTo(simpl29.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl33.snp.trailing)
        }

        simpl35.snp.makeConstraints { make in
            make.top.equalTo(simpl29.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl34.snp.trailing)
        }

        simpl36.snp.makeConstraints { make in
            make.top.equalTo(simpl29.snp.bottom)
            make.width.equalTo((UIScreen.main.bounds.width / 4))
            make.height.equalTo(UIScreen.main.bounds.height / 9)
            make.leading.equalTo(simpl35.snp.trailing)
        }
        
        centerLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(150)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(80)
        }
        
        tutorialImageView.snp.makeConstraints { make in
            make.width.equalTo(186)
            make.height.equalTo(159)
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
        }
        
        tutorialBackButton.snp.makeConstraints { make in
            make.size.equalTo(84)
            make.bottom.equalToSuperview().offset(-54)
            make.centerX.equalToSuperview()
        }
    }

}
