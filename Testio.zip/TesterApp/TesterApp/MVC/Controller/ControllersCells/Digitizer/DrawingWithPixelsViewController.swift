import UIKit
import CoreGraphics

class DrawingWithPixelsViewController: UIViewController {
   
    var drawingView = DigitizerView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }

    private func setup(){
        setupLayout()
        setupButtons()
    }
    
    private func setupLayout(){
        view.backgroundColor = .white
        navigationController?.isNavigationBarHidden = true
        view.addSubview(drawingView)
        
        drawingView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    }
    
    private func setupButtons() {
        drawingView.completion2 = {
            Constants.ud.digitizer = 2
           self.dismiss(animated: true)
        }
        
        drawingView.completion1 = {
            self.dismiss(animated: true)
        }
       
    }
    
    
}
