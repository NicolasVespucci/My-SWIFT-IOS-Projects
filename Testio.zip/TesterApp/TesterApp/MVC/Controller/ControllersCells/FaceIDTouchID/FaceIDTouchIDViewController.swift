import UIKit
import RxSwift
import LocalAuthentication

class FaceIDTouchIDViewController: UIViewController {
    
    private var centerLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 25, weight: .regular)
        label.textColor = .black
        label.textAlignment = .center
        label.text = "Use Face ID/Touch ID to unlock"
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var tutorialImageView: UIImageView = {
        let imageView = UIImageView(image: "FaceIDTouchIDTutorial".image)
        return imageView
    }()
    
    private var tutorialBackButton: UIButton = {
        let button = UIButton()
        button.setImage("backButton".image, for: .normal)
        button.isHidden = true
        return button
    }()

    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup(){
        setupLayout()
        setupButtons()
        setupCheckingID()
    }
    
    private func setupCheckingID(){
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.Authenticate { (success, alert) in
                            print(success, alert)
                        }
        }
    }
    
    private func setupLayout(){
        view.addSubviews(centerLabel, tutorialImageView, tutorialBackButton)
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = .white
        
        centerLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(150)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(30)
        }
        
        tutorialImageView.snp.makeConstraints { make in
            make.size.equalTo(144)
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
        }
        
        tutorialBackButton.snp.makeConstraints { make in
            make.size.equalTo(84)
            make.bottom.equalToSuperview().offset(-54)
            make.centerX.equalToSuperview()
        }

    }
    
    
    private func setupButtons() {
        tutorialBackButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.dismiss(animated: true)
        }.disposed(by: disposeBag)
    }
    
   
    //MARK: Face ID or Touch ID
    func Authenticate(completion: @escaping ((Bool, ()) -> ())){
            
            //Create a context
            let authenticationContext = LAContext()
            var error:NSError?
            
            //Check if device have Biometric sensor
            let isValidSensor : Bool = authenticationContext.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error)
            
            if isValidSensor {
                //Device have BiometricSensor
                //It Supports TouchID
                
                authenticationContext.evaluatePolicy(
                    .deviceOwnerAuthenticationWithBiometrics,
                    localizedReason: "Touch / Face ID authentication",
                    reply: { [unowned self] (success, error) -> Void in
                        
                        if(success) {
                            // Touch / Face ID recognized success here
                            completion(true, AlertManager.shared().faceIDSeccess())
                            DispatchQueue.main.async {
                                self.tutorialBackButton.isHidden = false
                            }
                            Constants.ud.faceIDTouchID = 2
                           
                        } else {
                            //If not recognized then
                            if let error = error {
                                let strMessage = self.errorMessage(errorCode: error._code)
                                if strMessage != "" {
                                    print("--------------------->", strMessage)
                                }
                            }
                            completion(false, AlertManager.shared().faceIDEnterPassword())
                            DispatchQueue.main.async {
                                self.tutorialBackButton.isHidden = false
                            }
                            Constants.ud.faceIDTouchID = 1
                        }
                })
            } else {
                
                let strMessage = self.errorMessage(errorCode: (error?._code)!)
                if strMessage != "" {
                    print("Not Added Face ID or Touch ID--->", strMessage)
                    AlertManager.shared().notFaceIDandTouchID()
                    DispatchQueue.main.async {
                        self.tutorialBackButton.isHidden = false
                    }
                    Constants.ud.faceIDTouchID = 1
                }
            }
        }
        
        //MARK: TouchID error
        func errorMessage(errorCode:Int) -> String{
            
            var strMessage = ""
            
            switch errorCode {
                
            case LAError.Code.authenticationFailed.rawValue:
                strMessage = "Authentication Failed"
                
            case LAError.Code.userCancel.rawValue:
                strMessage = "User Cancel"
                
            case LAError.Code.systemCancel.rawValue:
                strMessage = "System Cancel"
                
            case LAError.Code.passcodeNotSet.rawValue:
                strMessage = "Please goto the Settings & Turn On Passcode"
                
            case LAError.Code.biometryNotAvailable.rawValue:
                strMessage = "TouchI or FaceID DNot Available"
                
            case LAError.Code.biometryNotEnrolled.rawValue:
                strMessage = "TouchID or FaceID Not Enrolled"
                
            case LAError.Code.biometryLockout.rawValue:
                strMessage = "TouchID or FaceID Lockout Please goto the Settings & Turn On Passcode"
                
            case LAError.Code.appCancel.rawValue:
                strMessage = "App Cancel"
                
            case LAError.Code.invalidContext.rawValue:
                strMessage = "Invalid Context"
                
            default:
                strMessage = ""
                
            }
            return strMessage
        }
    

}
