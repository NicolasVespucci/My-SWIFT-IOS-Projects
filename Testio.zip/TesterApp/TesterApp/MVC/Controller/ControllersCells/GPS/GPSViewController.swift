import UIKit
import RxSwift
import CoreLocation

class GPSViewController: UIViewController {

    private var centerLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 25, weight: .regular)
        label.textColor = .black
        label.textAlignment = .center
        label.text = "GPS Checking"
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.numberOfLines = 0
        return label
    }()
    
    private var tutorialImageView: UIImageView = {
        let imageView = UIImageView(image: "GPStest".image)
        return imageView
    }()
    
    private var tutorialBackButton: UIButton = {
        let button = UIButton()
        button.setImage("backButton".image, for: .normal)
        return button
    }()
  
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup(){
        setupLayot()
        setupButtons()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.checkGPS()
        }
       
    }
    
    private func setupLayot(){
        view.backgroundColor = .white
        view.addSubviews(centerLabel, tutorialImageView, tutorialBackButton)
        
        centerLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(150)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(50)
        }
        
        tutorialImageView.snp.makeConstraints { make in
            make.width.equalTo(98)
            make.height.equalTo(116)
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
        }
        
        tutorialBackButton.snp.makeConstraints { make in
            make.size.equalTo(84)
            make.bottom.equalToSuperview().offset(-54)
            make.centerX.equalToSuperview()
        }
     
    }
    
    private func setupButtons() {
        tutorialBackButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.dismiss(animated: true)
        }.disposed(by: disposeBag)
    }

    //MARK: GPS
    func checkGPS(){
        var alert = TestManager.shared().showPermissionAlert(title: "GPS not working", message: "Your GPS not working please turn on your GPS in the Settings->Privacy->Location Services->Location Services ON. Go to Settings?")
        var currentGPSValue = CLLocationManager.locationServicesEnabled()
        if currentGPSValue {
            AlertManager.shared().testGPS()
            Constants.ud.GPS = 2
        } else {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                self.present(alert, animated: true, completion: nil)
                
            }
        }
     }
    
}
