import UIKit
import RxSwift
import SwiftUI

class LCDViewController: UIViewController {
    
    private var centerLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 25, weight: .regular)
        label.textColor = .black
        label.textAlignment = .center
        label.text = "Check if there are any dead pixels \non the folowing 5 colour screens"
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.numberOfLines = 0
        return label
    }()
    
    private var tutorialImageView: UIImageView = {
        let imageView = UIImageView(image: "colorsLCD".image)
        return imageView
    }()
    
    private var tutorialStepResulteImageView: UIImageView = {
        let imageView = UIImageView(image: "pressIf".image)
        return imageView
    }()
    
    private var tutorialSkipButton: UIButton = {
        let button = UIButton()
        button.setImage("skip".image, for: .normal)
        return button
    }()
    
    private var tutorialNextButton: UIButton = {
        let button = UIButton()
        button.setImage("next".image, for: .normal)
        return button
    }()
    
    private var tutorialFailedButton: UIButton = {
        let button = UIButton()
        button.setImage("failed".image, for: .normal)
        button.isHidden = true
        return button
    }()
    
    private var skipLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15, weight: .regular)
        label.textColor = "5D9EFD".hexColor.withAlphaComponent(0.55)
        label.textAlignment = .center
        label.text = "Skip"
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var nextLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15, weight: .regular)
        label.textColor = "5D9EFD".hexColor.withAlphaComponent(0.55)
        label.textAlignment = .center
        label.text = "Next"
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()
    
    private var failedLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15, weight: .regular)
        label.textColor = "5D9EFD".hexColor.withAlphaComponent(0.55)
        label.textAlignment = .center
        label.text = "Failed"
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        return label
    }()

    private var fullView: UIView = {
        let view = UIView()
        view.backgroundColor = .red
        view.isHidden = true
        return view
    }()
    
    private var fullButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = .clear
        button.isHidden = true
        return button
    }()
    
    let disposeBag = DisposeBag()
    var currentColor = 0
    var currentAlert = false
    var currentActionOnNextButton = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup(){
        configureLayout()
        setupButton()
        showColorSlow()
    }
    
    private func configureLayout(){
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = .white
        view.addSubviews(centerLabel, tutorialImageView, tutorialSkipButton, tutorialNextButton, skipLabel, nextLabel, fullView, fullButton)
        
        centerLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(167.resized())
            make.leading.equalToSuperview().offset(30)
            make.trailing.equalToSuperview().offset(-30)
            make.height.equalTo(48)
        }
        
        tutorialImageView.snp.makeConstraints { make in
            make.top.equalTo(centerLabel.snp.bottom).offset(127)
            make.height.equalTo(161)
            make.width.equalTo(285)
            make.centerX.equalToSuperview()
        }
        
        tutorialSkipButton.snp.makeConstraints { make in
            make.bottom.equalTo(skipLabel.snp.top).offset(-6)
            make.size.equalTo(66)
            make.leading.equalToSuperview().offset(68)
        }

        tutorialNextButton.snp.makeConstraints { make in make.bottom.equalTo(skipLabel.snp.top).offset(-6)
            make.size.equalTo(66)
            make.trailing.equalToSuperview().offset(-68)
        }
        
        skipLabel.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-35)
            make.leading.equalToSuperview().offset(68)
            make.width.equalTo(66)
            make.height.equalTo(24)
        }
        
        nextLabel.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-35)
            make.trailing.equalToSuperview().offset(-68)
            make.width.equalTo(66)
            make.height.equalTo(24)
        }

        fullView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        fullButton.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    }
    
    private func setupButton() {
        fullButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.fullButtonActions()
        }.disposed(by: disposeBag)
        
        tutorialSkipButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.dismiss(animated: true)
            Constants.ud.LCD = 1
        }.disposed(by: disposeBag)
        
        tutorialNextButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.nextButtonAction()
        }.disposed(by: disposeBag)
        
        tutorialFailedButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.dismiss(animated: true)
            Constants.ud.LCD = 1
        }.disposed(by: disposeBag)
    }
    
    
    private func nextButtonAction(){
        if currentActionOnNextButton == false {
            tutorialNextButton.isHidden = true
            tutorialSkipButton.isHidden = true
            skipLabel.isHidden = true
            nextLabel.isHidden = true
            tutorialImageView.isHidden = true
            centerLabel.isHidden = true
            fullButton.isHidden = false
            fullView.isHidden = false
            showColorSlow()
        } else {
            dismiss(animated: true)
        }
        
    }
    
    private func showColorSlow(){
        fullView.backgroundColor = .red
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.fullView.backgroundColor = .green
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            self.fullView.backgroundColor = .blue
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            self.fullView.backgroundColor = .white
        }

        DispatchQueue.main.asyncAfter(deadline: .now() + 7) {
            self.fullView.backgroundColor = .black
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 9) {
            self.navigationController?.popViewController(animated: true)
            if self.currentAlert == false {
                self.checkingPixels()
            }
         
            Constants.ud.LCD = 2
            self.currentActionOnNextButton = true
        }
        
    }
    
    private func fullButtonActions(){
        
        if currentColor == 0 {
            currentColor += 1
            fullView.backgroundColor = .red
        } else if currentColor == 1 {
            currentColor += 1
            self.fullView.backgroundColor = .green
        }  else if currentColor == 2 {
            currentColor += 1
            self.fullView.backgroundColor = .blue
        } else if currentColor == 3 {
            currentColor += 1
            self.fullView.backgroundColor = .white
        } else if currentColor == 4 {
            currentColor += 1
            self.fullView.backgroundColor = .black
        } else if currentColor == 5 {
            checkingPixels()
            currentAlert = true
            Constants.ud.LCD = 2
            currentActionOnNextButton = true
        }
    }
    
    private func checkingPixels() {
        tutorialNextButton.isHidden = false
        tutorialSkipButton.isHidden = false
        skipLabel.isHidden = false
        nextLabel.isHidden = false
        tutorialImageView.isHidden = false
        centerLabel.isHidden = false
     
        fullView.isHidden = true
        fullButton.isHidden = true
        tutorialImageView.isHidden = true
        
        tutorialSkipButton.snp.remakeConstraints { make in
            make.bottom.equalTo(skipLabel.snp.top).offset(-6)
            make.leading.equalToSuperview().offset(24)
            make.size.equalTo(66)
        }
        
        skipLabel.snp.remakeConstraints { make in
            make.leading.equalToSuperview().offset(24)
            make.height.equalTo(30)
            make.width.equalTo(66)
            make.bottom.equalToSuperview().offset(-35)
        }
        
        tutorialNextButton.snp.remakeConstraints { make in
            make.bottom.equalTo(skipLabel.snp.top).offset(-6)
            make.trailing.equalToSuperview().offset(-24)
            make.size.equalTo(66)
        }
        
        nextLabel.text = "Passed"
        nextLabel.snp.remakeConstraints { make in
            make.trailing.equalToSuperview().offset(-24)
            make.height.equalTo(30)
            make.width.equalTo(66)
            make.bottom.equalToSuperview().offset(-35)
        }
        
        view.addSubviews(tutorialFailedButton, failedLabel, tutorialStepResulteImageView)
        
        tutorialFailedButton.isHidden = false
        tutorialFailedButton.snp.makeConstraints { make in
            make.bottom.equalTo(skipLabel.snp.top).offset(-6)
            make.trailing.equalTo(tutorialNextButton.snp.leading).offset(-21)
            make.size.equalTo(66)
        }

        tutorialNextButton.setImage("pased".image, for: .normal)

        failedLabel.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-35)
            make.trailing.equalTo(tutorialNextButton.snp.leading).offset(-21)
            make.width.equalTo(66)
            make.height.equalTo(30)
        }

        centerLabel.text = "Did you discover any dead pixels ?"

        tutorialStepResulteImageView.snp.updateConstraints { make in
            make.top.equalTo(centerLabel.snp.bottom).offset(48)
            make.leading.equalToSuperview().offset(29)
            make.height.equalTo(59)
            make.width.equalTo(143)
        }
    }
}
