import UIKit

class MultiTouchView: UIView {
    var completionMultiTouch: (()->())?

    var touchViews = [UITouch: MultiTouchView]()
     
       override init(frame: CGRect) {
          super.init(frame: frame)
          isMultipleTouchEnabled = true
           backgroundColor = .clear
          // setupLayout()
       }
     
       required init?(coder aDecoder: NSCoder) {
          super.init(coder: aDecoder)
          isMultipleTouchEnabled = true
       }
     
       override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
           completionMultiTouch?()
          for touch in touches {
             createViewForTouch(touch: touch)
          }
       }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
       for touch in touches {
          let view = viewForTouch(touch: touch)
          // Move the view to the new location.
          let newLocation = touch.location(in: self)
          view?.center = newLocation
       }
    }
        
        
        override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
           for touch in touches {
              removeViewForTouch(touch: touch)
           }
        }
      
        override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
           for touch in touches {
              removeViewForTouch(touch: touch)
           }
        }
     
     func createViewForTouch( touch : UITouch ) {
        let newView = MultiTouchView()
         newView.backgroundColor = .black
        newView.bounds = CGRect(x: 0, y: 0, width: 1, height: 1)
        newView.center = touch.location(in: self)
      
        // Add the view and animate it to a new size.
        addSubview(newView)
        UIView.animate(withDuration: 0.2) {
            newView.layer.cornerRadius = 50
           newView.bounds.size = CGSize(width: 100, height: 100)
        }
      
        // Save the views internally
        touchViews[touch] = newView
     }
      
     func viewForTouch (touch : UITouch) -> MultiTouchView? {
        return touchViews[touch]
     }
      
     func removeViewForTouch (touch : UITouch ) {
         if touchViews.count == 5 {
             AlertManager.shared().multiTouch()
             Constants.ud.multiToch = 2
         } 
        if let view = touchViews[touch] {
           view.removeFromSuperview()
           touchViews.removeValue(forKey: touch)
            
        }
     }

}

