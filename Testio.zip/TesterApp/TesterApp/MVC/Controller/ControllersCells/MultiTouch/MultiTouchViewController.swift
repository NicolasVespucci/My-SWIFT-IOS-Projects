import UIKit
import CoreGraphics
import RxSwift

class MultiTouchViewController: UIViewController {
    
    var multiTouch = MultiTouchView()
    
    private var tutorialLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 25, weight: .regular)
        label.textColor = "242527".hexColor
        label.text = "Touch the screen \nwith five fingers"
        label.textAlignment = .center
        label.numberOfLines = 0
        return label
    }()

    private var tutorialImageView: UIImageView = {
        let imageView = UIImageView(image: "multiTouchTutorial".image)
        return imageView
    }()
    
    private var tutorialBackButton: UIButton = {
        let button = UIButton()
        button.setImage("backButton".image, for: .normal)
        return button
    }()
    
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup(){
        setupLayout()
        setupButtons()
    }
    
    private func setupLayout(){
        view.addSubviews(multiTouch, tutorialLabel, tutorialImageView, tutorialBackButton)
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = .white
        
        multiTouch.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        tutorialLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(150)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(80)
        }
        
        tutorialImageView.snp.makeConstraints { make in
            make.width.equalTo(136)
            make.height.equalTo(195)
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
        }
        
        tutorialBackButton.snp.makeConstraints { make in
            make.size.equalTo(84)
            make.bottom.equalToSuperview().offset(-54)
            make.centerX.equalToSuperview()
        }
    }
    
    
    private func setupButtons() {
        tutorialBackButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.dismiss(animated: true)
        }.disposed(by: disposeBag)
        
        multiTouch.completionMultiTouch = {
            self.tutorialImageView.isHidden = true
            self.tutorialLabel.isHidden = true
        }
    }
}
