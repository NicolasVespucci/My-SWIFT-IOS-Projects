import UIKit
import RxSwift

class PowerButtomViewController: UIViewController {

    private var centerLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 25, weight: .regular)
        label.textColor = .black
        label.textAlignment = .center
        label.text = ""
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.numberOfLines = 0
        return label
    }()
    
    private var tutorialImageView: UIImageView = {
        let imageView = UIImageView(image: "PowerB".image)
        return imageView
    }()
     
    private var tutorialBackButton: UIButton = {
        let button = UIButton()
        button.setImage("backButton".image, for: .normal)
        return button
    }()
  
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        var isBottom: Bool {
            if #available(iOS 11.0, *), let keyWindow = UIApplication.shared.keyWindow, keyWindow.safeAreaInsets.bottom > 0 {
                return true
            }
            return false
        }
        if isBottom {
            centerLabel.text = "Please press the volume Up button and \nthe Home Button at the same time and \nthen release both buttons immediately"
        } else {
            centerLabel.text = "Please press the volume Up button and \nthe Power Button at the same time and \nthen release both buttons immediately"
        }
        
        setup()
        
        
    }
    
    private func setup(){
        setupLayot()
        setupButtons()
    }
    
    private func setupLayot() {
        view.backgroundColor = .white
        view.addSubviews(centerLabel, tutorialImageView, tutorialBackButton)
        
        centerLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(150)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(80)
        }
        
        tutorialImageView.snp.makeConstraints { make in
            make.width.equalTo(98)
            make.height.equalTo(143)
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
        }
        
        tutorialBackButton.snp.makeConstraints { make in
            make.size.equalTo(84)
            make.bottom.equalToSuperview().offset(-54)
            make.centerX.equalToSuperview()
        }
    }
    
    private func setupButtons() {
        tutorialBackButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.dismiss(animated: true)
        }.disposed(by: disposeBag)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        //MARK: Power Button detectet
        NotificationCenter.default.addObserver(
            forName: UIApplication.userDidTakeScreenshotNotification,
            object: nil,
            queue: .main) { notification in
                AlertManager.shared().powerButton()
                Constants.ud.powerButtom = 2
        }
    }
}
