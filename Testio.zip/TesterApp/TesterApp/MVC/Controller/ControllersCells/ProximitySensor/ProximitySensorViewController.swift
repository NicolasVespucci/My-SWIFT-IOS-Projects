import UIKit
import RxSwift

class ProximitySensorViewController: UIViewController {
    
    private var centerLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 25, weight: .regular)
        label.textColor = .black
        label.textAlignment = .center
        label.text = "Move your hand to the \nProximity sensor"
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.numberOfLines = 0
        return label
    }()
    
    private var tutorialImageView: UIImageView = {
       // let imageView = UIImageView(image: "sensorP".image)
        let imageView = UIImageView(image: "PowerB".image)
        return imageView
    }()
    
    private var tutorialBackButton: UIButton = {
        let button = UIButton()
        button.setImage("backButton".image, for: .normal)
        return button
    }()
    
    private var tutorialPassedButton: UIButton = {
        let button = UIButton()
        button.setImage("pased".image, for: .normal)
        return button
    }()
    
    private var handImageView: UIImageView = {
        let imageView = UIImageView(image: "handProximitiSensor".image)
        return imageView
    }()
    
    var countAnimations = 0
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup(){
        setupLayot()
        activateProximitySensor()
        setupButtons()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.animateHand()
        }
    }
    
    private func setupLayot(){
        view.backgroundColor = .white
        view.addSubviews(centerLabel, tutorialImageView, handImageView, tutorialBackButton, tutorialPassedButton)
        
        centerLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(150)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(50)
        }
        
        tutorialImageView.snp.makeConstraints { make in
            make.width.equalTo(143)
            make.height.equalTo(193)
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
        }
        
        handImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview().offset(-80)
            make.leading.equalToSuperview().offset(10)
            make.width.equalTo(86.5)
            make.height.equalTo(124)
        }
        
        tutorialBackButton.snp.makeConstraints { make in
            make.size.equalTo(84)
            make.bottom.equalToSuperview().offset(-54)
            make.leading.equalToSuperview().offset(91.resized(.width))
        }
        
        tutorialPassedButton.snp.makeConstraints { make in
            make.size.equalTo(84)
            make.bottom.equalToSuperview().offset(-54)
            make.trailing.equalToSuperview().offset(-91.resized(.width))
        }
    }
    
    private func setupButtons() {
        tutorialBackButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.dismiss(animated: true)
            self.countAnimations += 10000
            let device = UIDevice.current
            device.isProximityMonitoringEnabled = false
            self.view.layer.removeAllAnimations()
        }.disposed(by: disposeBag)
        
        tutorialPassedButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.dismiss(animated: true)
            let device = UIDevice.current
            device.isProximityMonitoringEnabled = false
        }.disposed(by: disposeBag)
    }
  
    //MARK: ProximitySensor
    func activateProximitySensor() {
            let device = UIDevice.current
            device.isProximityMonitoringEnabled = true
            if device.isProximityMonitoringEnabled {
                NotificationCenter.default.addObserver(self, selector: #selector(proximityChanged(notification:)), name: NSNotification.Name(rawValue: "UIDeviceProximityStateDidChangeNotification"), object: device)
            }
        }

        @objc func proximityChanged(notification: NSNotification) {
            if let device = notification.object as? UIDevice {
                print("\(device) detected!")
                AlertManager.shared().comliteProximitySensor()
                Constants.ud.proximitySensor = 2
            }
        }
    
    
    private func animateHand(){
        UIView.animate(withDuration: 1.5, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
            self.handImageView.snp.updateConstraints { make in
                make.leading.equalToSuperview().offset(UIScreen.main.bounds.width - 126)
            }
            self.view.layoutIfNeeded()
            
               },completion: {_ in
                   self.countAnimations += 1
                   if self.countAnimations < 1000 {
                       self.animateHand1()
                   } else {
                       print("Finish")
                   }
                   
               })
    }
    
    private func animateHand1(){
        UIView.animate(withDuration: 1.5, delay: 0.0, options: UIView.AnimationOptions.curveLinear, animations: {
            self.handImageView.snp.updateConstraints { make in
                make.leading.equalToSuperview().offset(10)
            }
            self.view.layoutIfNeeded()
               },completion: {_ in
                   self.animateHand()
               })
    }
    
    deinit {
        print(self, #function)
        view.layer.removeAllAnimations()
    }
    
    
    
    
        
}
