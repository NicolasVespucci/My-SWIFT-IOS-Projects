import UIKit
import RxSwift

class RearMicrophoneViewController: UIViewController {

    private var centerLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 25, weight: .regular)
        label.textColor = .black
        label.textAlignment = .center
        label.text = "Make a noise in the Rear Microphone (shouting, or clapping your hands)"
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.numberOfLines = 0
        return label
    }()
    
    private var tutorialImageView: UIImageView = {
        let imageView = UIImageView(image: "flashTest".image)
        return imageView
    }()
    
    private var tutorialBackButton: UIButton = {
        let button = UIButton()
        button.setImage("backButton".image, for: .normal)
        return button
    }()
  
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup() {
        setupLayot()
        setupButtons()
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            Constants.ud.micWorking = true
            Constants.ud.thisIsTheRaerMic = true
            TestManager.shared().setupMicro(currentMicrophone: "Back")
        }
    }
    
    private func setupLayot(){
        view.backgroundColor = .white
        view.addSubviews(centerLabel, tutorialBackButton)
        
        centerLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(50)
        }
    
        tutorialBackButton.snp.makeConstraints { make in
            make.size.equalTo(84)
            make.bottom.equalToSuperview().offset(-54)
            make.centerX.equalToSuperview()
        }
     
    }
    
    private func setupButtons() {
        tutorialBackButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            Constants.ud.micWorking = false
            self.dismiss(animated: true)
        }.disposed(by: disposeBag)
    }

}
