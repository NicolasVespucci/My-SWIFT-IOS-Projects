import UIKit
import RxSwift
import AVFoundation
import AVKit
import AVFAudio
import MediaPlayer
import CoreAudio

class SpeakerBottonViewController: UIViewController {

    private var centerLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 25, weight: .regular)
        label.textColor = .black
        label.textAlignment = .center
        label.text = "Did you hear the Bottom Speaker \n the sound clearly ?"
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.numberOfLines = 0
        return label
    }()
    
    private var tutorialImageView: UIImageView = {
        let imageView = UIImageView(image: "bottonSpeaker".image)
        return imageView
    }()
    
    private var tutorialBackButton: UIButton = {
        let button = UIButton()
        button.setImage("backButton".image, for: .normal)
        return button
    }()
    
    private var tutorialPassedButton: UIButton = {
        let button = UIButton()
        button.setImage("pased".image, for: .normal)
        return button
    }()
  
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup(){
        setupLayot()
        setupButtons()
        setupSpeaker()
    }
    
    private func setupLayot(){
        view.backgroundColor = .white
        view.addSubviews(centerLabel, tutorialImageView, tutorialBackButton, tutorialPassedButton)
        
        centerLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(150)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(50)
        }
        
        tutorialImageView.snp.makeConstraints { make in
            make.width.equalTo(132)
            make.height.equalTo(108)
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
        }
        
        tutorialBackButton.snp.makeConstraints { make in
            make.size.equalTo(84)
            make.bottom.equalToSuperview().offset(-54)
            make.leading.equalToSuperview().offset(91.resized(.width))
        }
        
        tutorialPassedButton.snp.makeConstraints { make in
            make.size.equalTo(84)
            make.bottom.equalToSuperview().offset(-54)
            make.trailing.equalToSuperview().offset(-91.resized(.width))
        }
    }
    
    private func setupButtons() {
        tutorialBackButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.stopedAudioSession()
            self.dismiss(animated: true)
        }.disposed(by: disposeBag)
        
        tutorialPassedButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.stopedAudioSession()
            Constants.ud.speakerBotton = 2
            self.dismiss(animated: true)
        }.disposed(by: disposeBag)
    }
    
    private func setupSpeaker(){
        TestManager.shared().configureAudioSessionCategory()
        TestManager.shared().configureAudioSessionToSpeaker()
        MPVolumeView.setVolume(1)
        TestManager.shared().playSound(soundName: "applause")
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            AlertManager.shared().testSpeakerBottom()
        }
        stopedAudioSession()
    }
    
    func stopedAudioSession(){
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            let audioSession:AVAudioSession = AVAudioSession.sharedInstance()
            do {
                try audioSession.setActive(false)
               
            }
            catch{
                print("#configureAudioSessionToEarSpeaker Error \(error.localizedDescription)")
                Constants.ud.speakerBotton = 1
            }
        }
    }
}
