import UIKit
import RxSwift
import SnapKit

import AVFAudio

class VibrationViewController: UIViewController {
    
    private var centerLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 25, weight: .regular)
        label.textColor = .black
        label.textAlignment = .center
        label.text = "Is the device vibrating ? \n If it does not vibrate, check in the \nsettings whether vibration is enabled"
        label.adjustsFontSizeToFitWidth = true
        label.minimumScaleFactor = 0.5
        label.numberOfLines = 0
        return label
    }()
    
    private var tutorialImageView: UIImageView = {
        let imageView = UIImageView(image: "sensorP".image)
        return imageView
    }()
    
    private var tutorialBackButton: UIButton = {
        let button = UIButton()
        button.setImage("backButton".image, for: .normal)
        return button
    }()
    
    private var tutorialPassedButton: UIButton = {
        let button = UIButton()
        button.setImage("pased".image, for: .normal)
        return button
    }()
    
    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup(){
        setupLayot()
        activateVubration()
        setupButtons()
    }
    
    private func setupLayot(){
        view.backgroundColor = .white
        view.addSubviews(centerLabel, tutorialImageView, tutorialBackButton, tutorialPassedButton)
        
        centerLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(150)
            make.leading.equalToSuperview().offset(20)
            make.trailing.equalToSuperview().offset(-20)
            make.height.equalTo(80)
        }
        
        tutorialImageView.snp.makeConstraints { make in
            make.size.equalTo(144)
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview()
        }
        
        tutorialBackButton.snp.makeConstraints { make in
            make.size.equalTo(84)
            make.bottom.equalToSuperview().offset(-54)
            make.leading.equalToSuperview().offset(91.resized(.width))
        }
        
        tutorialPassedButton.snp.makeConstraints { make in
            make.size.equalTo(84)
            make.bottom.equalToSuperview().offset(-54)
            make.trailing.equalToSuperview().offset(-91.resized(.width))
        }
    }
    
    private func activateVubration(){
        AudioServicesPlayAlertSoundWithCompletion(SystemSoundID(kSystemSoundID_Vibrate)) { [weak self] in
            self?.infiniteVibration()
        }
    }
    
    private func infiniteVibration(){
        activateVubration()
    }
    
    private func stopedVibration(){
        AudioServicesDisposeSystemSoundID(SystemSoundID(kSystemSoundID_Vibrate))
    }
    
    private func setupButtons() {
        tutorialBackButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.stopedVibration()
            self.dismiss(animated: true)
        }.disposed(by: disposeBag)
        
        tutorialPassedButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.stopedVibration()
            Constants.ud.vibration = 2
            self.dismiss(animated: true)
        }.disposed(by: disposeBag)
    }
}
