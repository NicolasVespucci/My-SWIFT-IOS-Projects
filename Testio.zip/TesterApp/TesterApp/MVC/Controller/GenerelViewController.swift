import UIKit
import RxSwift
import CoreLocation
import AVFoundation
import AVKit
import AVFAudio
import MediaPlayer
import CoreAudio
import LocalAuthentication

class GeneralViewController: UIViewController {
    
    //MARK: Properties
    
    private var testModel1 = [TestModel(image: "DigitizerN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Digitizer", textColor: "5D9EFD"),
                             TestModel(image: "Multi-touchN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Multi-Touch", textColor: "5D9EFD"),
                             TestModel(image: "3D-touchN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "3D-Touch", textColor: "5D9EFD"),
                             TestModel(image: "FaceIDTouchIDN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Face ID/Touch ID", textColor: "5D9EFD"),
                             TestModel(image: "LCDN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "LCD", textColor: "5D9EFD"),
                             TestModel(image: "ProximitySensorN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Proximity Sensor", textColor: "5D9EFD"),
                             TestModel(image: "VibrationN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Vibration", textColor: "5D9EFD"),
                             TestModel(image: "FlashN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Flash", textColor: "5D9EFD"),
                             TestModel(image: "GPSN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "GPS", textColor: "5D9EFD"),
                             TestModel(image: "BottonMicrophoneN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Bottom Microphone", textColor: "5D9EFD"),
                             TestModel(image: "FrontMicrophoneN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Front Microphone", textColor: "5D9EFD"),
                             TestModel(image: "RearMicrophoneN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Rear Microphone", textColor: "5D9EFD"),
                             TestModel(image: "SpeakerMicN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Speaker Top", textColor: "5D9EFD"),
                             TestModel(image: "SpeakerN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Speaker Bottom", textColor: "5D9EFD"), TestModel(image: "PowerButtonN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Power Button", textColor: "5D9EFD")]
    
    private var testModel2 = [TestModel(image: "DigitizerN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Digitizer", textColor: "5D9EFD"),
                             TestModel(image: "Multi-touchN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Multi-Touch", textColor: "5D9EFD"),
                             TestModel(image: "FaceIDTouchIDN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Face ID/Touch ID", textColor: "5D9EFD"),
                             TestModel(image: "LCDN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "LCD", textColor: "5D9EFD"),
                             TestModel(image: "ProximitySensorN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Proximity Sensor", textColor: "5D9EFD"),
                             TestModel(image: "VibrationN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Vibration", textColor: "5D9EFD"),
                             TestModel(image: "FlashN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Flash", textColor: "5D9EFD"),
                             TestModel(image: "GPSN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "GPS", textColor: "5D9EFD"),
                             TestModel(image: "BottonMicrophoneN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Bottom Microphone", textColor: "5D9EFD"),
                             TestModel(image: "FrontMicrophoneN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Front Microphone", textColor: "5D9EFD"),
                             TestModel(image: "RearMicrophoneN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Rear Microphone", textColor: "5D9EFD"),
                             TestModel(image: "SpeakerMicN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Speaker Top", textColor: "5D9EFD"),
                             TestModel(image: "SpeakerN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Speaker Bottom", textColor: "5D9EFD"), TestModel(image: "PowerButtonN", check: "notStartInProcess", fullImageView: "notSelected", nameTestOption: "Power Button", textColor: "5D9EFD")]
    
    

    private var menuButton: UIButton = {
        let button = UIButton()
        button.setImage("menu".image, for: .normal)
        return button
    }()
    
    private var restartButton: UIButton = {
        let button = UIButton()
        button.setImage("restartTest".image, for: .normal)
        return button
    }()
    
    private var testCollectionView: UICollectionView = {
        let collection = UICollectionView(frame: .zero, collectionViewLayout: .init())
        collection.backgroundColor = .clear
        collection.showsHorizontalScrollIndicator = false
        collection.showsVerticalScrollIndicator = false
        collection.isScrollEnabled = true
        return collection
    }()
    
    private var testLayout: UICollectionViewLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 15
        layout.minimumLineSpacing = 15
        layout.itemSize = .init(width: (UIScreen.main.bounds.width - 40 - 15) / 2, height: 83)
        layout.sectionInset = .init(top: 0, left: 0, bottom: 0, right: 0)
        return layout
    }()

    let disposeBag = DisposeBag()
    var thteeDTouchisThereIs = false
    var selectedIndex = -1
    
    //MARK: viewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        if (self.traitCollection.forceTouchCapability == UIForceTouchCapability.available) {
            thteeDTouchisThereIs = true
            checkCompliteOptions()
        } else {
            checkCompliteOptions2()
        }
        checkStartOprions()
        
       
//        UIControl().sendAction(#selector(NSXPCConnection.suspend), to: UIApplication.shared, for: nil)
    
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.isNavigationBarHidden = true
        if (self.traitCollection.forceTouchCapability == UIForceTouchCapability.available) {
            thteeDTouchisThereIs = true
            checkCompliteOptions()
        } else {
            checkCompliteOptions2()
        }
    }
    
    //MARK: Configure Layout with 3D-Touch
    
    private func checkCompliteOptions(){
        // - Ditizer -
        if Constants.ud.digitizer == 2 {
            testModel1[0].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.digitizer == 1 {
            testModel1[0].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel1[0].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Multitouch -
        if Constants.ud.multiToch == 2 {
            testModel1[1].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.multiToch == 1 {
            testModel1[1].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel1[1].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - 3DTouch -
        if Constants.ud.threeDTouch == 2 {
            testModel1[2].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.threeDTouch == 1 {
            testModel1[2].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel1[2].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Face ID / Touch ID -
        
        if Constants.ud.faceIDTouchID == 2 {
            testModel1[3].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.faceIDTouchID == 1 {
            testModel1[3].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel1[3].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - LCD -
        if Constants.ud.LCD == 2 {
            testModel1[4].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.LCD == 1 {
            testModel1[4].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel1[4].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Proximity Sensor -

        if Constants.ud.proximitySensor == 2 {
            testModel1[5].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.proximitySensor == 1 {
            testModel1[5].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel1[5].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Vibration -
        if Constants.ud.vibration == 2 {
            testModel1[6].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.vibration == 1 {
            testModel1[6].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel1[6].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Flash -
        if Constants.ud.flash == 2 {
            testModel1[7].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.flash == 1 {
            testModel1[7].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel1[7].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - GPS -
        if Constants.ud.GPS == 2 {
            testModel1[8].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.GPS == 1 {
            testModel1[8].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel1[8].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Botton Microphone -
        
        if Constants.ud.bottonMicrophone == 2 {
            testModel1[9].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.bottonMicrophone == 1 {
            testModel1[9].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel1[9].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Front Microphone -
        if Constants.ud.frontMicrophone == 2 {
            testModel1[10].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.frontMicrophone == 1 {
            testModel1[10].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel1[10].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Rear Microphone  -
        if Constants.ud.rearMicrophone == 2 {
            testModel1[11].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.rearMicrophone == 1 {
            testModel1[11].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel1[11].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Speaker Top -
    
        if Constants.ud.speakerTop == 2 {
            testModel1[12].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.speakerTop == 1 {
            testModel1[12].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel1[12].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Speaker Botton -
        if Constants.ud.speakerBotton == 2 {
            testModel1[13].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.speakerBotton == 1 {
            testModel1[13].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel1[13].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        if Constants.ud.powerButtom == 2 {
            testModel1[14].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.powerButtom == 1 {
            testModel1[14].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel1[14].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
    }
    
    //MARK: Configure Layout Without 3D-Touch
    private func checkCompliteOptions2(){
        // - Ditizer -
        if Constants.ud.digitizer == 2 {
            testModel2[0].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.digitizer == 1 {
            testModel2[0].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel2[0].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Multitouch -
        if Constants.ud.multiToch == 2 {
            testModel2[1].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.multiToch == 1 {
            testModel2[1].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel2[1].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        

        // - Face ID / Touch ID -
        
        if Constants.ud.faceIDTouchID == 2 {
            testModel2[2].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.faceIDTouchID == 1 {
            testModel2[2].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel2[2].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - LCD -
        if Constants.ud.LCD == 2 {
            testModel2[3].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.LCD == 1 {
            testModel2[3].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel2[3].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Proximity Sensor -

        if Constants.ud.proximitySensor == 2 {
            testModel2[4].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.proximitySensor == 1 {
            testModel2[4].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel2[4].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Vibration -
        if Constants.ud.vibration == 2 {
            testModel2[5].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.vibration == 1 {
            testModel2[5].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel2[5].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Flash -
        if Constants.ud.flash == 2 {
            testModel2[6].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.flash == 1 {
            testModel2[6].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel2[6].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - GPS -
        if Constants.ud.GPS == 2 {
            testModel2[7].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.GPS == 1 {
            testModel2[7].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel2[7].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Botton Microphone -
        
        if Constants.ud.bottonMicrophone == 2 {
            testModel2[8].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.bottonMicrophone == 1 {
            testModel2[8].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel2[8].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Front Microphone -
        if Constants.ud.frontMicrophone == 2 {
            testModel2[9].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.frontMicrophone == 1 {
            testModel2[9].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel2[9].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Rear Microphone  -
        if Constants.ud.rearMicrophone == 2 {
            testModel2[10].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.rearMicrophone == 1 {
            testModel2[10].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel2[10].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Speaker Top -
    
        if Constants.ud.speakerTop == 2 {
            testModel2[11].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.speakerTop == 1 {
            testModel2[11].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel2[11].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        // - Speaker Botton -
        if Constants.ud.speakerBotton == 2 {
            testModel2[12].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.speakerBotton == 1 {
            testModel2[12].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel2[12].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
        
        if Constants.ud.powerButtom == 2 {
            testModel2[13].check = "complite"
            testCollectionView.reloadData()
        } else if Constants.ud.powerButtom == 1 {
            testModel2[13].check = "notComplite"
            testCollectionView.reloadData()
        } else {
            testModel2[13].check = "notStartInProcess"
            testCollectionView.reloadData()
        }
    }
    
    //MARK: checkStartOprions
    private func checkStartOprions(){
        
        // - Digitizer -
        Constants.ud.digitizer = 0
        
        // - Multitouch -
        Constants.ud.multiToch = 0
        
        // - 3D-Touch -
        Constants.ud.threeDTouch = 0
        
        // - Face ID / Touch ID -
        Constants.ud.faceIDTouchID = 0
        
        // - LCD -
        Constants.ud.LCD = 0
        
        // - Proximity Sensor -
        Constants.ud.proximitySensor = 0
        
        // - Vibration -
        Constants.ud.vibration = 0
        
        // - Flash -
        Constants.ud.flash = 0
        
        // - GPS -
        Constants.ud.GPS = 0
        
        // - Botton Microphone -
        Constants.ud.bottonMicrophone = 0
        
        // - Front Microphone -
        Constants.ud.frontMicrophone = 0
        
        // - Rear Microphone  -
        Constants.ud.rearMicrophone = 0
        
        // - Speaker Top -
        Constants.ud.speakerTop = 0
        
        // - Speaker Botton -
        Constants.ud.speakerBotton = 0
        
        // -  Power Buttom -
        Constants.ud.powerButtom = 0

    }

    //MARK: setup
    private func setup(){
        setupLayout()
        setupButtons()
        configureCollection()
    }
    
    //MARK: setupLayout
    private func setupLayout(){
        navigationController?.isNavigationBarHidden = true
        view.backgroundColor = .white
        view.addSubviews(menuButton, restartButton, testCollectionView)
        menuButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(63)
            make.leading.equalToSuperview().offset(41)
            make.height.equalTo(21)
            make.width.equalTo(34)
        }
        
        restartButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(63)
            make.trailing.equalToSuperview().offset(-41)
            make.size.equalTo(22)
        }
        
        testCollectionView.snp.makeConstraints { make in
            make.top.equalTo(menuButton.snp.bottom).offset(48)
            make.centerX.equalToSuperview()
            make.width.equalTo(UIScreen.main.bounds.width - 40)
            make.bottom.equalToSuperview()
        }
    }
    
    //MARK: configureCollection
    
    private func configureCollection() {
        testCollectionView.setCollectionViewLayout(testLayout, animated: true)
        testCollectionView.dataSource = self
        testCollectionView.delegate = self
        testCollectionView.register(TestCell.self, forCellWithReuseIdentifier: TestCell.nibIdentifier)
    }
    
    //MARK: Setup Buttons
    
    private func setupButtons() {
        menuButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.menuButtonAction()
        }.disposed(by: disposeBag)

        restartButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.removeChild()
            let controller = GeneralViewController()
            let navigationController = UINavigationController(rootViewController: controller)
            UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.rootViewController = navigationController
            UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.makeKeyAndVisible()
        }.disposed(by: disposeBag)
    }
    
    private func menuButtonAction(){
        let vc = MenuViewController()
        vc.modalPresentationStyle = .pageSheet
        present(vc, animated: true)
    }
    
    
    private func checkingVisualOption(){
        if thteeDTouchisThereIs {
            testModel1[selectedIndex].fullImageView = "selected"
            testModel1[selectedIndex].check = "inProcess"
            testModel1[selectedIndex].textColor = "FFFFFF"
        } else {
            testModel2[selectedIndex].fullImageView = "selected"
            testModel2[selectedIndex].check = "inProcess"
            testModel2[selectedIndex].textColor = "FFFFFF"
        }
    }
    

    //MARK: Show Alert
    func showAlertWithTitle( title:String, message:String ) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let actionOk = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(actionOk)
        self.present(alert, animated: true, completion: nil)
    }
    
}

//MARK: extentions Collection
extension GeneralViewController: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    
        selectedIndex = indexPath.item
        testCollectionView.reloadData()
        var test = ""
        if thteeDTouchisThereIs {
            test = testModel1[indexPath.item].nameTestOption!
        } else {
            test = testModel2[indexPath.item].nameTestOption!
        }
        
        switch test {
            
        case "Digitizer":
            Constants.ud.digitizer = 1
            checkingVisualOption()
            if thteeDTouchisThereIs {
                testModel1[selectedIndex].image = "Digitizer"
            } else {
                testModel2[selectedIndex].image = "Digitizer"
            }
            let vc = DrawingWithPixelsViewController()
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true)
            
        case "Multi-Touch":
            Constants.ud.multiToch = 1
            checkingVisualOption()
            if thteeDTouchisThereIs {
                testModel1[selectedIndex].image = "Multi-touch"
            } else {
                testModel2[selectedIndex].image = "Multi-touch"
            }
            
            let vc = MultiTouchViewController()
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true)
            
        case "3D-Touch":
            Constants.ud.threeDTouch = 1
            checkingVisualOption()
            if thteeDTouchisThereIs {
                testModel1[selectedIndex].image = "3D-touch"
            } else {
                print("hhh")
            }
            
            let vc = Test3DTouchViewController()
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true)
            
        case "Face ID/Touch ID":
            Constants.ud.faceIDTouchID = 1
            checkingVisualOption()
            if thteeDTouchisThereIs {
                testModel1[selectedIndex].image = "FaceIDTouchID"
            } else {
                testModel2[selectedIndex].image = "FaceIDTouchID"
            }
            
            let vc = FaceIDTouchIDViewController()
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true)
            
        case "LCD":
            Constants.ud.LCD = 1
            checkingVisualOption()
            if thteeDTouchisThereIs {
                testModel1[selectedIndex].image = "LCDS"
            } else {
                testModel2[selectedIndex].image = "LCDS"
            }
            
            testCollectionView.reloadData()
            let vc = LCDViewController()
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true)
            
        case "Proximity Sensor":
            Constants.ud.proximitySensor = 1
            checkingVisualOption()
            if thteeDTouchisThereIs {
                testModel1[selectedIndex].image = "ProximitySensor"
            } else {
                testModel2[selectedIndex].image = "ProximitySensor"
            }
            
            let vc = ProximitySensorViewController()
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true)
            
        case "Vibration":
            Constants.ud.vibration = 1
            checkingVisualOption()
            if thteeDTouchisThereIs {
                testModel1[selectedIndex].image = "Vibration"
            } else {
                testModel2[selectedIndex].image = "Vibration"
            }
            
            let vc = VibrationViewController()
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true)

        case "Flash":
            Constants.ud.flash = 1
            checkingVisualOption()
            if thteeDTouchisThereIs {
                testModel1[selectedIndex].image = "Flash"
            } else {
                testModel2[selectedIndex].image = "Flash"
            }
            let vc = FlashViewController()
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true)
        case "GPS":
            Constants.ud.GPS = 1
            checkingVisualOption()
            if thteeDTouchisThereIs {
                testModel1[selectedIndex].image = "GPS"
            } else {
                testModel2[selectedIndex].image = "GPS"
            }
            let vc = GPSViewController()
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true)
        case "Bottom Microphone":
            AVAudioSession.sharedInstance().requestRecordPermission { granted in
                if granted {
                    print("Permission granted")
                    Constants.ud.bottonMicrophone = 1
                    self.checkingVisualOption()
                    if self.thteeDTouchisThereIs {
                        self.testModel1[self.selectedIndex].image = "BottonMicrophone"
                    } else {
                        self.testModel2[self.selectedIndex].image = "BottonMicrophone"
                    }
                    
                    DispatchQueue.main.async {
                        let vc = BottomMicrophoneViewController()
                        vc.modalPresentationStyle = .fullScreen
                        self.present(vc, animated: true)
                    }
                } else {
                    print("Permission denied")
                    var alert = TestManager.shared().showPermissionAlert(title: "Microphone not working", message: "Your Microphone not working please turn on your Microphone in the Settings. Go to Settings?")
                    DispatchQueue.main.async {
                        self.present(alert, animated: true, completion: nil)
                    }
                }
            }
           
     
        case "Front Microphone":
            AVAudioSession.sharedInstance().requestRecordPermission { granted in
                if granted {
                    print("Permission granted")
                    Constants.ud.frontMicrophone = 1
                    self.checkingVisualOption()
                    if self.thteeDTouchisThereIs {
                        self.testModel1[self.selectedIndex].image = "FrontMicrophone"
                    } else {
                        self.testModel2[self.selectedIndex].image = "FrontMicrophone"
                    }
                    
                    DispatchQueue.main.async {
                        let vc = FrontMicrophoneViewController()
                        vc.modalPresentationStyle = .fullScreen
                        self.present(vc, animated: true)
                    }
                   
                } else {
                    print("Permission denied")
                    var alert = TestManager.shared().showPermissionAlert(title: "Microphone not working", message: "Your Microphone not working please turn on your Microphone in the Settings. Go to Settings?")
                    DispatchQueue.main.async {
                        self.present(alert, animated: true, completion: nil)
                    }
                }
            }
        case "Rear Microphone":
            AVAudioSession.sharedInstance().requestRecordPermission { granted in
                if granted {
                    print("Permission granted")
                    Constants.ud.rearMicrophone = 1
                    self.checkingVisualOption()
                    if self.thteeDTouchisThereIs {
                        self.testModel1[self.selectedIndex].image = "RearMicrophone"
                    } else {
                        self.testModel2[self.selectedIndex].image = "RearMicrophone"
                    }
                    
                    DispatchQueue.main.async {
                        let vc = RearMicrophoneViewController()
                        vc.modalPresentationStyle = .fullScreen
                        self.present(vc, animated: true)
                    }
                } else {
                    print("Permission denied")
                    var alert = TestManager.shared().showPermissionAlert(title: "Microphone not working", message: "Your Microphone not working please turn on your Microphone in the Settings. Go to Settings?")
                    DispatchQueue.main.async {
                        self.present(alert, animated: true, completion: nil)
                    }
                }
            }
        case "Speaker Top":
            Constants.ud.speakerTop = 1
            checkingVisualOption()
            if thteeDTouchisThereIs {
                testModel1[selectedIndex].image = "SpeakerMic"
            } else {
                testModel2[selectedIndex].image = "SpeakerMic"
            }
            let vc = SpeakerTopViewController()
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true)

        case "Speaker Bottom":
            Constants.ud.speakerBotton = 1
            checkingVisualOption()
            if thteeDTouchisThereIs {
                testModel1[selectedIndex].image = "Speaker"
            } else {
                testModel2[selectedIndex].image = "Speaker"
            }
            let vc = SpeakerBottonViewController()
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true)
        
        case "Power Button":
            Constants.ud.powerButtom = 1
            checkingVisualOption()
            if thteeDTouchisThereIs {
                testModel1[selectedIndex].image = "PowerButton"
            } else {
                testModel2[selectedIndex].image = "PowerButton"
            }
            let vc = PowerButtomViewController()
            vc.modalPresentationStyle = .fullScreen
            present(vc, animated: true)
        default:
            break
        }
        
    }
     
}

extension GeneralViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if thteeDTouchisThereIs {
            return testModel1.count
        } else {
            return testModel2.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: TestCell.nibIdentifier, for: indexPath) as! TestCell
        if thteeDTouchisThereIs {
            let testModel = testModel1[indexPath.item]
            cell.testModel = testModel
            return cell
        } else {
            let testModel = testModel2[indexPath.item]
            cell.testModel = testModel
            return cell
        }
        
       
    }
    
    
}

extension UIViewController {
        
  func removeChild() {
    self.children.forEach {
      $0.willMove(toParent: nil)
      $0.view.removeFromSuperview()
      $0.removeFromParent()
    }
  }
}

