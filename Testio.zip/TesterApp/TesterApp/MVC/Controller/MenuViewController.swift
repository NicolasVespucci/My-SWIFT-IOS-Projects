import UIKit
import RxSwift
import MessageUI
import StoreKit

class MenuViewController: UIViewController {
    
    public var settingModelsTwo = [MenuModel(image: "privacy", title: NSLocalizedString("Privacy Policy", comment: "")),
                                   MenuModel(image: "terms", title: NSLocalizedString("Terms of Use", comment: "")),
                                   MenuModel(image: "contact", title: NSLocalizedString("Contact Support", comment: "")),
                                   MenuModel(image: "share", title: NSLocalizedString("Share App", comment: "")), MenuModel(image: "rateUs", title: NSLocalizedString("Rate Us", comment: ""))
    ]
    
    private var topLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 25, weight: .regular)
        label.text = "Menu"
        label.textAlignment = .center
        label.textColor = "242527".hexColor
        return label
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("backButton".image, for: .normal)
        return button
    }()
    
    private lazy var tableViewTwo: UITableView = {
        let table = UITableView()
        table.showsVerticalScrollIndicator = false
        table.rowHeight = 48
        table.backgroundColor = .clear
        table.layer.cornerRadius = 12
        table.separatorStyle = .singleLine
        table.isScrollEnabled = false
        return table
    }()

    let disposeBag = DisposeBag()
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
    }
    
    private func setup(){
        setupLayout()
        setupButtons()
        configureTableViewTwo()
    }
    
    private func setupLayout(){
        view.backgroundColor = .white
        view.addSubviews(topLabel, backButton, tableViewTwo)
        
        topLabel.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(50)
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.height.equalTo(30)
        }
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(40)
            make.trailing.equalToSuperview().offset(-40)
            make.size.equalTo(40)
        }
        
        tableViewTwo.snp.makeConstraints { make in
            make.top.equalTo(topLabel.snp.bottom).offset(50)
            make.leading.equalToSuperview().offset(30)
            make.trailing.equalToSuperview().offset(-30)
            make.height.equalTo(240)
        }
    }
    
    private func configureTableViewTwo() {
        tableViewTwo.delegate = self
        tableViewTwo.dataSource = self
        tableViewTwo.register(TwoSettingsCell.self, forCellReuseIdentifier: TwoSettingsCell.nibIdentifier)
    }
    
    private func setupButtons() {
        backButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.dismiss(animated: true)
        }.disposed(by: disposeBag)
    }
    
    func pushPoliciesVC(_ policiesType: Policies) {
        let termsVC = PoliciesVC()
        termsVC.policiesType = policiesType
        termsVC.modalPresentationStyle = .pageSheet
        present(termsVC, animated: true)
    }
    
    private func contact() {
        if MFMailComposeViewController.canSendMail() {
            let toRecipients = ["testio.app.suppor@gmail.com"]
            let subject = "Feedback"
            let mail = configuredMailComposeViewController(recipients: toRecipients, subject: subject, body: "", isHtml: true, images: nil)
            presentMailComposeViewController(mailComposeViewController: mail)
        } else {
            print("You don't have email in Mail iOS App")
         }
    }
    
//    private func rateUs(){
//        if #available(iOS 14.0, *) {
//            if let scene = UIApplication.shared.currentScene {
//                SKStoreReviewController.requestReview(in: scene)
//            }
//        } else {
//            SKStoreReviewController.requestReview()
//        }
//    }
    
    
    func rateUs() {
        if #available(iOS 10.3, *) {
            SKStoreReviewController.requestReview()

        } else if let url = URL(string: "itms-apps://itunes.apple.com/app/" + Constants.app.appid) {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)

            } else {
                UIApplication.shared.openURL(url)
            }
        }
    }
    
}

extension MenuViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

            switch settingModelsTwo[indexPath.row].title {
            case NSLocalizedString("Privacy Policy", comment: ""):
                pushPoliciesVC(.privacy)
            case NSLocalizedString("Terms of Use", comment: ""):
                pushPoliciesVC(.terms)
            case NSLocalizedString("Contact Support", comment: ""):
                contact()
            case NSLocalizedString("Share App", comment: ""):
                share()
            case NSLocalizedString("Rate Us", comment: ""):
                rateUs()
            default: print("Unknown")
            }
    }
}


extension MenuViewController: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return settingModelsTwo.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
            let twoCell = tableViewTwo.dequeueReusableCell(withIdentifier: TwoSettingsCell.nibIdentifier, for:  indexPath) as! TwoSettingsCell
            let settingModelTwo = settingModelsTwo[indexPath.row]
            twoCell.settingModelTwo = settingModelTwo
            return twoCell
        
    }
    
    func share() {
        UIGraphicsBeginImageContext(view.frame.size)
        view.layer.render(in: UIGraphicsGetCurrentContext()!)

        let textToShare = "Check out my app"

        if let myWebsite = URL(string: "http://itunes.apple.com/app/\(Constants.app.appid)") {//Enter link to your app here
            let objectsToShare = [textToShare, myWebsite] as [Any]
            let activityVC = UIActivityViewController(activityItems: objectsToShare, applicationActivities: nil)
            activityVC.excludedActivityTypes = [UIActivity.ActivityType.airDrop, UIActivity.ActivityType.addToReadingList]
            activityVC.popoverPresentationController?.sourceView = self.view
            self.present(activityVC, animated: true, completion: nil)
        }
    }
}
