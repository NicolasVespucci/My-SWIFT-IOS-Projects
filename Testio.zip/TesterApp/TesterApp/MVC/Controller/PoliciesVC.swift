import UIKit
import WebKit
import SnapKit
import IHProgressHUD
import RxSwift

enum Policies {
    case terms, privacy
}

class PoliciesVC: UIViewController {
    
    // MARK: PROPERTIES
    private lazy var webView: WKWebView = {
        let view = WKWebView()
        return view
    }()
    
    private var backButton: UIButton = {
        let button = UIButton()
        button.setImage("backButton".image, for: .normal)
        return button
    }()
    
    var policiesType: Policies = .terms
    
    let disposeBag = DisposeBag()
    // MARK: LIFE CYCLE
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        view.addSubviews(backButton, webView)
        
        backButton.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(10)
            make.trailing.equalToSuperview().offset(-10)
            make.size.equalTo(40)
        }
        
        webView.snp.makeConstraints {
            $0.top.equalTo(backButton.snp.bottom).offset(10)
            $0.leading.trailing.bottom.equalToSuperview()
        }
        
        
        
        setupButtons()
        
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        let url: String
        switch policiesType {
        case .terms:
            url = "https://sites.google.com/view/testioapp/terms-of-use"
        case .privacy:
            url = "https://sites.google.com/view/testioapp/privacy-policy"
        }
        loadRequest(urlString: url)
       
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        IHProgressHUD.dismiss()
        navigationController?.isNavigationBarHidden = true
    }
    
    private func setupButtons() {
        backButton.rx.tap.bind { [weak self] in
            guard let self = self else { return }
            self.dismiss(animated: true)
        }.disposed(by: disposeBag)
    }
    
    private func loadRequest(urlString: String) {
        
        IHProgressHUD.show()
        let url = URL(string: urlString)
        let urlRequest = URLRequest(url: url!)
        webView.navigationDelegate = self
        webView.load(urlRequest)
    }
}

// MARK: UIWebViewDelegate
extension PoliciesVC: WKNavigationDelegate {
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        IHProgressHUD.dismiss()
    }
    
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        IHProgressHUD.dismiss()
    }
    
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        IHProgressHUD.dismiss()
    }
}

