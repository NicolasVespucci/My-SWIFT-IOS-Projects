import Foundation

struct MenuModel {
    var image: String?
    var title: String?
}
