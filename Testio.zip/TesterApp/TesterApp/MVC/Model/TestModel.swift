import Foundation

struct TestModel {
    var image: String?
    var check: String?
    var fullImageView: String?
    var nameTestOption: String?
    var textColor: String?
}
