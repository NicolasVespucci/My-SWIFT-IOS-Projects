import UIKit

class TestCell: UICollectionViewCell {
    
    var testModel: TestModel? {
        didSet{ configureTestModel() }
    }
    
    private lazy var cellImageView: UIImageView = {
        let imageView = UIImageView(image: "notSelected".image)
        imageView.contentMode = .scaleToFill
        return imageView
    }()
    
    private var testOptionImageView: UIImageView = {
        let imageView = UIImageView()
        return imageView
    }()
    
    private var checkImageView: UIImageView = {
        let imageView = UIImageView()
        return imageView
    }()
    
    private lazy var nameTestOptionLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 15, weight: .regular)
        label.textColor = "5D9EFD".hexColor
        label.adjustsFontSizeToFitWidth = true
        label.textAlignment = .left
        label.minimumScaleFactor = 0.5
        label.numberOfLines = 0
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //MARK: Not Selected Layout
     func setupLayout() {
         
         cellImageView.subviews.forEach({
             $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
             $0.removeBorders()
             $0.removeFromSuperview()
         })
         
         subviews.forEach({
             $0.layer.sublayers?.forEach({ $0.removeFromSuperlayer() })
             $0.removeBorders()
             $0.removeFromSuperview()
         })
         
        addSubview(cellImageView)
        cellImageView.addSubviews(testOptionImageView, checkImageView, nameTestOptionLabel)
        
        cellImageView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        testOptionImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(7)
            make.leading.equalToSuperview().offset(7)
            make.size.equalTo(50)
        }
        
        checkImageView.snp.makeConstraints { make in
            make.top.equalToSuperview().offset(11)
            make.trailing.equalToSuperview().offset(-12)
            make.size.equalTo(20)
        }
        
        nameTestOptionLabel.snp.makeConstraints { make in
            make.bottom.equalToSuperview().offset(-8)
            make.height.equalTo(24)
            make.leading.equalToSuperview().offset(14)
            make.trailing.equalToSuperview().offset(-12)
        }
        
        cellImageView.image = "notSelected".image
        checkImageView.image = "notSelectedCheck".image
    }
    
    private func configureTestModel(){
        guard let testModel = testModel else { return }
        nameTestOptionLabel.text = testModel.nameTestOption
        testOptionImageView.image = testModel.image?.image
        cellImageView.image = testModel.fullImageView?.image
        checkImageView.image = testModel.check?.image
        nameTestOptionLabel.textColor = testModel.textColor?.hexColor
    }
}
