import UIKit

class TwoSettingsCell: UITableViewCell {
    
    var settingModelTwo: MenuModel? {
        didSet { configurePayModelTwo() }
    }
    
    private lazy var mainView: UIView = {
        let view = UIView()
        view.backgroundColor = .clear
        return view
    }()
    
    private lazy var settingsImageView: UIImageView = {
        let imageView = UIImageView(image: "".image)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private lazy var nameCellLabel: UILabel = {
        let label = UILabel()
        label.font = .systemFont(ofSize: 16)
        label.adjustsFontSizeToFitWidth = true
        label.textColor = "404147".hexColor
        return label
    }()
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        selectionStyle = .none
        configureLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func configureLayout() {
        addSubview(mainView)
        mainView.addSubviews(settingsImageView, nameCellLabel)
        
        mainView.snp.makeConstraints { make in
            make.top.equalToSuperview()
            make.leading.equalToSuperview()
            make.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        
        settingsImageView.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalToSuperview().offset(16)
            make.size.equalTo(24)
        }
        
        nameCellLabel.snp.makeConstraints { make in
            make.centerY.equalToSuperview()
            make.leading.equalTo(settingsImageView.snp.trailing).offset(18)
            make.height.equalTo(24)
            make.width.equalTo(200)
        }
    }
    
    private func configurePayModelTwo() {
        guard let settingModelTwo = settingModelTwo else { return }
        settingsImageView.image = settingModelTwo.image?.image
        nameCellLabel.text = settingModelTwo.title
    }
}

