import Foundation
import UIKit
import RxSwift
import CoreLocation
import AVFoundation
import AVKit
import AVFAudio
import MediaPlayer
import CoreAudio



class TestManager {
    private static let sharedTestManager = TestManager()
    
    static func shared() -> TestManager {
      return sharedTestManager
    }
    
    
    //MARK: GPS
    
     func checkGPS() -> Bool {
          var currentGPSValue = CLLocationManager.locationServicesEnabled()
         if currentGPSValue {
             AlertManager.shared().testGPS()
         }
         return currentGPSValue
      }

    //MARK: Alert Settings
    
    func showPermissionAlert(title: String, message: String) -> UIAlertController {
            let alertController = UIAlertController (title: title, message: message, preferredStyle: .alert)
            
            let settingsAction = UIAlertAction(title: "Settings", style: .default) { (_) -> Void in
                
                guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
                    return
                }
                
                if UIApplication.shared.canOpenURL(settingsUrl) {
                    UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                        print("Settings opened: \(success)") // Prints true
                    })
                }
            }
            alertController.addAction(settingsAction)
            let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil)
            alertController.addAction(cancelAction)
            
        return alertController
    }
    
    //MARK: ProximitySensor
    var currentWorkingProximitySensor = false
    func activateProximitySensor() {
            let device = UIDevice.current
            device.isProximityMonitoringEnabled = true
            if device.isProximityMonitoringEnabled {
                NotificationCenter.default.addObserver(self, selector: #selector(proximityChanged(notification:)), name: NSNotification.Name(rawValue: "UIDeviceProximityStateDidChangeNotification"), object: device)
            }
        }

        @objc func proximityChanged(notification: NSNotification) -> Bool {
            if let device = notification.object as? UIDevice {
                print("\(device) detected!")
                currentWorkingProximitySensor = true
            }
            return currentWorkingProximitySensor
        }
    
  
    //MARK: Speaker Top and Bottom

     let audioSession = AVAudioSession.sharedInstance()
    
     func configureAudioSessionCategory() {
          print("Configuring audio session")
          do {
            try audioSession.setCategory(AVAudioSession.Category.playAndRecord, mode: AVAudioSession.Mode.voiceChat)
            try audioSession.overrideOutputAudioPort(AVAudioSession.PortOverride.none)
            print("AVAudio Session out options: ", audioSession.currentRoute)
            print("Successfully configured audio session.")
          } catch (let error) {
            print("Error while configuring audio session: \(error)")
          }
        }

        func configureAudioSessionToSpeaker(){
            do {
                try audioSession.overrideOutputAudioPort(AVAudioSession.PortOverride.speaker)
                try audioSession.setActive(true)
                print("Successfully configured audio session (SPEAKER-Bottom).", "\nCurrent audio route: ",audioSession.currentRoute.outputs)
            } catch let error as NSError {
                print("#configureAudioSessionToSpeaker Error \(error.localizedDescription)")
            }
        }

        func configureAudioSessionToEarSpeaker(){

            let audioSession:AVAudioSession = AVAudioSession.sharedInstance()
            do { ///Audio Session: Set on Speaker
                try audioSession.overrideOutputAudioPort(AVAudioSession.PortOverride.none)
                try audioSession.setActive(true)

                print("Successfully configured audio session (EAR-Speaker).", "\nCurrent audio route: ",audioSession.currentRoute.outputs)
            }
            catch{
                print("#configureAudioSessionToEarSpeaker Error \(error.localizedDescription)")
            }
        }
    
    var player: AVAudioPlayer?
 
    func playSound(soundName: String) { //
               let url = Bundle.main.url(forResource: soundName, withExtension: "wav")
               player = try! AVAudioPlayer(contentsOf: url!)
              // player?.numberOfLoops =  -1 // set your count here
               player?.play()
           }
    
    //MARK: - MIC -
    
    var recorder: AVAudioRecorder!
    var levelTimer: Timer?
    let successLevel: Float = 10.0
        
    //MARK: Bottom Mic
    
    //MARK: Front Mic
    //MARK: Back Mic
    
    //MARK:
    
    func setupMicro(currentMicrophone: String) {
        let documents = URL(fileURLWithPath: NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)[0])
        let url = documents.appendingPathComponent("record.caf")
       
        let recordSettings: [String: Any] = [
            AVFormatIDKey:              kAudioFormatAppleIMA4,
            AVSampleRateKey:            44100.0,
            AVNumberOfChannelsKey:      2,
            AVEncoderBitRateKey:        12800,
            AVLinearPCMBitDepthKey:     16,
            AVEncoderAudioQualityKey:   AVAudioQuality.max.rawValue
        ]
        
        //Front mic
        guard let inputs = AVAudioSession.sharedInstance().availableInputs else { return }
        var preferredPort = inputs[0]
        var front: AVAudioSessionDataSourceDescription?
        
        if let dataSources = preferredPort.dataSources{
            for source in dataSources {
                if source.dataSourceName == currentMicrophone {
                    front = source
                }
            }
        }
        
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(AVAudioSession.Category.record)
            try audioSession.setActive(true)
            try recorder = AVAudioRecorder(url:url, settings: recordSettings)
            try preferredPort.setPreferredDataSource(front)
        } catch {
            return
        }
        
        recorder.prepareToRecord()
        recorder.isMeteringEnabled = true
        recorder.record()
        
        levelTimer = Timer.scheduledTimer(timeInterval: 0.01, target: self, selector: #selector(levelTimerCallback), userInfo: nil, repeats: true)
    }
    
    @objc func levelTimerCallback() {
        var level = (recorder?.averagePower(forChannel: 0) ?? 200.0) * -1
        let isLoud = level < successLevel
        if level == 120.0 {
            print("ЦЭвильно")
            AlertManager.shared().testSuccessfulMicrophone()
            levelTimer?.invalidate()
            levelTimer = nil
            recorder.stop()
            if Constants.ud.thisIsTheBottonMic == true {
                Constants.ud.bottonMicrophone = 2
                Constants.ud.thisIsTheBottonMic = false
            } else if Constants.ud.thisIsTheFrontMic == true {
                Constants.ud.frontMicrophone = 2
                Constants.ud.thisIsTheFrontMic = false
            } else if Constants.ud.thisIsTheRaerMic == true {
                Constants.ud.rearMicrophone = 2
                Constants.ud.thisIsTheRaerMic = false
            }
        }
        print(level)
        print(isLoud)
        if isLoud == true {
            print("ЦЭвильно")
            AlertManager.shared().testSuccessfulMicrophone()
            self.player?.stop()
            levelTimer?.invalidate()
            levelTimer = nil
            recorder.stop()
            player = nil
            if Constants.ud.thisIsTheBottonMic == true {
                Constants.ud.bottonMicrophone = 2
                Constants.ud.thisIsTheBottonMic = false
            } else if Constants.ud.thisIsTheFrontMic == true {
                Constants.ud.frontMicrophone = 2
                Constants.ud.thisIsTheFrontMic = false
            } else if Constants.ud.thisIsTheRaerMic == true {
                Constants.ud.rearMicrophone = 2
                Constants.ud.thisIsTheRaerMic = false
            }
        } else {
            recorder.updateMeters()
        }
        
        if Constants.ud.micWorking == false {
            self.player?.stop()
            levelTimer?.invalidate()
            levelTimer = nil
            recorder.stop()
            player = nil
        }
        
    }
    
    func stopedAudioSession(){
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            let audioSession:AVAudioSession = AVAudioSession.sharedInstance()
            do {
                try audioSession.setActive(false)
            }
            catch{
                print("#configureAudioSessionToEarSpeaker Error \(error.localizedDescription)")
            }
        }
    }
    
}



extension MPVolumeView {
  static func setVolume(_ volume: Float) {
    let volumeView = MPVolumeView()
    let slider = volumeView.subviews.first(where: { $0 is UISlider }) as? UISlider

    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.01) {
      slider?.value = volume
    }
  }
}
